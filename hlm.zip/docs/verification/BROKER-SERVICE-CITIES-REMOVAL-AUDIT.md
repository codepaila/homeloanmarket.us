# Broker serviceCities Search Removal Audit

## A. serviceCities usages found

`serviceCities` is used extensively as broker profile/business data across the codebase: registration/onboarding (`BrokerSetupWizard`, `broker-registration`, `lib/broker-registration.ts`), profile editing (`CompanyProfile`, `EditProfile`), subscription limits (`lib/broker-policy.ts`), dashboard/display cards, seed fixtures, import mapping, and owner DTOs.

Only two usages were part of the search/filter path, both in `app/api/brokers/route.ts`:

- `if (city) where.serviceCities = { has: city }`
- the `radius === 0` block: `if (!city && (locationCity || verifiedLocation?.city)) where.serviceCities = { has: locationCity || verifiedLocation?.city }`

## B. serviceCities usages removed from search

- `app/api/brokers/route.ts`: removed both `where.serviceCities` assignments, and removed the now-unused `city` and `locationCity` query-parameter reads.

## C. serviceCities usages intentionally preserved

All profile/registration/business usages remain unchanged (registration, onboarding, profile editing, subscription limit, dashboard, cards, import mapping, seed, owner DTO).

## D. Final broker geographic search flow

`$geoNear` against `Broker.location` (GeoJSON `[longitude, latitude]`, `spherical: true`, `maxDistance = radiusMiles * 1609.344`) → public eligibility → optional text search → `$facet` pagination. `serviceCities` plays no role.

## E. Why dbCount was previously 0

Imported/admin-created brokers default to `verificationStatus = UNVERIFIED` and `isVisible = false`. Public listing correctly requires `isVisible=true` and `VERIFIED`, so anonymous users see zero brokers until an admin publishes and verifies them. Diagnostic on a disposable DB confirmed: 2 brokers, `visible=0`, `verified=0`, `eligible=0`, `located=2`. This is correct data-state behavior, not a code defect; eligibility was not weakened.

## F. Public eligibility verification

Anonymous listing still requires `isVisible=true`, `verificationStatus=VERIFIED`, `brokerStatus != SUSPENDED`, and (unowned `userId:null` or active owner). Admin behavior unchanged.

## G. Radius verification

Radius boundaries remain monotonic (1→1, 3→1, 5→2, 10→2, 25→3, 100→4 with a 120-mile broker excluded).

## H. GeoJSON/location verification

Brokers persist `location` as `{ type: 'Point', coordinates: [longitude, latitude] }`; `$geoNear` uses the same order and `spherical: true`.

## I. 2dsphere index verification

`brokers_location_2dsphere` is used (not recreated) and the missing-index path returns an actionable error.

## J/K. Tests and validation

- `tests/broker-service-cities-search.test.ts`: 6/6 passed.
- Radius unit/contract tests: 12/12 passed.
- Radius integration tests: 3/3 passed (disposable Mongo).
- TypeScript: passed; Build: passed; Prisma validate/generate: passed; changed-file ESLint: passed; `git diff --check`: passed.

## L. Exact files changed

- `app/api/brokers/route.ts`
- `tests/broker-service-cities-search.test.ts`
- `docs/verification/BROKER-SERVICE-CITIES-REMOVAL-AUDIT.md`

## M. Remaining issue

Brokers imported/created with the default UNVERIFIED/hidden state must be published and verified by an admin before they appear publicly or in radius results. Browser verification was not performed.
