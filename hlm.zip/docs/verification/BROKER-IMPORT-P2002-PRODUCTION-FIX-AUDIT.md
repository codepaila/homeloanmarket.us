# Broker Import P2002 Production Fix Audit

## Status

**CONDITIONAL PASS**

The parser, preview, confirmation modes, shared normalization, ownership-index preflight, and race-safe persistence path are fixed and verified locally. The named Houston workbook and production database/indexes were not available in this environment, so a production import is not claimed.

## Root Cause

The current Prisma schema defines `Broker.userId` as nullable and unique. Admin-created broker imports intentionally write `userId: null`. MongoDB requires the corresponding ownership index to be partial for non-null ObjectIds so multiple unowned brokers are valid. The repository includes `scripts/ensure-ownership-index.ts` for this exact remediation.

The reported pattern of one successful row followed by 61 P2002 failures is consistent with a stale non-partial unique `userId` index: the first null owner is accepted and subsequent null owners conflict. Preview previously checked only NMLS, email, and phone, so it could report `NEW` without checking the actual ownership-index state.

`Broker.nmls` is indexed but not unique in the current Prisma schema. `Broker.profileSlug` is unique and is generated from the same company/name slug helper used by manual admin creation. `Broker.email`, `Broker.phone`, `registrationNumber`, and `panNumber` are not schema-unique Broker fields, but are supported business identities and are now normalized and checked for existing/import-file conflicts.

The preview failure `Unknown tagged value` was a separate transport defect in the ownership-index preflight. Prisma Client 6.19.3 cannot deserialize the raw Mongo `listIndexes` response when it contains `partialFilterExpression.userId.$type = "objectId"`; `$type` is interpreted as Prisma's tagged-value protocol marker. Ownership validation was retained and now uses a Mongo `$indexStats` aggregation projection that returns only scalar index name/key/uniqueness/partial-type metadata.

## Changes

- `lib/admin/broker-import.ts`
  - Canonical email normalization removes quotes, Markdown `mailto:` wrappers, `mailto:` prefixes, whitespace, and lowercases comparison values.
  - NMLS normalization handles strings, numeric spreadsheet values, and scientific notation.
  - Shared canonical identity includes NMLS, email, phone, registration number, PAN, and the exact admin slug base.
  - Missing optional values remain `null`, never empty-string unique sentinels.
  - In-file duplicate detection includes optional registration/PAN identities.
- `lib/admin/broker-data.ts`
  - Preview compares against stored Broker identity values using canonical normalization, including punctuation-independent phone matching.
  - Preview inspects the actual Mongo `brokers` indexes and rejects a stale non-partial unique `userId` index with an actionable reconciliation message.
  - Preview avoids returning raw Mongo partial-filter documents through Prisma's tagged-value deserializer.
  - Create uses the same slug identity and collision logic as preview/manual admin creation.
  - `CREATE_ONLY` skips known existing records and reports post-preview conflicts safely.
  - `UPDATE_ONLY` reports `IMPORT_NOT_FOUND` instead of creating.
  - `UPSERT` updates identity matches and handles race-created conflicts.
  - P2002 diagnostics identify ownership index, slug, NMLS, email, or phone where Prisma exposes the target; otherwise they report a safe post-preview duplicate message.
  - Existing ownership, claims, subscriptions, verification, visibility, and status fields are not overwritten by update imports.
- `app/admin/brokers/import/page.tsx`
  - Preview now displays phone, email, and the canonical office address in addition to name and NMLS.
- `tests/broker-import.test.ts`
  - Added canonical email, identity, and null-optional-field coverage.
- `tests/broker-import-p2002.test.ts`
  - Added ownership-index, mode, and disposable Mongo lifecycle coverage.

## Index / Production State

Production access was not available. The required controlled operation for a stale ownership index is:

```bash
yarn db:ensure-ownership-index
```

Run it with the intentionally selected production `DATABASE_URL` after reviewing its duplicate-owner check and output. It creates/verifies `brokers_userId_non_null_unique` with a partial filter for ObjectIds and removes the old non-partial unique ownership index. It does not reset Broker data or drop unrelated indexes.

The import preview now blocks before claiming rows are new if the stale index is still present.

## Validation

- `yarn prisma validate`: passed.
- `npx prisma generate`: passed.
- `npx tsc --noEmit`: passed.
- Changed import-file ESLint: passed.
- Import unit/UI/P2002 tests: passed, 13/13 with the disposable integration database enabled.
- Disposable Mongo import lifecycle: passed, two-run CREATE_ONLY verification.
- Controlled stale-index reproduction: first unowned row created, second row produced P2002; the final error identified the ownership index and preview blocked before reporting rows as new.
- Relevant broker/claim/advertisement/subscription regressions: passed, 73 passed and 20 environment-dependent tests skipped.
- `yarn build`: passed.
- `git diff --check`: passed.
- Houston workbook `Homeloanmarket Broker list - Houston - 2026-08-06.xlsx`: not available in the workspace; no fabricated 62-row success is claimed.
- Production controlled preview/import: not run.

## Remaining Limitations

- The exact production Mongo index metadata and the real Houston workbook still require operator-side verification.
- Before a production import, reconcile the ownership index if preview reports the stale-index error, then run preview again. Do not delete the successful LaShaun Fontenot record blindly; inspect by NMLS `1029135` first.
