# Imported Broker, Google Location, Radius, Listing, and Local Ads Integration Audit

Date: 2026-08-11
Scope: Existing Admin Broker import/export integration only.

## 1. Import Path

Current source path:

```text
Admin /admin/brokers/import
→ multipart CSV/XLS/XLSX upload
→ parseBrokerWorkbook
→ header alias detection / editable mapping
→ row validation and in-file duplicate detection
→ annotateBrokerImportRows
→ CREATE_ONLY / UPDATE_ONLY / UPSERT
→ existing Broker record or new ADMIN_CREATED Broker
→ existing Broker listing/radius/claim paths
```

Import routes:

- `POST /api/admin/brokers/import/preview`;
- `POST /api/admin/brokers/import`; and
- `GET /api/admin/brokers/export?format=csv|xlsx`.

Imports do not create Users, claims, ownership, verification, featured state, or paid subscriptions. New imports use the existing unowned `ADMIN_CREATED` Broker path with active FREE subscription and unpublished/unverified defaults.

## 2. Broker Field Compatibility

| Imported field | Broker field | Listing use | Location use | Result |
|---|---|---|---|---|
| Name | `displayName` | Card/profile name | None | Supported |
| NMLS | `nmls` | Admin/search identity | None | Supported, indexed in schema |
| Zip code | `pinCode` | Text/ZIP filter | Backfill input | Supported |
| Phone | `phone` | Entitlement-gated contact | None | Supported |
| Address | `officeAddress` | Text search/profile | Backfill input | Supported |
| Company Name | `companyName` | Card/search/profile | None | Supported |
| Email | `email` | Entitlement-gated contact | None | Supported |
| State | `state` | Text/state filter | Backfill input | Supported |
| City/default city | `city` | Listing/search | Backfill input | Supported; no address inference |
| Description | `description` | Text/card/profile | None | Optional source/default |
| Website | `website` | Profile/contact policy | None | Optional canonical field |
| Experience | `experienceYears` | Filter/sort/card | None | Optional |
| Specializations | `specializations` | Filter/card | None | Optional |
| Service cities | `serviceCities` | Location filter/card | None | Defaults to city if absent |
| Languages | `languages` | Filter/card | None | Defaults to English if absent |
| Registration/license | `registrationNumber` | Admin/profile | None | Optional |
| PAN/tax number | `panNumber` | Admin/profile | None | Optional |

`officeAddress` remains the canonical internal field. The import/export display label may be `Address`; no rename was made.

## 3. Google Location

Imported rows do not automatically call Google during import. Address, city, state, and ZIP are stored faithfully. Coordinates remain nullable until the existing explicit backfill/location process resolves them through:

- `lib/location/google-place.ts`;
- `/api/location/autocomplete`;
- `/api/location/resolve`; and
- `/api/location/geocode`.

The server-only Google key and signed search-location token architecture are unchanged. No second imported-Broker location system exists.

## 4. Radius

The existing listing flow remains:

```text
main location search
→ signed location token
→ Radius Search toggle
→ existing latitude/longitude/radius/locationToken query
→ GET /api/brokers
→ lib/location/broker-geo.ts
→ Mongo $geoNear
```

The geospatial layer applies the same public visibility, verification, active-owner, suspension, filtering, sorting, and pagination rules to imported and manually created Brokers.

Radius `0` retains the documented no-radius-restriction behavior. Positive radius values use the existing miles-to-meters conversion and 2dsphere query.

## 5. Imported Broker Eligibility

### No coordinates

An imported Broker with address fields but no canonical `location` is excluded from positive-radius `$geoNear` results. It remains compatible with ordinary non-radius admin/public listing behavior once visibility and verification rules allow publication.

### Valid coordinates

Once explicit backfill or an admin location workflow writes a valid GeoJSON Point, the imported Broker is queried through the same `Broker` collection, same `$geoNear` pipeline, same public filters, same pagination, and same Broker card DTO. There is no `creationSource` branch in the radius query.

### Outside radius

The same `$geoNear maxDistance` excludes the Broker.

### Current database state

| Metric | Result |
|---|---:|
| Brokers | 8 |
| Brokers with NMLS | 0 |
| Brokers with coordinates | 0 |
| Brokers without coordinates | 8 |
| Imported rows written | 0 |

The source workbook was not present in the workspace and no production import was executed.

## 6. Local Ads

`BROKER_LISTING_LOCAL` remains the only local public-ad placement. It uses the same signed search-location token as broker radius search. The server validates the token before local-ad eligibility evaluation.

Local ads additionally require:

- target-radius match;
- active Company;
- active CompanySubscription;
- active schedule/device/lifecycle; and
- square creative.

Local ads are not attached to imported Brokers and do not use Broker ownership or NMLS matching.

Multiple eligible square ads render in the existing public card/tracking architecture as a responsive grid.

## 7. Claim/Ownership

Imported Brokers are `ADMIN_CREATED` and unowned. Import does not create a User or Claim. Existing claim completion can attach ownership to the same imported Broker, preserving Broker identity, profile, subscription, claims, and history.

No second Broker is created by the import path.

## 8. Registration Compatibility

The import path does not enter public email/Google registration, BrokerRegistration, plan selection, BrokerRegistrationSubscription, or onboarding. It remains the separate admin-created profile path.

Existing public registration, Google intent, subscription gating, and onboarding code paths were not changed by import integration.

## 9. Security

Verified:

- import preview/import/export require ADMIN;
- ownership/status/verification/subscription are server-controlled;
- imported Brokers do not receive random owners;
- location backfill does not fabricate coordinates;
- radius/local-ad coordinates require existing signed location-token validation;
- claim authorization remains existing claim authorization; and
- export excludes secrets, password hashes, tokens, sessions, and OAuth data.

## 10. Database

Verified reachable database indexes:

- Broker partial ownership index;
- Broker `2dsphere` location index;
- User partial phone index;
- registration indexes;
- company subscription indexes; and
- advertisement-target indexes.

The schema contains `Broker.nmls` with an index, but the reachable database did not show the NMLS index because schema synchronization for that latest addition has not been applied. This is a migration/deployment requirement, not a Broker model redesign.

## 11. Validation

Passed in the focused validation run:

- broker import parser tests;
- CSV BOM/quoted-address/ZIP normalization;
- 62-row equivalent XLSX fixture;
- XLS parsing;
- duplicate NMLS;
- export safety/formula protection;
- broker registration/security;
- claim compatibility;
- location/radius contracts;
- local-ad placement;
- company contracts; and
- C1-H7 focused security tests.

Latest focused run: **87 passed, 0 failed**.

Also passed:

- `yarn prisma validate`;
- `yarn prisma generate`;
- `npx tsc --noEmit`;
- `yarn build`; and
- `git diff --check`.

Targeted ESLint for the import/export scope passes. Full repository lint retains unrelated existing failures.

Google endpoint live diagnostics were previously verified with HTTP 200 autocomplete, place resolution, and ZIP geocoding. No Google key was printed or exposed.

Browser automation and populated radius results were unavailable.

## 12. Remaining Limitations

- The referenced Houston workbook was not present, so direct 62-row source-file validation was unavailable.
- No imported Broker exists in the reachable database.
- All reachable Brokers lack coordinates, so populated imported-Broker radius behavior is not live-certified.
- The NMLS index requires controlled schema synchronization.
- Coordinate backfill remains an explicit required operation.
- Browser, live Stripe, Redis, email, and populated Mongo radius E2E were unavailable.
- Import history is operation-result based, not persisted as a separate history model.

## 13. Production Recommendation

**NO-GO** for claiming complete imported-Broker radius production readiness.

The import/listing architecture is integrated and imported Brokers use the normal Broker ecosystem. However:

> Imported Brokers require valid location coordinates before they can participate in radius-based search.

Production certification requires the real workbook, controlled staging import, NMLS index synchronization, validated coordinate backfill, and populated inside/outside/boundary radius tests.
