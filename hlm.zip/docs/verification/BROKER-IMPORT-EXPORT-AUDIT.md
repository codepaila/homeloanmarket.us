# Broker Import/Export Audit

Date: 2026-08-11
Scope: Existing Broker compatibility and Admin CSV/XLS/XLSX import/export.

## Final Integration Update

`Broker.city` and `Broker.state` are now nullable while retaining the existing fields and indexes. Import validation requires `displayName`, NMLS, phone, office address, and the existing required ZIP field, but no longer requires city or state. Explicit source city/state values are stored; absent values remain null.

Directly affected admin/dashboard/profile/seed display paths use null-safe city/state rendering. Google location resolution, coordinate backfill, radius search, claims, ownership, subscriptions, registration, onboarding, and advertisements remain unchanged.

## 1. Existing Broker Model Audit

The existing `Broker` entity remains the single record for manually created, imported, self-registered, and claimed brokers.

Existing fields reused include:

- `displayName` for source Name;
- `companyName`;
- `email`;
- `phone`;
- `officeAddress`;
- `city`;
- `state`;
- `pinCode`;
- `description`;
- `website`;
- `experienceYears`;
- `specializations`;
- `serviceCities`;
- `languages`;
- `registrationNumber`;
- `panNumber`;
- existing verification/visibility/status fields;
- existing location representation; and
- existing BrokerSubscription/ownership/claim relations.

No parallel ImportedBroker model or generic second ID was added.

## 2. Spreadsheet Structure

The referenced workbook was not present in the repository workspace, so original-file inspection and direct import were unavailable.

The implementation accepts the documented source contract:

- Name;
- NMLS;
- Zip code;
- Phone;
- Address;
- Company Name;
- Email; and
- State.

The regression fixture generates 62 rows with those 8 columns and verifies duplicate-NMLS behavior. The import UI provides an explicit default City because the documented source does not contain a City column and the existing Broker model requires city.

## 3. Field Mapping

| Source field | Canonical Broker field | Transformation | Required | Notes |
|---|---|---|---|---|
| Name | `displayName` | trim | yes | Existing Broker display identity |
| NMLS | `nmls` | trim | yes | External identifier, not database ID |
| Zip code | `pinCode` | digits, preserve leading zero | yes under existing required Broker schema | Existing postal field |
| Phone | `phone` | trim, validate digit count | yes | Existing Broker phone |
| Address | `officeAddress` | trim | yes | Canonical internal business-address field |
| Company Name | `companyName` | trim/null | no | Existing Broker company field |
| Email | `email` | trim/lowercase | no | Existing Broker contact email |
| State | `state` | trim | no | Existing nullable state field |
| City/default city | `city` | explicit admin default or mapped source value | no | No address inference |
| Description/default description | `description` | mapped or explicit admin default | model-required | No source description is invented from address |
| Website | `website` | trim | no | Supported when present in exports/custom mappings |
| Experience years | `experienceYears` | numeric | no | Defaults to 0 |
| Specializations | `specializations` | comma/semicolon list | no | Defaults to Home Loan |
| Service cities | `serviceCities` | comma/semicolon list | no | Defaults to city |
| Languages | `languages` | comma/semicolon list | no | Defaults to English |
| Registration number | `registrationNumber` | trim | no | Existing field |
| PAN/tax number | `panNumber` | trim | no | Existing field |

Unsupported columns are ignored unless manually mapped to a supported canonical field.

## 4. `officeAddress` Decision

`officeAddress` is the existing canonical Broker business address. It is used by registration, onboarding, admin creation/editing, public search text matching, public profile data policies, geocoding/backfill, and location persistence.

Decision: **KEEP `officeAddress` internally.**

Import/export may label it `Address`; no database/API rename is justified.

## 5. ID Decision

The existing Prisma/Mongo `Broker.id` remains the internal primary key. NMLS is represented by nullable indexed `Broker.nmls`.

NMLS was not made unique because a complete production duplicate audit has not been performed. Application preview/import matching treats NMLS as the primary external identity and reports conflicts rather than silently merging.

## 6. Canonical Import/Export Contract

CSV, XLS, XLSX import, CSV export, and XLSX export use the same supported broker data fields. System fields such as verification, status, visibility, plan, and dates are export-only and never accepted as import authority.

Exports also include safe operational context:

- internal `ID`;
- verification status;
- Broker status;
- visibility;
- plan; and
- created/updated dates.

Secrets, password hashes, OAuth/session data, reset/claim token fields, and private User relations are excluded.

## 7. CSV Support

Supported through the single `xlsx`/SheetJS parser boundary:

- `.csv`;
- UTF-8/BOM;
- quoted fields;
- commas inside addresses;
- empty cells;
- normalized headers; and
- safe ZIP normalization.

Maximum file size: 10 MB. Maximum rows: 10,000.

## 8. XLSX/XLS Support

Supported extensions:

- `.xlsx`;
- `.xls`;
- workbook sheet metadata;
- selected sheet;
- header detection;
- empty-row handling; and
- formula contents treated as data, not executed macros.

## 9. Preview/Validation

The Admin flow requires:

```text
Upload → Parse → Map → Preview → Validate → Confirm → Import → Results
```

Preview reports total, invalid, duplicate, existing, and new rows. Row errors are preserved with row numbers.

## 10. Duplicate Behavior

Matching order:

1. NMLS;
2. normalized email; and
3. exact phone.

Within-file duplicate NMLS/email/phone rows are marked `DUPLICATE_IN_FILE`. Existing records are marked `EXISTING` with changed-field metadata. No fuzzy auto-merge is performed.

Supported modes:

- `CREATE_ONLY` default;
- `UPDATE_ONLY`; and
- `UPSERT`.

Invalid and duplicate rows are skipped with errors. Existing Broker ownership, verification, visibility, status, claims, metrics, and subscriptions are never overwritten by import.

## 11. Google Location Behavior

Imports preserve address/city/state/ZIP and do not invent coordinates. The existing Google location/backfill architecture remains a separate explicit operation. Imported records can therefore be created with nullable location, reported as location-missing, and later backfilled through the existing server-side Google path.

No Google key is exposed to the import browser UI.

## 12. Radius Compatibility

Imported records use the existing Broker location fields and remain compatible with future coordinate backfill, the GeoJSON representation, the `2dsphere` index, and `$geoNear` radius search. Import never writes fake latitude/longitude.

## 13. Admin Functionality

Existing `/admin/brokers` and manual `/admin/brokers/create` remain available. New actions are:

- Import;
- Export CSV; and
- Export XLSX.

All new APIs require active `ADMIN` authorization.

## 14. Export Behavior

Export uses the same data contract and current admin filters for search, ownership, verification, Broker status, state, and city. Formula-like cell values beginning with `=`, `+`, `-`, or `@` are prefixed before spreadsheet generation to reduce formula injection risk.

## 15. Security

Verified source behavior:

- admin-only preview/import/export;
- server-side file limits and parsing;
- no client-controlled Broker ownership/status/verification/plan writes;
- no automatic User creation;
- no claim creation during import;
- no sensitive export fields; and
- existing claim, listing, subscription, location, and authorization paths preserved.

## 16. Tests

Passed focused tests:

- CSV BOM/quoted-address/ZIP test;
- 62-row XLSX/duplicate-NMLS test;
- legacy XLS extension test;
- legacy XLS parsing test;
- CSV/XLSX export safety/formula-injection test;
- admin Broker/policy tests;
- registration/security tests;
- claim tests;
- location/radius tests;
- advertisement placement tests; and
- company tests.

Import-specific tests: **4 passed, 0 failed**. The combined relevant import/location/company/placement test run passes after the final changes.

## 17. Migration Requirements

Required schema change:

- nullable indexed `Broker.nmls`.

No unique NMLS constraint is required or safe until production duplicate analysis is complete. No existing Broker data is rewritten by schema addition.

The source workbook was not imported into any database.

## 18. Existing Architecture Preserved

Preserved without redesign:

- public/email/Google broker registration;
- BrokerRegistration and onboarding state;
- BrokerSubscription and registration subscription ownership;
- claims and ownership;
- Google location and radius logic;
- local advertisement behavior;
- company authorization and billing;
- public listing visibility; and
- admin Broker creation/management.

## 19. Remaining Issues

- Original workbook unavailable in the workspace, so no direct 62-row source-file import was executed.
- Location resolution is intentionally not automatic during import; imported coordinates remain missing until explicit backfill.
- Import history is returned as a completed operation result but is not persisted as a separate import-history model.
- Full repository ESLint retains pre-existing errors.
- `xlsx@0.18.5` installation reported npm audit high-severity findings requiring dependency review.
- Browser/admin UI automation was unavailable.

## 20. Production Recommendation

**CONDITIONAL GO for source-level implementation.**

The import/export architecture is admin-authorized, model-compatible, preview-first, and regression-tested. Before production use, obtain the original workbook, run a controlled staging preview/import, review NMLS duplicates, verify location/backfill policy, and review the dependency audit findings.
