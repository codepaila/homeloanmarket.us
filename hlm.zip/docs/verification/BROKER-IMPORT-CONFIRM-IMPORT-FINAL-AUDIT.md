# Broker Import Confirm Import Final Audit

## Root Cause

The first-row confirmation reproduction failed with:

```text
Prisma error: P2002
Unique constraint failed on the constraint: brokers_userId_key
```

The import correctly creates ADMIN_CREATED Brokers with `userId: null`, but
the configured MongoDB database still had the old normal unique `userId`
index. MongoDB treated the second and later null ownership values as duplicate
keys, so all 62 rows were reported as failed.

## Exact Failing Prisma/API Operation

The failing operation was the create branch in
`lib/admin/broker-data.ts`:

```text
tx.broker.create({ data: { ..., userId: null, ... } })
```

The failure occurred before location processing and was unrelated to NMLS,
address nullability, email, phone, subscription, Stripe, or Google APIs.

## Files Changed

- `lib/admin/broker-import.ts`: added Street Address and Business Address
  aliases.
- `lib/admin/broker-data.ts`: added safe structured per-row errors and safe
  diagnostic logging.
- `app/admin/brokers/import/page.tsx`: displays row, status, name, NMLS,
  error code, and safe error text after confirmation.
- `tests/broker-import.test.ts`: added per-row error contract coverage.

No Prisma schema change was required. The existing approved database repair
script was run:

```text
yarn db:ensure-ownership-index
```

It replaced `brokers_userId_key` with
`brokers_userId_non_null_unique`, a unique partial index applying only when
`userId` is an ObjectId.

## Why Preview Worked

Preview only parses, normalizes, validates, and performs duplicate lookups. It
does not create a Broker and therefore never exercised the database ownership
index. The preview payload was compatible with the current `Broker` model.

## Why Confirmation Failed

Confirmation executed the first create against the stale non-sparse unique
ownership index. Every admin-created row has `userId: null`, so the database
rejected the rows after the existing null entry. The importer caught the raw
exception and returned only a generic row error, while the UI displayed only
aggregate counts.

## Import Payload Before/After

The create payload already contained the current schema fields:

- `displayName`
- `nmls`
- `companyName`
- `description`
- `phone`
- normalized `email`
- `officeAddress`
- optional `city`, `state`, and `pinCode`
- `experienceYears`
- `specializations`, `serviceCities`, and `languages`
- `website`, `registrationNumber`, and `panNumber`
- `profileSlug`
- `userId: null`
- `creationSource: ADMIN_CREATED`
- existing admin defaults
- nested FREE `BrokerSubscription`

No location or Google resolution is invoked. The payload was not redesigned;
the database index was corrected.

## Schema Compatibility

Current `Broker` fields confirm:

- `officeAddress` is required.
- `city`, `state`, `pinCode`, and `location` are nullable.
- `nmls` is a nullable String with an index, not a unique Prisma selector.
- `userId` is nullable and ownership uniqueness is enforced for non-null owners
  by the repaired partial database index.
- `BrokerSubscription` is created with FREE defaults for imported Brokers.

`yarn prisma validate` and `yarn prisma generate` passed. No schema change was
needed.

## Address Handling

Address mapping remains normalized and case-insensitive. The importer now also
recognizes `Street Address` and `Business Address` in addition to `Address`,
`Office Address`, and `Office`. `officeAddress` is required; city, state,
postal code, and location remain optional.

## Email Normalization

Plain email, `mailto:`, and Markdown mailto links are normalized before
duplicate detection and persistence. Markdown wrappers are not stored.

## NMLS Handling

NMLS values remain strings. Integer strings, `.0` spreadsheet values, and safe
scientific-notation values are normalized without floating-point loss or
removal of valid leading zeroes.

## Transaction Behavior

Rows are processed independently. One row failure does not stop unrelated rows.
Each create still uses the existing per-row transaction so the Broker and its
FREE subscription remain atomic.

Persistence failures now return:

```json
{
  "row": 2,
  "rowNumber": 2,
  "status": "FAILED",
  "name": "...",
  "nmls": "...",
  "errorCode": "P2002",
  "error": "Unique constraint violation while creating the broker record."
}
```

Raw stack traces and Prisma query text are not sent to the browser. Server logs
contain only row, NMLS, name, mode, safe code, and safe reason.

## Database Synchronization

The approved ownership repair completed successfully:

```text
database: homeloan-listing-demo
replacementIndex: brokers_userId_non_null_unique
oldIndex: brokers_userId_key
duplicateOwnerGroups: 0
status: reconciled
```

Direct MongoDB verification showed exactly one `userId` index with the partial
ObjectId filter and no old normal unique ownership index.

## Real 62-Row Import Result

**Not verified.** The actual 62-row workbook was not present in the workspace,
so it was not fabricated or substituted for final proof. The confirmed
diagnostic row was imported successfully after index reconciliation and then
deleted, but this is not evidence of 62 production rows.

## Database Verification

The diagnostic Broker create after repair returned:

```text
imported: 1
updated: 0
skipped: 0
failed: 0
locationMissing: 1
```

The diagnostic Broker and its subscription were removed afterward. No 62-row
database count is claimed.

## Listing Verification

Not run against the missing real workbook. The import payload preserves the
existing ADMIN_CREATED defaults and does not change public listing logic.

## Location Compatibility

The import does not call Google APIs and leaves `location` nullable. Existing
explicit location resolution/backfill remains responsible for coordinates.
No radius or GeoJSON behavior was changed.

## Radius Compatibility

Not browser- or workbook-verified. No radius search code was modified.

## Security Verification

- No users are created for imported Brokers.
- `userId` remains null.
- No claims are created.
- No registration, onboarding, Google OAuth, Stripe, or FEATURED subscription
  path is invoked.
- Existing admin authorization remains on preview and confirm routes.
- Safe per-row error logging excludes secrets, tokens, passwords, and raw stack
  traces from the browser response.

## Tests

Passed:

- CSV parser and normalization tests
- XLSX 62-row parser and duplicate NMLS test
- XLS parser boundary test
- CSV/XLSX export test
- address-first optional-field test
- admin-created defaults test
- per-row error contract test
- targeted TypeScript validation
- targeted ESLint with 0 errors
- `git diff --check`

The database ownership integration suite had 21 passed and 1 environmental
failure: `phase-6.5-integration.test.ts` expects an empty `user` collection,
but the configured shared database already contains 19 users. Its ownership
index, multiple-null-owner, duplicate-owner, and rollback checks passed.

The parser test uses a generated 62-row workbook only for parser/duplicate
coverage. It is not claimed as the real production import.

## Build

Passed after the final import changes:

- `yarn prisma validate`
- `yarn prisma generate`
- `npx tsc --noEmit`
- `yarn build`
- targeted ESLint with 0 errors
- `git diff --check`

## Remaining Limitations

- The actual 62-row CSV/XLS/XLSX workbook was unavailable.
- The expected `62 created / 0 failed` result and database count of 62 are not
  claimed.
- Browser listing, admin management, claim, location backfill, radius, and
  local advertisement verification remain pending against real imported data.

## Recommendation

**NO-GO until the actual workbook is rerun.**

The root database defect is confirmed and repaired, and a real diagnostic
admin-created Broker now imports successfully. Release acceptance still
requires the actual workbook confirmation to show 62 created, 0 updated, 0
skipped, 0 failed, followed by database verification of exactly 62 records.
