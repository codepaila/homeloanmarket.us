# Broker Registration Plan Setup Dashboard Loop Fix

## Root Cause

The setup guard used `session.user.brokerProfile`, while the status endpoint
and dashboard used a fresh database read through `getCurrentUser()`. Those are
different sources for mutable onboarding state. When they disagree, `/setup`
can redirect to `/broker/dashboard` while the dashboard redirects back to
`/setup` because its database read still has no Broker profile.

Broker creation itself is transactional in `createBrokerForExistingUser()`;
the Broker, registration completion, and draft completion are persisted before
`POST /api/brokers` returns. The loop was therefore a guard-consistency issue,
not a missing `setupCompleted` field or a subscription transaction issue.

## Fix

- Added `lib/broker-onboarding-state.ts` with the canonical state predicate:
  setup is complete when the authenticated user has a Broker profile.
- Updated `app/api/broker-registration/status/route.ts` and
  `app/broker/dashboard/page.tsx` to use that predicate.
- Updated `app/setup/page.tsx` to use the fresh status endpoint for both the
  completed and incomplete states, removing the stale session-profile
  short-circuit.
- Kept the existing plan gate: no active registration subscription goes to
  `/broker/subscription/select`; an active plan with no Broker goes to
  `/setup`.
- Removed the post-submit `router.refresh()` from
  `components/sections/broker/BrokerSetupWizard.tsx`. The awaited API response
  already completes the database transaction before dashboard navigation.
- Added focused assertions in `tests/broker-setup-dashboard-loop.test.ts`.

## State Contract

```text
no plan
  -> /broker/subscription/select

active plan + no Broker
  -> /setup

active plan + Broker exists
  -> /broker/dashboard
```

The setup API creates the Broker and marks the registration/draft complete in
the same transaction. Both route guards now evaluate the same persisted Broker
existence state.

## Tests

- `node --import tsx --test tests/broker-setup-dashboard-loop.test.ts`: 3 passed
- `node --import tsx --test tests/broker-registration-gate.test.ts tests/registration-flow-security.test.ts tests/phase-15-register-flow.test.ts`: 18 passed, 2 skipped
- `yarn prisma validate`: passed
- `yarn prisma generate`: passed
- `yarn tsc --noEmit`: passed
- `yarn build`: passed
- `git diff --check`: passed

## Browser Verification

Not run in this environment. No authenticated browser session and runnable
application/database instance were available for the requested manual email,
verification, plan, setup, refresh, and direct-route checks.

The production build completed successfully, and the route contract is covered
by the focused regression test. The expected final URL after setup is
`/broker/dashboard`; revisiting `/setup` uses the same fresh state and redirects
there once.

## Unrelated Systems

This loop fix does not change claims, subscription architecture, Google
registration callbacks, admin-created Broker imports or claim flow,
advertisements, location autocomplete, location tokens, radius search, or
`$geoNear` behavior.

## Remaining Issues

Only browser-level verification remains to be performed against a running
environment with a real broker registration and payment/plan setup.
