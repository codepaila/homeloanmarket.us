# Broker Import/Export Verification

Date: 2026-08-11
Scope: Admin Broker CSV/XLS/XLSX import preview, validation, create/update, and export.

## Runtime Prisma/Normalization Diagnostic Update

`Broker.nmls` exists in `prisma/schema.prisma` as nullable `String?` with `@@index([nmls])`. The generated `@prisma/client` exposes `Prisma.BrokerScalarFieldEnum.nmls`, and a direct runtime `prisma.broker.findMany` query selecting `nmls` succeeds.

The reported `Unknown argument nmls` was caused by a stale development Prisma/Turbopack module graph after schema/client generation. The development server was stopped and restarted after `yarn prisma generate`, and the runtime client was verified directly.

Import normalization now converts Markdown `mailto` links and `mailto:` prefixes to trimmed lowercase email values. Phone formatting uses normalized comparison keys without changing stored display data. NMLS numeric/scientific spreadsheet values are normalized without scientific notation, while text leading zeroes are preserved.

## 1. Existing Broker Model Audit

The existing `Broker` model is reused. Existing fields cover:

- `displayName` for Name;
- `phone`;
- `officeAddress`;
- `city`;
- `state`;
- `pinCode`;
- `companyName`;
- `email`;
- existing canonical location fields; and
- existing verification, visibility, subscription, ownership, claim, and metric fields.

The model did not contain an NMLS/external professional identifier. A nullable indexed `nmls` field was added. It was not made unique because existing production-compatible data was not proven duplicate-free across the whole database.

No second generic ID or ImportedBroker model was added.

## 2. Spreadsheet-to-Model Mapping

| Spreadsheet column | Broker field |
|---|---|
| Name | `displayName` |
| NMLS | `nmls` |
| Zip code | `pinCode` |
| Phone | `phone` |
| Address | `officeAddress` |
| Company Name | `companyName` |
| Email | `email` |
| State | `state` |
| Optional City/default city | `city` |

The import does not infer city from Address or call Google geocoding automatically. Because the existing Broker model requires city and description, the admin import UI accepts an explicit default city and default description for source files that omit them.

Coordinates are not invented or imported from address text.

## 3. Fields Reused

Existing Broker fields are used for all supplied source columns. Existing creation defaults are preserved:

- `creationSource = ADMIN_CREATED`;
- `userId = null`;
- `verificationStatus = UNVERIFIED`;
- `brokerStatus = FREE`;
- `isVisible = false`; and
- active FREE BrokerSubscription.

Imported records do not bypass verification, publication, ownership, claims, or subscription rules.

## 4. New Fields Added

Only `Broker.nmls String?` and `@@index([nmls])` were added. The field is nullable and non-unique for migration safety.

## 5. Database Indexes/Constraints

The NMLS index is non-unique. Import duplicate detection is application-controlled by NMLS, with email/phone fallback and normalized name/company shown as a possible duplicate signal only through the preview result.

Existing ownership, phone, subscription, claim, location, and publication constraints remain unchanged.

## 6. CSV Import

`lib/admin/broker-import.ts` parses CSV through the single XLSX/SheetJS dependency and supports:

- UTF-8/BOM;
- quoted fields;
- commas inside addresses;
- empty cells;
- whitespace normalization;
- ZIP leading-zero preservation;
- header aliases; and
- row limits.

Maximum file size is 10 MB and maximum rows are 10,000.

## 7. XLSX Import

XLSX workbooks support:

- workbook parsing;
- first-sheet default selection;
- multiple-sheet response metadata;
- header mapping;
- empty-row handling;
- formula data treated as values; and
- invalid-file handling.

No macros are executed.

The supplied `Homeloanmarket Broker list - Houston - 2026-08-06.xlsx` was not present in the repository workspace. A generated equivalent 62-row XLSX fixture with the same eight headers was used for regression validation.

## 8. Preview/Validation

Admin flow:

```text
Upload
→ server parse
→ column mapping
→ preview
→ validation
→ duplicate classification
→ explicit confirmation
→ import result
```

Preview reports:

- total rows;
- invalid rows;
- duplicate rows;
- existing rows; and
- new rows.

Invalid rows are not silently written.

## 9. Duplicate Handling

Primary signal: NMLS.

Secondary exact signals:

- normalized email;
- phone; and
- existing exact identifiers.

Duplicate rows inside a file are marked `DUPLICATE_IN_FILE`. Existing matches are marked `EXISTING` and expose changed-field metadata. Fuzzy matching does not automatically merge records.

## 10. Create/Update Behavior

Import modes:

- `CREATE_ONLY` is the default UI mode;
- `CREATE_UPDATE` requires explicit admin selection.

Creates use the existing unowned admin Broker path and create exactly one FREE subscription. Updates change only imported profile fields and preserve:

- ownership;
- claims;
- verification;
- publication;
- broker status;
- metrics; and
- subscription ownership.

Processing is controlled per row and returns imported, updated, skipped, failed, and row-error results.

## 11. Export CSV

`GET /api/admin/brokers/export?format=csv` is admin-authorized and exports the currently selected admin filter dataset.

Export fields include:

- internal ID;
- NMLS;
- name;
- email;
- phone;
- company;
- address;
- city;
- state;
- ZIP;
- verification status;
- Broker status;
- visibility;
- plan;
- created date; and
- updated date.

Passwords, authentication tokens, OAuth credentials, claim token hashes, and private User data are not selected.

## 12. Export XLSX

`GET /api/admin/brokers/export?format=xlsx` uses the same server-side filters and safe field projection, producing an XLSX workbook named `brokers.xlsx`.

## 13. Admin Authorization

Import preview, import, and export routes all call `getCurrentUser()` and require `role === ADMIN`. The existing admin page and manual creation route remain admin-controlled.

## 14. Claim Compatibility

Imported records are unowned `ADMIN_CREATED` Brokers. They converge on the existing claim flow and do not create Users or Claim rows during import. Claiming attaches ownership to the same Broker record.

## 15. Listing Compatibility

Imported records retain existing unverified/unpublished/FREE defaults. They appear publicly only when existing verification, visibility, active-user, and status rules permit.

## 16. Location/Radius Compatibility

Import writes address, city, state, and ZIP fields only. It does not fabricate coordinates or automatically geocode imported addresses. Coordinate backfill remains a separate explicit operation.

## 17. Security

Validated:

- admin authorization;
- file extension and size limits;
- server-side parsing;
- row count limits;
- safe field projection on export;
- no client-controlled ownership/status/verification/subscription writes;
- no automatic User creation; and
- no claim/security bypass.

## 18. Tests

Passed:

- CSV BOM/quoted-comma/ZIP/default-city test;
- generated 62-row XLSX/header/duplicate-NMLS test;
- CSV/XLSX safe export test;
- Broker admin/policy tests;
- Broker registration tests;
- location/company/advertisement regression tests; and
- C1-H7 focused security tests.

Focused combined run: **101 passed, 0 failed**.

## 19. Build/TypeScript/Prisma

- `yarn prisma validate`: passed;
- `yarn prisma generate`: passed;
- `npx tsc --noEmit`: passed;
- `yarn build`: passed;
- targeted new-scope ESLint: passed; and
- `git diff --check`: passed.

Full repository lint retains pre-existing errors outside this feature scope.

## 20. Remaining Issues

- The supplied workbook was not available in the workspace; original-file execution was not possible.
- NMLS is indexed but intentionally not unique until a complete production duplicate audit is approved.
- No live large-file/import database run was executed.
- No browser automation was available for the admin import UI.
- The `xlsx` dependency installation reported four npm audit high-severity findings; dependency security review is required before production release.

No production seed data was added and no production database records were imported.
