# Broker Registration, Location, Local Ads, and Company Integration Verification

Date: 2026-08-11
Mode: Final integration and production validation
Repository source, Prisma schema, tests, and reachable MongoDB were inspected independently.

## Google Autocomplete Diagnostic Update

The configured development variable is `GOOGLE_MAPS_SERVER_API_KEY`. The server location service was reading only `GOOGLE_MAPS_SERVER_KEY` and `GOOGLE_PLACES_API_KEY`, so the configured key was ignored. In addition, `proxy.ts` whitelisted only the exact `/api/location` path while the actual endpoints are nested under `/api/location/*`; autocomplete requests therefore returned HTTP 401 before reaching Google.

The smallest fixes were:

- accept `GOOGLE_MAPS_SERVER_API_KEY` as the server-only primary variable; and
- whitelist the `/api/location` path prefix in `proxy.ts`.
- add the explicit Radius Search toggle to the existing broker Filters panel; the underlying radius query wiring was already correct.

No browser key, client Google call, architecture, auth, subscription, company, or advertisement behavior was changed.

## 1. Executive Summary

The implemented source architecture is internally coherent for the broker registration gate, server-validated location flow, radius query layer, local advertisement placement, and company account model.

Three genuine integration defects were found and corrected during this validation:

1. Radius and local-ad APIs trusted raw browser coordinates. They now require a signed server-issued search-location token.
2. ZIP-only search could not obtain a validated coordinate for radius mode. A server geocoding endpoint and ZIP blur resolution were added.
3. The existing admin placement picker did not expose `BROKER_LISTING_LOCAL`. The canonical placement picker, preview, badge, toolbar, and layout now expose it.

The repository is **not production-ready yet** because:

- the reachable database contains 8 Brokers and 0 stored coordinates;
- Google server location credentials are configured, but no coordinate backfill was run;
- live Google, Stripe, Redis, email, browser, and populated Mongo `$geoNear` E2E were unavailable;
- full ESLint fails on existing repository-wide errors.

The Broker `2dsphere` index and the documented partial ownership index were reconciled on the configured `homeloan-listing-demo` database. No broker/user/ad/company data was deleted or rewritten.

## 2. Broker Registration

### Source result

The current email path is:

```text
/register
→ /auth/signup
→ POST /api/auth/register/broker
→ User + BrokerRegistration + BrokerOnboardingDraft
→ email verification
→ /broker/subscription/select
→ FREE or FEATURED
→ /setup
→ POST /api/brokers
→ existing /broker/dashboard
```

Initial email registration currently collects only:

- full name;
- email;
- password;
- password confirmation;
- CAPTCHA/security control; and
- terms acceptance.

It does not collect phone, company name, description, address, city, state, ZIP, service cities, professional data, logo, website, or WhatsApp.

Password hashing, duplicate email protection, registration rate limiting, terms handling, and broker email verification remain server-controlled.

### State and resumability

The following models exist in the schema:

- `BrokerRegistration`;
- `BrokerRegistrationSubscription`; and
- `BrokerOnboardingDraft`.

The onboarding draft is saved through `PATCH /api/broker-registration/onboarding`, restricted to an authenticated Broker registration with an active subscription. Completion remains guarded by duplicate Broker checks and one transaction.

### Result

**ALREADY FIXED / SOURCE VERIFIED**

Live email delivery and browser execution were unavailable.

## 3. Google OAuth

### Source result

The broker registration page establishes a signed HttpOnly broker-intent cookie before Google OAuth. The callback goes to `/broker-registration/continue`, which requires the cookie, authenticates the account through Auth.js, creates/resumes the registration state, promotes only the explicitly participating account, refreshes the session, and routes to subscription selection.

Generic Google login does not use this broker-intent path.

Existing Broker users with a profile are routed to the existing dashboard. Existing normal Users require explicit broker intent before registration state is created.

### Security result

- OAuth identity remains database/Auth.js authoritative.
- No unsafe email-linking override was added.
- The intent cookie contains a signed fixed-purpose value, not OAuth tokens or profile data.
- C1 JWT identity protection remains intact.
- C3 client DTO protections remain intact.

### Result

**SOURCE VERIFIED; LIVE GOOGLE E2E UNAVAILABLE**

## 4. Subscription Before Onboarding

### FREE

`POST /api/broker-registration/subscription/free`:

- requires authenticated BROKER role and registration;
- uses the shared billing lock;
- creates/updates only `BrokerRegistrationSubscription`;
- does not call Stripe;
- marks the registration onboarding-ready; and
- routes to `/setup`.

### FEATURED

`POST /api/broker-registration/subscription/checkout`:

- validates the server-authoritative FEATURED price;
- creates/reuses a registration-owned Stripe customer;
- validates remote customer metadata;
- uses the shared billing lock;
- uses deterministic idempotency;
- creates recurring Checkout; and
- includes registration metadata for webhook reconciliation.

The Stripe webhook falls back from BrokerSubscription to registration subscription and company subscription ownership when the customer is not a completed Broker owner.

### Result

**SOURCE VERIFIED; LIVE STRIPE E2E UNAVAILABLE**

Existing `BrokerSubscription` records remain Broker-owned and were not changed by the new pre-profile model.

## 5. Broker Onboarding

`/setup` calls `/api/broker-registration/status` before rendering the wizard.

The route redirects to subscription selection if an active registration subscription is absent. It redirects completed Brokers to `/broker/dashboard`.

The wizard:

- saves progress between steps;
- restores draft data and current step;
- validates existing profile fields;
- resolves the selected location server-side during final Broker creation;
- enforces the existing service-city entitlement; and
- refreshes the session before dashboard navigation.

The final transaction creates exactly one Broker, materializes the selected subscription once, marks the registration completed, and marks the onboarding draft completed.

Existing Broker dashboard source was preserved.

Result: **SOURCE VERIFIED; LIVE BROWSER/DB COMPLETION E2E UNAVAILABLE**

## 6. Google Location

The Google boundary is isolated in `lib/location/google-place.ts` and exposed through:

- `/api/location/autocomplete`;
- `/api/location/resolve`; and
- `/api/location/geocode`.

The server uses only Google for autocomplete, selected-place resolution, geocoding, and US address validation. No runtime broker lookup is sent to Google.

Google API keys are read only from server environment variables:

- `GOOGLE_MAPS_SERVER_API_KEY`; or
- `GOOGLE_MAPS_SERVER_KEY`; or
- `GOOGLE_PLACES_API_KEY`.

The configured development key is present in `.env.local`; the browser bundle and API responses do not contain it.

Live development verification after the fix:

| Request | HTTP | Result |
|---|---:|---|
| `GET /api/location/autocomplete?input=Los%20Angeles` | 200 | 5 suggestions with place IDs and labels |
| `POST /api/location/resolve` using returned place ID | 200 | US location, normalized address, city/state, coordinates, signed search token |
| `POST /api/location/geocode` for `90001, USA` | 200 | US location with ZIP and coordinates |

The actual Google Places API (New) endpoint returned suggestions. The response key was not logged or returned. Browser automation was unavailable, but the server/network path is live-verified.

Result: **ALREADY FIXED / LIVE SERVER VERIFIED; BROWSER AUTOMATION UNAVAILABLE**

## 7. Stored Coordinates

Broker location fields are additive:

- `normalizedAddress`;
- `googlePlaceId`;
- `locationCountryCode`; and
- nullable `location` JSON.

The canonical representation is:

```json
{
  "type": "Point",
  "coordinates": [longitude, latitude]
}
```

The onboarding server resolves the selected place again and does not trust browser latitude/longitude. The backfill script likewise resolves existing address data through the Google boundary and skips valid existing location data.

Current reachable database result:

| Metric | Result |
|---|---:|
| Brokers | 8 |
| Brokers with location | 0 |
| Brokers missing location | 8 |
| Valid GeoJSON locations | 0 |

Radius search therefore cannot produce a meaningful live result until a configured Google key is used to backfill or manually populate canonical locations.

Result: **MUST FIX BEFORE PRODUCTION: coordinate backfill**

## 8. MongoDB 2dsphere

The repository script `db:ensure-broker-location-index` was executed successfully against `homeloan-listing-demo`.

Verified index:

```text
brokers_location_2dsphere
key: { location: "2dsphere" }
```

The known legacy non-partial Broker ownership index was also reconciled with `db:ensure-ownership-index`.

Verified Broker ownership indexes now include:

- `brokers_userId_non_null_unique`, unique with a partial ObjectId filter;
- no conflicting non-partial `brokers_userId_key`; and
- `brokers_location_2dsphere`.

Registration, registration-subscription, onboarding-draft, company-subscription, advertisement-target, and partial User.phone unique/index structures are present in the reachable database.

Result: **ALREADY FIXED / DATABASE INDEX VERIFIED**

## 9. Broker Radius Search

The broker API accepts the existing filters plus validated location token/radius state. Positive radius searches use `lib/location/broker-geo.ts`, which executes Mongo `$geoNear` with miles converted to meters.

The query layer composes:

- city/service city;
- state;
- ZIP;
- specialization;
- rating;
- experience;
- language;
- text search;
- verification;
- Broker status;
- public visibility;
- active owner; and
- suspended exclusion.

Pagination is applied inside the aggregation result facet, and the page IDs are then hydrated through Prisma without loading every Broker into memory.

Radius behavior:

- `0`: no radius restriction; resolved city/state/ZIP normal filtering applies;
- positive values: inclusive distance boundary;
- maximum: 100 miles;
- missing coordinates: absent from `$geoNear` results; and
- invalid/tampered location token: HTTP 400 or no local ads, depending on endpoint.

Live boundary tests were unavailable because the database has no coordinates. Google autocomplete, place resolution, and ZIP geocoding were live-verified separately.

Result: **SOURCE VERIFIED / LIVE DATA TEST UNAVAILABLE**

## 10. Radius UI

`app/(public)/brokers/page.tsx` and `hooks/useClient.ts` maintain:

- selected location;
- place label;
- city/state/ZIP context;
- server-issued location token;
- latitude/longitude display state; and
- radius 0-100.

Location changes reset the selected location and page state. Radius changes preserve the selected location. ZIP blur invokes server geocoding, allowing ZIP searches to become radius searches when Google infrastructure is configured.

Result: **SOURCE VERIFIED / LIVE BROWSER UNAVAILABLE**

## 11. Local Advertisement Targeting

`AdvertisementLocationTarget` stores:

- label;
- US country code;
- city/state/ZIP;
- Google Place ID;
- target latitude/longitude; and
- target radius.

Admin creation/edit routes require the local placement for targeted data and re-resolve the selected Google Place ID server-side. Client coordinates are not authoritative.

Public local-ad eligibility requires:

- `BROKER_LISTING_LOCAL` placement;
- active/enabled state;
- not archived/deleted;
- schedule validity;
- device eligibility;
- valid server-issued search-location token;
- target country US;
- target radius match;
- active Company status; and
- active CompanySubscription.

Multiple eligible ads use existing priority, display order, schedule, device, and carousel behavior.

Result: **SOURCE VERIFIED / LIVE POPULATED-AD TEST UNAVAILABLE**

## 12. Broker Listing Local Placement

The existing generic `BROKER_LISTING` placement remains mounted near the existing listing header. The new `BROKER_LISTING_LOCAL` placement is mounted exactly once at the bottom of the listing result content.

The local placement is also exposed through the existing admin:

- PlacementPicker;
- placement preview metadata;
- PlacementBadge;
- AdvertisementToolbar;
- canonical placement specs; and
- canonical bounded layout.

No local placement is mounted on homepage, broker profile, dashboard, subscription, blog, company dashboard, or admin pages.

Result: **SOURCE VERIFIED**

## 13. Company Registration

Company registration creates:

- a normal `USER`;
- a `Company`;
- an owner `CompanyMembership`; and
- no Broker, BrokerRegistration, or claim.

Required company data is represented:

- company name;
- company type;
- company address;
- contact name;
- position;
- phone;
- banner address; and
- banner phone.

Supported types match the requested six categories.

Result: **SOURCE VERIFIED / LIVE EMAIL E2E UNAVAILABLE**

## 14. Company Subscription

Company billing uses `CompanySubscription`, never `BrokerSubscription`.

The company Checkout route:

- resolves ownership from active CompanyMembership;
- uses a company billing lock;
- creates/reuses a company Stripe customer;
- checks company and user metadata;
- creates recurring monthly Checkout;
- enables Stripe promotion codes; and
- uses deterministic idempotency.

Company cancellation and billing portal routes validate remote customer ownership. The shared webhook service reconciles company subscription state and activates Company status after active payment.

The current environment has Stripe credentials but no live provider test was executed. `STRIPE_COMPANY_AD_PRICE_ID` was not confirmed in the environment and must be configured before company checkout can work in deployment.

Result: **SOURCE VERIFIED / MUST CONFIGURE AND LIVE-TEST BEFORE PRODUCTION**

## 15. Company Authorization

Company access is relation-based. No `COMPANY` or `ADVERTISER` UserRole was added.

Company users cannot access Broker routes because they remain USER. Claim completion explicitly rejects active company memberships. Broker creation requires BROKER plus BrokerRegistration and active registration subscription. Company APIs resolve the authenticated membership server-side rather than trusting request company IDs.

Company dashboard exposes profile display, subscription/billing, promotion-code-capable Checkout, and request/status. Actual advertisement creation remains admin-only.

Result: **SOURCE VERIFIED**

## 16. C1-H7 Regression

Focused current run:

| Suite | Result |
|---|---:|
| C1-H7 and Stripe focused set | 68 passed |
| New broker registration/location/company contracts | 10 passed |
| Registration/security suite | 23 passed |
| H5 creation-limit suite | 11 passed |
| Combined reported focused run including H5 | 89 passed |

Verified controls:

- C1 client session identity merge absent;
- C2 canonical public contact resolution preserved;
- C3 safe client DTOs preserved;
- H1 contact entitlement preserved;
- H2 allowlists preserved;
- H3 reset token protection preserved;
- H4 valid verification enum preserved;
- H5 FREE one-city limit preserved;
- H6 webhook ordering/processing/idempotency preserved; and
- H7 claim recipient binding preserved.

Result: **ALREADY FIXED / REGRESSION SET PASSED**

## 17. Database Migration

`prisma validate` and `prisma generate` pass.

The current repository uses MongoDB schema synchronization rather than a checked-in relational migration directory. No `prisma db push` was executed in this validation. The reachable database already contains the new collections/index structures, but the source of that prior synchronization is not established by this audit.

No data deletion or destructive migration was performed.

Result: **SHOULD FIX BEFORE PRODUCTION: document and rehearse controlled schema synchronization**

## 18. Coordinate Backfill

`db:backfill-broker-locations` is resumable and skips Brokers where `location` is already present. It uses existing Broker address fields and server-side Google geocoding.

Backfill execution was not attempted because the validation environment was not authorized to perform a bulk Google geocode/write operation. No coordinates were overwritten.

Result: **MUST FIX BEFORE PRODUCTION**

## 19. Advertisement Regression

Existing advertisement behavior remains source-connected:

- admin authorization;
- media selection/upload;
- lifecycle/archive/delete;
- schedule;
- device filtering;
- priority/order;
- creative fallback;
- carousel; and
- tracking.

The focused advertisement test run produced 31 passes and 6 environment-gated skips. `tests/phase-13.13-media-selector.test.tsx` timed out after 180 seconds with a pending Promise. This is an existing media-selector test/runtime limitation and was not hidden.

The new local placement is isolated from generic placement behavior.

Result: **SOURCE VERIFIED; MEDIA TEST TIMEOUT IS AN INFRASTRUCTURE/TESTING GAP**

## 20. Test Results

### Passed

- Prisma validation;
- Prisma generation;
- TypeScript;
- production build;
- C1-H7/Stripe focused tests: 68;
- new feature contracts: 10;
- registration/security: 23;
- H5 creation limits: 11;
- location token tests;
- targeted advertisement contracts; and
- company account contracts.

### Failed

- Phase 7.5 integration suite: initially 11 fixture failures caused by the configured database's non-partial optional-phone index. After replacing it with `users_phone_non_null_unique`, the suite passed 11/11.
- Full `yarn lint`: existing repository-wide lint errors, principally legacy `any`, hook-rule, and JSX entity findings.

### Skipped

- Six advertisement/search tests were environment-gated because live base URLs/database fixtures were unavailable.

### Timed out

- `tests/phase-13.13-media-selector.test.tsx`: pending Promise after 180 seconds.

## 21. Browser Results

No browser automation or viewport certification was available.

Classification: **INFRASTRUCTURE / TESTING GAP**

## 22. Google Results

The server-side Google location key is configured. Autocomplete, place resolution, and ZIP geocoding were live-tested successfully. Onboarding geocoding and bulk backfill were not executed.

Classification: **INFRASTRUCTURE / TESTING GAP**

## 23. Stripe Results

Stripe secrets are present, but no Stripe test-mode Checkout, webhook, renewal, failed-payment, cancellation, promotion-code, or company billing E2E was executed.

Source-level ownership, locks, idempotency, and webhook dispatch are covered by focused tests for existing Broker billing and source inspection for registration/company ownership.

Classification: **INFRASTRUCTURE / TESTING GAP**

## 24. Redis Results

Redis environment variables are present. No live lock-renewal, contention, failure, or multi-instance test was executed.

Classification: **INFRASTRUCTURE / TESTING GAP**

## 25. Remaining Risks

### MUST FIX BEFORE PRODUCTION

- Backfill all eligible Brokers with validated coordinates and review ambiguous/failed addresses.
- Execute live browser onboarding location selection.
- Configure `STRIPE_COMPANY_AD_PRICE_ID` and execute company Stripe test-mode flows.
- Run populated Mongo `$geoNear` inside/boundary/outside-radius tests after backfill.
- Rehearse all index reconciliation scripts in a clean staging database after schema synchronization.

### SHOULD FIX BEFORE PRODUCTION

- Add an admin UI for company advertisement-request review; the current request review boundary is API-level while actual ad creation remains in the existing admin CMS.
- Add a dedicated company coupon/status UI if product requires coupon application outside hosted Stripe Checkout. Current coupon support is Stripe-hosted promotion-code entry.
- Resolve repository-wide ESLint errors.
- Resolve the media-selector pending-Promise timeout.
- Rehearse schema synchronization and all index scripts in a clean staging database.

### ACCEPTABLE DOCUMENTED RISK

- Browser/live provider certification is unavailable in this environment.
- Existing advertisement impression/click abuse hardening remains separate from this feature.
- Existing media storage lifecycle limitations remain outside this integration scope.

### ALREADY FIXED

- Raw coordinate injection into radius/local-ad queries during this validation.
- Google variable-name mismatch and location-route proxy 401.
- ZIP-only radius coordinate resolution gap.
- Missing admin local-placement selection.
- Legacy conflicting Broker ownership index in the inspected database.
- Missing Broker location `2dsphere` index in the inspected database.
- Optional User.phone non-partial unique index causing real multi-user registration collisions.

## 26. Production Recommendation

**NO-GO for production release of the complete integrated feature.**

The source/build/security validation is strong and the core integration boundaries are present. Production release remains blocked by the absence of Broker coordinates, missing browser onboarding certification, unverified company Stripe price/E2E, and the lack of populated Mongo geospatial boundary testing.

The existing Broker dashboard, BrokerSubscription ownership, claim security, public visibility rules, admin advertisement authorization, and C1-H7 controls remain preserved.

No production behavior was weakened to make tests pass. No production data was deleted. The only live database changes made during validation were non-destructive index reconciliation:

- `brokers_location_2dsphere` created;
- legacy non-partial `brokers_userId_key` removed after duplicate-owner verification; and
- the required partial ownership index retained.
