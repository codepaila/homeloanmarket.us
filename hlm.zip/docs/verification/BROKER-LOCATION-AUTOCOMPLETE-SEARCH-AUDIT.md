# Broker Location Autocomplete & Exact Location Filtering Audit

## Root Cause

Two drops of the selected **city**:

1. **Frontend** — `hooks/useClient.ts` `useAllBrokers()` serialized only `locationState`
   and `locationZip` from the selected location, never `locationCity`.
2. **API** — `app/api/brokers/route.ts` read only `locationState`/`locationZip` and, in the
   `radius === 0` branch, reduced a city selection to `state` only.

So selecting "Dallas, TX" became `state = TX`, returning brokers from any Texas city.

## Existing Location Flow

`/brokers` autocomplete → `POST /api/location/autocomplete` → click result →
`POST /api/location/resolve` (issues a signed `locationToken`) → `selectedLocation` state
(stores `city`, `state`, `zip`, `latitude`, `longitude`, `token`) → `useAllBrokers` →
`GET /api/brokers?...&locationToken=...`. The landing `SearchSection`/`Hero2` build the same
structured URL params (`locationCity`, `locationState`, `locationZip`, `locationToken`).

## Why Dallas returned other locations

The verified location token always contained `city`, but neither the query hook nor the API
ever consumed it; only `state` (and `zip`, when present) were applied.

## Frontend changes

`hooks/useClient.ts`: append `locationCity` from the structured selected location.

## API changes

`app/api/brokers/route.ts`:
- Read `locationCity` param.
- `radius === 0` now applies, using server-verified token values where available:
  - `city` = selected city
  - `state` = selected state (unless an explicit `state` filter was set)
  - `pinCode` = selected ZIP (unless an explicit `zip` filter was set)
- Added `mode` (`TEXT`/`CITY`/`ZIP`/`RADIUS`/`ALL`) and non-sensitive location fields to the
  `[BROKER API]` log (never logs the full token).

## Radius behavior

`radius > 0` still uses `findBrokerIdsWithinRadius` (2dsphere `$geoNear` on `Broker.location`).
`radius === 0` is exact selected-location search: city+state for a city, ZIP+state for a ZIP.

## Token validation

Unchanged. `locationToken` is required whenever coordinates are present and is verified via
`verifySearchLocationToken`; invalid/expired tokens return 400. Client-supplied
`locationCity/State/Zip/latitude/longitude` are never trusted over the signed token values.

## serviceCities audit

`serviceCities` is not referenced in `app/api/brokers/route.ts`, `lib/location/broker-geo.ts`,
or `hooks/useClient.ts`. Public broker search and radius use actual `Broker.location`/address
fields only.

## Test matrix/results

`tests/broker-location-city-filter.test.ts` (new) + existing location suites:
- A free-text search, B city+state constraint, C/D radius geo, G no-ZIP city, I/K token
  required, M/N no serviceCities, frontend sends `locationCity` — all pass.
- 39 tests, 37 pass, 0 fail, 2 skipped (DB-only).

## TypeScript

`npx tsc --noEmit` — exit 0.

## Build

`npx next build` — success.

## ESLint

`npx eslint hooks/useClient.ts app/api/brokers/route.ts tests/broker-location-city-filter.test.ts` — clean.

## git diff --check

Clean for changed files.

## Browser verification

Not executed (no running app / automation). Verified via type-check, build, and source tests.
Manual checklist: type "Dallas" → click "Dallas, TX" → only Dallas brokers; change to Houston
→ Dallas results disappear; refresh → Houston retained; radius search returns geographic radius
only; a Houston broker with `serviceCities:["Dallas"]` does not appear in Dallas exact search.

## Remaining Issues

1. Pre-existing stale test `tests/broker-search-url.test.ts` ("radius is committed to the URL
   immediately on change") fails on an outdated `specialization` assertion, unrelated to this
   change.
2. The `/brokers` page re-geocodes the `location`/`locationLabel` URL text on hydration rather
   than consuming the already-present `locationCity/State/Zip/locationToken`; functionally
   equivalent, but a future optimization could avoid the extra geocode call.
