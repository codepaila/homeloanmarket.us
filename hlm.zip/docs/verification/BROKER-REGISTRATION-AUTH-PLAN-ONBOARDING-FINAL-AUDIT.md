# Broker Registration Auth Plan Onboarding Final Audit

## 1. Final Registration Architecture

Email and Google registration converge on the existing
`BrokerRegistration` -> `BrokerRegistrationSubscription` ->
`BrokerOnboardingDraft` -> `Broker` architecture.

The canonical plan route is `/broker/subscription/select`. The canonical setup
route is `/setup`, and the canonical completed destination is
`/broker/dashboard`.

## 2. Email Registration Flow

`/register` links the broker email path to `/auth/signup`. The signup API
creates a `User` with role `BROKER`, an unverified email, a
`BrokerRegistration`, and an onboarding draft. No Broker profile is created at
this stage.

After registration, the verification URL is `/auth/verify-email?...`. A
successful broker verification establishes a normal Auth.js credentials
session using the one-time verification token and redirects to
`/broker/subscription/select`.

## 3. Google Registration Flow

The broker card posts a signed, httpOnly `homeloanmarket_broker_intent` cookie
before starting Google OAuth. Google returns to
`/broker-registration/continue`. That route verifies the intent cookie,
creates or resumes `BrokerRegistration`, promotes the authenticated non-admin
account to `BROKER`, refreshes the Auth.js session, and redirects to the same
plan route.

Customer Google registration does not use the broker intent path and remains
unchanged.

## 4. Verification Flow

Verification hashes and validates the token and expiry before updating
`emailVerified`. For broker registrations, the existing Auth.js
`credentials` provider accepts the verification token only for an already
verified, active account with the matching stored hash. It atomically consumes
the token and issues the normal Auth.js session cookie. This avoids a second
manual login without creating another authentication system.

Email-change verification continues to clear its token directly and does not
use the broker registration handoff.

## 5. Plan Selection

The plan page is protected by the existing broker route authorization. Server
APIs re-read the authenticated user and require role `BROKER` plus an existing
`BrokerRegistration`; client role or subscription state is not trusted.

No active registration subscription sends the user to the plan route. An active
plan proceeds to setup, not directly to the dashboard.

## 6. FREE Plan

`POST /api/broker-registration/subscription/free` uses the existing billing
lock and upserts an active FREE registration subscription. It updates
registration progress and returns `/setup`.

## 7. FEATURED Plan / Stripe

FEATURED selection creates or resumes a Stripe checkout session and records
`CHECKOUT_PENDING`. The success page calls the existing server-side
verification endpoint, which validates the Stripe customer, checkout session,
payment status, subscription status, ownership metadata, and price. The
registration subscription is activated transactionally before returning
`/setup`.

Live Stripe checkout and webhook delivery were not browser-tested in this
environment.

## 8. Setup / Onboarding

`/setup` requires an authenticated session and fetches fresh state from
`/api/broker-registration/status`. It resumes the persisted draft and step.
No client JWT `brokerProfile` shortcut competes with that server read.

Final setup submission waits for `POST /api/brokers`. That API calls the
transactional `createBrokerForExistingUser()` flow, which creates the
self-registered Broker and subscription, marks the registration completed, and
marks the onboarding draft completed before returning. Only then does the
wizard navigate to `/broker/dashboard`.

## 9. Dashboard

The dashboard uses `getCurrentUser()`, which resolves fresh database state.
The canonical completion state is the existence of the user-owned Broker
profile. A registration with no active plan redirects to the plan route; an
active-plan registration without a Broker redirects to `/setup`; a Broker
profile renders the dashboard.

The dashboard no longer depends on stale client onboarding state.

## 10. Redirect Guard Architecture

```text
unverified email
  -> /auth/verify-email

verified broker registration + no plan
  -> /broker/subscription/select

active plan + no Broker profile
  -> /setup

active plan + Broker profile exists
  -> /broker/dashboard
```

The setup status endpoint and dashboard share `isBrokerSetupComplete()`.
Middleware handles authentication and role access; mutable onboarding state is
resolved server-side by the route/API guards.

## 11. Loop Root Cause

The loop was caused by competing state authorities. `/setup` used the client
session's `brokerProfile`, while the status endpoint and dashboard used a
fresh database read. A stale session could therefore send setup to dashboard
while the dashboard's current database read sent the user back to setup.

The Auth.js JWT refresh callback also failed to explicitly clear a stale
`token.brokerProfile` when the database relation was absent, allowing old
profile state to persist in a session.

## 12. Confirmed Fixes

- Added the shared `isBrokerSetupComplete()` type predicate.
- Made setup use the fresh status endpoint as its sole mutable onboarding
  guard.
- Made dashboard use the same persisted Broker-existence predicate.
- Cleared stale `token.brokerProfile` during database refresh.
- Removed the setup completion `router.refresh()` and verification redirect
  delay.
- Added atomic Auth.js verification-token consumption and broker session
  establishment.
- Preserved draft persistence and transactional Broker completion.

## 13. Security Validation

- Existing `AUTH_SECRET` remains the sole auth secret.
- Broker intent is signed, httpOnly, same-site, short-lived, and same-origin
  protected.
- Registration and plan APIs resolve ownership and role server-side.
- Verification tokens are hashed, expiry-checked, and atomically consumed for
  the Auth.js handoff.
- Existing rate limiting, duplicate registration checks, Broker ownership, and
  Stripe ownership validation remain in place.
- Admin-created Brokers remain outside public self-registration.

## 14. Regression Tests

Focused coverage asserts:

- broker registration creates pre-profile registration state;
- verification routes broker registrations to plan;
- verification uses the existing Auth.js provider for session establishment;
- FREE and FEATURED routes point to setup before dashboard;
- dashboard and setup use one completion state;
- setup persistence completes before dashboard navigation;
- stale session-profile short-circuits and refresh loops are absent;
- Google broker intent remains explicit and session-safe;
- existing auth hardening checks pass.

## 15. Build / TypeScript / Prisma

Validated during this audit:

- `yarn prisma validate`: passed
- `yarn prisma generate`: passed; no schema changes were made
- `npx tsc --noEmit`: passed
- `yarn build`: passed after the final auth handoff edit
- targeted ESLint: 0 errors; existing warnings remain in auth/config and
  legacy components
- `git diff --check`: passed

The combined targeted suite completed with 54 passed and 0 failed tests,
including registration security, Auth.js hardening, Google broker intent,
verification, plan gating, setup/dashboard loop, and setup persistence checks.

## 16. Browser Verification

Not run. Browser automation and a running authenticated application/database
session were unavailable.

Email delivery, Google OAuth, and live Stripe payment were not claimed as
tested. The static route audit and focused tests cover their server-side
contracts only.

## 17. Remaining Limitations

- A real browser run is still required for email-link session cookie behavior,
  Google OAuth callback behavior, Stripe return handling, refresh stability,
  and network-console inspection.
- Targeted ESLint reports warnings but no errors; these warnings predate or are
  unrelated to the redirect contract.

## 18. Production Recommendation

**CONDITIONAL GO**

The confirmed redirect and stale-state defects are fixed, TypeScript and
focused security/regression checks pass, and no unrelated business systems
were redesigned. Production release should remain conditional on browser
verification of email auto-session establishment, Google OAuth, and live or
test-mode Stripe checkout in the deployment environment.
