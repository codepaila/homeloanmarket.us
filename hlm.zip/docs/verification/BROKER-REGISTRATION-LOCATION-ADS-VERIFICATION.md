# Broker Registration, Location, Local Ads, and Company Verification

Status: Source implemented; database migration and external E2E pending
Date: 2026-08-11

## Implemented

### Broker

- Email broker registration now collects account fields only.
- Existing security controls remain in place.
- Explicit Google broker intent is carried through a signed HttpOnly intent cookie.
- Google continuation promotes/creates broker registration only after explicit intent.
- `BrokerRegistration` represents pre-profile workflow state.
- `BrokerRegistrationSubscription` represents FREE/FEATURED state before Broker creation.
- `BrokerOnboardingDraft` stores resumable onboarding data.
- `/setup` requires active pre-profile subscription and registration state.
- Existing Brokers continue to `/broker/dashboard`.
- Broker creation materializes the selected subscription exactly once.

### Location

- Broker location fields are additive and nullable.
- Selected Google places are resolved server-side.
- Live server autocomplete, place resolution, and ZIP geocoding were verified with the configured development key.
- Only US locations are accepted.
- Google keys are server-only.
- Radius and local-ad requests require a signed server-issued search-location token; raw browser coordinates are not authoritative.
- Broker coordinates are stored as GeoJSON Point data using `[longitude, latitude]`.
- Radius search uses a dedicated Mongo `$geoNear` layer.
- Radius range is 0-100 miles.
- Radius 0 preserves normal location filtering.
- Existing visibility, verification, suspension, filtering, sorting, and pagination paths remain applied.
- A resumable broker-location backfill script is available.

### Local advertisements

- `BROKER_LISTING_LOCAL` is a separate placement.
- Local ads render only at the bottom of broker listing results.
- Public eligibility requires active lifecycle/device/schedule state, validated search coordinates, target radius eligibility, active Company status, and active CompanySubscription.
- Existing advertisement placements and canonical slot sizing remain intact.
- Admin target coordinates are resolved from a selected Google place server-side.
- Multiple eligible ads retain existing priority/order/carousel behavior.

### Company

- Companies use normal authenticated `USER` accounts.
- No `ADVERTISER` role was added.
- Company, membership, subscription, and advertisement-request models were added.
- Company users cannot use broker registration/onboarding/claim capabilities.
- Company dashboard exposes profile, subscription/billing, coupon-enabled Checkout, and advertisement requests.
- Company users cannot publish advertisements.
- Admin request review can associate an admin-created Advertisement with a Company.

## Preserved

- C1 JWT identity protection.
- C2 public contact resolution.
- C3 explicit client DTO boundaries.
- H1 contact entitlement.
- H2 broker update allowlists.
- H3 password recovery.
- H4 verification enum protection.
- H5 FREE service-city limits.
- H6 Stripe ordering/idempotency/processing guards.
- H7 claim recipient binding.
- Existing Broker ownership and claim semantics.
- Existing BrokerSubscription ownership.
- Existing Broker dashboard.
- Existing admin advertisement/media authorization.

## Validation Results

Passed:

- `npx prisma validate`
- `npx prisma generate`
- `npx tsc --noEmit`
- `yarn build`
- `tests/broker-registration-gate.test.ts`: 4 passed
- `tests/location-ads-contract.test.ts`: 4 passed
- `tests/company-account-contract.test.ts`: 2 passed
- `tests/phase-19-h5-creation-limit.test.ts`: 11 passed
- C1-H7/Stripe focused regression set: 68 passed

Targeted ESLint for newly added boundaries has no errors; warnings remain in existing components. Full repository ESLint remains failing on pre-existing repository errors, including legacy `any` usage and legacy hook-rule violations.

## Migration Status

Prisma schema changes are present but have not been pushed to the configured database.

Before deployment, review and execute in a controlled environment:

1. `npx prisma db push` or the repository-approved Mongo schema-sync process.
2. `yarn db:ensure-ownership-index` after schema sync because the existing nullable Broker ownership index is operationally sensitive.
3. `yarn db:ensure-user-phone-index` because optional User.phone requires a partial non-null unique index.
4. `yarn db:ensure-broker-registration-indexes`.
5. `yarn db:ensure-broker-location-index`.
6. Inspect index output and existing data before enabling radius search.
7. Run `yarn db:backfill-broker-locations` with a configured server-side Google key, rate limits, and review of failures.

No destructive migration, database push, or coordinate backfill was executed. The location `2dsphere` and Broker ownership index reconciliation scripts were executed non-destructively against the reachable demo database after duplicate-owner verification.

## External E2E Limitations

Not executed:

- live browser Google location selection and bulk backfill;
- live Stripe checkout/webhook/cancellation;
- Redis lock/concurrency failure behavior;
- email delivery;
- browser/viewport automation;
- live Mongo `$geoNear` query against a migrated/indexed database; and
- live company/admin advertisement request workflow.

## Remaining Production Gate

The implementation is source/build/test validated but is not production-certified until schema synchronization, index verification, coordinate backfill, Google/Stripe configuration, and live integration checks are completed.
