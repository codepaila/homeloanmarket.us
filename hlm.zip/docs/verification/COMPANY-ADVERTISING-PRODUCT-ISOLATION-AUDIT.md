# Company Advertising Product — Isolation Audit

## A. PASS (already correct)

- **Schema isolation**: `CompanyAdvertisingPlan` (dedicated model with `stripePriceId @unique`,
  `features`, `isActive`) is separate from the broker `SubscriptionPlan` enum.
  `CompanySubscription.planId → CompanyAdvertisingPlan` is the authoritative plan relationship;
  the legacy `plan String @default("ADVERTISING")` is not used as a second source of truth.
- **Company model family**: `Company`, `CompanyMembership`, `CompanySubscription`,
  `CompanyAdRequest`, `Advertisement`, `AdvertisementLocationTarget` all exist and are linked
  (`User → CompanyMembership → Company`).
- **Email company registration** (`app/api/company/register`): creates a normal `USER` role
  account + `Company` + `CompanyMembership(OWNER)`; it never creates a broker, `BrokerSubscription`,
  or `BrokerRegistrationSubscription`.
- **Company checkout** (`app/api/company/subscription/checkout`): resolves a
  `CompanyAdvertisingPlan`, sets Stripe `ownerType=COMPANY`, `companyId`, `planId` metadata on
  both customer and subscription, and scopes access via server-derived `getCurrentCompany()`.
- **Webhook company branch** (`SubscriptionService.updateCompanySubscriptionFromStripe`): updates
  only `CompanySubscription`, resolves the plan from the Stripe price via
  `resolveCompanyPlanByStripePrice`, and activates the company.
- **Company billing management**: cancel + billing portal routes are company-scoped and validate
  Stripe customer ownership.
- **Company dashboard**: exposes profile, billing, and advertising-request sections only (no broker
  controls).
- **Advertising request flow**: company can submit (`/api/company/requests`), admin can review
  (`/api/admin/company-ad-requests` PATCH), and `Advertisement` can be linked to `Company` /
  `CompanyAdRequest`.
- **Public ad rendering** (`lib/advertisements/advertisementRepository.ts`): enforces active dates,
  placement, company `ACTIVE` status + active subscription, SQUARE creative, and distance/radius
  targeting for `BROKER_LISTING_LOCAL`.

## B. FAIL (missing / incorrect)

1. **"Full Name" is not collected by the company registration form.** The API requires `name` but
   the UI only sends `contactName`; email company registration always fails with
   "All company registration fields are required".
2. **No company plan-selection page.** There is no `/company/subscription/select`; the dashboard
   checkout button calls checkout without a `planId`, silently picking the first active plan.
3. **Company checkout has a global price fallback.** `plan.stripePriceId || STRIPE_COMPANY_AD_PRICE_ID`
   can charge the wrong price instead of failing clearly.
4. **Verified company is routed to `/company/dashboard`, not the advertising plan flow.**
5. **No Google company intent.** The company register page has no Google option; Google sign-in
   creates a bare `USER` with no `Company`/`CompanyMembership`, and the only intent cookie is
   broker-specific.
6. **No admin company-advertising-plan management UI** (API exists, UI is absent).
7. **No explicit `ownerType` guard in the webhook dispatcher** — it relies solely on unique
   `stripeCustomerId`.

## C. RISK (cross-product mixing)

- The webhook dispatcher (`updateSubscriptionFromStripe`) tries broker → registration → company by
  `stripeCustomerId` without validating `ownerType`. Safe while customer IDs remain unique, but a
  mislabeled metadata field or a shared customer could route a company event to a broker
  subscription (or vice versa).
- `COMPANY_PLAN_DEFAULT_NAME = 'ADVERTISING'` overlaps semantically with the legacy
  `CompanySubscription.plan` string; harmless today but a future change could treat it as the
  authoritative plan.

## D. BUGS

- Company email registration cannot succeed (Full Name mismatch) — see FAIL #1.
- Company checkout fallback price can silently charge the wrong amount — see FAIL #3.

## E. REQUIRED CHANGES

1. `app/(public)/company/register/page.tsx` — add Full Name (and confirm-password) fields.
2. `app/api/company/subscription/checkout/route.ts` — remove global price fallback; fail with
   "Company advertising plan is not configured for checkout."
3. `app/company/subscription/select/page.tsx` — new plan-selection page loading
   `/api/company/subscription/plans`.
4. `app/company/dashboard/CompanyDashboardClient.tsx` — route "Start advertising subscription" to
   the selection page and pass the chosen `planId` to checkout.
5. `app/api/auth/verify-email/route.ts` — route verified company to `/company/subscription/select`.
6. `lib/company-intent.ts` + `app/api/auth/company-intent/route.ts` + `GoogleContinueButton`
   company support + `app/company/register/continue/page.tsx` — Google company intent flow.
7. `lib/subscription.ts` — validate `ownerType` in the webhook dispatcher (company events only
   mutate `CompanySubscription`).
8. `app/admin/company-advertising-plans/` — minimal admin plan-management UI.
9. Tests for product isolation, registration, verification routing, plan selection, checkout, and
   webhook ownership.
