# USER + BROKER Registration Verification

Scope: verification that both normal User/Consumer registration and Broker registration exist, are fully wired end-to-end, are secure against client-side role/ownership/subscription/verification injection, and are covered by regression tests. No authentication architecture was redesigned; no duplicate registration system was introduced.

**Date:** 2026-08-11
**Mode:** remediation + verification
**Environment:** repository code (`prisma/schema.prisma`, `lib/`, `app/api/auth/register/*`, `app/(public)/register`), Prisma validation, TypeScript, ESLint, regression test suites, production build.

---

## 1. Original Finding

The remediation brief stated "Normal User/Consumer registration is missing or incomplete." A read-only trace of the entire registration surface was performed before any change.

## 2. Root Cause Assessment

**No defect existed in the backend.** Both canonical registration implementations are present, wired, and secure:

| Flow | Route | UI entry | Role | Status |
|---|---|---|---|---|
| Normal User/Consumer | `POST /api/auth/register/user` | `/register` → "I'm a Home Buyer" card → `HomeBuyerCard` → `CustomerEmailSignup` | `USER` | Complete |
| Mortgage Broker | `POST /api/auth/register/broker` | `/register` → "Join as a Mortgage Broker" → `GoogleContinueButton(callbackUrl=/setup)` or `/auth/signup` | `BROKER` + `Broker` profile | Complete |

Per the remediation brief's final rule ("If normal USER registration already exists somewhere else in the repository, DO NOT create another implementation… Do not manufacture a diff"), **no duplicate backend was created**. The only production code change made during validation was unblocking a pre-existing TypeScript build error in the landing `Hero.tsx` (see §7).

## 3. Canonical Registration Architecture

### USER (Consumer) registration

```
/register → Home Buyer card → CustomerEmailSignup (client form)
  ↓
POST /api/auth/register/user            (app/api/auth/register/user/route.ts)
  ↓ validate name/email format/password length (>= 8)
  ↓ rate limit  customerRegisterRateLimit (3/30min/IP)
  ↓ duplicate email check  → 409
  ↓ hashPassword (bcrypt, 10 rounds)   (lib/aes.ts)
  ↓ prisma.user.create { role: 'USER', isActive: true, emailVerified: false }
  ↓ sendUserVerificationEmail           (actions/email.action.ts)
  ↓ redirect /auth/verify-email?email=…
  ↓
POST /api/auth/verify-email → emailVerified=true, token single-use (SHA-256 hashed)
  ↓ redirect: claim → /claim-broker/continue; broker → /setup; USER → /
```

Login: Credentials `authorize` returns the user; the BROKER-only `emailVerified` gate does not apply to `USER` (documented asymmetric policy). `roleHome('USER') = '/'`.

### BROKER registration

```
/register → "Join as a Mortgage Broker" → GoogleContinueButton(/setup) OR /auth/signup
  ↓
POST /api/auth/register/broker          (app/api/auth/register/broker/route.ts)
  ↓ normalizeBrokerRegistrationInput + validateBrokerRegistrationInput
  ↓ CAPTCHA + terms check, brokerRegisterRateLimit
  ↓ createBrokerAccount                 (lib/broker-registration.ts)
  ↓   transactional: duplicate email/phone → DuplicateAccountError (409)
  ↓   create User { role: 'BROKER', isActive: true, emailVerified: false }
  ↓   create Broker { creationSource: 'SELF_REGISTERED', userId = user.id,
  ↓                   UNVERIFIED, FREE, isVisible: true, unique profileSlug }
  ↓   create BrokerSubscription { plan: 'FREE', isActive: true }  (same transaction)
  ↓ sendBrokerRegistrationEmails
  ↓ redirect /auth/verify-email?email=…
  ↓
verify → /setup (profile exists) → /broker/dashboard
```

Login: BROKER with `emailVerified === false` is blocked in `authorize` (auth.config.ts line 90-92). `roleHome('BROKER') = '/broker/dashboard'`.

## 4. Role Assignment (server-controlled)

- `POST /api/auth/register/user` hardcodes `role: 'USER'` — the request body is never read for role.
- `POST /api/auth/register/broker` hardcodes `role: 'BROKER'` via `createBrokerAccount` → `selfRegisteredBrokerDefaults.role`.
- The Google `signIn` callback creates new Google accounts with `role: 'USER'` hardcoded.
- Claim setup creates BROKER-role users only via the intended claim workflow.
- `ADMIN` is never assigned by any public registration path.

## 5. Security Controls Verified

| Control | Mechanism | Verified |
|---|---|---|
| Role injection | role hardcoded server-side; body ignored | PASS |
| Admin creation | no public path assigns `ADMIN` | PASS |
| Ownership injection | `broker.userId` set server-side to the created user's id | PASS |
| Subscription injection | FREE plan created inside canonical transaction; body never sets plan | PASS |
| Verification injection | `emailVerified: false` on create; verified only via SHA-256 token flow | PASS |
| Featured/status injection | `verificationStatus`/`brokerStatus`/`isVisible` server constants | PASS |
| Password hashing | `bcrypt` 10 rounds via `hashPassword` (lib/aes.ts) | PASS |
| Duplicate email | user route 409; broker route DuplicateAccountError 409; unique email/phone | PASS |
| User enumeration | resend-verification returns generic response for unknown/verified accounts | PASS |
| Verification bypass | token stored SHA-256 hashed, single-use, expiry enforced | PASS |
| Session integrity | C1: jwt callback never merges client `session.user`; DB refresh keyed by `token.email` | PASS |
| Redirects | `/register` redirects authenticated users via `roleHome`; verify-email role-aware redirect | PASS |
| Rate limiting | `customerRegisterRateLimit`, `brokerRegisterRateLimit`, `resendVerificationRateLimit` | PASS |
| CSRF/origin | claim mutations origin-guarded; registration uses POST JSON + SameSite session model | PASS |

## 6. Regression Tests

New suite `tests/registration-flow-security.test.ts` (14 tests):

1. USER registration creates role `USER` (server-controlled).
2. Duplicate email is rejected (unique constraint).
3. USER registration does not create a `Broker` profile.
4. BROKER registration creates User + Broker atomically (`SELF_REGISTERED`, `UNVERIFIED`, `FREE`, unique slug).
5. Client cannot select/inject `ADMIN`.
6. Ownership is server-bound (`broker.userId === user.id`).
7. Subscription is server-assigned `FREE` (client cannot inject FEATURED/PREMIUM).
8. Duplicate broker profile for an existing user is rejected (`ALREADY_A_BROKER`).
9. Self-registration creates **no** `BrokerClaim`.
10. Passwords are bcrypt-hashed, never plaintext, comparison works.
11. BROKER login is blocked until `emailVerified` (auth gate present).
12. USER verification lifecycle (emailVerified false on create; verification via token).
13/14. Redirect flows documented for USER and BROKER.

Existing suites re-run (no regressions):

| Suite | Result |
|---|---|
| `phase-16-critical-security-fixes` (C1/C2/C3) | 10/10 PASS |
| `phase-17-high-fixes` (H1/H2/H3) | 13/13 PASS |
| `phase-18-high-medium-fixes` (H4/H5/H6/H7) | 15/15 PASS |
| `phase-15-register-flow` | 2 PASS / 2 HTTP-skip |
| `phase-7-claim` | 1 PASS |
| `phase-6-admin-broker` | 6 PASS |
| `phase-3b-broker-policy` | 7 PASS |

## 7. Files Changed

- `tests/registration-flow-security.test.ts` — **added**: 14-test regression suite (no production code duplicated).
- `components/sections/landing/Hero.tsx` — **1-line type fix**: `ease: [0.25, 0.46, 0.45, 0.94] as const`. This unblocks a **pre-existing** TypeScript build error (committed at HEAD `5e8577c`, 2026-08-10, before this remediation; the rest of the file is untouched). Unrelated to registration — made only so `yarn build` could be validated.
- `docs/verification/USER-BROKER-REGISTRATION-VERIFICATION.md` — **added**: this document.

No authentication architecture, Prisma schema, or registration backend was modified.

## 8. Validation Results

| Category | Result |
|---|---|
| `npx prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS (0 errors) |
| ESLint (changed files) | PASS (registration test clean; Hero.tsx change adds no lint issue) |
| ESLint (full repo) | FAIL — 155 pre-existing errors in committed code (e.g. `types/resend.d.ts`), none from this work |
| Registration security suite | 14/14 PASS |
| C1–C3 + H1–H7 suites | 38/38 PASS |
| Auth/claim/broker suites | 16/16 PASS, 2 HTTP-skip |
| `yarn build` | PASS (after Hero.tsx type unblock) |

## 9. Previous Security Findings (C1–C3, H1–H7)

All remain intact (verified by re-running the C1–C3/H1–H7 suites and source inspection):

- **C1** JWT/session identity never merges client input. PASS
- **C2** Public broker contact resolves by `profileSlug` anonymously. PASS
- **C3** OAuth tokens / contactMessages excluded from client payloads. PASS
- **H1** Public contact details entitlement-gated. PASS
- **H2** Broker PATCH routes use strict allowlists. PASS
- **H3** Password reset at `/auth/reset-password`, tokens never logged. PASS
- **H4** No invalid `verificationStatus`/`verificationDocuments` writes. PASS
- **H5** FREE service-city limit enforced. PASS
- **H6** Stripe event ordering protected. PASS
- **H7** Claim recipient binding enforced. PASS

## 10. Remaining Limitations

- Google OAuth cannot be exercised end-to-end without provider credentials (existing limitation; service-layer coverage exists).
- Email delivery (verification) is not sent in this environment; delivery logic unchanged.
- The two `phase-15-register-flow` HTTP tests require a live server (`REGISTER_BASE_URL`) and were skipped in this run (documented behavior).
- Full-repo ESLint has pre-existing errors unrelated to registration.

## 11. Production Status

- **USER REGISTRATION = READY** (exists, wired, secure, regression-covered).
- **BROKER REGISTRATION = READY** (exists, wired, secure, regression-covered).
- This remediation is **production-safe**: no duplicate system was created, the canonical flows were preserved, and the pre-existing build blocker was unblocked.
