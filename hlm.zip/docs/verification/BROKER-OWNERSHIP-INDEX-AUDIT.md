# Broker Ownership Index Audit

## Rule

`Broker.userId` remains nullable. Multiple `null`/missing ownership values are allowed, while a non-null user ID may own only one Broker.

## Before Fix

The disposable reproduction showed:

```text
key: { userId: 1 }
name: brokers_userId_key
unique: true
partialFilterExpression: none
```

That ordinary unique index treats the first unowned `null` Broker as occupying the unique value and causes subsequent admin-created Brokers to fail with P2002.

## Reconciliation

`yarn db:ensure-ownership-index` now:

- inspects only the `brokers.userId` ownership indexes;
- reports duplicate non-null owner IDs and Broker IDs/profile slugs before changes;
- creates/verifies `brokers_userId_non_null_unique` with `{ userId: { $type: 'objectId' } }` partial filtering;
- removes only stale indexes on the exact `{ userId: 1 }` key;
- preserves Broker documents and unrelated indexes;
- reports `healthy` with no changes when the canonical index already exists;
- creates the `brokers` collection only when the target database has not created it yet.

The application-side preview ownership check uses a scalar `$indexStats` projection rather than returning raw partial-filter metadata through Prisma. This avoids Prisma 6.19.3's `Unknown tagged value` failure for Mongo's `$type` key while preserving the stale-index validation.

## Verification

- Stale `userId_1` disposable index reconciled to the partial canonical index.
- Re-running reconciliation reported `healthy` with no changes.
- Duplicate non-null ownership was detected and reconciliation aborted without index changes.
- Multiple unowned Brokers succeeded.
- Duplicate non-null owner rejected.
- Different non-null owner succeeded through the existing integration coverage.
- Three admin-created import rows with `userId=null` imported successfully against the partial index.
- Production database modified: NO.
