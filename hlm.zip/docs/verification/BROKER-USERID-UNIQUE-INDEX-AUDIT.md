# Broker userId Unique Index Fix Audit

## Root Cause

`Broker.userId` was declared `String? @unique @db.ObjectId`. Prisma generates a normal unique index (`brokers_userId_key`) for any `@unique` field, and MongoDB treats `null` as a distinct value in a normal unique index. Once multiple admin-created brokers existed with `userId = null`, `npx prisma db push` attempted to create `brokers_userId_key` and failed with `E11000 DuplicateKey { userId: null }`.

Additionally, Prisma enforces that a one-to-one relation must have a unique field on the defining side, so `@unique` could not simply be removed while keeping `User.brokerProfile Broker?`.

## Fix

- Removed `@unique` from `Broker.userId` (still `String? @db.ObjectId`, still nullable).
- Changed the relation to one-to-many: `User.brokerProfile Broker?` → `User.brokerProfile Broker[]`.
- Replaced all broker ownership lookups that relied on `userId` being unique (`findUnique`/`update` by `userId`) with `findFirst`/`update` by `id`:
  - `lib/auth.config.ts`
  - `lib/currentUser.ts`
  - `lib/claim-completion.ts`
  - `lib/broker-registration.ts`
  - `lib/broker-intent.ts`
  - `app/api/brokers/route.ts`
  - `app/api/brokers/me/route.ts`
  - `app/api/auth/verify-email/route.ts`
  - `app/api/auth/resend-verification/route.ts`
  - `actions/email.action.ts`
  - `app/api/user/profile/route.ts`
  - `app/broker/company/edit/page.tsx`
  - `tests/registration-flow-security.test.ts`
- The one-to-many relation is now backed by a MongoDB partial unique index (managed by the existing `scripts/ensure-ownership-index.ts`), so the business rule "one non-null user owns at most one broker" is still enforced by the database while multiple `userId = null` brokers are allowed.
- Added `db:ensure-broker-user-ownership-index` package alias (points to the same idempotent reconciliation script; `db:ensure-ownership-index` is retained for compatibility).

## Indexes

Before (problematic):

- `brokers_userId_key` — normal unique index, rejects multiple `null` userId values.

After:

- `brokers_userId_non_null_unique` — partial unique index `{ userId: 1 }` with `partialFilterExpression: { userId: { $type: 'objectId' } }`.
- `brokers_location_2dsphere` — 2dsphere on `location` (preserved, untouched).

The ownership reconciliation script:
- detects duplicate non-null owner groups and aborts before changing indexes;
- creates/verifies the partial unique index;
- removes only stale `userId` ownership indexes;
- never touches `brokers_location_2dsphere` or broker documents.

## Ownership

- `userId = null` (multiple) → allowed.
- `userId = userA` + `userId = userB` → allowed.
- `userId = userA` + `userId = userA` → rejected (verified by integration tests and the claim race test).

## Location

Existing broker location data (GeoJSON `location`, `normalizedAddress`, `googlePlaceId`, `locationCountryCode`, address fields) is untouched. No re-geocoding or re-import was performed. The 2dsphere index remains healthy.

## Radius

Radius search is unchanged (pure `$geoNear` on `Broker.location`, public eligibility, optional text search). No `serviceCities` dependency. The 2dsphere index remains present.

## Tests

- `tests/broker-userid-nullable.test.ts`: 6/6 passed.
- Ownership integration (`phase-6.5-integration.test.ts`): multiple unowned brokers allowed, duplicate non-null owner rejected, final index is partial and unique — passed. (One pre-existing subscription-rollback test fails on a fresh disposable DB because that DB lacks the unrelated `broker_subscriptions.brokerId` unique index, not because of this change.)
- Claim flow (`phase-7-claim.integration.test.ts`): 3/3 passed, including "two claimants race with exactly one ownership winner".
- Focused radius/visibility/import/location/search suites: passed (57 passed, 2 env-dependent skipped).

## Validation

- `npx prisma validate`: passed.
- `npx prisma generate`: passed.
- `npx tsc --noEmit`: passed.
- `yarn build`: passed.
- Changed-file ESLint: no errors (only pre-existing unused-var warnings).
- `git diff --check` (changed files): clean.

## Database Safety

- brokers deleted: 0
- broker location data modified: 0
- Prisma schema changes: `Broker.userId` `@unique` removed; `User.brokerProfile` changed to one-to-many (`Broker[]`).
- indexes created/removed: `brokers_userId_key` removed; `brokers_userId_non_null_unique` created/verified (partial); `brokers_location_2dsphere` untouched.
- production database modified: NO (disposable MongoDB only).

## Remaining

`npx prisma db push` should be inspected before use: it no longer generates `brokers_userId_key` for `userId`, but operators should rely on `yarn db:ensure-broker-user-ownership-index` and `yarn db:ensure-broker-location-index` for ownership/location indexes rather than a raw `db push` against a populated production database.
