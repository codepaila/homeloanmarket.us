# Broker Import Address-First End-to-End Audit

## Root Cause And Scope

The repository did not contain `Homeloanmarket Broker list - Houston - 2026-08-06.xlsx`, so the exact uploaded workbook could not be browser-tested. Source and disposable-Mongo verification used the actual documented Houston header contract and representative rows.

The import API/button path was present and correctly connected, but the parser did not derive location fields from the canonical `Address` column, did not recognize all documented aliases, and did not explicitly discard completely empty mapped rows. The preview also lacked the derived/location columns and gave no explicit parsing/validation progress message.

## XLSX Detection

Supported automatic headers now include:

- `Name`, `full name`, `broker name`
- `NMLS`, `NMLS number`, `NMLS id`
- `Zip code`, `zipcode`, `postalcode`, and related aliases
- `Phone`, `telephone`, `mobile`
- `Address`, `Office Address`, `officeAddress`, `Street Address`
- `Company Name`, `companyName`, `business name`
- `Email`, `Email Address`, `E-mail`
- `State`, `State Code`, `Province`

CamelCase headers are normalized before alias comparison, so `{}` mapping works for the supplied contract.

## Address Handling

`Address` remains the source of truth for `Broker.officeAddress`. A shared parser derives fields without reconstructing or replacing the source string:

```text
738 E 29th St, Houston, TX 77009
-> officeAddress: 738 E 29th St, Houston, TX 77009
-> city: Houston
-> state: TX
-> pinCode: 77009
```

If derivation fails, the source address remains importable and explicit source/default values remain available. No Google API calls are introduced into import.

## Preview And Confirm

Preview remains read-only: parse, normalize, validate, inspect indexes/conflicts, and return rows/summary only. Confirm reparses with the same file/options, revalidates, and persists per row using the existing modes:

- `CREATE_ONLY`: existing matches skipped; only missing Brokers created.
- `UPDATE_ONLY`: existing matches updated; missing Brokers skipped with `IMPORT_NOT_FOUND`.
- `UPSERT`: existing matches updated; missing Brokers created.

The UI now reports `Parsing and validating...`, surfaces `Preview failed: ...`, and displays Name, NMLS, Phone, Email, Office Address, City, State, ZIP, and Errors/Changes.

## Ownership And Visibility

Imported Brokers continue to use the existing admin-created defaults: `userId=null`, `creationSource=ADMIN_CREATED`, and `isVisible=false`. No User, Account, Claim, or owner is created by import. Existing conflict/index handling remains active, including the partial ownership-index preflight and row-safe P2002 handling.

## Validation

- Import tests with disposable Mongo lifecycle enabled: **16/16 passed**.
- Address parsing, Houston aliases, numeric normalization, empty rows, and UI progress/address coverage: passed.
- Prisma validation/generate: previously passed; schema unchanged.
- TypeScript: passed.
- Changed-file ESLint: passed.
- Production/public browser verification: not performed.
- Real Houston workbook: unavailable; no fabricated 62-row result claimed.
- Production database modified: NO.

## Remaining Verification

When the workbook is available, run the existing Admin flow and confirm the actual sheet name, populated row count, empty-row count, preview values, and import result against a disposable database before any production operation.
