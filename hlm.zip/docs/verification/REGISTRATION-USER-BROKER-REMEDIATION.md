# USER + BROKER Registration Remediation — Verification

**Date:** 2026-08-11
**Scope:** Targeted production remediation of the auth/registration flow (USER/Consumer + BROKER).
**Mode:** Audit + regression-test addition. No duplicate auth system introduced.

---

## 1. Original Defect (as reported)

The reported finding was: "Broker registration exists. Normal User/Consumer registration is missing or incomplete."

## 2. Root Cause Analysis

**The premise is incorrect for this repository.** The normal User/Consumer registration flow **already exists and is complete and connected to the UI.** The trace below is authoritative:

| Asset | Route / File | Status |
|---|---|---|
| Registration landing | `app/(public)/register/page.tsx` | Present — renders BOTH the "Home Buyer" card and the "Mortgage Broker" card |
| USER card | `components/auth/HomeBuyerCard.tsx` | Present — Google (`callbackUrl="/"`) or email |
| USER email form | `components/auth/CustomerEmailSignup.tsx` | Present — posts to `/api/auth/register/user` |
| USER API | `app/api/auth/register/user/route.ts` | Present — creates `role: 'USER'`, hashes password, sends verification email |
| BROKER card | `app/(public)/register/page.tsx` | Present — Google (`callbackUrl="/setup"`) or email |
| BROKER email form | `app/(public)/auth/signup/page.tsx` | Present — posts to `/api/auth/register/broker` |
| BROKER API | `app/api/auth/register/broker/route.ts` | Present — calls canonical `createBrokerAccount` |
| USER email verify | `app/api/auth/verify-email/route.ts` + `/auth/verify-email` | Present |
| Resend verification | `app/api/auth/resend-verification/route.ts` | Present (enumeration-resistant) |

## 3. Canonical Registration Architecture

### USER (Consumer)

```
/register → "I'm a Home Buyer" card
  → Google (callbackUrl "/")  OR  CustomerEmailSignup
  → POST /api/auth/register/user
  → server validates name/email/password (email regex, password ≥ 8)
  → rate limit (customerRegisterRateLimit, 3/30min/IP)
  → duplicate-email check (409, generic message)
  → bcrypt(password, 10)  [lib/aes.ts hashPassword]
  → prisma.user.create({ role: 'USER', isActive: true, emailVerified: false })
  → sendUserVerificationEmail (SHA-256 token, 24h expiry)
  → redirect /auth/verify-email?email=...
  → POST /api/auth/verify-email → emailVerified = true
  → USER home redirect (roleHome('USER') = '/')
```

### BROKER

```
/register → "Join as a Mortgage Broker" card
  → Google (callbackUrl "/setup")  OR  /auth/signup form
  → POST /api/auth/register/broker
  → normalize + validateBrokerRegistrationInput (canonical lib/broker-registration.ts)
  → CAPTCHA check + rate limit (brokerRegisterRateLimit)
  → createBrokerAccount (transactional):
      user.create({ role: 'BROKER', emailVerified: false })
      broker.create({ userId, creationSource: 'SELF_REGISTERED',
                      verificationStatus: 'UNVERIFIED', brokerStatus: 'FREE',
                      isVisible: true, profileSlug (unique) })
      subscription.create({ plan: 'FREE', isActive: true })   // atomic, once
  → sendBrokerRegistrationEmails
  → redirect /auth/verify-email?email=...
  → BROKER login requires emailVerified (auth.config.ts) → /broker/dashboard
```

## 4. Production-Safe Change Made

Per the workflow's final rule — "If normal USER registration already exists, DO NOT create another implementation" — **no duplicate backend or UI was created.** The only production code change required to reach a green, shippable state was unblocking a pre-existing build error (see §7). The registration flows themselves were left untouched; they were verified correct and are now covered by a dedicated regression suite.

## 5. Files Changed

| File | Change |
|---|---|
| `tests/registration-flow-security.test.ts` | **NEW** — 14 regression tests covering both flows |
| `components/sections/landing/Hero.tsx` | 1-line `as const` on `ease` array — unblocks a **pre-existing** `tsc`/build type error (unrelated to registration) |

No Prisma schema changes. No auth configuration changes. No new roles/models.

## 6. Security Controls Verified (Phase 7 audit)

| Control | Result |
|---|---|
| Role injection (`role=ADMIN`) | ❌ Impossible — role hardcoded server-side (`'USER'` / `'BROKER'`); client body is never read for role |
| Role override | ❌ Impossible — registration routes read only name/email/password (+ broker fields); no `role` key accepted |
| Broker ownership injection | ❌ Impossible — `userId` set by server from the newly created user; `createBrokerAccount` links the created user only |
| Subscription injection (FEATURED/PREMIUM) | ❌ Impossible — subscription is `FREE + active` only, created inside the transaction; client cannot pass a plan |
| Featured / verification / visibility injection | ❌ Impossible — `verificationStatus: 'UNVERIFIED'`, `brokerStatus: 'FREE'`, `isVisible` server-derived |
| Password hashing | ✅ bcrypt(10) via canonical `lib/aes.ts`; never stored plaintext (test-verified) |
| Duplicate email | ✅ 409 generic "account already exists"; DB unique on email; broker path also checks phone |
| User enumeration | ✅ duplicate/resend/verify use generic messages; resend returns the same message for unknown/verified accounts |
| Verification bypass | ✅ signup token is SHA-256 digest, 24h expiry, single-use clear; BROKER login gated on `emailVerified` |
| Session/identity | ✅ C1 intact — JWT derives identity only from server-issued user + DB refresh keyed by server email; no client `session.user` merge |
| Redirects | ✅ `/register` → roleHome; verify → claim-context or broker `/setup` or `/`; auth-redirect canonical helpers used |
| Rate limiting | ✅ per-IP limits on user/broker register and resend |

## 7. Regression Tests — Results

Suite: `tests/registration-flow-security.test.ts` — **14 pass / 0 fail / 0 skip**

- USER creates correct `USER` role (server-controlled)
- duplicate email rejected safely
- USER registration does not create a BrokerProfile
- BROKER created atomically with `SELF_REGISTERED`, `UNVERIFIED`, `FREE`, unique slug, linked FREE subscription
- role injection (ADMIN) impossible
- ownership injection impossible (server-linked userId)
- subscription injection impossible (FREE only)
- duplicate broker profile for an existing user blocked (`ALREADY_A_BROKER`)
- self-registration creates no BrokerClaim
- password stored bcrypt-hashed (format + comparison verified)
- USER/BROKER email-verification gating verified
- USER → home / BROKER → dashboard redirect contracts verified

## 8. Previous Security Findings — Re-confirmed Intact

| ID | System | Verification |
|---|---|---|
| C1 | JWT identity not client-overwritable | ✅ `auth.config.ts` jwt callback — no `session.user` merge; DB refresh keyed by server email |
| C2 | Public broker contact resolves by `profileSlug`, anonymous | ✅ `toPublicBrokerRecord` + slug resolution present |
| C3 | No OAuth tokens / contactMessages in client payloads | ✅ `currentUser.ts` explicitly excludes `accounts` / `contactMessages` |
| H1 | Contact details entitlement-gated | ✅ `includeContact` flag in public DTO |
| H2 | Broker PATCH strict allowlists | ✅ `pickBrokerEditableFields` present |
| H3 | Password reset `/auth/reset-password`, no raw token logging | ✅ present (unmodified) |
| H4 | No invalid verification writes | ✅ enum-only `UNVERIFIED | VERIFIED` |
| H5 | FREE service-city limit enforced | ✅ `maxServiceCitiesForEntitlement` |
| H6 | Stripe event ordering protected | ✅ `isStaleEvent` + in-flight registration |
| H7 | Claim recipient binding enforced | ✅ `isClaimRecipientMatch` |

Regression suites: `phase-16` (C1–C3) + `phase-17` (H1–H3) + `phase-18` (H4–H7) = **38 pass / 0 fail**.

Additional suites: `phase-15-register-flow` + `phase-7-claim` + `phase-6-admin-broker` + `phase-3b-broker-policy` = **16 pass / 2 skip** (2 HTTP-only tests require a live server with `REGISTER_BASE_URL`, matching documented behavior).

## 9. Validation

| Category | Result |
|---|---|
| `npx prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS (0 errors after unblocking pre-existing Hero.tsx `ease` type) |
| ESLint (changed files) | PASS — 0 errors on `tests/registration-flow-security.test.ts`; `as const` adds no issues |
| ESLint (full repo) | FAIL — **155 pre-existing errors** (e.g. `types/resend.d.ts` `no-explicit-any`, `Hero.tsx` `set-state-in-effect`, unused vars). **None introduced by this remediation.** |
| Registration regression suite | PASS — 14/14 |
| C1–C3 + H1–H7 suites | PASS — 38/38 |
| Registration + claim + admin + policy suites | PASS — 16 pass / 2 skip |
| `yarn build` | PASS (after the pre-existing Hero.tsx `as const` unblock) |

## 10. Remaining Limitations

- Email delivery (Resend) is not exercised end-to-end in this environment; delivery logic unchanged.
- Google OAuth end-to-end requires provider credentials; service-level behavior verified.
- The two `phase-15` HTTP tests require a running dev server (`REGISTER_BASE_URL=http://localhost:3000`).
- The repo-wide lint baseline (155 errors) is pre-existing and out of scope for this registration remediation.
- The USER `emailVerified` asymmetry is documented and intentional: a USER may sign in while unverified; a BROKER cannot.

## 11. Final Status

- **USER REGISTRATION = READY** (already implemented, verified, now regression-tested)
- **BROKER REGISTRATION = READY** (already implemented, verified, now regression-tested)
- This remediation is **production-safe**: no authentication architecture was changed, no duplicate system was created, and the only production-file edit was a 1-line type fix unblocking a pre-existing build failure.
