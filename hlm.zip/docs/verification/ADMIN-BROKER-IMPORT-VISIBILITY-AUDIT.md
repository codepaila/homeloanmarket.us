# Admin Broker Import Visibility Audit

## Root Cause

Admin-imported brokers were created through the shared `adminCreatedBrokerDefaults` in `lib/admin-broker.ts`, which hardcoded `verificationStatus: 'UNVERIFIED'` and `isVisible: false`. Both the bulk import (`lib/admin/broker-data.ts`) and manual admin create (`app/api/admin/brokers/route.ts`) spread these defaults into the `Broker.create` data. Because the public listing correctly requires `isVisible=true` + `VERIFIED`, every admin-imported broker was excluded from the public marketplace. `verifiedAt` was never set.

## Import Flow

Admin import / create → `adminCreatedBrokerDefaults` → `prisma.broker.create` → `Broker` state. The defaults were the single source of the wrong initial state.

## Fix

- `lib/admin-broker.ts`: `adminCreatedBrokerDefaults` now sets `verificationStatus: 'VERIFIED'` and `isVisible: true` (still `userId: null`, `creationSource: 'ADMIN_CREATED'`, `brokerStatus: 'FREE'`).
- `lib/admin/broker-data.ts` (import) and `app/api/admin/brokers/route.ts` (manual create): set `verifiedAt: new Date()` on creation.
- Self-registration is untouched (still `SELF_REGISTERED` + normal verification/onboarding lifecycle).

## Backfill

New `scripts/backfill-admin-created-broker-visibility.ts` (+ `db:backfill-admin-broker-visibility`, supports `--dry-run`):

- Targets only `creationSource = ADMIN_CREATED` AND `userId = null` AND `brokerStatus != SUSPENDED`.
- Promotes `UNVERIFIED` → `VERIFIED` (with `verifiedAt = new Date()`) + `isVisible = true`.
- Reveals `VERIFIED` + hidden → `isVisible = true` (verifiedAt preserved).
- Skips already-correct, SUSPENDED, owned (`userId != null`), and self-registered brokers.
- Idempotent: second run reports 0 changes.

Verified against a disposable DB (7 brokers): dry-run reported 2 unverified + 1 hidden-verified candidates; real run promoted 2 + revealed 1; second run changed 0. Suspended, owned, and self-registered records remained unchanged.

## Public Eligibility (unchanged)

Anonymous users still require `isVisible=true`, `VERIFIED`, not `SUSPENDED`, and (unowned `userId:null` or active owner). No eligibility weakening; `app/api/brokers/route.ts` was not changed.

## serviceCities

Not used for public geographic/radius eligibility (unchanged from prior work). Remaining occurrences are broker profile/business/registration/display usages only.

## Ownership

Imported brokers remain `userId = null`; `brokers_userId_non_null_unique` (partial unique) and `brokers_location_2dsphere` remain intact and untouched.

## Location

`Broker.location`, `normalizedAddress`, `googlePlaceId`, address fields, and the 2dsphere index are unchanged; no re-geocoding or re-import.

## Tests

- `tests/admin-broker-visibility-import.test.ts`: 5/5 passed (defaults, verifiedAt, backfill policy, public predicate, end-to-end import → public eligibility).
- Updated `phase-6-admin-broker.test.ts` and `broker-public-visibility.test.ts` for the new defaults.
- Import/radius/visibility/serviceCities/ownership/company-plan suites: 61 passed, 3 env-dependent skipped across the focused run.

## Validation

- Prisma validate/generate: passed
- TypeScript: passed
- Build: passed
- Changed-file ESLint: passed
- `git diff --check` (changed files): clean

## Database Safety

- brokers deleted: 0
- broker IDs changed: 0
- broker locations changed: 0
- userId ownership changed: 0
- schema changed: NO

## Remaining

Operators must run `yarn db:backfill-admin-broker-visibility --dry-run` then `yarn db:backfill-admin-broker-visibility` against the populated database to repair the existing ~62 admin-created records; this was not executed against production. A verified-but-`verifiedAt: null` existing record is left as-is by the reveal step (its timestamp is not fabricated). Browser verification was not performed.
