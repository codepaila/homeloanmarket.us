# Broker Admin Public Visibility Audit

## Business Requirement

Admin-created/imported Brokers use the existing Broker record and may become public independently of ownership. Claiming remains a separate ownership operation and attaches a User to that same Broker.

## Current Implementation

The canonical public eligibility policy is `isPublicBroker()`:

- `isVisible === true`
- `verificationStatus === VERIFIED`
- `brokerStatus !== SUSPENDED`
- unowned (`userId === null`) or owned by an active User

There is no blanket ownership requirement. `ADMIN_CREATED + userId=null + isVisible=true + VERIFIED + FREE` is therefore valid public state. Imported/admin-created defaults remain hidden and unverified until an administrator publishes/reviews them.

The public `/api/brokers` route and radius aggregation use the same visibility, verification, suspension, and unowned/active-owner conditions. The public slug page applies the same policy before rendering. City/state remain public location context; exact office contact fields remain behind the existing DTO contact entitlement.

## Root Cause

The public listing lifecycle was already correct. The confirmed defect was authorization scope: `isVisible` was included in the general broker-editable allowlist, allowing an owned Broker user to submit the generic Broker PATCH and change visibility. Visibility is an administrative publication decision, so it must be admin-only.

## Changes

- Removed `isVisible` from `BROKER_EDITABLE_FIELDS`.
- Added `isVisible` to `BROKER_ADMIN_FIELDS`.
- Preserved the existing admin-only `/api/admin/brokers/[id]` PATCH visibility control.
- Added focused visibility, security, import-default, claim, and radius regression tests.
- No listing query, claim flow, subscription, location, advertisement, or schema redesign was made.

## Visibility State

- `VISIBLE`: `isVisible=true`; still requires existing verification and active-status rules for public listing.
- `HIDDEN`: `isVisible=false`; excluded from non-admin listing, radius results, public detail, and metadata.
- `SUSPENDED`: excluded regardless of visibility.
- `UNVERIFIED`: excluded under the existing public verification policy.

Ownership and visibility remain independent. Claim completion updates only the existing Broker `userId` and claim state; it does not create a Broker or change `isVisible`.

## Imported Brokers

Imports remain `ADMIN_CREATED`, unowned, FREE, and initially hidden/unverified through `adminCreatedBrokerDefaults`. Admins can review, verify, and publish the imported Broker from the existing admin detail action. No User, owner, claim, or registration is created by import.

## Claim Compatibility

Claim invitation eligibility still requires an unowned `ADMIN_CREATED` Broker that is not suspended. Completion attaches ownership to the existing Broker record. The public listing policy continues to allow that record to remain public after claim completion.

## Public Listing And Radius

`GET /api/brokers`, `/brokers`, `/brokers/[slug]`, and `findBrokerIdsWithinRadius()` use the existing Broker query path. Visible imported/admin Brokers with valid location coordinates enter the same `$geoNear` path as manually created Brokers. Brokers without coordinates remain eligible for ordinary filters but cannot satisfy positive-radius searches.

## Security

- Only the admin broker PATCH route accepts visibility changes through an authenticated `ADMIN` session.
- Generic broker/company PATCH requests use the canonical allowlist and no longer accept `isVisible` from Broker users.
- Client input cannot set `userId`, `creationSource`, verification ownership, subscription, or claim state.
- Public DTOs continue to omit owner IDs, claim data, internal IDs, private contact fields, subscription metadata, and security fields unless the existing server entitlement permits contact fields.
- Hidden and suspended Brokers remain excluded from public listing/detail/radius paths.

## Tests

- Visibility policy tests cover visible/unowned, hidden, suspended, unverified, and active/inactive-owned states.
- Security tests verify visibility is admin-only.
- Import tests verify imported defaults remain hidden.
- Claim tests verify the same Broker record is retained.
- Radius/public query source tests verify the existing unowned visibility path.
- Focused run result: 27 passed, 3 environment-dependent search tests skipped.

## Validation

- Prisma validation: passed.
- Prisma generate: passed.
- TypeScript: passed.
- Build: passed.
- Changed-file ESLint: passed.
- Live browser verification: not available.
- Production database modified: NO.

## Live Verification

**Source verified:** public eligibility, admin mutation authorization, import defaults, claim preservation, DTO boundaries, and radius query conditions.

**Live browser verified:** not performed. No production Broker was modified.

## Remaining Issues

No confirmed visibility/ownership/listing blocker remains in source. A live controlled test should still verify one existing `ADMIN_CREATED`, verified, active, visible Broker through `/api/brokers`, then toggle it hidden and restore its original value without mass-editing production data.
