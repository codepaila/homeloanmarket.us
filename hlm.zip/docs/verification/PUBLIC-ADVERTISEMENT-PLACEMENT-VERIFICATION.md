# Public Advertisement Placement Verification

Date: 2026-08-11
Scope: Public rendering placement only

## Public Advertisement Mounts

| Route/surface | Previous | New | Status |
|---|---|---|---|
| `/` | Homepage hero/featured/CTA mounts | No public ad mounts | REMOVE FROM PUBLIC UI |
| `/about` | Shared layout mounts | No public ad mounts | REMOVE FROM PUBLIC UI |
| `/faq` | Shared layout mounts | No public ad mounts | REMOVE FROM PUBLIC UI |
| `/contact` | Shared layout mounts | No public ad mounts | REMOVE FROM PUBLIC UI |
| `/calculator` | `LOAN_CALCULATOR` mount | No public ad mount | REMOVE FROM PUBLIC UI |
| `/guides` | `BLOG_INLINE` mount | No public ad mount | REMOVE FROM PUBLIC UI |
| `/blog` | `BLOG_INLINE` mount | No public ad mount | REMOVE FROM PUBLIC UI |
| `/blog/[slug]` | `BLOG_INLINE` mount | No public ad mount | REMOVE FROM PUBLIC UI |
| `/brokers/[slug]` | `BROKER_PROFILE_HEADER` mount | No public ad mount | REMOVE FROM PUBLIC UI |
| shared header/footer/layout | Announcement, popup, mobile, footer mounts | No general public ad mounts | REMOVE FROM PUBLIC UI |
| `/brokers` | Generic `BROKER_LISTING` plus local mount | Local mount only at result bottom | KEEP / REFINED |
| Admin routes | Admin CMS and preview | Unchanged | ADMIN ONLY |
| Company dashboard | No public renderer | No public renderer | COMPANY ONLY |

Advertisement API routes, database records, admin CRUD, media ownership, lifecycle, and tracking were not removed or redesigned.

## Broker Listing

`BROKER_LISTING_LOCAL` remains the only public renderer mounted on `/brokers`.

It is mounted after the broker result section and pagination. It requires a validated search-location token and uses the same resolved search origin as broker radius search.

Local eligibility remains server-side and independently applies:

- active state;
- archive/delete state;
- schedule;
- device targeting;
- Company status/subscription;
- configured target radius; and
- local placement.

The local placement now permits square creatives only and renders multiple eligible ads in a responsive grid:

- mobile: one column;
- tablet: two columns; and
- desktop: up to three columns.

No eligible ads produce no local-resource container.

## Advertisement Engine

The existing advertisement engine was not redesigned. Preserved systems include:

- `AdvertisementRepository`;
- `AdvertisementService`;
- admin CRUD;
- media picker/upload;
- lifecycle and scheduling;
- device filtering;
- priority/order;
- `AdvertisementWrapper` tracking;
- impression/click routes; and
- existing generic placement records.

Only public renderer mounts and the local placement presentation were changed.

## Admin

Admin advertisement creation/editing remains available. `BROKER_LISTING_LOCAL` remains selectable in the existing placement picker and local target configuration remains server-validated through the existing Google location boundary.

No admin authorization, media ownership, Stripe, company billing, or advertisement CRUD behavior was changed.

## Company

Company registration, company subscription, company request/status, and restricted company dashboard behavior remain unchanged. Companies do not receive direct ad publishing or admin ad-management access.

## Tracking

Impression and click tracking remain in `AdvertisementWrapper`, `AdvertisementService`, and the existing public tracking routes. No tracking logic was changed.

## Tests

Passed:

- public placement integration tests: 13 passed in the focused run;
- local location/ad/company/H5 tests: 30 passed;
- C1-H7 and Stripe focused tests: 68 passed in the prior integration run;
- Prisma validation;
- Prisma generation;
- TypeScript; and
- production build.

Skipped:

- 6 environment-gated advertisement/search tests requiring live HTTP/database fixtures.

Unavailable/timed out:

- Browser/viewport automation was unavailable.
- The existing media-selector test timed out with a pending Promise.
- Full ESLint remains blocked by pre-existing repository-wide errors.

## Remaining Issues

- No live browser certification was available for 375px, 768px, 1024px, or 1440px.
- No populated live local-ad dataset was available for visual multi-square-ad verification.
- Existing generic advertisement API endpoints remain publicly callable by contract, but they are no longer mounted on general public pages.

## Files Changed In This Audit

- `app/(public)/page.tsx`
- `app/(public)/layout.tsx`
- `app/(public)/calculator/page.tsx`
- `app/(public)/guides/page.tsx`
- `app/(public)/blog/page.tsx`
- `app/(public)/blog/[slug]/page.tsx`
- `app/(public)/brokers/page.tsx`
- `components/layout/index.tsx`
- `components/layout/Header.tsx`
- `components/layout/Footer.tsx`
- `components/sections/broker/BrokerDetailClient.tsx`
- `components/advertisements/PublicAdvertisement.tsx`
- `lib/advertisements/formats.ts`
- `tests/phase-15.8-placement-integration.test.tsx`
- `tests/location-ads-contract.test.ts`
