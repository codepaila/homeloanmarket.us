# Broker Radius Filtering Audit

## Root Cause

Applying a radius returned no brokers because of a missing database geospatial index, compounded by silent error handling:

1. The radius query in `lib/location/broker-geo.ts` runs a Mongo `$geoNear` stage keyed on the `location` field. When the `brokers_location_2dsphere` index is missing, Mongo throws `error code 291: unable to find index for $geoNear query`.
2. The listing API caught this as a generic 500 `Failed to fetch brokers`, and the page (`useAllBrokers`) ignored the SWR `error`, silently rendering the empty state instead of reporting the failure.
3. `scripts/ensure-broker-location-index.ts` failed on a fresh/empty database (`ns does not exist`), so the index could not be created reliably, and it did not report a healthy/idempotent state.

Coordinates, units, and eligibility were verified correct: coordinates use GeoJSON `[longitude, latitude]`, radius is miles converted to meters (`radiusMiles * 1609.344`) with `spherical: true`, and public eligibility (`isVisible`, `VERIFIED`, not `SUSPENDED`, unowned or active owner) is preserved.

## Fix

- `scripts/ensure-broker-location-index.ts`: creates the `brokers` collection when missing; creates/verifies the `location` 2dsphere index; removes conflicting non-geospatial `location` indexes; reports `healthy` or `reconciled` idempotently.
- `lib/location/broker-geo.ts`: detects the missing-index `$geoNear` error and throws an actionable `Radius search is unavailable ... Run yarn db:ensure-broker-location-index.`
- `app/api/brokers/route.ts`: forwards the actionable radius message in the 500 response `message`.
- `app/(public)/brokers/page.tsx`: destructures `error` from `useAllBrokers` and renders a clear `Unable to load brokers` state with a retry action instead of silently showing an empty list.

## Radius / Coordinate Behavior

- GeoJSON `Point` coordinates are stored as `[longitude, latitude]`.
- Search `near` uses the same order; radius is miles converted to meters; `spherical: true`.
- Brokers without `location` coordinates are excluded from positive-radius results (expected). They remain available through normal city/state/ZIP/address filters. The existing geocoding path (admin "Resolve Location" and `db:backfill-broker-locations`) populates coordinates.
- Pagination is applied inside the geo `$facet` (`$skip` / `$limit`).

## Public Eligibility Behavior

Unchanged. Radius results for non-admin callers are filtered to `isVisible`, `VERIFIED`, not `SUSPENDED`, and either unowned (`userId: null`) or owned by an active user. Imported `ADMIN_CREATED` unowned brokers and claimed brokers both appear when eligible and within radius.

## Files Changed

- `scripts/ensure-broker-location-index.ts`
- `lib/location/broker-geo.ts`
- `app/api/brokers/route.ts`
- `app/(public)/brokers/page.tsx`
- `tests/broker-radius.test.ts`
- `tests/broker-radius-integration.test.ts`
- `docs/verification/BROKER-RADIUS-AUDIT.md`

## Tests

- `tests/broker-radius.test.ts`: 9/9 passed (units, coordinate order, eligibility, owner/unowned, pagination, index error, API forwarding, UI error state, radius sync/clear).
- `tests/broker-radius-integration.test.ts`: 3/3 passed against disposable Mongo (eligible unowned+claimed returned; hidden/unverified/suspended/inactive-owner/out-of-radius excluded; empty result; missing-index actionable error).

## Validation

- Prisma validate: passed
- Prisma generate: passed
- TypeScript: passed
- Build: passed
- Changed-file ESLint: passed
- `git diff --check` (changed files): passed
- Production database modified: NO

## Browser Verification

Not performed (no browser tooling). Radius behavior verified via disposable Mongo integration tests and source-level assertions.

## Remaining

Production operators must run `yarn db:ensure-broker-location-index` once, and imported brokers need coordinates (existing geocoding/backfill path) before they can appear in positive-radius results.
