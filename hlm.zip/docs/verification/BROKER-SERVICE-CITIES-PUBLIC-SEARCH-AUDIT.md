# Broker serviceCities Public Search Removal Audit

## Root Cause

`serviceCities` was historically used as a geographic proxy: the public broker API translated a selected city into `where.serviceCities = { has: city }` (and a `radius === 0` fallback from `locationCity`/`verifiedLocation.city`). This conflated a broker's self-declared service area with its physical office location, so a broker whose office was physically within a radius but whose `serviceCities` did not list that city could be excluded (and vice versa).

## Geographic Source of Truth

`Broker.location` (GeoJSON Point, geocoded from `officeAddress`/`city`/`state`/`pinCode`) is the sole geographic source. Public geographic discovery is:

address → geocoding → `Broker.location` → 2dsphere index → `$geoNear` → radius → public eligibility → optional text search → results.

## Removed (public search / geographic)

- `app/api/brokers/route.ts`: removed `if (city) where.serviceCities = { has: city }`.
- `app/api/brokers/route.ts`: removed the `radius === 0` `serviceCities` fallback (`where.serviceCities = { has: locationCity || verifiedLocation.city }`) and the now-unused `city`/`locationCity` reads.
- `lib/location/broker-geo.ts`: `baseMatch` contains no `serviceCities` (and no serviceCities/specialization/rating/experience/language/featured filters); radius is pure `$geoNear` + eligibility + optional text search.

## Preserved (legitimate non-search business)

- `serviceCities` remains a Prisma field and is used for broker profile display, registration/onboarding, admin management, import/export (optional column), and the service-city subscription limit (`assertServiceCityLimit` / `maxServiceCitiesForEntitlement`). It no longer affects public geographic discovery.

## Radius

`findBrokerIdsWithinRadius({ latitude, longitude, radiusMiles, page, take, search, admin })` runs `$geoNear` against `location` with `spherical: true` and `maxDistance = radiusMiles * 1609.344`, then public eligibility and optional text search. No `serviceCities` dependency.

## Public Eligibility (unchanged)

Anonymous users: `isVisible=true`, `verificationStatus=VERIFIED`, `brokerStatus != SUSPENDED`, and (unowned `userId:null` or active owner). Admin behavior unchanged. The signed location token is still required and validated.

## Location / Import

`Broker.location`, `normalizedAddress`, `googlePlaceId`, and `locationCountryCode` are generated from `officeAddress`/`city`/`state`/`pinCode`. CSV/Excel does not require latitude/longitude columns. The 2dsphere index (`brokers_location_2dsphere`) and partial ownership index (`brokers_userId_non_null_unique`) remain intact and unchanged.

## Tests

- `tests/broker-service-cities-search.test.ts`: 6/6 passed (static).
- `tests/broker-service-cities-geography.test.ts`: 2/2 passed (disposable Mongo) — empty/wrong/absent serviceCities all appear by location; a "Houston" service-city broker with a Dallas location does NOT appear; monotonic radius verified.
- Radius/visibility/listing suites: passed (30 total, 0 failures across the focused run).

## Validation

- Prisma validate/generate: passed
- TypeScript (`npx tsc --noEmit`): passed (removed a stale, git-ignored `.next/dev/types` artifact that was unrelated to source)
- Build (`yarn build`): passed
- Changed-file ESLint: passed
- `git diff --check` (changed files): clean
- Production database modified: NO

## Remaining serviceCities usages

All remaining occurrences are legitimate business/profile/registration/import/display/subscription-limit usages (see "Preserved"), with no public-search or geographic dependency.

## Browser Verification

Browser verification not performed.
