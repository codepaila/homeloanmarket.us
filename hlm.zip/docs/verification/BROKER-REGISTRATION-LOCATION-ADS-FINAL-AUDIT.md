# HomeLoanMarket Broker Ecosystem Final Audit

Date: 2026-08-11
Scope: Broker registration, Google/email auth, plan selection, onboarding, location, radius search, local ads, and company eligibility.

## 1. Executive Summary

The source implementation matches the approved broker ecosystem architecture. The final public advertisement refinement also matches the placement contract:

- general public pages have no mounted advertisements;
- `/brokers` has one `BROKER_LISTING_LOCAL` mount at the bottom of results;
- local ads require signed search-location context and active company/subscription state;
- local creatives are square-only and render in a responsive multi-card grid.

The implementation is source/build/test verified, but the complete feature is not fully live-certified because the reachable database contains 8 Brokers and 0 stored coordinates. Browser automation, live Stripe, Redis, email, and live company-ad workflows were unavailable.

## 2. Authoritative Product Flow

Current source supports:

```text
Google or email broker registration
→ explicit broker intent
→ BrokerRegistration
→ FREE or FEATURED selection
→ BrokerRegistrationSubscription
→ subscription-gated /setup
→ BrokerOnboardingDraft
→ server-validated US location
→ canonical Broker location
→ existing broker dashboard
→ /brokers location token
→ optional radius
→ Mongo $geoNear
→ BROKER_LISTING_LOCAL square ads
```

## 3. Documentation Reconciliation

Current verification documents were inspected. The older design document retains pre-implementation snapshots, which are explicitly superseded by its implementation update and this report.

The repository has no dedicated `docs/architecture/**` or `docs/security/**` directories. Relevant security and business contracts remain distributed across `docs/business`, `docs/verification`, and `docs/advertisement-management`.

## 4. Broker Registration Audit

Email registration uses `/auth/signup` and requests only account fields, CAPTCHA/security control, and terms. Broker profile fields are collected later by the onboarding wizard.

The route creates `User`, `BrokerRegistration`, and `BrokerOnboardingDraft`, but no completed Broker or BrokerSubscription. Duplicate email, password hashing, rate limiting, verification, and terms behavior remain server-controlled.

Status: **PASS / SOURCE VERIFIED**

## 5. Google OAuth Audit

The broker registration button first establishes a signed broker-intent cookie, then uses Google OAuth. `/broker-registration/continue` requires the intent, creates/resumes registration state, refreshes the session, and routes to plan selection.

Generic Google login does not enter this flow. Existing users are not converted without explicit intent. No unsafe account-linking configuration was added.

Status: **PASS / SOURCE VERIFIED; LIVE OAUTH UNAVAILABLE**

## 6. Email Registration Audit

Email verification redirects broker registrations to plan selection. Unverified broker credential login remains blocked. Broker intent is persisted in the database rather than inferred from `/setup`.

Status: **PASS / SOURCE AND REGRESSION VERIFIED**

## 7. Plan Selection Audit

FREE selection creates an active registration-owned FREE subscription without Stripe. FEATURED selection validates the server-side price, creates recurring Stripe Checkout, uses the shared billing lock, and stores registration metadata.

Client plan identifiers cannot establish entitlement without server validation.

Status: **PASS / SOURCE VERIFIED; LIVE STRIPE UNAVAILABLE**

## 8. Subscription Audit

`BrokerRegistrationSubscription` remains separate from established `BrokerSubscription`. `/setup` requires an active registration subscription. Final Broker creation materializes the selected subscription exactly once.

Existing BrokerSubscription ownership and Stripe webhook reconciliation remain preserved.

Status: **PASS / SOURCE VERIFIED**

## 9. Onboarding Audit

`BrokerOnboardingDraft` stores allowlisted draft data and current step. `/setup` restores the draft and requires active subscription state. Finalization uses the existing Broker creation transaction, service-city entitlement checks, duplicate protection, and session refresh.

Status: **PASS / SOURCE VERIFIED; LIVE BROWSER E2E UNAVAILABLE**

## 10. Google Location Audit

Location components use:

- `/api/location/autocomplete`;
- `/api/location/resolve`; and
- `/api/location/geocode`.

The server calls Google Places API (New) autocomplete at `places.googleapis.com/v1/places:autocomplete`, resolves selected places through the Places API (New) details endpoint, and uses Google Geocoding for ZIP/address resolution.

The configured server variable is `GOOGLE_MAPS_SERVER_API_KEY`. It is not `NEXT_PUBLIC_*`, does not reach client props, and was not found in generated static JavaScript.

Live development requests succeeded:

- Los Angeles autocomplete: HTTP 200, 5 suggestions;
- selected place resolution: HTTP 200, US address and coordinates;
- ZIP `90001`: HTTP 200, US address and coordinates.

Status: **PASS / LIVE SERVER VERIFIED; BROWSER UI UNAVAILABLE**

## 11. Coordinate Persistence Audit

Onboarding sends the selected place ID. The server resolves it again and persists a GeoJSON Point using `[longitude, latitude]`, plus normalized address, place ID, and country code.

Reachable database state:

| Metric | Result |
|---|---:|
| Brokers | 8 |
| Brokers with coordinates | 0 |
| Brokers missing coordinates | 8 |

New-broker persistence is source-verified. Existing-data radius readiness is not complete.

Status: **PARTIAL / BACKFILL REQUIRED**

## 12. Radius Search Audit

`/brokers` stores selected location and signed token state. `useAllBrokers` serializes location token, coordinates, and radius to `/api/brokers`.

Positive radius queries use `lib/location/broker-geo.ts` and Mongo `$geoNear`, converting miles to meters. Existing visibility, verification, active-owner, suspension, text, city, ZIP, specialty, rating, experience, language, featured, sorting, and pagination rules are composed.

Radius `0` means no radius restriction and uses normal resolved location filtering.

Source status: **PASS**

Live inside/outside/boundary result status: **NOT CERTIFIED**, because no Broker has stored coordinates.

## 13. Broker Listing Audit

The listing page maintains:

- location input;
- autocomplete suggestions;
- selected resolved location;
- ZIP geocoding;
- signed location token;
- Radius Search toggle; and
- 0-100 mile slider.

The radius toggle was added as a targeted correction because the previous implementation had the slider but no explicit toggle. Changing location resets radius-enabled state; changing radius preserves the selected location and resets pagination.

Status: **PASS / SOURCE VERIFIED; BROWSER VERIFICATION UNAVAILABLE**

## 14. Advertisement Placement Audit

Public mounts now classify as follows:

| Surface | Status |
|---|---|
| Homepage | No public ad mount |
| About/FAQ/Contact | No public ad mount |
| Calculator | No public ad mount |
| Guides/Blog/Blog detail | No public ad mount |
| Broker detail | No public ad mount |
| Shared header/footer/layout | No general public ad mount |
| `/brokers` | One local-resource mount after results |
| Admin | Existing CMS unchanged |
| Company dashboard | No public ad mount |

The advertisement engine, records, admin CRUD, media, scheduling, device targeting, and tracking remain intact.

Status: **PASS / SOURCE AND PLACEMENT TEST VERIFIED**

## 15. Local Advertisement Targeting Audit

`BROKER_LISTING_LOCAL` requires:

- active ad;
- valid schedule;
- device eligibility;
- US location target;
- target-radius match;
- active Company;
- active CompanySubscription; and
- a signed server-issued search-location token.

Raw browser coordinates are not authoritative. Multiple eligible ads are returned by the existing bounded public-ad query.

Status: **PASS / SOURCE VERIFIED; POPULATED LIVE DATA UNAVAILABLE**

## 16. Multiple Square Advertisement Audit

`BROKER_LISTING_LOCAL` permits `SQUARE` creatives only. The public component renders all eligible ads in an existing advertisement-card/tracking path using:

- one column mobile;
- two columns tablet; and
- three columns desktop.

Zero eligible ads produce no local-ad container. One or multiple eligible ads render without requiring a second ad engine.

Status: **PASS / SOURCE AND FOCUSED TEST VERIFIED**

## 17. Company Advertisement Audit

Company accounts remain normal `USER` accounts with CompanyMembership authorization. Company billing uses CompanySubscription, not BrokerSubscription. Company users cannot create Brokers, access Broker routes, claim Brokers, or publish ads.

Admin request review can associate an admin-created advertisement with a Company. Company status and active subscription are required for local-ad eligibility.

Status: **PASS / SOURCE VERIFIED; LIVE BILLING/ADMIN E2E UNAVAILABLE**

## 18. Security Audit

Verified/preserved:

- C1 JWT identity cannot be client-overwritten;
- C2 public contact uses canonical Broker resolution;
- C3 client DTOs exclude credentials/OAuth tokens/lead data;
- H1 contact fields remain entitlement-gated;
- H2 Broker allowlists remain enforced;
- H3 reset tokens remain hashed and single-use;
- H4 verification enum protection remains enforced;
- H5 FREE service-city limit remains enforced;
- H6 Stripe ordering/idempotency remains protected; and
- H7 claim recipient binding remains enforced.

Location tokens are signed, expiring, US-bound, and coordinate-validated. The Google key is server-only.

Status: **PASS / FOCUSED SECURITY TESTS PASSED**

## 19. Database/Index Audit

Verified in the reachable Mongo database:

- `brokers_location_2dsphere`;
- `brokers_userId_non_null_unique` partial ownership index;
- `users_phone_non_null_unique` partial optional-phone index;
- Broker registration unique/index structures;
- company subscription indexes; and
- advertisement target indexes.

The non-partial Broker ownership and User phone indexes were reconciled using the repository scripts after duplicate checks. No data was deleted.

Status: **PASS / INDEXES VERIFIED; COORDINATE DATA INCOMPLETE**

## 20. Test Results

Passed:

- Prisma validation;
- Prisma generation;
- TypeScript;
- production build;
- focused broker/location/company/H5/placement suite: 30 passed;
- C1-H7/Stripe focused suite: 68 passed;
- registration/security suite: 23 passed;
- Phase 7.5 integration: 11 passed after optional-phone index correction; and
- focused advertisement suite: 31 passed, 6 skipped.

Failed/skipped:

- Full ESLint: existing repository-wide errors;
- six advertisement/search tests: environment-gated;
- media-selector test: timed out with pending Promise.

## 21. Browser Verification

**Browser verification unavailable.**

No Playwright/browser automation is installed or available. Responsive behavior at 375px, 768px, 1024px, and 1440px is source/CSS verified but not browser-certified.

## 22. External Provider Limitations

- Google Places/autocomplete/resolve/geocode: live server requests passed; browser onboarding was not executed.
- Stripe: live Checkout, webhook, renewal, cancellation, and company billing were unavailable.
- Redis: live lock failure/concurrency testing was unavailable.
- Email: delivery testing was unavailable.
- Mongo: indexes were live-verified, but populated `$geoNear` boundary behavior was not testable with zero coordinates.

## 23. Confirmed Implemented Changes Reviewed

- Removed general public advertisement mounts.
- Removed generic public `BROKER_LISTING` mount.
- Kept one bottom-of-results `BROKER_LISTING_LOCAL` mount.
- Restricted local placement to square creatives.
- Added responsive multi-ad local grid.
- Updated placement regression tests.

No production code was modified during this final audit pass.

## 24. Remaining Issues

### MUST FIX BEFORE FULL PRODUCTION CERTIFICATION

- Backfill or otherwise populate validated coordinates for the 8 existing Brokers.
- Run populated inside/boundary/outside Mongo radius tests.
- Complete live Stripe/company billing certification.

### SHOULD FIX

- Add browser/Playwright certification.
- Resolve full repository ESLint baseline.
- Resolve existing media-selector timeout.

### INFRASTRUCTURE / TESTING GAP

- Browser automation unavailable.
- Live Stripe/Redis/email E2E unavailable.

## 25. Final Verification Matrix

| Area | Status | Evidence | Limitation |
|---|---|---|---|
| Google broker registration | PASS | Intent cookie and continuation source | Live OAuth unavailable |
| Email broker registration | PASS | Registration/security tests | Email delivery unavailable |
| Broker intent | PASS | Signed intent route/tests | Browser unavailable |
| Plan selection | PASS | FREE/FEATURED routes/source | Stripe E2E unavailable |
| Registration subscription | PASS | Separate model and gate | Live billing unavailable |
| Subscription gating | PASS | `/setup` status gate | Browser unavailable |
| Onboarding draft | PASS | Draft API/source | Browser unavailable |
| Onboarding completion | PASS | Transaction/source/tests | Existing data not exercised |
| Google autocomplete | PASS | Live HTTP 200 suggestions | Browser unavailable |
| Google resolve | PASS | Live HTTP 200 coordinates | Browser unavailable |
| ZIP geocoding | PASS | Live HTTP 200 | Browser unavailable |
| Coordinate persistence | PASS | Server write path | 0 existing coordinates |
| Broker GeoJSON | PASS | Source/schema | No populated live data |
| 2dsphere index | PASS | Live Mongo index | None |
| Radius toggle | PASS | UI source/test | Browser unavailable |
| Radius API | PASS | Hook/API/token source | Live results unavailable |
| Radius filtering | NOT LIVE-VERIFIED | `$geoNear` source | 0 coordinate records |
| Existing filters + radius | PASS | Geo query composition | Live data unavailable |
| Broker location token | PASS | Signing/verification tests | None |
| Local ad targeting | PASS | Server target/radius source | No populated ad data |
| Local ad radius | PASS | Server distance logic | Live data unavailable |
| Multiple square ads | PASS | Format/grid/tests | Browser unavailable |
| Public-page ad removal | PASS | Mount audit/tests | Browser unavailable |
| Company eligibility | PASS | Company/subscription checks | Live billing unavailable |
| Ad authorization | PASS | Admin/source/security tests | Live admin unavailable |
| Google key security | PASS | Server-only source/bundle inspection | None |
| TypeScript | PASS | `npx tsc --noEmit` | None |
| Build | PASS | `yarn build` | None |
| Prisma validation | PASS | `yarn prisma validate` | None |
| Relevant tests | PASS WITH SKIPS | Focused suites passed | Environment skips/timeout |
| Browser verification | UNAVAILABLE | No browser runtime | Required for final UI certification |

## 26. Production Recommendation

**CONDITIONAL GO**

The implementation and security boundaries are internally consistent and the focused validation stack passes. Full production certification remains conditional on validated coordinate backfill, populated radius boundary tests, live company Stripe testing, and browser verification.
