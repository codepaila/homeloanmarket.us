# Company Advertising Plan Separation Audit

## Objective

"Join as Company" uses its own advertising subscription product and plans, fully separate from broker subscription plans.

## Root Cause / Gap

The company advertising product already had a separate `CompanySubscription` model and a separate Stripe price (`STRIPE_COMPANY_AD_PRICE_ID`) with `ownerType: 'COMPANY'` metadata, and the webhook already dispatched broker → registration → company by `stripeCustomerId`. However, there was no dedicated company advertising plan model: company checkout used a single hardcoded price/plan (`plan: 'ADVERTISING'`) rather than a plan-driven catalog, and there was no admin plan management.

## Changes

- **Prisma**: added `CompanyAdvertisingPlan` (id, `name` @unique, description, price, billingInterval, `stripeProductId`, `stripePriceId` @unique, features, isActive) and linked it to `CompanySubscription` via nullable `planId` + `advertisingPlan` relation (keeping the existing `plan String` for backward compatibility).
- **`lib/company-plan.ts`** (new): `getActiveCompanyAdvertisingPlans`, `getCompanyAdvertisingPlan`, `resolveCompanyPlanForCheckout`, `resolveCompanyPlanByStripePrice`.
- **Company checkout** (`app/api/company/subscription/checkout/route.ts`): resolves an active `CompanyAdvertisingPlan` (by optional `planId`, else first active plan), uses `plan.stripePriceId` (with the env price as fallback), and records `planId`/`plan.name` on the subscription and Stripe metadata.
- **Webhook** (`lib/subscription.ts` `updateCompanySubscriptionFromStripe`): now receives the Stripe `priceId`, resolves the matching `CompanyAdvertisingPlan` via `resolveCompanyPlanByStripePrice`, and records `planId`/`plan` on the `CompanySubscription`.
- **Admin API** (`app/api/admin/company-advertising-plans/route.ts`): admin-only create/update/list of company advertising plans.
- **Public plan selector** (`app/api/company/subscription/plans/route.ts`): lists active company advertising plans (no Stripe IDs exposed).
- **Seed** (`scripts/ensure-company-advertising-plan.ts` + `db:ensure-company-advertising-plan`): idempotently creates/updates a default `ADVERTISING` plan.

## Separation Guarantees

- Broker plans are the `SubscriptionPlan` enum (`FREE`/`FEATURED`/`PREMIUM`) on `BrokerSubscription`; company plans are `CompanyAdvertisingPlan` records on `CompanySubscription`. There is no cross-link.
- Broker checkout continues to use broker `subscriptionPlans`; company checkout uses only `CompanyAdvertisingPlan`. `getPlanForStripePrice` (broker) never consults company plans.
- The webhook updates `CompanySubscription` only when the Stripe customer belongs to a company subscription; broker/registration subscriptions are handled by their own branches. `updateCompanySubscriptionFromStripe` never writes a broker subscription.
- Stripe isolation: company plans carry their own `stripeProductId`/`stripePriceId`; broker prices remain separate.

## Tests

- `tests/company-plan-isolation.test.ts`: 7/7 passed.
- Existing `company-account-contract.test.ts` (dedicated company models, separate billing): passed.
- Stripe subscription integrity/concurrency suites (phase-21, phase-22): passed (63 total, 0 failures across the focused run).

## Validation

- Prisma validate/generate: passed
- TypeScript (`npx tsc --noEmit`): passed
- Build (`yarn build`): passed
- Changed-file ESLint: passed
- `git diff --check` (changed files): clean
- Production database modified: NO (disposable MongoDB only)
- Broker data / location / ownership index: unchanged

## Remaining

The company dashboard still shows a single "Start advertising subscription" button (single active plan); a full plan-selection UI in the dashboard was not added — plans are selectable via the checkout `planId` and the public plans endpoint. Admin plan management is API-only (no admin UI page was added). Browser verification was not performed.
