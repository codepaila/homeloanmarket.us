# Broker Registration, Location, and Company Design

Status: Phase 0 audit, Phase 1 design proposal, and implementation record
Mode: Read-only production audit plus design only
Date: 2026-08-11

Sections describing the pre-implementation current architecture are retained as the historical baseline. The implementation update and `BROKER-REGISTRATION-LOCATION-ADS-INTEGRATION-VERIFICATION.md` record current source behavior; current source supersedes those historical snapshots.

## Implementation Update

The broker registration slice is implemented in the current worktree:

- minimal email broker registration;
- explicit Google broker-intent cookie and continuation;
- `BrokerRegistration` state;
- `BrokerRegistrationSubscription` pre-profile ownership;
- `BrokerOnboardingDraft` durable draft storage;
- FREE/FEATURED selection before onboarding;
- subscription-gated `/setup`;
- session refresh after Google intent promotion;
- idempotent Broker creation using the selected subscription; and
- non-destructive `db:ensure-broker-registration-indexes` reconciliation tooling.
- non-destructive `db:ensure-user-phone-index` reconciliation tooling for optional User.phone values.

The location and local-advertisement slices are also implemented at source level:

- additive Broker canonical location fields;
- server-only US Google autocomplete/place-resolution/geocoding service;
- validated location endpoints;
- signed search-location tokens preventing arbitrary coordinate injection;
- Mongo `$geoNear` radius query layer and location index reconciliation tooling;
- 0-100 mile radius UI with `0` meaning no radius restriction;
- resumable canonical broker location storage from selected place IDs;
- separate `BROKER_LISTING_LOCAL` placement;
- server-validated advertisement location targets;
- bottom-of-results Related Local Resources rendering; and
- multiple targeted-ad eligibility with existing lifecycle/device/order behavior.

The company slice is implemented at source level with:

- dedicated Company, membership, subscription, and advertisement-request models;
- normal `USER` authentication without an advertiser role;
- restricted company dashboard;
- company-owned recurring Stripe subscription;
- Stripe promotion-code support at Checkout;
- company cancellation/portal paths; and
- admin request review API while actual ad creation remains admin-owned.

Validation for this slice:

- `npx prisma validate`: passed;
- `npx prisma generate`: passed;
- `npx tsc --noEmit`: passed;
- `yarn build`: passed;
- `tests/broker-registration-gate.test.ts`: 4 passed;
- `tests/phase-19-h5-creation-limit.test.ts`: 11 passed; and
- existing `tests/registration-flow-security.test.ts` plus `tests/phase-3b-broker-policy.test.ts`: passed in the focused run.
- `tests/location-ads-contract.test.ts`: 4 passed.
- `tests/company-account-contract.test.ts`: 2 passed.

No database push or coordinate backfill was executed against the configured database. The location `2dsphere` and existing Broker ownership indexes were reconciled non-destructively after duplicate-owner verification. Google provider E2E, Stripe provider E2E, email delivery E2E, and browser E2E were not executed.

The source implementation is complete for the requested feature slices. Database synchronization/index creation, coordinate backfill, and external Google/Stripe/browser/live Mongo verification remain pending.

This document records the independent source verification requested before implementation of:

- broker registration refinement;
- Google-backed US location selection and HomeLoanMarket radius search;
- location-targeted broker-listing advertisements; and
- company advertising accounts.

No production code, Prisma schema, migration, API, UI, authentication, authorization, advertisement, dashboard, claim, or Stripe implementation was changed for this phase.

## 1. Audit Scope and Evidence

### Repository documentation inspected

The following documentation sets were inspected:

- `docs/verification/**`;
- `docs/business/**`;
- `docs/advertisement-management/**`;
- `docs/FINAL-PRODUCTION-READINESS-AUDIT.md`;
- `docs/business/33-CLAIM-CONTRACT.md`;
- the C1-C3 security remediation report;
- the H1-H7 remediation material;
- the Phase 1K and Phase 1L Stripe remediation reports; and
- the latest final production-readiness reports.

The requested `docs/architecture/**` and `docs/security/**` directories do not exist in the current repository. Security and architecture rules are distributed across `docs/business`, `docs/verification`, and `docs/advertisement-management`.

The requested `docs/CLAIM-CONTRACT.md` does not exist. The repository's claim contract is `docs/business/33-CLAIM-CONTRACT.md`.

The supplied BROKER REGISTRATION + LOCATION SEARCH ARCHITECTURE AUDIT is not present as a repository file. Its conclusions were compared with the current source and are identified below as supplied-audit findings rather than repository-document findings.

### Evidence precedence

The current source is authoritative. Documentation is treated as business and security intent, historical evidence, or a remediation claim until the source confirms it.

Historical documents conflict on production readiness. The root `docs/FINAL-PRODUCTION-READINESS-AUDIT.md` says NO-GO, while `docs/verification/FINAL-PRODUCTION-READINESS-AUDIT-FINAL.md` says GO. Phase 1K and 1L claim source/test-level Stripe remediation but explicitly retain unavailable live Stripe/Redis certification. This design does not convert either historical verdict into a new production certification.

## 2. Phase 0 Current Architecture

### 2.1 Authentication and sessions

Primary files:

- `lib/auth.ts`
- `lib/auth.config.ts`
- `lib/currentUser.ts`
- `lib/auth-redirect.ts`
- `proxy.ts`
- `app/api/auth/[...nextauth]/route.ts`
- `app/providers/SessionProvider.tsx`

Auth.js uses the Prisma adapter and JWT sessions. The JWT callback refreshes identity claims from the database using the server-issued token email. It does not merge client-supplied `session.user` data into the JWT. This confirms the C1 remediation remains present.

The session includes role, active state, email-verification state, and broker profile summary. `getCurrentUser()` deliberately selects safe User scalars and excludes password, reset tokens, verification tokens, OAuth accounts, and contact messages. The current `app/broker/profile/edit/page.tsx` also constructs an explicit `profileUser` projection before passing it to the client component. The C3-equivalent leak described in the root 2026-08-10 audit is not present in the current worktree source path.

The current remaining session constraint is architectural: role changes made by a transaction require an explicit session refresh before middleware sees the new role. `BrokerSetupWizard` and claim completion pages currently call `useSession().update()` before dashboard navigation.

`proxy.ts` is a route-level guard, not the authoritative business authorization boundary. It:

- decodes the Auth.js JWT;
- exposes public routes and public APIs;
- returns JSON `401` for unauthenticated protected APIs;
- requires `ADMIN` for `/admin`;
- requires `BROKER` for `/broker`; and
- permits `/setup` to reach the client page without a server-side broker-intent check.

The current `/setup` exception is material to the new design. A normal `USER` can still reach the setup page after authentication, and the page itself does not require a durable broker-registration intent before rendering the wizard.

### 2.2 Current email broker registration

Trace:

```text
app/(public)/register/page.tsx
  -> /auth/signup
  -> app/api/auth/register/broker/route.ts
  -> lib/broker-registration.ts:createBrokerAccount
  -> User + Broker + BrokerSubscription transaction
  -> email verification
  -> /setup
  -> existing broker detected
  -> /broker/dashboard
```

`app/(public)/auth/signup/page.tsx` currently asks for:

- full name;
- email;
- phone;
- password and confirmation;
- company name;
- description;
- office address;
- city;
- state;
- ZIP;
- CAPTCHA;
- terms; and
- optional marketing consent.

`app/api/auth/register/broker/route.ts` normalizes and validates all of those fields, applies the broker registration rate limiter, checks the client-generated CAPTCHA answer, requires terms, and calls `createBrokerAccount`.

`createBrokerAccount` transactionally:

1. checks duplicate email or phone;
2. creates a lower-case email User with a bcrypt password;
3. assigns `role: BROKER`;
4. sets `isActive: true` and `emailVerified: false`;
5. creates a complete owned `SELF_REGISTERED` Broker;
6. sets the Broker to `UNVERIFIED`, `FREE`, and visible;
7. creates an active FREE `BrokerSubscription`; and
8. returns the new User and Broker.

The registration API sends verification/admin email after the transaction and redirects to `/auth/verify-email`. Broker credential login rejects an unverified broker. Verification redirects a broker with a profile to `/setup`; `/setup` immediately sends that user to `/broker/dashboard`.

Confirmed gap: initial email registration violates the target minimum-data requirement and creates the completed broker profile and FREE subscription before subscription selection.

### 2.3 Current Google broker registration

Trace:

```text
app/(public)/register/page.tsx
  -> GoogleContinueButton(callbackUrl="/setup")
  -> Google provider
  -> Auth.js / Prisma adapter
  -> new user defaults to USER
  -> /setup
  -> BrokerSetupWizard
  -> POST /api/brokers
  -> createBrokerForExistingUser
  -> role BROKER + Broker + FREE subscription
  -> session update
  -> /broker/dashboard
```

`lib/auth.config.ts` maps Google profile fields to name, email, image, and `role: USER`. The sign-in callback creates a new database User with `role: USER` if the email does not already exist. Existing users are not recreated.

The broker registration button supplies `/setup` as the callback URL, but the OAuth flow does not persist a durable broker-registration intent. `/setup` is therefore the implicit broker-intent boundary.

Current source now confirms that the historical F6 defects have been remediated:

- `app/api/brokers/route.ts` accepts both `pinCode` and wizard `zipCode`;
- the route no longer creates a second subscription;
- the route no longer redundantly promotes the role;
- the response uses `broker.profileSlug`; and
- `createBrokerForExistingUser` keeps broker, subscription, bank partnerships, and role promotion in one transaction.

The Google path remains architecturally unsuitable for the target because:

- a new Google broker starts as `USER`;
- an existing ordinary `USER` can reach `/setup` without a durable broker intent;
- broker intent is represented only by navigation to `/setup`; and
- the profile and FREE subscription are still created before any subscription choice.

This does not silently convert every Google login into a broker. It does, however, allow an authenticated normal user who can reach `/setup` to enter the broker creation path without the explicit intent/state model required by the target.

### 2.4 Existing-user and duplicate behavior

Email broker registration checks email or phone and maps the application duplicate error to HTTP `409`.

Normal USER registration checks email and maps an existing account to HTTP `409`.

Google sign-in checks the database by email before its explicit create branch. Auth.js/Prisma account-linking behavior remains provider-controlled; the application does not add a custom unsafe email-linking override. New broker intent must not weaken this boundary.

`createBrokerForExistingUser` rejects an existing Broker for the User. `POST /api/brokers` also checks for an existing Broker before calling the transactional helper.

Existing users must be handled by an explicit broker-registration action. A visit to `/setup`, an arbitrary callback URL, an email match, or a Google login alone must not be treated as broker intent.

### 2.5 Subscription ownership and ordering

`BrokerSubscription` is currently owned by `Broker` through a required unique `brokerId`. Current Stripe routes and actions require `user.brokerProfile`.

Current FREE behavior:

- direct email registration creates FREE inside the Broker transaction;
- existing-user onboarding creates FREE inside `createBrokerForExistingUser`; and
- claims retain/create FREE according to the claim contract.

Current FEATURED behavior:

- a broker creates or reuses a Stripe customer;
- customer ownership is checked locally and remotely;
- plan/price is validated server-side;
- checkout uses deterministic idempotency and a broker billing lock;
- webhooks update local subscription state; and
- cancellation/upgrade/portal/invoice paths use ownership and reconciliation helpers.

The current subscription architecture cannot represent a paid or free broker-registration state before a Broker exists without either fake profile data or a new pre-profile ownership model. The target explicitly rejects a fake/placeholder BrokerSubscription, so this is a genuine design/schema boundary.

### 2.6 Broker onboarding and dashboard

`app/setup/page.tsx` and `components/sections/broker/BrokerSetupWizard.tsx` implement the current multi-step profile wizard. It collects the existing broker profile fields, including contact, office location, professional details, service cities, languages, and bank partnerships.

The wizard submits the complete profile to `POST /api/brokers`. It does not persist partial drafts. `currentStep` is client state only, and a refresh loses incomplete data.

The current route protects duplicate completion by checking for an existing Broker and the transactional helper checks again. It does not have a durable onboarding state, subscription gate, or server-side broker-intent gate.

`app/broker/dashboard/page.tsx` and the existing Broker dashboard remain the canonical destination. FREE owners retain dashboard access; paid entitlements add paid analytics/features. The dashboard must not be redesigned for this initiative.

### 2.7 Current broker search

Trace:

```text
app/(public)/brokers/page.tsx
  -> hooks/useClient.ts:useAllBrokers
  -> GET /api/brokers
  -> Prisma Broker.findMany + count
  -> public broker DTO
  -> BrokerGridCard / pagination
```

Current filters include:

- city via `serviceCities has`;
- ZIP via case-insensitive string contains on `pinCode`;
- specialization;
- minimum rating;
- verification status;
- broker status;
- minimum experience;
- language; and
- free-text matching on name, company, description, address, city, state, and ZIP.

Non-admin results require:

- `isVisible = true`;
- `verificationStatus = VERIFIED`;
- non-suspended status; and
- an active owning user where ownership exists.

The API uses offset pagination and sorts by broker status, featured rank, rating, and experience. These rules must remain unchanged around a future geospatial stage.

### 2.8 Current location storage

`Broker` currently stores:

- `officeAddress`;
- `city`;
- `state`;
- `pinCode`; and
- `serviceCities` as a string array.

There are no latitude, longitude, GeoJSON, Google Place ID, normalized address, geocoding, or address-validation fields.

`lib/location.ts` and `/api/states`/`/api/cities` use the `countries-states-cities` package for static US state/city lists. They are not Google integrations and do not resolve coordinates.

Repository search found no Google Places, Maps, geocoding, autocomplete, latitude/longitude, `$near`, `$geoNear`, `2dsphere`, or existing raw Mongo geospatial query implementation.

### 2.9 Current advertisement architecture

The current advertisement system is an internal admin CMS, not an external advertiser platform. Documentation and source establish:

- admin-only creation/edit/publish/lifecycle;
- media assets and creative assignments;
- placement enum values;
- priority and display ordering;
- schedule and device filters;
- bounded canonical slot heights;
- public anonymous delivery; and
- impression/click tracking.

Relevant current files:

- `prisma/schema.prisma`;
- `app/api/ads/public/route.ts`;
- `lib/advertisements/advertisementRepository.ts`;
- `lib/advertisements/services.ts`;
- `components/advertisements/PublicAdvertisement.tsx`;
- `components/advertisements/AdvertisementRenderer.tsx`;
- `app/admin/ads/new/page.tsx`; and
- `app/admin/ads/[id]/edit/page.tsx`.

The public broker page currently mounts the generic `BROKER_LISTING` placement near the top of the page. The public ad endpoint filters by placement, lifecycle, schedule, and device, but not by search location.

There is no ad location, target city, target ZIP, latitude, longitude, radius, company owner, or request relation. `AdEvent.city` is tracking context only and cannot be used for eligibility.

Advertisement documentation contains stale legacy statements, including the original internal-CMS/no-advertiser model and older media/placement details. Current source plus the format verification matrix is authoritative for preserving the existing engine.

### 2.10 Current company/account architecture

The Prisma schema has:

- `UserRole.USER`, `BROKER`, and `ADMIN`;
- no Company model;
- no company membership relation;
- no company subscription;
- no advertisement request model; and
- no company dashboard.

`Broker.companyName` is only a broker profile field. `app/broker/company/page.tsx` is a broker company-profile page, not an independent company account. Company routes and APIs currently refer to broker profile data.

The requested company capability cannot be represented cleanly with `Broker.companyName` or `BrokerSubscription`. A separate company entity and ownership model are required. No `ADVERTISER` role should be introduced.

### 2.11 Security and business-rule preservation

The following current controls are preserved as constraints for the design:

- C1: JWT identity is not client-overwritable;
- C2: public contact resolves the Broker server-side and enforces public eligibility;
- C3: generic current-user data and client DTO boundaries exclude secrets/lead PII;
- H1: protected contact data is entitlement-gated;
- H2: broker update fields use allowlists;
- H3: reset tokens are hashed, expiring, and single-use;
- H4: verification writes use the valid enum;
- H5: FREE service-city limits are server-enforced;
- H6: Stripe webhook ordering and processing state are protected; and
- H7: claim recipient binding is checked at email and completion.

Claim ownership remains separate from direct broker registration. Direct registration must never create a claim. Claim completion must continue attaching an existing unowned Broker and must never create a second Broker.

## 3. Phase 0 Gap Confirmation

| Area | Current source | Target | Confirmed gap |
|---|---|---|---|
| Initial broker form | Full profile and phone | Account fields only | Yes |
| Broker intent | Mostly route/callback convention | Durable explicit intent | Yes |
| Google new broker | New User, then `/setup` | Same explicit broker flow | Yes |
| Existing USER | Can enter setup path | Explicit intent and controlled transition | Yes |
| Subscription owner | Required Broker | Pre-profile registration owner | Yes |
| FREE selection | Automatic during Broker create | Explicit before onboarding | Yes |
| FEATURED selection | Existing post-profile checkout | Before onboarding | Yes |
| Onboarding resume | Client-only form state | Durable incomplete state | Yes |
| Onboarding authorization | `/setup` lacks server intent gate | Intent required | Yes |
| Broker coordinates | None | Canonical persisted location | Yes |
| Google location | None | Utility-only integration | Yes |
| Radius query | None | Mongo geospatial query | Yes |
| Ad targeting | None | Broker-listing local-resource targeting | Yes |
| Company account | No Company model | Company capability without advertiser role | Yes |
| Company billing | Broker-only | Separate company ownership | Yes |
| Coupon | No company coupon flow | Stripe-authoritative promotion mechanism | Yes |

Historical findings that are different in current source:

- The F6 existing-user `/api/brokers` defects described in the 2026-08-09 audit are fixed in the current source.
- The stale JWT role-promotion path is mitigated by session refresh in the current setup and claim UIs.
- The C3 alternate profile-edit DTO issue described by the root 2026-08-10 audit is fixed in the current source path.
- The public subscription page currently posts both `priceId` and `plan`.

These fixes are not reimplemented by this design phase.

## 4. Phase 1 Target Architecture

### 4.1 Design principles

1. Preserve the existing Auth.js, User, Account, claim, Broker, dashboard, entitlement, advertisement, and Stripe security boundaries.
2. Add explicit workflow state instead of inferring intent from `/setup` or profile existence.
3. Do not create placeholder Broker profile data merely to satisfy current billing ownership.
4. Keep broker profile creation after subscription selection and onboarding completion.
5. Keep Google limited to OAuth identity and location utility operations; never use Google as a broker data source.
6. Keep company users as authenticated normal users with company capability, not an `ADVERTISER` role.
7. Keep admin authority for actual advertisement creation and publication.
8. Make all new state transitions server-authoritative and auditable.

### 4.2 Proposed broker registration state

Introduce a durable broker-registration workflow entity associated one-to-one with a User. Proposed conceptual fields:

```text
BrokerRegistration
  id
  userId
  intentStatus
  emailVerification/activation state reference or status
  subscriptionState
  selectedPlan
  onboardingState
  createdAt
  updatedAt
```

The entity is not a Broker profile and does not contain fake broker profile values. It represents explicit intent and pre-profile workflow state.

Recommended statuses:

```text
INTENT_SELECTED
ACCOUNT_CREATED
SUBSCRIPTION_PENDING
FREE_SELECTED
FEATURED_CHECKOUT_PENDING
FEATURED_ACTIVE
ONBOARDING_IN_PROGRESS
COMPLETED
ABANDONED
```

Email verification remains a parallel account state. It must not be collapsed into subscription or onboarding status.

For new email registration, the user is created only after the broker flow is explicitly selected. For a new Google user, the OAuth callback is accepted only when the server has a previously established broker-registration intent. For an existing USER, promotion to broker capability occurs only from that explicit intent flow, not from visiting `/setup`.

The exact role timing requires one deliberate choice:

- Recommended: retain `USER` until the explicit broker-intent transaction succeeds, then promote to `BROKER` while the workflow has no Broker profile; or
- Alternative: assign `BROKER` at explicit account creation and make all broker routes require both `BROKER` and an appropriate registration state.

The recommended choice minimizes accidental broker authorization and makes the durable workflow capability the source of truth during pre-profile onboarding. In either choice, arbitrary `/setup` access is denied.

### 4.3 Proposed subscription ownership

Do not create a placeholder `Broker` or fake `BrokerSubscription`.

Recommended design: add a pre-profile broker-registration subscription owner separate from `BrokerSubscription`.

Conceptually:

```text
BrokerRegistrationSubscription
  id
  brokerRegistrationId
  plan: FREE | FEATURED
  status
  startDate
  endDate
  stripeCustomerId
  stripeSubId
  createdAt
  updatedAt
```

The existing `BrokerSubscription` remains the authoritative subscription for completed Brokers. At onboarding completion, a transaction creates the real Broker and transfers/ materializes the selected subscription state into the existing BrokerSubscription while preserving Stripe identifiers and entitlement state. The transition must be idempotent and must not create two active local subscription owners.

The shared Stripe service should be generalized around an internal billing-owner interface, not by weakening Broker ownership checks. Both registration-owner and Broker-owner paths must resolve their owner server-side and use the same:

- plan/price validation;
- customer ownership validation;
- billing lock;
- idempotency namespace;
- webhook ordering ledger; and
- reconciliation rules.

A second viable design is to extend `BrokerSubscription` to support exactly one of `brokerId` or `brokerRegistrationId`, backed by explicit operational indexes. This is more compact but has greater MongoDB/Prisma optional-unique-index risk and a larger compatibility surface. It should not be selected without a Prisma/Mongo index proof.

### 4.4 Broker state transitions

Recommended state machine:

```text
VISITOR
  -> BROKER_INTENT_SELECTED
  -> ACCOUNT_CREATED
  -> EMAIL_PENDING or ACCOUNT_ACTIVE
  -> SUBSCRIPTION_PENDING
  -> FREE_ACTIVE or FEATURED_CHECKOUT_PENDING
  -> FEATURED_ACTIVE
  -> ONBOARDING_IN_PROGRESS
  -> PROFILE_COMPLETED
  -> EXISTING_BROKER_DASHBOARD
```

Parallel states:

- account activation: `PENDING_EMAIL -> ACTIVE -> DISABLED`;
- subscription: `PENDING -> FREE_ACTIVE` or Stripe lifecycle states;
- onboarding: `NOT_STARTED -> IN_PROGRESS -> COMPLETED`; and
- broker trust/publication: existing verification/visibility states.

Registration, subscription, verification, ownership, publication, and claim state must remain separate.

### 4.5 Email broker path

Proposed flow:

```text
/register
  -> explicit broker choice
  -> minimal email form
  -> create User + BrokerRegistration only
  -> verify email / activate account
  -> subscription selection
  -> FREE state or FEATURED Stripe checkout
  -> durable onboarding
  -> create completed Broker + BrokerSubscription transactionally
  -> refresh session
  -> existing /broker/dashboard
```

The initial form must not accept or persist broker profile fields. Terms, security controls, rate limits, password hashing, duplicate handling, and verification behavior remain policy-controlled.

### 4.6 Google broker path

Proposed flow:

```text
/register
  -> server creates broker-intent context
  -> Continue with Google
  -> OAuth state/callback preserves that intent
  -> new or existing account resolved by Auth.js rules
  -> account enters BrokerRegistration workflow
  -> subscription
  -> onboarding
```

Cases:

- New Google user: create/link the User through Auth.js, then associate the explicit broker-registration workflow. Do not treat generic Google login as broker registration.
- Existing USER: preserve the account and require explicit broker-intent confirmation before any role/capability promotion. Do not duplicate the User or silently convert from email match alone.
- Existing BROKER with completed profile: normal Google login resolves to the existing dashboard.
- Existing BROKER without completed profile: resume the associated BrokerRegistration workflow if present; otherwise use an explicit support/recovery path rather than guessing.
- Account email collision: preserve Auth.js account-linking security. Do not enable unsafe email linking. A Google account may use an already-linked provider account; unlinked collisions require the existing safe authentication/linking policy.
- Abandoned onboarding: leave the User and BrokerRegistration in a resumable state. Do not create a Broker, subscription placeholder, claim, or duplicate account.
- Completed onboarding: resolve through the existing broker dashboard and do not create a second Broker.

The OAuth callback must carry an opaque/signed workflow reference or server-side intent cookie. A user-controlled callback URL alone is not sufficient workflow state.

### 4.7 Existing-user behavior

An existing normal USER can choose broker registration deliberately. The server must verify:

- authenticated identity;
- explicit broker intent;
- active account;
- no existing Broker ownership; and
- no conflicting active broker-registration workflow.

Only then may it create or resume BrokerRegistration and apply the chosen role/capability transition. Visiting `/setup` without this state returns to a safe account home or broker registration entry point. The route must not create a Broker from a bare authenticated session.

### 4.8 Onboarding resume and completion

The wizard needs durable draft state. Recommended options:

- a `BrokerOnboardingDraft` relation owned by BrokerRegistration; or
- a BrokerRegistration JSON draft with strict server validation and versioning.

The preferred minimum design is a separate draft relation if profile fields are large or independently editable. The draft must:

- be server-owned by the current registration/User;
- save only allowlisted profile fields;
- never accept `userId`, role, status, verification, visibility, plan, or Stripe fields;
- support step-independent save/resume;
- be idempotent; and
- be deleted or marked completed only when the Broker transaction succeeds.

On completion, one transaction must:

1. validate registration ownership and selected subscription;
2. validate all onboarding fields;
3. enforce FREE service-city entitlement;
4. generate a unique profile slug;
5. create exactly one Broker;
6. create or materialize exactly one BrokerSubscription;
7. mark registration/onboarding completed; and
8. promote/confirm the role server-side.

The transaction must reject a pre-existing Broker and must be safe to retry.

## 5. Location Design

### 5.1 Google boundary

Google is a utility only:

- client autocomplete may display candidate US places;
- server-side selected-place resolution validates the place and country;
- server-side geocoding/address validation canonicalizes broker addresses; and
- stored canonical coordinates are used for all subsequent searches.

Google is never queried for broker records during public search. Runtime result data, visibility, ranking, filtering, pagination, and advertisements come from HomeLoanMarket.

### 5.2 Proposed broker location representation

No schema change is made in this phase. The proposed minimum persisted representation is:

```text
Broker.latitude: Float?
Broker.longitude: Float?
Broker.geoPoint: Json?
  {
    type: "Point",
    coordinates: [longitude, latitude]
  }
Broker.googlePlaceId: String?
Broker.normalizedAddress: String?
Broker.locationCountryCode: String?
Broker.locationUpdatedAt: DateTime?
```

The preferred query representation is a GeoJSON `Point` suitable for a MongoDB `2dsphere` index. Latitude/longitude scalar fields are useful for API DTOs, validation, diagnostics, and backfill. Whether Prisma Mongo `Json` is suitable for the generated client and raw command path must be proven before schema approval. If not, a native Mongo-compatible representation must be selected without exposing it through ordinary Prisma filters.

Only US locations are accepted. Coordinates must be range-validated and cross-checked against the selected place/geocoding response. Client-submitted arbitrary coordinates are never authoritative.

### 5.3 Search location representation

The selected user search location should be request-scoped and need not be persisted as a User record. The validated request object should contain:

```text
query/display label
normalized address or ZIP
countryCode = US
latitude
longitude
placeId (optional)
```

A plain ZIP search must resolve through the approved location utility before radius search. If only a ZIP is supplied, the selected search point must have documented centroid/representative-point semantics.

### 5.4 Geospatial query design

MongoDB design:

- store GeoJSON Point on Broker;
- create a native `2dsphere` index on the point field;
- use a raw Mongo aggregation or equivalent driver operation for `$geoNear`/`$near`;
- apply existing visibility/verification/active-user/suspension predicates in the same query pipeline;
- preserve specialization, language, experience, rating, featured, city/state, and text filters; and
- perform count and page retrieval consistently from the same filter definition.

Prisma normal `findMany` does not express the required geospatial operator. The repository currently has no raw Mongo query path, so a small isolated geospatial repository boundary is preferable to scattering raw database calls through the API route.

The query must not replace public policy. The geospatial stage narrows candidates; the existing public eligibility predicate remains authoritative.

### 5.5 Radius semantics

The UI range is `0-100` miles. The design must make radius `0` explicit before implementation.

Recommended semantics: radius `0` means “no radius restriction” and preserves the selected-location/city/ZIP search behavior. This avoids requiring exact floating-point coordinate equality, which is not a meaningful broker-distance policy. If product wants exact-point semantics instead, the slider should use a positive minimum or define a documented tolerance.

This recommendation requires product approval before implementation; no code should infer one silently.

For positive radius values:

- validate finite numeric input;
- clamp to 1-100 miles after the zero case is resolved;
- convert miles to meters for MongoDB;
- include the boundary distance; and
- test points exactly inside, on, and outside the boundary.

### 5.6 Location migration and backfill

No migration is created in Phase 0/1. The implementation design must include:

1. Schema proposal review and Prisma capability proof.
2. Additive nullable location fields so existing brokers remain readable.
3. A native idempotent `2dsphere` index operation.
4. A backfill job for valid existing `officeAddress`, city, state, and ZIP records.
5. Google geocoding rate limits, retry policy, and failure logging without raw secrets.
6. A review queue for ambiguous/failed addresses.
7. A count of brokers with missing/invalid coordinates.
8. A dual-read period if old string search and new radius search coexist.
9. A rollback path that disables radius filtering while retaining old location fields.

Backfill must not overwrite manually corrected canonical locations without an explicit reconciliation policy. New broker onboarding and profile edits should resolve/store canonical coordinates at write time rather than geocoding every search.

### 5.7 Index and rollback strategy

The index operation must be:

- idempotent;
- separately verifiable with `listIndexes`;
- deployed after data-shape validation;
- observable for build time and failures; and
- reversible by dropping only the new named index.

The existing Prisma ownership-index operational requirement must remain separate. A location index must not change or recreate the Broker ownership index.

## 6. Advertisement Location Design

### 6.1 Placement boundary

Existing generic advertisement placements remain intact. The new requirement must use a distinct broker-listing local-resource placement, for example:

```text
BROKER_LISTING_LOCAL_RESOURCES
```

This placement is rendered only:

- on broker listing results;
- after the broker result set; and
- when the request has a validated search location.

It must not be mounted on the homepage, broker profile, calculator, blog, footer, or generic site pages.

The current generic `BROKER_LISTING` placement should not be silently repurposed. Existing ad behavior and existing admin-created ads must remain compatible.

### 6.2 Target model

Two safe additive designs exist:

#### Recommended: separate target relation

```text
AdvertisementLocationTarget
  id
  advertisementId unique
  locationLabel
  countryCode = US
  latitude
  longitude
  googlePlaceId optional
  radiusMiles
  createdAt
  updatedAt
```

This keeps legacy Advertisement records unchanged and makes location eligibility explicit. It also allows a future one-to-many target model without changing the core ad document again.

#### Smaller alternative: nullable fields on Advertisement

Add nullable target latitude, longitude, label/place ID, radius, and a targeting mode directly to Advertisement. This is simpler but couples new location behavior to every legacy ad record and makes future multiple-target support harder.

The separate relation is recommended because the product requires multiple ads for the same target, not multiple target areas per ad.

### 6.3 Eligibility query

Public local-resource retrieval should accept validated search coordinates and use:

- the new local-resource placement;
- enabled, non-archived, non-deleted state;
- start/end schedule;
- device visibility;
- target country US;
- target center and radius distance; and
- existing priority/display order/created-at sorting.

Ads with no location target must not be returned from the location-targeted placement. Existing global ads remain governed by their existing placement contract.

Multiple eligible ads are returned using the existing bounded limit and carousel behavior. There is no new dynamic height field. Slot sizing remains owned by `placementSpecs.ts` and `ad-layout.ts` with literal Tailwind classes.

### 6.4 Admin target selection

Admin UI should submit a selected US place identifier/selection object, not arbitrary authoritative coordinates. The server should:

1. authenticate active ADMIN;
2. resolve/validate the selected place through the server-side Google boundary;
3. validate country and coordinates;
4. validate radius bounds;
5. persist canonical target data; and
6. create/update the target relation transactionally with the ad configuration.

The server may compare client-provided display information, but it must not trust client-provided latitude/longitude without provider-backed validation.

### 6.5 Company request to admin ad flow

Company users submit an `AdvertisementRequest`. The request may contain requested creative/content and a desired US target location, but it does not publish an ad.

Admin then:

- reviews the company/request;
- creates or edits the actual Advertisement through the existing admin CMS;
- uploads/selects media through existing admin media controls;
- assigns and validates the target location/radius; and
- publishes the ad.

The actual Advertisement remains admin-owned and admin-published. A company relation on the ad is attribution/billing context, not publishing authority.

## 7. Company Account Design

### 7.1 No advertiser role

Do not add `ADVERTISER` to `UserRole`.

A company registrant remains a normal authenticated `USER` with a company membership/capability relation. This prevents the company account from being treated as a broker or as an admin advertisement publisher.

### 7.2 Proposed entities

Minimum conceptual model:

```text
Company
  id
  name
  type
  address
  bannerAddress
  bannerPhone
  status
  createdAt
  updatedAt

CompanyMembership
  id
  companyId
  userId
  name
  position
  phone
  membershipRole
  status
  createdAt
  updatedAt

CompanyAdvertisementRequest
  id
  companyId
  requestedByMembershipId
  status
  request details
  requested location fields
  admin notes
  advertisementId optional
  createdAt
  updatedAt

CompanySubscription
  id
  companyId
  plan/status
  stripeCustomerId
  stripeSubId
  coupon/promotion reference fields as needed
  startDate
  endDate
  createdAt
  updatedAt
```

Exact field names, enums, and relations require schema review. `CompanyMembership` is preferred over putting all employee/contact fields directly on User because it preserves account identity separately from company profile data and allows future authorized company members without redesigning User.

### 7.3 Company registration flow

```text
Join as Company
  -> minimal company/account form
  -> create or authenticate normal User
  -> create Company + owner membership
  -> verify account/company policy
  -> request advertisement
  -> company subscription
  -> admin review
  -> admin creates/publishes Advertisement
```

Required registration data:

- company name;
- company type;
- company address;
- registering user name;
- position;
- phone;
- banner address; and
- banner phone.

Company users must not be able to call broker creation, broker profile editing, broker leads, or claim completion successfully.

### 7.4 Company authorization

Company API authorization must require:

- authenticated active User;
- active CompanyMembership for the target Company; and
- membership capability appropriate to the action.

The server must not use a client-supplied `companyId` alone as authority. Company dashboard routes should load the company from the authenticated membership.

Broker authorization must continue to require broker ownership and broker policy. A company membership must not satisfy broker ownership.

`proxy.ts` may provide only authentication routing for `/company`; page/API handlers remain authoritative for membership and capability checks. No broker navigation should be rendered in the company layout.

### 7.5 Company dashboard boundary

The company dashboard exposes only:

- company profile;
- company subscription;
- billing;
- coupon/promotion status/application; and
- advertisement request/status.

It must not expose:

- broker dashboard;
- broker listing management;
- broker profile management;
- broker leads;
- broker claims;
- admin media management; or
- ad publishing controls.

## 8. Company Subscription and Coupon Design

### 8.1 Ownership

Company billing must use `CompanySubscription`, not `BrokerSubscription`. Stripe customer metadata should include server-derived company and owner membership identifiers. All checkout, portal, invoice, cancellation, and webhook operations must resolve the company from the authenticated membership and verify the remote Stripe customer metadata.

Existing broker billing ownership and webhook rules remain unchanged.

### 8.2 Recurring monthly lifecycle

Recommended company lifecycle:

```text
REQUESTED
  -> SUBSCRIPTION_PENDING
  -> ACTIVE
  -> PAST_DUE / CANCELLING
  -> CANCELED / EXPIRED
```

Cancellation removes company advertising entitlement at the defined lifecycle boundary but does not silently delete historical requests or published ad records. Admin publication/lifecycle remains separate from billing entitlement.

The exact rule for whether an active ad is unpublished immediately or at period end must be a product/admin decision before implementation. It must not be inferred from broker subscription semantics.

### 8.3 Coupons

Do not hardcode discounts in application code.

Recommended Stripe approach:

- use Stripe-supported promotion codes on company Checkout, such as `allow_promotion_codes`, if the product wants customer-entered codes;
- optionally provide a server-authoritative promotion-code validation endpoint for pre-checkout display; and
- persist only Stripe identifiers and resulting billing state, not a client-calculated discount.

If a coupon code is submitted separately, the server must resolve it through Stripe for the authenticated company, validate active/expiration/redemption constraints, and pass only the validated promotion/coupon identifier into Checkout. The client must never set final amount, recurring price, discount percentage, or entitlement.

Coupon behavior must be tested for invalid, expired, reused, and valid promotion codes.

## 9. Proposed API Surface

No API is created in this phase. The following is the proposed boundary only.

### Broker registration

- `POST /api/auth/register/broker-intent`
- `POST /api/auth/register/broker/email`
- OAuth callback continuation using server-bound intent
- `GET /api/broker-registration/me`
- `POST /api/broker-registration/subscription/free`
- `POST /api/broker-registration/subscription/checkout`
- `GET/PATCH /api/broker-registration/onboarding`
- `POST /api/broker-registration/onboarding/complete`

The exact route names are not final. Existing registration and Auth.js security helpers should be reused rather than creating a second authentication system.

### Location

- server-side selected-place resolution;
- broker profile geocoding/validation;
- broker search with validated location and radius; and
- public location-targeted ad retrieval with validated location.

The public search API should reject or ignore unvalidated coordinate input and should not accept Google result data as broker records.

### Advertisements

Existing admin ad APIs should be extended rather than replaced. New request parameters should represent selected US location intent; server resolution persists canonical target data. Public local-resource retrieval should have a distinct placement/contract.

### Company

- company registration/profile;
- company membership/session context;
- advertisement request creation/list/status;
- company subscription checkout/portal/invoices/cancel;
- server-authoritative promotion-code validation/application.

Admin advertisement APIs remain the only actual ad create/edit/publish authority.

## 10. Migration and Existing-Data Strategy

### Broker registration data

Existing self-registered and claimed Brokers remain valid. No existing Broker should be converted into a draft registration. The new registration entity applies only to new or incomplete target-flow accounts.

Existing Users with no Broker are not automatically assigned broker intent. Existing Brokers continue to reach the existing dashboard.

### Subscription data

Existing `BrokerSubscription` records remain unchanged. New pre-profile registration subscriptions use the new registration owner. A controlled completion transaction materializes the Broker-owned record. A reconciliation job must detect:

- registration owner with no Broker;
- Broker with multiple local subscription owners;
- Stripe customer without local owner;
- local owner without matching Stripe metadata; and
- completed registration without BrokerSubscription.

### Location data

Location fields are additive and nullable initially. Backfill is asynchronous and observable. Brokers with failed geocoding remain searchable by existing city/ZIP/text filters but are excluded from radius results until coordinates are corrected.

### Advertisement data

Existing Advertisement rows remain global/placement-based. The new local-resource placement is opt-in. Existing ads must not gain a default location target accidentally.

### Company data

No existing Broker.companyName values are migrated into Company records automatically. Those fields represent broker profile content, not company accounts. New Company records are created only through explicit company registration or an approved admin migration plan.

## 11. Rollback Strategy

### Broker registration

- Disable new broker-intent entry while preserving existing broker login/dashboard.
- Leave incomplete registrations resumable or mark them abandoned according to retention policy.
- Do not delete Users or active Stripe subscriptions automatically during rollback.
- Reconcile any pre-profile Stripe owner before disabling the flow.

### Location

- Feature-flag radius search and Google location UI independently.
- Fall back to existing city/ZIP/text search if geospatial query or provider integration is unavailable.
- Retain canonical coordinate data when disabling the feature.
- Drop only the named new geospatial index after data compatibility review.

### Ads

- Disable local-resource placement retrieval/mounting without changing existing placements.
- Existing ad lifecycle and media records remain intact.
- Stop publishing new targeted ads while preserving admin access to existing records.

### Company

- Disable company registration/request entry while preserving existing User accounts.
- Do not delete Company, request, or billing history as a feature rollback.
- Revoke company dashboard capability only through server-side status, not role mutation.

## 12. Security and Authorization Design

The implementation must preserve:

- C1 no client-controlled JWT identity;
- explicit safe client DTOs at every RSC/client boundary;
- no OAuth token serialization;
- server-derived User/Broker/Company ownership;
- no role, plan, Stripe, verification, visibility, or owner fields accepted from clients;
- strict broker update allowlists;
- public contact entitlement and visibility checks;
- claim recipient binding and atomic ownership attach;
- Stripe signature, ownership, idempotency, and ordering controls;
- admin-only actual advertisement management;
- no company access through broker role checks; and
- no broker access through company membership checks.

New workflow cookies/state must be signed, short-lived where appropriate, bound to the authenticated account or registration, and never contain raw Google tokens, passwords, Stripe secrets, raw claim tokens, or uncontrolled owner identifiers.

Google OAuth callback state must preserve CSRF/state protections. A callback URL must not be used as the only evidence that a user selected broker registration.

## 13. Regression Test Plan

### Broker registration

- minimal email form contains no broker profile fields;
- server rejects profile data as registration authority;
- duplicate email/phone behavior remains deterministic;
- role cannot be client-injected;
- no Broker or BrokerSubscription is created before the designed subscription/profile transition;
- FREE does not call Stripe;
- FEATURED uses recurring checkout;
- abandoned and resumed registration are idempotent;
- existing USER requires explicit broker intent;
- `/setup` without intent cannot create a Broker;
- completed registration reaches the existing dashboard;
- retry cannot create duplicate Broker or subscription.

### Google

- new Google broker intent;
- new generic Google login remains USER;
- existing USER explicit broker intent;
- existing BROKER with profile;
- existing BROKER without completed registration;
- email collision and unlinked-account behavior;
- OAuth state/intent binding;
- abandoned callback/onboarding;
- session refresh after role/capability transition;
- no OAuth token reaches client payloads.

### Location

- US-only selected place validation;
- invalid country rejection;
- coordinate range validation;
- Place ID/geocode consistency;
- broker write persists canonical coordinates;
- backfill success, retry, ambiguity, and missing coordinate behavior;
- geospatial index creation and verification;
- radius 0 documented behavior;
- radius 1-100 validation;
- exact inside/boundary/outside distance cases;
- missing-coordinate exclusion from radius results;
- existing visibility and VERIFIED filters;
- suspended/inactive exclusion;
- all existing filters and sorting;
- count/pagination consistency.

### Advertisements

- location-targeted placement only appears on broker listing results;
- no target means no local-resource eligibility;
- target inside/boundary/outside radius;
- multiple eligible ads;
- priority/display order;
- schedule and device filters;
- anonymous rendering;
- existing generic placements unchanged;
- admin target selection validates Google place/country/coordinates;
- arbitrary client coordinates rejected;
- canonical slot sizing remains unchanged;
- no dynamic Tailwind height classes;
- ad request does not grant company publish authority.

### Company

- registration stores required company and representative information;
- no `ADVERTISER` role exists;
- company user cannot access broker dashboard/profile/leads/claims;
- broker user cannot access another company;
- membership ownership is server-derived;
- company request lifecycle;
- admin review and actual ad creation;
- company cannot publish/edit an Advertisement;
- company subscription Stripe ownership;
- recurring billing/cancellation;
- valid/invalid/expired promotion codes;
- coupon amount/entitlement remains server-authoritative;
- company dashboard exposes only approved capabilities.

## 14. Implementation Sequence After Approval

1. Review and approve this ownership/state design.
2. Produce a schema-only design review with exact Prisma/Mongo index feasibility.
3. Add focused tests for state transitions and ownership before production implementation.
4. Implement broker registration intent and pre-profile subscription ownership only.
5. Implement minimal registration UI/API changes and durable resume state.
6. Verify existing broker dashboard, claim, authentication, and Stripe regressions.
7. Implement canonical broker location persistence and backfill tooling.
8. Implement isolated geospatial repository/query and radius API.
9. Implement broker listing radius UI and search-result integration.
10. Implement separate location-targeted local-resource advertisement placement.
11. Implement admin target selection and server-side Google validation.
12. Implement Company, membership, request, and separate subscription ownership.
13. Implement restricted company dashboard and coupon flow.
14. Run full validation, migration/index verification, and available live/staging checks.

No phase should combine registration state, geospatial storage, ad targeting, and company billing in one uncontrolled refactor.

## 15. Files Likely Involved Later

### Existing broker/auth files

- `app/(public)/register/page.tsx`
- `app/(public)/auth/signup/page.tsx`
- `components/auth/GoogleContinueButton.tsx`
- `app/api/auth/register/broker/route.ts`
- `lib/broker-registration.ts`
- `lib/auth.config.ts`
- `lib/auth-redirect.ts`
- `proxy.ts`
- `app/setup/page.tsx`
- `components/sections/broker/BrokerSetupWizard.tsx`
- `app/api/brokers/route.ts`
- `app/broker/dashboard/page.tsx` only if route integration requires it; dashboard UI remains unchanged

### Subscription files

- `prisma/schema.prisma`
- `lib/subscription.ts`
- `lib/stripe.ts`
- `actions/subscription.ts`
- `app/api/subscription/checkout/route.ts`
- `app/api/subscription/verify/route.ts`
- `app/api/subscription/portal/route.ts`
- `app/api/subscription/invoices/route.ts`
- `app/api/subscription/cancel/route.ts`
- `app/api/subscription/upgrade/route.ts`
- `app/api/stripe/webhook/route.ts`

### Location/search files

- `prisma/schema.prisma`
- `lib/location.ts`
- `app/api/cities/route.ts`
- `app/api/states/route.ts`
- `app/api/brokers/route.ts`
- `hooks/useClient.ts`
- `app/(public)/brokers/page.tsx`
- new isolated Google location utility
- new isolated Mongo geospatial repository
- new backfill/index verification scripts

### Advertisement files

- `prisma/schema.prisma`
- `app/api/ads/public/route.ts`
- `lib/advertisements/advertisementRepository.ts`
- `lib/advertisements/services.ts`
- `lib/advertisements/types.ts`
- `lib/advertisements/validation.ts`
- `lib/advertisements/placementSpecs.ts`
- `components/advertisements/AdvertisementRenderer.tsx`
- `components/advertisements/PublicAdvertisement.tsx`
- `app/(public)/brokers/page.tsx`
- `app/admin/ads/new/page.tsx`
- `app/admin/ads/[id]/edit/page.tsx`
- `lib/admin/advertisement-dto.ts`

### Company files

- `prisma/schema.prisma`
- new company registration/API modules
- new company authorization policy
- new company dashboard/layout
- new company request/subscription/billing APIs
- existing admin advertisement routes and forms for request attribution/review

The exact final file list must be narrowed during each approved implementation phase. No file in this list is changed by this document.

## 16. Open Decisions Requiring Approval

1. Whether the role becomes `BROKER` immediately after explicit account creation or only after explicit intent plus subscription selection, while still preventing arbitrary `/setup` access.
2. Separate `BrokerRegistrationSubscription` versus a union ownership extension to `BrokerSubscription`.
3. Separate onboarding draft relation versus versioned draft JSON on registration.
4. Exact Prisma representation of GeoJSON and raw Mongo query boundary.
5. ZIP search representative-point/centroid semantics.
6. Radius `0` semantics. Recommended: no radius restriction; exact-coordinate behavior is not recommended.
7. Whether a targeted advertisement has exactly one target or a future target relation should support multiple targets per ad.
8. Whether company advertising entitlement ends immediately or at period end after cancellation.
9. Company verification/approval state and who can approve it.
10. Whether company requests may include creative content or only campaign/location intent.
11. Whether company Checkout allows Stripe promotion codes directly or requires a server validation preview.
12. Production Google API provider, quota, key restrictions, and server/client key boundary.
13. Backfill handling for ambiguous broker addresses.

## AUDIT STATUS

COMPLETE. Current source was independently checked against the supplied architecture audit and repository documentation. Confirmed gaps are documented; historical findings that are fixed in the current source are called out explicitly.

## DESIGN STATUS

PROPOSAL COMPLETE. The ownership model, state transitions, schema direction, API boundaries, Google boundary, geospatial design, advertisement targeting, company model, billing/coupon direction, migration, rollback, and regression plan are documented. Implementation must wait for review and approval of the open decisions.

## PRODUCTION CHANGES: 0

Only this documentation file was created. No production source, Prisma schema, migration, API, UI, authentication, authorization, dashboard, claim, advertisement, Stripe, or test file was changed.
