# Broker Business Claim Audit

## Executive Summary

The broker business claim flow was audited read-only against the current schema and code. The flow is correct and required no code fixes. The recent ownership changes (nullable `Broker.userId`, one-to-many `User.brokerProfile`, partial unique ownership index) are compatible with the existing claim architecture. A focused regression test was added to lock in the "claimed VERIFIED admin broker remains publicly eligible" behavior.

## Existing Claim Architecture

- `lib/claim-invitation.ts` — admin issues invitations (Redis-locked, revokes prior ACTIVE invitations, stores only `tokenHash`).
- `lib/claim-flow.ts` — invitation validation (`findClaimInvitation` / `findClaimInvitationByContext`), eligibility, `safeClaimProfile`, event recording.
- `lib/claim-policy.ts` — `isClaimRecipientMatch` (recipient binding) and `isClaimInvitationActive`.
- `lib/claim-completion.ts` — `completeClaimForUser` (atomic ownership transfer).
- `lib/claim-context.ts` — HMAC-signed, httpOnly claim-context cookie (30-minute TTL).
- Routes: `app/api/claims/[token]`, `[token]/start`, `session`, `session/email`, `session/reauth`, `session/complete`, and `app/api/auth/claim-setup`.

## Claim Lifecycle

Invitation `CREATED → SENT → ACTIVE → (ACCEPTED | REVOKED | EXPIRED)`; claim `INVITED → IN_PROGRESS → COMPLETED`. Claim events are recorded for STARTED, EMAIL_SUBMITTED, VERIFICATION_PENDING, COMPLETED, EXPIRED, REVOKED.

## Root Cause Findings

No genuine defect was found. The claim flow is race-safe and preserves public state:

- Ownership transfer is atomic: `tx.broker.updateMany({ where: { id, userId: null }, data: { userId } })` with an `attached.count !== 1` guard, backed by `brokers_userId_non_null_unique`.
- Eligibility requires `creationSource === ADMIN_CREATED`, `userId === null`, and `brokerStatus !== SUSPENDED`; already-owned and self-registered-owned brokers are not claimable.
- `completeClaimForUser` mutates only `userId`, claim status, invitation status, events, and the claimant's role. It never touches `verificationStatus`, `isVisible`, `creationSource`, or `location`.

## Fixes Applied

None to production code. Added `tests/broker-claim-visibility.test.ts` (static + disposable-Mongo) to assert the claim completion preserves verification/visibility/location and that a claimed VERIFIED admin broker remains publicly eligible via `isPublicBroker`.

## Ownership Safety

One broker → at most one owner; one owner → at most one broker. Enforced by the atomic `updateMany` guard and the partial unique index `brokers_userId_non_null_unique` (`partialFilterExpression: { userId: { $type: 'objectId' } }`). No normal unique `brokers_userId_key` was reintroduced.

## Claim Security

- Unauthenticated/unauthorized claimants cannot complete ownership.
- Recipient email binding prevents link transfer.
- Re-authentication (credentials or Google) is required and time-boxed.
- Replay (USED), revoked, expired, invalid tokens all fail safely.
- Origin checks (`isSameOriginRequest`) and per-IP/rate limits are present on claim mutation endpoints.

## Invitation Lifecycle

Superseding an ACTIVE invitation revokes it; revoked/expired/used invitations cannot be reused; only the intended recipient email can proceed.

## Admin Review

Admin claim-invitation issue/resend/revoke routes and broker detail claim history exist and are admin-gated; they do not delete brokers or mutate location/subscription/visibility.

## Public Visibility After Claim

`completeClaimForUser` does not change `isVisible` or `verificationStatus`, so a VERIFIED + visible admin broker remains VERIFIED + visible after claim. `isPublicBroker` remains satisfied because the claimant is an active user (`userId != null` + `user.isActive`).

## Radius Search After Claim

Claim completion does not touch `Broker.location`, GeoJSON coordinates, `normalizedAddress`, `googlePlaceId`, `locationCountryCode`, or the 2dsphere index. Radius remains `$geoNear` + public eligibility + optional text search.

## serviceCities Usage

`serviceCities` is NOT used for public geographic/radius eligibility. Remaining usages are broker profile/business/registration/display only.

## Subscription Handling

Claim completion does not create, delete, upgrade, downgrade, or transfer subscriptions. The existing FREE/paid broker subscription remains attached to the broker (unchanged).

## Dashboard Ownership

`getCurrentUser()` derives a single `brokerProfile` from `user.brokerProfile[0] ?? null`, so the broker dashboard resolves ownership correctly after claim without reintroducing `@unique`.

## Tests

- `tests/broker-claim-visibility.test.ts`: 3/3 passed.
- `tests/phase-7-claim.integration.test.ts`: 3/3 passed (atomic attach, replay rejection, concurrent-claim single winner).
- `tests/phase-7.5-remediation.integration.test.ts`: 11/11 passed (supersede/revoke/expire/used, ownership-conflict rejection, Google reauth, self-registration).
- `tests/phase-7-claim.test.ts`: passed.

## Validation

- Prisma validate/generate: passed
- TypeScript (`npx tsc --noEmit`): passed
- Build (`yarn build`): passed
- Changed-file ESLint: passed
- `git diff --check`: clean

## Browser Verification

Not performed (no browser tooling).

## Database Safety

- brokers deleted: 0
- broker IDs changed: 0
- locations changed: 0
- ownership changed: 0 (outside disposable test DBs)
- schema changes: NO
- indexes changed: NO

## Remaining Issues

No genuine remaining issues. Browser-level end-to-end claim verification (start → authenticate → complete → dashboard) was not performed.
