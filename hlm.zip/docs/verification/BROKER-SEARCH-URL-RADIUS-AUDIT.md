# Broker Search URL + Location + Radius Audit

## Current Architecture

The public broker search previously carried resolved location state in the browser URL as an opaque, signed `locationToken` plus `locationLabel`, `locationLatitude`, `locationLongitude`, `locationCity`, `locationState`, and `locationZip`. The token was an HMAC-signed base64 payload containing `placeId`, `normalizedAddress`, `city`, `state`, `zip`, `countryCode`, `latitude`, `longitude`, and an expiry. It was issued server-side by `/api/location/resolve` and `/api/location/geocode`, verified server-side by the broker API, and was required whenever a positive radius was requested. Radius itself was not persisted in the URL at all, so refresh/back lost the radius state.

## Root Cause

The URL encoded internal implementation state (a large signed coordinate blob) rather than user search intent. It was not human-readable or bookmark-friendly, could become stale relative to a newly selected location, and radius was not part of the URL contract.

## URL Design

Canonical public URL now represents user search state:

- `/brokers?location=Houston%2C%20TX`
- `/brokers?location=Houston%2C%20TX&radius=25`

The page writes only `location` (the human-readable selected address) and `radius` (integer miles). The resolved coordinate token remains internal transport between the client and the broker API and is no longer written to the browser URL.

## Location Resolution

- Autocomplete continues through the server-side `/api/location/autocomplete` and `/api/location/resolve` (Google New Places API, unchanged).
- Selecting a suggestion resolves it server-side and stores the internal resolved object (with a fresh signed token) in memory; the URL commits the human-readable `location`.
- On initial load/refresh/Back/Forward, the page reads `location`, geocodes it server-side via `/api/location/geocode` (which issues a fresh token), and restores the internal resolved location and radius. A transient `resolvingLocation` guard prevents a free-text or autocomplete request from firing during restore, avoiding a hydration flash.

## Radius

- `radius` is an integer miles parameter (0–100). It is written to the URL on change and read back on hydration.
- The broker API still resolves coordinates from the internal token and runs `$geoNear` with `key: 'location'`, `spherical: true`, and `maxDistance = radiusMiles * 1609.344` (miles to meters), with GeoJSON `[longitude, latitude]`.
- Clearing the location removes both `location` and `radius`.
- Missing geo index still produces an actionable error (`yarn db:ensure-broker-location-index`).

## Compatibility

Legacy `locationToken`/`locationLabel` URLs are read for backward compatibility: `locationLabel` is treated as the location text and re-resolved; the page strips all legacy location params and rewrites the URL to the new canonical form.

## Security

Implementation-heavy resolved-location data (signed coordinate payload) no longer lives in public, shareable URLs. The internal token remains server-issued and server-verified.

## Files Changed

- `app/(public)/brokers/page.tsx`
- `tests/broker-search-url.test.ts`
- `tests/broker-search-autocomplete.test.ts`

## Tests

- `tests/broker-search-url.test.ts`: 7/7 passed.
- `tests/broker-search-autocomplete.test.ts`: 8/8 passed.
- `tests/broker-radius.test.ts`: 9/9 passed.
- `tests/broker-radius-integration.test.ts`: 3/3 passed (disposable Mongo).
- `tests/broker-listing-location-ui.test.ts`: passed.

## Validation

- Prisma validate: passed
- Prisma generate: passed
- TypeScript: passed
- Build: passed
- Changed-file ESLint: passed
- `git diff --check` (changed files): passed
- Production database modified: NO

## Browser Verification

NOT PERFORMED (no browser tooling). URL/radius behavior verified via source-level and disposable Mongo integration tests.
