# Company Registration & Advertising Flow Audit

## Current Architecture

- `User` (role `USER`) is the account; company access is via `CompanyMembership` (OWNER).
- `Company` holds business fields: name, type, address, contactName, contactPosition,
  phone, bannerAddress, bannerPhone, status, and (new) `onboardedAt`.
- `CompanySubscription` → `CompanyAdvertisingPlan` (`planId`), independent of the broker
  `SubscriptionPlan` enum and `BrokerSubscription`.
- `CompanyAdRequest` (status: REQUESTED/UNDER_REVIEW/APPROVED/REJECTED/FULFILLED/CANCELED)
  links a company to a requested advertisement; admin links it to an `Advertisement`.
- `Advertisement` + `AdvertisementLocationTarget` (lat/lng/radiusMiles) power the existing
  centralized advertisement engine; public rendering already enforces active dates,
  placement, company ACTIVE status + active subscription, and radius targeting for
  `BROKER_LISTING_LOCAL`.

## Current Registration Problem

The Join as Company form mixed account registration with company onboarding and ad
information (company name/type/address/contact/banner) — all collected at signup.

## Registration Changes

- `app/(public)/company/register/page.tsx` is now account-only: Full name, Email, Password,
  Confirm password, Continue with Google, Terms.
- `app/api/company/register/route.ts` requires only name/email/password. It creates the User
  (role USER) plus a **PENDING** company shell (name = user name, type OTHER, empty business
  fields) and OWNER membership. The shell exists only so the company-scoped
  subscription/dashboard can be attached before onboarding; onboarding completes it.

## Authentication

Google auth remains the single NextAuth abstraction. `GoogleContinueButton` gained a
`companyIntent` flag that sets a signed company-intent cookie before `signIn('google')`.

## Email Verification

`app/api/auth/verify-email/route.ts` routes verified company members to
`/company/subscription/select` (was `/company/dashboard`). Broker/claim routing is unchanged.

## Google Registration

`/company/register` → Google → `/company/register/continue` → PUT
`/api/auth/company-intent` → `establishCompanyForUser` creates the PENDING company shell +
OWNER membership → `/company/subscription/select`. No Broker/BrokerRegistration is created.

## Company Subscription

Reused as-is: `CompanySubscription` (keyed to Company) with `planId → CompanyAdvertisingPlan`.
Checkout scopes to the authenticated company via `getCurrentCompany()` and writes
`ownerType=COMPANY` metadata on the Stripe customer and subscription.

## Broker vs Company Plan Separation

`CompanyAdvertisingPlan` (with `stripePriceId @unique`, `features`, `isActive`) is fully
separate from the broker `SubscriptionPlan` enum. Company checkout resolves
`CompanyAdvertisingPlan.stripePriceId` with no fallback and fails clearly when unconfigured.

## Coupon Flow

No dedicated coupon model existed; the only infrastructure is Stripe promotion codes. Added a
server-side validation path (`lib/company-coupon.ts` →
`POST /api/company/subscription/coupon/validate`) that validates against Stripe and fails
closed; checkout applies a validated coupon via `discounts: [{ coupon }]`. Client-side discount
calculations are never trusted.

## Company Onboarding

New `app/company/onboarding/page.tsx` (4-step wizard) + `PATCH /api/company/onboarding`
collects: company name, type (exactly Home Loan Company / HELOC Company / DSCR Loan Company /
Title Company / Home Insurance Company / Other), address, contact name/position/phone, banner
address/phone. It sets `status: ACTIVE` and `onboardedAt`.

## Company Dashboard

Reused. `app/company/dashboard/page.tsx` now redirects to `/company/onboarding` while
`company.onboardedAt` is null, otherwise renders the existing dashboard (profile, billing,
advertisement requests).

## Advertisement Request

Reused `POST /api/company/requests` (company-scoped) and `GET`. Request payload remains
`requestDetails`; the existing `CompanyAdRequest.targetLocation` JSON field and status enum are
retained. Location-aware request submission is not yet wired end-to-end (see Remaining Issues).

## Location Targeting

`lib/location/advertisement-target.ts` + `AdvertisementLocationTarget` already provide
validated Google-Places + radius targeting. `BROKER_LISTING` and `BROKER_LISTING_LOCAL`
placements already exist. No new geo system was introduced.

## Admin Review

`GET/PATCH /api/admin/company-ad-requests` (admin-only) supports review, status transitions,
and linking an `Advertisement` (`advertisementId`) to a request + company.

## Advertisement Creation

The existing centralized advertisement engine (`/api/admin/ads`) is unchanged; admin creates
the actual advertisement and links it to the request/company via
`/api/admin/company-ad-requests`.

## Public Broker Listing Integration

`lib/advertisements/advertisementRepository.ts` already gates `BROKER_LISTING_LOCAL` ads on
company ACTIVE + active subscription + radius match. `serviceCities` is NOT used.

## serviceCities

serviceCities is not used for company advertisement targeting. Company targeting uses
`AdvertisementLocationTarget` (lat/lng/radius). Broker public search/radius also do not use it.

## Authorization

Company routes resolve the acting company server-side via `getCurrentCompany()` (active
membership + non-suspended company). Company A cannot access Company B's subscription/requests.

## Redirect Flow

- New registration → `/auth/verify-email`
- Verified company → `/company/subscription/select`
- Not onboarded (onboardedAt null) → `/company/onboarding`
- Onboarded → `/company/dashboard`

## Database Changes

Single minimal, non-destructive change: added nullable `Company.onboardedAt DateTime?`. No
existing records are deleted or rewritten.

## Tests

`tests/company-advertising-isolation.test.ts` (extended), `company-plan-isolation`,
`company-account-contract`, plus Stripe/subscription suites — all pass.

## Validation

- `npx prisma validate` — valid
- `npx prisma generate` — ok
- `npx tsc --noEmit` — exit 0
- `npx next build` — ok (new routes `/company/onboarding`, `/company/subscription/select`)
- `npx eslint` (changed files) — 0 errors
- `git diff --check` (changed files) — clean

## Browser Verification

Not executed (no running app / Stripe test keys). Verified via type-check, build, and unit
tests only. Manual checklist remains: registration → verify → plans → coupon → checkout →
onboarding → dashboard → request → admin review → ad creation → radius eligibility.

## Remaining Issues

1. Company advertisement request submission is not yet location-aware in the UI (the
   `requestDetails` free-text path is retained; `targetLocation` is not surfaced in the
   company form). Admin-side ad creation/linking already works.
2. Coupon validation is implemented against Stripe promotion codes and is not integration
   tested (no Stripe test keys).
3. Pre-existing failing test `tests/registration-flow-security.test.ts` asserts
   `user.brokerProfile === null`; the field is now `Broker[]` after an earlier schema change.
   Unrelated to this task.
