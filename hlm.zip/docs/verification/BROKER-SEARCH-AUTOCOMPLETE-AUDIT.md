# Broker Search & Autocomplete Audit

## Root Cause

The search input was never directly delayed, but the remote work and URL state were coupled to slow timers and loop-prone effect dependencies:

- The unified search field debounced the broker query at 400ms and the autocomplete at 300ms, so suggestions appeared slower than necessary.
- The autocomplete effect depended on `locationSuggestions.length`, causing it to re-run after every result render and re-trigger the effect after each suggestion list mutation.
- Autocomplete requests had no abort/sequence protection, so a slower response for an older keystroke could overwrite a newer result.
- The same debounced `search` value also drove `window.history.replaceState`, coupling query timing to URL updates.
- There was no `popstate` listener, so Back/Forward restored a stale page without re-syncing React state.
- The suggestion list had no keyboard navigation, active-descendant ARIA, or inline error surface.

## Fixes

- **Immediate input**: `searchInput` updates synchronously from `onChange`; only remote work is debounced.
- **Debounce**: broker query and autocomplete both reduced to ~200ms.
- **Stale protection**: autocomplete uses `AbortController` plus a monotonically increasing request ID, discarding aborted/out-of-order responses.
- **URL state**: added a separate `committedSearch` state. Typing updates only local input; Enter (or location selection) commits search and updates the URL once via `replaceState`.
- **Back/Forward**: `popstate` re-syncs all search/location/filter state from the URL.
- **Google integration**: unchanged server-side New Places API boundary (`/api/location/autocomplete`, `/api/location/resolve`); no client-side Google script was added or duplicated.
- **Error handling**: Google/network failures surface as a safe inline `role="status"` message; the listing page remains usable.
- **Accessibility**: input now uses the combobox pattern (`role="combobox"`, `aria-autocomplete="list"`, `aria-expanded`, `aria-controls`, `aria-activedescendant`) with Arrow Up/Down navigation, Enter select, and Escape close.

## Business Logic Safety

No changes were made to:

- Prisma schema
- broker ownership (`userId`)
- visibility (`isVisible`)
- verification/suspension rules
- claim lifecycle
- subscription rules
- public listing eligibility
- radius/location token semantics
- broker DTO entitlement
- advertisements
- authentication/authorization

## Files Changed

- `app/(public)/brokers/page.tsx`
- `tests/broker-search-autocomplete.test.ts`
- `docs/verification/BROKER-SEARCH-AUTOCOMPLETE-AUDIT.md`

## Tests

Focused search/autocomplete tests: **15/15 passed**.

Existing broker listing/location tests: passed.

## Validation

- TypeScript: passed
- Build: passed
- Changed-file ESLint: passed
- `git diff --check` (changed files): passed

## Browser Verification

Not performed (no browser tooling available). Source-level verification only.

## Remaining Issues

- A real browser run (desktop 1440px and mobile 390px) is still recommended to confirm perceived latency and Google script behavior in production.
- Live broker search still uses a debounced free-text query; this preserves existing product behavior and is not a regression.
