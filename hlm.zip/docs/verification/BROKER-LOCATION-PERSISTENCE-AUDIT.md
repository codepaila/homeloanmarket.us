# Broker Location Persistence & Automatic Geocoding Audit

## Objective

Administrators supply addresses only; the application geocodes and persists coordinates; radius search uses those persisted coordinates.

## Root Cause

Imported and manually created brokers had `location: null`, `normalizedAddress: null`, and `googlePlaceId: null` because neither admin creation nor import called the existing geocoder. The only coordinate source was a manual admin "Resolve Location" action and a separate backfill script. Radius search therefore returned zero results for these brokers. The broker API also contained debug logging that dumped full broker arrays.

## Implementation

New shared helper `lib/location/broker-location.ts`:

- `buildBrokerAddress` joins `officeAddress`, `city`, `state`, `pinCode`.
- `isValidLatitude` / `isValidLongitude` / `isValidCoordinatePair` reject NaN, Infinity, and out-of-range values.
- `toBrokerLocationPatch` maps a resolved location to the Prisma `location` GeoJSON `{ type: 'Point', coordinates: [longitude, latitude] }` plus `normalizedAddress`, `googlePlaceId`, and `locationCountryCode`, rejecting invalid coordinates.
- `resolveBrokerLocation` calls the existing `geocodeUSAddress` and returns `null` on failure (non-fatal).
- `locationHasValidCoordinates` validates an already-stored `location` value.

Wiring:

- **Admin create** (`app/api/admin/brokers/route.ts`): resolves the address and persists coordinates when the address can be geocoded; creation still succeeds when geocoding fails.
- **Admin edit** (`app/api/admin/brokers/[id]/route.ts`): detects `officeAddress`/`city`/`state`/`pinCode` changes, re-resolves and persists on change, and clears location on address change when re-resolution fails; unchanged addresses do not re-geocode.
- **Import** (`lib/admin/broker-data.ts`): each created broker is geocoded (120ms throttle, non-fatal). Updates only re-geocode when the existing broker lacks valid coordinates. Counters report `locationResolved` / `locationFailed` / `locationMissing`.
- **Backfill** (`scripts/backfill-broker-locations.ts`): now detects invalid coordinates (not just null), reports `Total / Already located / Attempted / Resolved / Failed / Skipped / Coverage`, and preserves all non-location fields.
- **Broker API** (`app/api/brokers/route.ts`): removed the full broker-array debug dump; logs only concise counts/role/radius.

No latitude/longitude columns are required in CSV/Excel, and admins do not enter coordinates.

## Validation

- `tests/broker-location-persistence.test.ts`: 9/9 passed.
- Import lifecycle with disposable Mongo: geocoding produced real coordinates and persisted `location`, `normalizedAddress`, and `googlePlaceId` (verified directly).
- Radius integration tests: 3/3 passed.
- Radius unit tests: 9/9 passed.
- Prisma validate/generate: passed.
- TypeScript: passed.
- Build: passed.
- Changed-file ESLint: passed.
- `git diff --check` (changed files): passed.
- Production database modified: NO.

## Files Changed

- `lib/location/broker-location.ts` (new)
- `app/api/admin/brokers/route.ts`
- `app/api/admin/brokers/[id]/route.ts`
- `lib/admin/broker-data.ts`
- `scripts/backfill-broker-locations.ts`
- `app/api/brokers/route.ts`
- `tests/broker-location-persistence.test.ts`

## Remaining

- Existing production brokers still require the backfill (`yarn db:backfill-broker-locations`) and the 2dsphere index (`yarn db:ensure-broker-location-index`) to enter radius results.
- Browser verification was not performed.
