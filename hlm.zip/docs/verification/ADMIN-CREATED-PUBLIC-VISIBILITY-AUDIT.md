# Admin Created Public Visibility Audit

## Root Cause

The public broker listing (`GET /api/brokers`), the radius search pipeline, and the
public detail/contact/sitemap eligibility all required **both** of the following for a
broker to be publicly visible:

```
isVisible = true
verificationStatus = VERIFIED
```

Admin-created / imported brokers are platform-published marketplace profiles that do not
go through the self-registration verification lifecycle. Legacy imports left them in an
`UNVERIFIED` state, so they were excluded from the public marketplace even though they are
legitimate pre-claim profiles. The fix introduces `creationSource` as an explicit part of
the eligibility policy rather than relying solely on verification defaults.

## Existing Public Eligibility

Before this change, eligibility was duplicated in several places, each requiring
`verificationStatus = VERIFIED` for every broker:

- `app/api/brokers/route.ts` — inline `publicEligibility` object
- `lib/location/broker-geo.ts` — `baseMatch()` MongoDB `$match`
- `app/api/brokers/featured/route.ts` — paid featured listing
- `app/sitemap.ts` — sitemap `where`
- `lib/broker-policy.ts` — `isPublicBroker()` predicate used by broker detail, company detail,
  reviews, contact, and SEO

## New ADMIN_CREATED Eligibility

The eligibility policy now has a single canonical helper `publicBrokerWhere()` in
`lib/broker-policy.ts`, with the predicate `isPublicBroker()` accepting an optional
`creationSource`.

```ts
export function publicBrokerWhere(): Prisma.BrokerWhereInput {
  return {
    isVisible: true,
    brokerStatus: { not: 'SUSPENDED' },
    AND: [
      { OR: [{ userId: null }, { user: { isActive: true } }] },
      { OR: [{ creationSource: 'ADMIN_CREATED' }, { verificationStatus: 'VERIFIED' }] },
    ],
  }
}
```

Semantically:

- **ADMIN_CREATED branch**: `creationSource = ADMIN_CREATED`, not suspended, not
  hard-hidden (`isVisible`), and ownership valid (unowned or active owner). Verification is
  not required because admin-created brokers are platform-published.
- **SELF_REGISTERED branch**: unchanged — must still be `VERIFIED`, visible, not suspended,
  and with valid ownership.

Shared protections (suspension, ownership, hard-hide) are preserved for both branches.
`serviceCities`, `specializations`, `languages`, `avgRating`, and `experienceYears` are not
part of eligibility.

## SELF_REGISTERED Eligibility

Unchanged. A SELF_REGISTERED broker is public only when:

```
isVisible = true
AND verificationStatus = VERIFIED
AND brokerStatus != SUSPENDED
AND (userId null OR user.isActive = true)
```

`isVisible` remains the administrative hard-hide flag for all brokers, including
ADMIN_CREATED. The policy is intentionally **not** `isVisible OR creationSource`, and not
`verificationStatus OR creationSource` as a loose whole-predicate replacement — the
suspension, ownership, and hard-hide protections are always retained.

## Claim Lifecycle

Verified and unchanged:

- `lib/claim-invitation.ts` requires an unowned, `ADMIN_CREATED`, non-suspended broker.
- `lib/claim-flow.ts` rejects claimed / non-`ADMIN_CREATED` / suspended targets.
- `lib/claim-completion.ts` attaches `userId` only via a guarded `updateMany` on
  `userId: null`, and never mutates `creationSource`, `verificationStatus`, `isVisible`, or
  `location`.

After claim, `creationSource` remains `ADMIN_CREATED` and the broker continues to satisfy the
ADMIN_CREATED branch (owned + active owner), so it stays public.

## Radius Search

`lib/location/broker-geo.ts` keeps `$geoNear` as the first stage using `Broker.location`
(2dsphere), `radiusMiles`, `maxDistance`, `distanceMeters`, pagination, and ordering. Public
eligibility is applied after `$geoNear` and now mirrors `publicBrokerWhere()`:

```
$and: [
  { isVisible: true },
  { brokerStatus: { $ne: 'SUSPENDED' } },
  { $or: [{ creationSource: 'ADMIN_CREATED' }, { verificationStatus: 'VERIFIED' }] },
]
```

plus the existing owner lookup (`userId: null` OR owner `isActive`). No legacy attributes
are used for radius eligibility.

## serviceCities

`serviceCities` is **not** part of public geographic eligibility. It is not used for radius
filtering, not restored as `where.serviceCities = { has: ... }`, and not mapped from
`locationCity`/`state`/`zip`. Search continues to match actual address fields
(`displayName`, `companyName`, `description`, `officeAddress`, `city`, `state`, `pinCode`).
The database field was left untouched.

## Existing Data

Read-only diagnostic (`npm run db:diagnose-admin-broker-visibility`) against the local dev
database reported:

| Metric | Count |
| --- | --- |
| Total brokers | 62 |
| Admin-created | 62 |
| Self-registered | 0 |
| Unclassified source | 0 |
| Admin-created, unowned | 62 |
| — suspended | 0 |
| — hard-hidden (`isVisible=false`) | 60 |
| — verified | 0 |
| — unverified | 62 |
| Admin-created, owned | 0 |

Interpretation:

- The policy fix alone makes the 2 unverified-but-visible admin-created brokers public
  immediately.
- 60 legacy admin-created brokers remain hard-hidden because they were imported with
  `isVisible=false`. `isVisible` is intentionally retained as a hard-hide, so these require
  the existing targeted backfill `db:backfill-admin-broker-visibility` (dry-run capable,
  limited to `ADMIN_CREATED` + unowned + non-suspended). No production data was modified by
  this change.

## Files Changed

- `lib/broker-policy.ts` — added `creationSource` to `BrokerPublicState`, updated
  `isPublicBroker()`, added `publicBrokerWhere()`.
- `app/api/brokers/route.ts` — listing now delegates to `publicBrokerWhere()`.
- `lib/location/broker-geo.ts` — `baseMatch()` mirrors the ADMIN_CREATED branch.
- `app/api/brokers/[id]/route.ts` — passes `creationSource` to `isPublicBroker`.
- `app/api/company/[slug]/route.ts` — passes `creationSource` to `isPublicBroker`.
- `app/api/company/[slug]/reviews/route.ts` — selects and passes `creationSource`.
- `app/api/contacts/send/route.ts` — passes `creationSource` to `isPublicBroker`.
- `app/sitemap.ts` — sitemap `where` uses the ADMIN_CREATED branch and passes `creationSource`.
- `lib/admin/dashboard.ts` — active-broker count uses `publicBrokerWhere()`.
- `scripts/diagnose-admin-created-broker-visibility.ts` — new read-only diagnostic.
- `package.json` — added `db:diagnose-admin-broker-visibility` script.
- `tests/broker-service-cities-search.test.ts` — updated eligibility assertions to the shared helper.
- `tests/broker-radius.test.ts` — updated eligibility assertions to the shared helper.
- `tests/broker-admin-created-public-visibility.test.ts` — new regression matrix.

## Tests

- `tests/broker-admin-created-public-visibility.test.ts` — 12/12 pass (matrix A–I plus helper/radius structure).
- `tests/phase-3b-broker-policy.test.ts` — pass.
- `tests/admin-broker-visibility-import.test.ts` — pass.
- `tests/broker-claim-visibility.test.ts` — pass.
- `tests/broker-service-cities-search.test.ts` — pass.
- `tests/broker-radius.test.ts` — pass.
- `tests/broker-service-cities-geography.test.ts` — pass.
- `tests/broker-search-autocomplete.test.ts` — pass.
- `tests/broker-import.test.ts` — pass.

Focused run: 71 tests, 67 pass, 0 fail, 4 skipped (DB-only tests skipped without their env vars).

## Validation

- `npx prisma validate` — valid.
- `npx prisma generate` — success.
- `npx tsc --noEmit` — exit 0.
- `npx next build` — success.
- `npx eslint` (changed files) — 0 errors (1 pre-existing unused-import warning in
  `app/api/company/[slug]/route.ts`).
- `git diff --check` — clean for all files changed by this task (3 unrelated pre-existing
  trailing-whitespace warnings remain in `Header.tsx`, `Hero.tsx`, `SearchSection.tsx`).

## Browser/API Verification

Not executed against a running server in this session (no live `next dev`/deploy available).
The change is verified via type-check, build, and unit/source regression tests. Manual
verification checklist remains: `GET /brokers`, `GET /api/brokers?page=1&pageSize=10`,
search, radius, claim-then-public, and suspended-not-public.

## Database Safety

- brokers deleted = 0
- ownership changed = 0
- locations changed = 0
- Prisma schema changed = no
- indexes changed = no
- no destructive migration run; only a read-only diagnostic was executed locally

## Remaining Issues

1. 60 legacy admin-created brokers in the local database remain `isVisible=false` and will
   only appear publicly after the existing targeted backfill
   `db:backfill-admin-broker-visibility` is run (intentional — `isVisible` remains a
   hard-hide).
2. `tests/broker-search-url.test.ts` fails on an unrelated, pre-existing assertion
   (`specialization` in the brokers page effect deps), outside this task's scope.
3. Pre-existing trailing whitespace in `Header.tsx`, `Hero.tsx`, `SearchSection.tsx`.
