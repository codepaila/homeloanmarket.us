# Broker Radius Search Simplification Audit

## Root Cause

Radius search was mixing geographic distance with unrelated broker attributes. `lib/location/broker-geo.ts` applied `serviceCities`, `state`, `zip`, `specialization`, `avgRating`, `experienceYears`, `languages`, and `featuredOnly` inside `baseMatch` after `$geoNear`, so a broker physically within radius could be excluded because its `serviceCities` did not contain the selected city. Separately, the public listing `where` had `isVisible` and `verificationStatus` disabled, so the non-radius listing population diverged from the radius population, making radius look like a "completely different" result set.

## Fix

- `lib/location/broker-geo.ts`: reduced `BrokerGeoSearchInput` to `latitude`, `longitude`, `radiusMiles`, `page`, `take`, optional `search`, and `admin`. `baseMatch` now applies only public eligibility (anonymous: `isVisible=true`, `VERIFIED`, not `SUSPENDED`, unowned or active owner) plus optional text search. Removed serviceCities/state/zip/specialization/rating/experience/language/featured from the radius pipeline.
- `app/api/brokers/route.ts`: restored public eligibility (`isVisible`, `VERIFIED`, not `SUSPENDED`, active owner or `userId:null`) for anonymous users; built a dedicated `geoWhere` (eligibility + optional search) used for the radius `findMany` so `total` stays consistent with the geo facet. Non-radius listing still applies the full filter set (city/state/zip/specialization/rating/experience/language/featured).

## Geographic Search

Radius now means exactly: `$geoNear` against `Broker.location` (GeoJSON `[longitude, latitude]`, `spherical: true`, `maxDistance = radiusMiles * 1609.344`), then public eligibility, then optional text search, then `$facet` pagination. `$geoNear` remains the first stage.

## Public Eligibility (unchanged)

Anonymous users see only brokers where `isVisible=true`, `verificationStatus=VERIFIED`, `brokerStatus != SUSPENDED`, and (unowned `userId:null` or an active owner). Admins keep existing admin behavior. The signed location token is still required and validated server-side.

## Verification

Manual radius boundaries against a disposable Mongo with a Houston center and brokers at 0.5/3/10/30/120 miles:

- 1 mi → 1
- 3 mi → 1
- 5 mi → 2
- 10 mi → 2
- 25 mi → 3
- 100 mi → 4 (120-mile broker correctly excluded)

Increasing radius returns the same or more eligible brokers; results are monotonic and purely geographic.

## Files Changed

- `lib/location/broker-geo.ts`
- `app/api/brokers/route.ts`
- `tests/broker-radius.test.ts`
- `tests/broker-public-visibility.test.ts`
- `tests/broker-listing-location-ui.test.ts`
- `docs/verification/BROKER-RADIUS-SIMPLIFICATION-AUDIT.md`

## Tests

- Radius unit/contract tests: 12/12 passed.
- Radius disposable-Mongo integration: 3/3 passed.
- Public visibility/listing/location tests: passed.
- Search URL/autocomplete tests: passed.
- TypeScript: passed.
- Build: passed.
- Prisma validate/generate: passed.
- Changed-file ESLint: passed.
- `git diff --check` (changed files): passed.

## Database

- Prisma schema changed: NO
- Broker data modified: NO (disposable test databases only)
- 2dsphere index: existing/healthy (used, not recreated)

## Remaining

Browser verification not performed. Location token security, automatic geocoding, import, and backfill remain unchanged.
