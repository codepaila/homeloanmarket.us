import type { MetadataRoute } from 'next'
import prisma from '@/lib/prisma'
import { canonicalUrl, isIndexablePublicBroker } from '@/lib/seo'
import { publicBrokerWhere } from '@/lib/broker-policy'
import { ABOUT_PAGE_ID } from '@/lib/about/about'

const corePublicPaths = ['/', '/brokers', '/contact', '/faq', '/guides', '/blog', '/calculator', '/privacy-policy', '/terms-of-service']

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [brokers, posts, aboutPage] = await Promise.all([
    prisma.broker.findMany({
      // Same canonical public eligibility as the listing/detail (visibility,
      // status, completeness, ownership). Verification is not a public
      // eligibility requirement, so self-registered brokers are indexable once
      // their complete, published profile is public.
      where: publicBrokerWhere(),
      select: {
        profileSlug: true,
        userId: true,
        isVisible: true,
        verificationStatus: true,
        brokerStatus: true,
        creationSource: true,
        updatedAt: true,
        user: { select: { isActive: true, companyMemberships: { where: { isActive: true }, select: { id: true } } } },
      },
    }),
    prisma.blogPost.findMany({
      where: { isPublished: true },
      select: { slug: true, updatedAt: true },
      orderBy: { updatedAt: 'desc' },
    }),
    prisma.aboutPage.findUnique({
      where: { id: ABOUT_PAGE_ID },
      select: { isActive: true },
    }),
  ])

  const publicPaths = aboutPage?.isActive
    ? [...corePublicPaths, '/about']
    : corePublicPaths

  const entries: MetadataRoute.Sitemap = publicPaths.map((path) => ({
    url: canonicalUrl(path),
    changeFrequency: path === '/' ? 'daily' : 'weekly',
    priority: path === '/' ? 1 : 0.6,
  }))

  entries.push(...brokers.filter((broker) => isIndexablePublicBroker({
    isVisible: broker.isVisible,
    verificationStatus: broker.verificationStatus,
    brokerStatus: broker.brokerStatus,
    creationSource: broker.creationSource,
    userId: broker.userId,
    userIsActive: broker.user?.isActive,
    // An advertising/company account is never indexable as a public broker.
    hasActiveCompanyMembership: (broker.user?.companyMemberships?.length ?? 0) > 0,
  })).map((broker) => ({
    url: canonicalUrl(`/brokers/${broker.profileSlug}`),
    lastModified: broker.updatedAt,
    changeFrequency: 'weekly' as const,
    priority: 0.7,
  })))

  entries.push(...posts.map((post) => ({
    url: canonicalUrl(`/blog/${post.slug}`),
    lastModified: post.updatedAt,
    changeFrequency: 'weekly' as const,
    priority: 0.6,
  })))

  return [...new Map(entries.map((entry) => [entry.url, entry])).values()]
}
