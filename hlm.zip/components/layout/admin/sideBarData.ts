import {
  Home,
  Users,
  User as UserIcon,
  CreditCard,
  Settings,
  Calculator,
  TrendingUp,
  HelpCircle,
  FileSpreadsheet,
  Search,
  MessageSquare,
  ChartBar,
  Megaphone,
  Building2,
  Heart,
  Crown,
} from 'lucide-react'
import type { SidebarItem, SidebarSection, QuickAction, SidebarData, UserRole } from '@/types/nav'

export type { SidebarItem, SidebarSection }

// Loose shape of the authenticated user consumed by the sidebar builder. The
// source is the transformed current-user object (see hooks/useCurrentUser).
export type SidebarUserInput = {
  id?: string
  name?: string | null
  email?: string | null
  phone?: string | null
  image?: string | null
  role?: UserRole
  isActive?: boolean
  unreadContacts?: number
  unreadNotifications?: number
  brokerProfile?: {
    id?: string
    displayName?: string
    companyName?: string | null
    verificationStatus?: string
    brokerStatus?: string
    profileSlug?: string
    avgRating?: number
    totalReviews?: number
    totalLeads?: number
    profileViews?: number
    subscription?: { plan?: string; isActive?: boolean; startDate?: Date; endDate?: Date | null } | null
  } | null
} | null

export const appSidebarData = (user: SidebarUserInput): SidebarData => {
  // Helper functions based on your schema
  const isAdmin = user?.role === "ADMIN"
  const isBroker = user?.role === "BROKER"
  const isUser = user?.role === "USER"
  
  // Get broker profile and subscription
  const brokerProfile = user?.brokerProfile
  const subscription = brokerProfile?.subscription
  
  const hasActiveSubscription = Boolean(brokerProfile) && (subscription?.isActive ?? true)
  const isVerifiedBroker = brokerProfile?.verificationStatus === "VERIFIED"
  const subscriptionPlan = subscription?.plan || "FREE"
  const isPremiumBroker = false
  const isFeaturedPlan = subscription?.isActive === true && subscriptionPlan === "FEATURED"
  const isFeaturedBroker = subscription?.isActive === true &&
    subscriptionPlan === "FEATURED"


  // ==================== BROKER NAVIGATION ====================
  const brokerNavItems: SidebarItem[] = isBroker ? [
    {
      title: "Dashboard",
      url: "/broker/dashboard",
      icon: Home,
      roles: ["BROKER"]
    },
    {
      title: "My Profile",
      url: "/broker/profile",
      icon: UserIcon,
      // items: [
      //   { title: "Profile Overview", url: "/broker/profile" },
      //   { title: "Edit Profile", url: "/broker/profile/edit" },
      //   // { title: "Verification Status", url: "/broker/profile/verification", 
      //   //   badge: isVerifiedBroker ? "Verified" : "Pending" 
      //   // },
      // ]
    },
     {
      title: "Company Profile",
      url: "/broker/company",
      icon: UserIcon,
      // items: [
      //   { title: "Overview", url: "/broker/company" },
      //   { title: "Edit  ", url: "/broker/company/edit" },
      //   { title: "Preview", url: `/brokers/${brokerProfile?.profileSlug || 'preview'}` }
      // ]
    },
  
    // {
    //   title: "Reviews",
    //   url: "/broker/reviews",
    //   icon: Star,
    //   badge: brokerProfile?.totalReviews || 0,
    //   items: [
    //     { title: "All Reviews", url: "/broker/reviews" },
    //     { title: "Review Insights", url: "/broker/reviews/insights" },
    //     { title: "Respond to Reviews", url: "/broker/reviews/respond" },
    //   ]
    // },
    {
      title: "Subscription",
      url: "/broker/subscription",
      icon: CreditCard,
      // items: [
      //   { title: "Current Plan", url: "/broker/subscription", 
      //     badge: subscriptionPlan === "FREE" ? "Free" : subscriptionPlan 
      //   },
      //   { title: subscriptionPlan === "FREE" ? "Upgrade Plan" : "Change Plan", 
      //     url: "/broker/subscription/upgrade" 
      //   },
      //   { title: "Billing History", url: "/broker/subscription/billing" },
      //   { title: "Subscription Usage", url: "/broker/subscription/usage" },
      // ]
    },
    // user.isFeaturedBroker &&
    // {
    //   title: "Analytics",
    //   url: "/broker/analytics",
    //   icon: ChartBar,
    //   requiresSubscription: true,
    //   items: [
    //     { title: "Dashboard", url: "/broker/analytics" },
    //     { title: "Profile Analytics", url: "/broker/analytics/profile" },
    //     { title: "Performance Report", url: "/broker/analytics/report" },
    //   ]
    // },
    // {
    //   title: "Messages",
    //   url: "/broker/messages",
    //   icon: MessageCircle,
    //   badge: user.unreadContacts, // Unread messages count
    //   // items: [
    //   //   { title: "All Conversations", url: "/broker/messages" },
    //   //   { title: "Unread Messages", url: "/broker/messages?filter=unread" },
    //   //   { title: "Important", url: "/broker/messages?filter=important" },
    //   // ]
    // },
    {
      title: "Support Tickets",
      url: "/broker/support/tickets",
      icon: HelpCircle,
      // items: [
      //   { title: "My Tickets", url: "/broker/support/tickets" },
      //   // { title: "Create Ticket", url: "/broker/support/create" },
      //   // { title: "FAQ", url: "/broker/support/faq" },
      //   // { title: "Priority Support", url: "/broker/support/priority",
      //   //   enabled: isPremiumBroker
      //   // },
      // ]
    },
  ] : []

  // Filter broker items based on subscription requirements
  const filteredBrokerNavItems = brokerNavItems
    .filter(item => {
      if (item.requiresSubscription && !hasActiveSubscription) {
        return false
      }
      if (item.enabled === false) {
        return false
      }
      return true
    })
    .map(item => ({
      ...item,
      items: item.items?.filter(subItem => {
        if (subItem.requiresSubscription && !hasActiveSubscription) {
          return false
        }
        if (subItem.enabled === false) {
          return false
        }
        return true
      })
    }))

  // ==================== USER NAVIGATION ====================
  const userNavItems: SidebarItem[] = isUser ? [
    {
      title: "Dashboard",
      url: "/dashboard",
      icon: Home,
      roles: ["USER"]
    },
    {
      title: "Find Mortgage Originators",
      url: "/brokers",
      icon: Search,
      items: [
        { title: "Browse Mortgage Originators", url: "/brokers" },
        { title: "Mortgage Experts", url: "/brokers?featured=true" },
        { title: "Verified Mortgage Originators", url: "/brokers?verified=true" },
        { title: "By City", url: "/brokers/cities" },
      ]
    },
    {
      title: "My Leads",
      url: "/leads",
      icon: MessageSquare,
      items: [
        { title: "All Leads", url: "/leads" },
        { title: "Send New Lead", url: "/leads/create" },
        { title: "Lead History", url: "/leads/history" },
      ]
    },
    {
      title: "Saved Mortgage Originators",
      url: "/saved",
      icon: Heart,
      badge: "12", // Saved brokers count
      items: [
        { title: "All Saved", url: "/saved" },
        { title: "Recent Views", url: "/saved/recent" },
        { title: "Top Picks", url: "/saved/top" },
      ]
    },
    // {
    //   title: "EMI Calculator",
    //   url: "/calculator",
    //   icon: Calculator,
    //   items: [
    //     { title: "Loan Calculator", url: "/calculator/loan" },
    //     { title: "Affordability", url: "/calculator/affordability" },
    //     { title: "Comparison", url: "/calculator/comparison" },
    //   ]
    // },
    // {
    //   title: "Resources",
    //   url: "/resources",
    //   icon: FileText,
    //   items: [
    //     { title: "Loan Guides", url: "/resources/guides" },
    //     { title: "Bank Rates", url: "/resources/rates" },
    //     { title: "FAQ", url: "/resources/faq" },
    //     { title: "Blog", url: "/resources/blog" },
    //   ]
    // },
  ] : []

  // ==================== COMMON NAVIGATION ====================
  const commonNavItems: SidebarItem[] = [
    // {
    //   title: "Notifications",
    //   url: "/notifications",
    //   icon: Bell,
    //   badge: user?.unreadNotifications || 0,
    //   items: [
    //     { title: "All Notifications", url: "/notifications" },
    //     { title: "Unread", url: "/notifications?filter=unread" },
    //     { title: "Settings", url: "/notifications/settings" },
    //   ]
    // },
    // {
    //   title: "Settings",
    //   url: "/settings",
    //   icon: Settings,
    //   items: [
    //     { title: "Account Settings", url: "/settings/account" },
    //     { title: "Profile", url: "/settings/profile" },
    //     { title: "Security", url: "/settings/security" },
    //     { title: "Notifications", url: "/settings/notifications" },
    //     { title: "Preferences", url: "/settings/preferences" },
    //   ]
    // },
    // {
    //   title: "Help & Support",
    //   url: "/support",
    //   icon: HelpCircle,
    //   items: [
    //     { title: "Help Center", url: "/support/help" },
    //     { title: "Contact Us", url: "/support/contact" },
    //     { title: "Documentation", url: "/support/docs" },
    //     { title: "Feedback", url: "/support/feedback" },
    //   ]
    // },
  ]

  // ==================== COMBINE ALL NAVIGATION ====================
  const allNavItems = [
    ...filteredBrokerNavItems,
    ...userNavItems,
    ...commonNavItems
  ]

  // Filter items based on user role and enabled status
  const filteredNavItems = allNavItems.filter(item => {
    // Filter by role
    if (item.roles && user?.role && !item.roles.includes(user.role)) {
      return false
    }
    
    // Filter by enabled flag
    if (item.enabled === false) {
      return false
    }
    
    return true
  })

  // ==================== QUICK ACTIONS ====================
  const quickActions = getQuickActions(user, {
    isAdmin,
    isBroker,
    isUser,
    hasActiveSubscription,
    isVerifiedBroker,
    subscriptionPlan,
  })

  return {
    user: {
      id: user?.id || "",
      name: user?.name || "User",
      email: user?.email || "",
      phone: user?.phone || "",
      image: user?.image || "",
      role: user?.role || "USER",
      isActive: user?.isActive || false,
      
      // Broker specific
      brokerProfile: brokerProfile ? {
        id: brokerProfile.id,
        displayName: brokerProfile.displayName,
        companyName: brokerProfile.companyName,
        verificationStatus: brokerProfile.verificationStatus,
        brokerStatus: brokerProfile.brokerStatus,
        profileSlug: brokerProfile.profileSlug,
        subscription: subscription ?? null,
      } : null,
      
      // Subscription info
      hasActiveSubscription,
      subscriptionPlan,
      isVerifiedBroker,
      isFeaturedBroker,
      isPremiumBroker,
    },
    navMain: filteredNavItems,
    quickActions,
  }
}

// Helper function for quick actions
function getQuickActions(user: SidebarUserInput, options: {
  isAdmin: boolean;
  isBroker: boolean;
  isUser: boolean;
  hasActiveSubscription: boolean;
  isVerifiedBroker: boolean;
  subscriptionPlan: string;
}): QuickAction[] {
  const {
    isAdmin,
    isBroker,
    isUser,
    hasActiveSubscription,
    isVerifiedBroker,
    subscriptionPlan,
  } = options

  const actions: QuickAction[] = []

  if (isBroker) {
    actions.push(
      {
        title: "View Profile",
        url: `/brokers/${user?.brokerProfile?.profileSlug || 'preview'}`,
        icon: UserIcon,
        color: "primary"
      },
      {
        title: "Upgrade Plan",
        url: "/broker/subscription/upgrade",
        icon: Crown,
        color: "warning",
        enabled: subscriptionPlan === "FREE"
      }
    )

    if (hasActiveSubscription) {
      actions.push(
        {
          title: "Analytics",
          url: "/broker/analytics",
          icon: ChartBar,
          color: "info"
        }
      )
    }
  }

  if (isUser) {
    actions.push(
      {
        title: "Find Mortgage Originators",
        url: "/brokers",
        icon: Search,
        color: "primary"
      },
      {
        title: "EMI Calculator",
        url: "/calculator",
        icon: Calculator,
        color: "success"
      },
      {
        title: "Send Lead",
        url: "/leads/create",
        icon: MessageSquare,
        color: "info"
      }
    )
  }

  if (isAdmin) {
    actions.push(
      {
        title: "Broker Management",
        url: "/admin/brokers",
        icon: Users,
        color: "primary"
      },
      {
        title: "Analytics",
        url: "/admin/analytics",
        icon: TrendingUp,
        color: "success"
      },
      {
        title: "Support Tickets",
        url: "/admin/support/tickets",
        icon: HelpCircle,
        color: "info"
      }
    )
  }

  return actions.filter(action => action.enabled !== false)
}
