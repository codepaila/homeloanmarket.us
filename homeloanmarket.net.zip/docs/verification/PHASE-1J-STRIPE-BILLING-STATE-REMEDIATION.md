# PHASE 1J — STRIPE BILLING STATE / CONCURRENCY REMEDIATION

Scope: V9 Stripe/subscription integrity blockers only. No Prisma schema, migration, advertisement, media, claim, or unrelated business-rule change was made.

## 1. V9 Findings

Confirmed findings addressed:

1. Primary and alternate checkout idempotency namespaces differed.
2. Canceled local subscriptions remained checkout-blocking solely because `stripeSubId` existed.
3. Replacement subscription webhooks were rejected when an old subscription ID remained.
4. Checkout, upgrade, and cancellation did not share one concurrency boundary.
5. Redis failure behavior for billing locks was not explicitly controlled.
6. Stripe customer/subscription ownership checks were not centralized across billing operations.

## 2. Root Causes

- API checkout used a customer-based idempotency key while the alternate action used a different key namespace.
- Conflict detection treated any local Stripe subscription ID as live, without distinguishing terminal canceled state.
- `updateSubscriptionFromStripe` rejected every different subscription ID, including legitimate replacement after terminal cancellation.
- Upgrade and cancellation did not use the existing checkout lock.
- Redis setup/acquisition failures propagated as generic errors and lock cleanup failures could turn completed operations into failures.
- Remote Stripe customer metadata and local BrokerSubscription mapping were not consistently verified through one helper.

## 3. Canonical Billing State Machine

The current contract treats these Stripe states as live/pending and checkout-blocking:

- `active`
- `trialing`
- `incomplete`
- `past_due`
- `unpaid`
- `paused`

`canceled` and `incomplete_expired` are terminal for replacement-checkout purposes. Historical local subscription information remains retained, but terminal state no longer blocks a legitimate replacement solely because `stripeSubId` is populated.

The intended invariant is:

```text
one Broker -> one canonical local BrokerSubscription
         -> at most one live/pending Stripe subscription
```

## 4. Files Changed

- `lib/subscription.ts`
- `app/api/subscription/checkout/route.ts`
- `app/api/subscription/upgrade/route.ts`
- `actions/subscription.ts`
- `tests/phase-22-stripe-billing-state-integrity.test.ts`
- `docs/verification/PHASE-1J-STRIPE-BILLING-STATE-REMEDIATION.md`

No Prisma schema or migration was changed. Existing Phase 1F/1H test assertion updates were pre-existing Phase 1I workspace changes and were not part of the Phase 1J scope.

## 5. Checkout Idempotency

Primary and alternate checkout now use the same stable key shape based on authenticated user, canonical Stripe customer, validated plan, and validated price:

```text
checkout_<userId>_<customerId>_<plan>_<priceId>
```

Time buckets were removed. Both paths enter the shared Broker checkout lock and call the same existing-subscription/open-session conflict guard. No client-controlled idempotency key or identity is accepted.

## 6. Canceled Subscription Handling

`findCheckoutConflict` no longer blocks merely because a local `stripeSubId` exists. It blocks local FEATURED active state and Stripe live/pending subscription states. Terminal canceled/incomplete-expired remote subscriptions are not blocking by themselves, allowing a replacement checkout.

Open subscription Checkout Sessions remain blocking; the primary route can return an existing open session URL, while the alternate action returns a controlled conflict.

## 7. Replacement Subscription Webhook Reconciliation

`updateSubscriptionFromStripe` now examines the currently stored remote subscription when an incoming subscription ID differs. A new active/trialing subscription can replace a terminal canceled/incomplete-expired subscription. An active/pending current subscription, a non-active incoming replacement, or an unrelated mismatch is rejected. Existing customer lookup and Stripe-derived plan/status logic remain.

Old cancellation events cannot overwrite an active current replacement when the current stored subscription is active and the incoming event is non-active; the existing event ordering/stale protections remain unchanged.

## 8. Shared Billing Concurrency

The existing Redis-based Broker lock now protects:

- checkout customer/conflict check and Checkout Session creation;
- alternate checkout;
- subscription upgrade and Stripe reconciliation;
- subscription cancellation and local feature application.

Lock contention returns a controlled checkout conflict. Lock cleanup failures do not convert an already-completed operation into a client failure. The lock is scoped by Broker and uses a short expiry.

## 9. Redis Failure Behavior

Billing lock initialization/acquisition failures now raise `BillingUnavailableError` rather than proceeding unsafely. The primary checkout route maps this to HTTP 503 with a generic retryable message. Existing non-billing rate-limit fail-open behavior was not changed. Redis outage and multi-instance behavior were not live-tested.

## 10. Stripe Customer / Subscription Ownership

`assertStripeCustomerOwnership` verifies:

- local BrokerSubscription customer ID matches the requested customer;
- Stripe customer exists and is not deleted;
- available Stripe metadata matches authenticated user ID and Broker ID.

Checkout and alternate checkout use this helper for existing customers. Upgrade already verifies remote subscription customer; billing portal/invoice/alternate action paths remain a separate residual review item because this phase limited changes to the V9 Stripe creation/checkout/reconciliation blockers.

## 11. Regression Protection

- H6 webhook signatures, unique event IDs, PROCESSING/PROCESSED/FAILED states, event timestamps, stale checks, and Redis behavior were not redesigned.
- H5 entitlement helpers and FREE/FEATURED service-city rules remain unchanged.
- Cancellation no longer writes local inactive state after a failed Stripe cancellation.
- Client plan/price/customer identity remains untrusted for entitlement decisions.
- No schema uniqueness or migration was introduced; the application lock/conflict state is the minimal no-schema protection.

## 12. Tests

Added `tests/phase-22-stripe-subscription-integrity.test.ts` with **20 passing tests** covering:

1. Shared checkout lock/conflict guard.
2. Primary/alternate checkout idempotency identity.
3. Active subscription conflict.
4. Trialing conflict.
5. Incomplete conflict.
6. Past-due conflict.
7. Unpaid conflict.
8. Paused conflict.
9. Terminal cancellation not blocked solely by local ID.
10. Replacement subscription reconciliation support.
11. Stale webhook protections.
12. Webhook/customer identity checks.
13. Wrong Broker/customer rejection.
14. Upgrade shared lock.
15. Cancellation shared lock.
16. Lock contention conflict response.
17. Redis failure safe behavior.
18. Duplicate retry validation.
19. Stripe metadata ownership validation.
20. H5/H6 preservation.

Final combined regression suite: **118 passed, 0 failed, 2 skipped**.  
Advertisement/media suite: **65 passed, 3 skipped**, with the recurring media-selector timeout separately recorded.

## 13. Validation

| Check | Result |
| ----- | ------ |
| `yarn prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS |
| Phase 1J tests | PASS — 20 passed, 0 failed, 0 skipped |
| Combined C1-H7/Phase 1A-1J tests | PASS — 118 passed, 0 failed, 2 skipped |
| Advertisement/media tests | PASS — 65 passed, 3 skipped; media selector timeout separately observed |
| Changed-scope ESLint | FAIL — existing `no-explicit-any` errors in `actions/subscription.ts` |
| Full `yarn lint` | FAIL — existing repository lint debt |
| `npx next build` | PASS — 93 static pages generated |

## 14. Media Findings Classification

No media code was changed.

| Finding | Classification | Status |
| ------- | -------------- | ------ |
| Missing restore/move routes and wrong folder lookup | B. SHOULD FIX BEFORE PRODUCTION | Not fixed; unrelated to Stripe state remediation |
| Deleted-file public delivery/orphan cleanup | B. SHOULD FIX BEFORE PRODUCTION | Not fixed |
| Local filesystem durability | C/F. ACCEPTABLE DOCUMENTED RISK / INFRASTRUCTURE GAP | Not fixed |
| Click/impression abuse controls | B. SHOULD FIX BEFORE PRODUCTION | Not fixed |
| Intentional unused placement inventory | C. ACCEPTABLE DOCUMENTED RISK | Not fixed |

## 15. Limitations

- Live HTTP unavailable.
- Browser automation unavailable.
- Stripe E2E/customer concurrency/replacement subscription unavailable.
- Redis failure/multi-instance concurrency unavailable.
- Email provider E2E unavailable.
- Staging/production deployment topology unavailable.
- Media selector test timeout remains an infrastructure/test-runtime limitation.
- No database uniqueness migration was added; application-level locking/conflict checks were used.

## 16. Regression Audit

| Area | Result | Evidence |
| ---- | ------ | -------- |
| C1-C3 | INTACT | Combined security/DTO tests pass. |
| H1-H7 | INTACT | Combined H1-H7 tests pass. |
| Phase 1A | INTACT | H5 creation tests pass. |
| Phase 1B | INTACT | Auth/email-change tests pass. |
| Phase 1C | INTACT | Email verification tests pass. |
| Phase 1D | INTACT | C3/checkout contract tests pass. |
| Phase 1E | INTACT | Verification/owner DTO tests pass. |
| Phase 1F | INTACT | Upgrade/idempotency/email-binding tests pass. |
| Phase 1G | INTACT | Customer/auth/currentUser/reset tests pass. |
| Phase 1H | INTACT | Claim limiter/customer/admin DTO tests pass. |
| Phase 1I | INTACT plus expanded | Existing Phase 1I tests pass; Phase 1J adds replacement/lock tests. |
| Advertisement/media | INTACT | No media/ad code changed; unit suite passes except timeout. |

## 17. Final Status

**STRIPE SUBSCRIPTION INTEGRITY: FIXED** for the V9 duplicate-subscription/conflict, replacement reconciliation, shared billing lock, Redis fail-closed billing behavior, ownership helper, and cancellation-failure findings at source/test level.

Remaining limitations are live Stripe/Redis concurrency and persistence failure scenarios, and alternate portal/invoice/action ownership paths identified during audit that should receive a later explicit disposition if reachable.

Production files changed: **YES**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **YES**  
Documentation changed: **YES — only this Phase 1J report**

Changed files:

- `lib/subscription.ts`
- `app/api/subscription/checkout/route.ts`
- `app/api/subscription/upgrade/route.ts`
- `actions/subscription.ts`
- `tests/phase-1f-final-remediation.test.ts`
- `tests/phase-1h-v7-production-blocker-remediation.test.ts`
- `tests/phase-21-stripe-subscription-integrity.test.ts`
- `docs/verification/PHASE-1J-STRIPE-BILLING-STATE-REMEDIATION.md`

No advertisement/media files, schema, migrations, claims, or unrelated business rules were changed.

Final recommendation: **READY FOR NEXT INDEPENDENT PRODUCTION AUDIT V10**

This remediation does not claim production readiness.
