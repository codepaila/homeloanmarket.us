# Broker Claim & Registration Audit

Read-only implementation-vs-business-rules audit of the Broker Claim system and the public Self-Registration system. No production code was modified.

**Date:** 2026-08-09
**Mode:** READ-ONLY
**Environment:** `homeloan-listing-demo` MongoDB replica set (`rs0`), live Next.js dev server on `:3000`

---

## 1. Business Rules Audited

Authoritative sources:

| Source | Role |
|---|---|
| `docs/business/33-CLAIM-CONTRACT.md` | **Authoritative claim contract** — invitation lifecycle, token security, claimant account rules, ownership, state machines, API contracts, race conditions, security. |
| `docs/business/39-PHASE-7-CLAIM-IMPLEMENTATION-REPORT.md` | Claimant-side implementation report (PASS with non-blocking issues). |
| `docs/business/28-BROKER-REGISTRATION-IMPLEMENTATION-PLAN.md` | Self-registration target flow (atomic User+Broker+FREE). |
| `docs/business/36-OWNERSHIP-INDEX-REMEDIATION-REPORT.md` | Required partial unique ownership index (`brokers_userId_non_null_unique`). |
| `docs/business/35-PHASE-6.5-PRE-CLAIM-HARDENING-REPORT.md` | Index blocker reproduction. |
| `docs/business/38-RECIPIENT-EMAIL-IMPLEMENTATION-REPORT.md` | Invitation issuance/resend/revoke recipient behavior. |
| `prisma/schema.prisma` | Logical data model (BrokerClaim, BrokerClaimInvitation, BrokerClaimEvent, Broker, BrokerSubscription). |

### Checklist extracted from the contract

1. Admin creates `ADMIN_CREATED`, unowned (`userId=null`), `UNVERIFIED`, `isVisible=false`, FREE+ACTIVE Broker. ✔ implemented
2. Invitation: 32-byte token, SHA-256 hex digest only, unique `tokenHash`, 7-day expiry, one ACTIVE per claim, supersede+REVOKED(SUPERSEDED), GENERATED/SENT events. ✔ implemented
3. Revoke: ACTIVE→REVOKED + `revokedAt`, claim blocked, REVOKED event. ✔ implemented
4. Preview/start: digest lookup, generic errors, non-consuming GET, STARTED/IN_PROGRESS, signed 30-min HttpOnly claim context. ✔ implemented
5. Email submit: generic response, EMAIL_SUBMITTED with hash, VERIFICATION_PENDING. ✔ implemented
6. New claimant: create BROKER-role User, verified email, password, attach only at completion. ✔ implemented
7. Existing USER: reauth + verified email → promote to BROKER at completion. ✔ implemented
8. BROKER-with-profile: denied. ADMIN: denied. Inactive: denied. Google-only: allowed with provider reauth. ⚠ partially (see §12)
9. Completion: atomic conditional `Broker.userId` update where null, claim COMPLETED, invitation USED, event, FREE retained, no second Broker, no verification/subscription change. ✔ implemented
10. Rate limits on preview/start/email/setup/complete + admin issuance/resend/revoke. ⚠ partial (§16)
11. CSRF/origin protection on mutations. ❌ not implemented (relies on SameSite only)
12. Partial unique ownership index. ❌ **not present in configured DB** (§6, §16)

---

## 2. Admin Broker Management

### Pages / routes

| Asset | Route | Auth | Status |
|---|---|---|---|
| List page | `app/admin/brokers/page.tsx` | server check ADMIN | ✔ present; shows ownership/source/verification/subscription/visibility/claim+latest invitation; filters search/ownership; bulk-invite widget |
| Create page + form | `app/admin/brokers/create/page.tsx` + `AdminBrokerForm.tsx` | ADMIN | ✔ present; posts to `POST /api/admin/brokers` |
| Detail page | `app/admin/brokers/[id]/page.tsx` | ADMIN | ✔ present; stat cards + `AdminBrokerActions` |
| Actions | `app/admin/brokers/[id]/AdminBrokerActions.tsx` | client, calls admin APIs | ✔ edit profile (PATCH), issue/resend invitation, revoke active, copy claim link, invitation history |
| Bulk invitations | `app/admin/brokers/AdminBulkInvitations.tsx` | client → bulk API | ✔ present |

### APIs

| API | Method | Auth | Trace | DB effect |
|---|---|---|---|---|
| `/api/admin/brokers` | GET | ADMIN ✔ | filters, include subscription+claim+latest invitation | read |
| `/api/admin/brokers` | POST | ADMIN ✔ | normalize+validate; dup email/phone/regNo check; transaction create Broker + nested FREE subscription; slug suffix loop | Broker `ADMIN_CREATED`, `userId=null`, `UNVERIFIED`, `isVisible=false`, `FREE` ✔ |
| `/api/admin/brokers/[id]` | GET | ADMIN ✔ | include user/subscription/claim/invitations/events | read |
| `/api/admin/brokers/[id]` | PATCH | ADMIN ✔ | allowlist fields only (no `userId`, `creationSource`, `brokerStatus`, `verificationStatus`); normalizes email/website | Broker update ✔ |
| `/api/admin/brokers/[id]/claim-invitations` | POST | ADMIN ✔ | rate-limit email; `issueBrokerClaimInvitation`; send email | claim INVITED / invitation ACTIVE / prior ACTIVE→REVOKED(SUPERSEDED) / GENERATED+SENT events ✔ |
| `/api/admin/brokers/bulk-claim-invitations` | POST | ADMIN ✔ | batch ≤50, per-item email limit, per-admin batch limit | per-item same as single issue ✔ |
| `/api/admin/claim-invitations/[id]/resend` | POST | ADMIN ✔ | uses stored recipient or supplied; `issueBrokerClaimInvitation`; email | new ACTIVE, old→REVOKED ✔ |
| `/api/admin/claim-invitations/[id]/revoke` | POST | ADMIN ✔ | lock + tx; ACTIVE→REVOKED, claim→REVOKED, event | ✔ |

### Verification per checklist item

- page exists / route works: ✔
- API exists: ✔
- API authorization correct: ✔ (all ADMIN-gated)
- UI calls correct API: ✔ (AdminBrokerActions→issue/resend/revoke; AdminBrokerForm→create; bulk→bulk API)
- API performs documented operation: ✔
- DB state changes correctly: ✔ (verified in `issueBrokerClaimInvitation` tx)
- errors handled: ✔ (ClaimInvitationError→404/409/429; 422/429 email; 500 generic)
- loading states: ✔ (saving flag)
- success states: ✔ (message, emailSent indicator, claim link copy)
- duplicate actions prevented: ⚠ — Redis lock (`withBrokerClaimLock`) serializes issue/revoke per broker; second issuance supersedes rather than blocks, which matches the contract's one-active-invitation rule.

**Admin finding (non-claim):** `components/layout/admin/sideBarData.ts` links to `/admin/brokers/featured`, `/admin/brokers/verification`, `/admin/brokers/suspended`, `/admin/brokers/analytics` — **none of these routes exist** (dead navigation links).

---

## 3. Claim Invitation

Trace: `AdminBrokerActions` → `POST /api/admin/brokers/:id/claim-invitations` (or bulk/resend) → `issueBrokerClaimInvitation` → Prisma tx → `sendBrokerClaimInvitationEmail` → SENT/FAILED event.

### Contract checks

| Requirement | Result |
|---|---|
| Invitation generated | ✔ `generateClaimToken()` = `crypto.randomBytes(32)` base64url |
| Correct broker associated | ✔ lookup by `brokerId` in tx; eligibility check (`userId null`, `ADMIN_CREATED`, not `SUSPENDED`, claim not COMPLETED) |
| Recipient email correct | ✔ persisted `recipientEmail`; delivery to admin-supplied email |
| Token handling secure | ✔ raw token never persisted; URL carries raw token |
| Plaintext not persisted | ✔ only `tokenHash` (SHA-256 lowercase hex) stored; `tokenHash` is `@unique` |
| Expiration works | ✔ `expiresAt = now + 7d`; checked on every claim operation |
| Revoked cannot be used | ✔ `REVOKED` → `ClaimFlowError('REVOKED')` |
| Expired cannot be used | ✔ `EXPIRED` or `expiresAt <= now` → materialize + `ClaimFlowError('EXPIRED')` |
| Used cannot be reused | ✔ `USED` → `ClaimFlowError('USED')`; unique `tokenHash` |
| Duplicate active invitations | ✔ prior ACTIVE atomically REVOKED(SUPERSEDED) with events; only one ACTIVE remains |
| Resend behavior | ✔ issues a new invitation (supersedes old ACTIVE); uses stored email if absent |
| Invitation status changes | ✔ ACTIVE→USED/REVOKED/EXPIRED via conditional updates |
| Claim events | ✔ GENERATED (issue), SENT/FAILED (email), REVOKED (supersede), REVOKED (admin revoke), EXPIRED (materialize) |

### Findings (invitation)

- **F1 — Redis lock keyed by `brokerId`, not `brokerClaimId`.** `withBrokerClaimLock` locks `claim-issuance:{brokerId}`. Since `brokerClaim.brokerId` is `@unique` (1:1), this is functionally equivalent, but it is a deviation from the contract's literal "keyed by brokerClaimId". Low risk.
- **F2 — No admin issuance rate limit.** Contract requires an admin creation/issuance rate limit. Single-issue and resend routes rate-limit only the recipient email via the in-memory `checkEmailRateLimit`; there is no per-admin/hour issuance limit. Bulk has an admin batch limit. Partial compliance.
- **F3 — Redis/Upstash dependency for issuance.** `issueBrokerClaimInvitation` hard-fails (LOCKED/exception) if Upstash is unreachable. Contractually acceptable, but single point of failure.

---

## 4. Invitation → Claim

Trace: email link `/claim-broker/{token}` → preview → start → context cookie → email → account classification → reauth/setup → verify → complete → `/broker/dashboard`.

### Flow walkthrough

1. **Preview** `GET /api/claims/:token` → `findClaimInvitation` (digest lookup; status/expiry/source/ownership checks) → safe profile + `canStart`. Non-consuming. ✔
2. **Start** `POST /api/claims/:token/start` → validates; sets claim IN_PROGRESS + STARTED event; sets signed 30-min HttpOnly claim-context cookie. ✔
3. **Email** `POST /api/claims/session/email` → validates + in-memory rate limit; binds `email` into context; EMAIL_SUBMITTED (hash only). Generic response (no enumeration). ✔
4. **Account classification** — `classifyClaimUser` exists but is **dead code**; it is never called by any route (only by a unit test). The actual branching is inline in the UI + `completeClaimForUser` checks.
5. **New claimant** `POST /api/auth/claim-setup` → creates BROKER-role User, bcrypt password, `emailVerified=false`, **no Broker**; VERIFICATION_PENDING event; sends verification email. ✔
6. **Existing claimant reauth** `POST /api/claims/session/reauth` → checks session email == context email, active, provider (google account present) or password via bcrypt; sets `reauthenticatedAt`. ✔
7. **Verify** → `POST /api/auth/verify-email` → if claim context cookie exists, `redirectTo: '/claim-broker/continue'`, else broker-with-profile → `/setup`, else `/`. ✔
8. **Complete** `POST /api/claims/session/complete` → `completeClaimForUser` (atomic) → clears context → `{ success, brokerId, profileSlug, subscriptionPlan:'FREE', redirectTo:'/broker/dashboard' }`. ✔

### Case matrix (what actually happens)

| Case | Behavior | Verdict |
|---|---|---|
| Unauthenticated claimant | preview → start → email → new-account or reauth path | ✔ works (path-wise) |
| Existing USER | reauth + verified email → promoted to BROKER | ✔ in lib; **redirect bug** (F5) |
| Existing BROKER no profile | reauth + verified → attach | ✔ |
| Existing BROKER with another profile | CONFLICT denied | ✔ |
| New account | claim-setup → verify → continue → complete | ✔ path exists; requires reauth on continue page |
| Google auth | see §11 | ⚠ new Google claimant blocked (F7) |
| Email auth | see §12 | ✔ |
| Wrong account (email mismatch) | session email must equal context email; else INELIGIBLE | ✔ |
| Expired invitation | 410 / generic "not available" | ✔ |
| Revoked invitation | generic 404/409 | ✔ |
| Already claimed broker | OWNED → generic | ✔ |
| Already completed claim | OWNED → generic | ✔ |
| Invalid token | INVALID → generic 404 | ✔ |
| Reused token | USED → generic | ✔ |

### Findings (claim flow)

- **F5 — Stale session after role promotion.** `completeClaimForUser` promotes an existing USER to BROKER in the DB and returns `redirectTo:'/broker/dashboard'`. The client does `router.push('/broker/dashboard')`. The middleware (`proxy.ts`) reads the JWT cookie (`getToken`) which still contains role `USER`, so `/broker/dashboard` → redirected to `roleHome('USER')` = `/`. **A freshly-claimed USER lands on the home page, not the dashboard**, until the session is refreshed. The claim UI never calls `session.update()`. The same latent issue exists for the `/api/brokers` self-registration path (F6).
  - Evidence: `app/api/claims/session/complete/route.ts` → `router.push(data.redirectTo)` in both `claim-broker/[token]/page.tsx` and `claim-broker/continue/page.tsx`; `proxy.ts` lines 105-110 gate `/broker*` on cookie role.
- **F6 — `POST /api/brokers` (existing User → Broker) is broken.**
  - Wizard sends `zipCode`; API requires `pinCode` → **always 400 "Missing required fields: pinCode"** before any DB write.
  - Even if that were fixed, `createBrokerForExistingUser` already creates the FREE subscription and sets role in its own transaction, and then the route *also* runs `prisma.brokerSubscription.create({ brokerId })` (line 227) and `prisma.user.update({ role:'BROKER' })` (line 221) — the second subscription insert violates `BrokerSubscription.brokerId @unique` → **500**.
  - Additionally `profileUrl: '/broker/${profileSlug}'` references an undefined `profileSlug` (would be a runtime error if reached).
  - Net: the entire "existing USER → broker" onboarding (BrokerSetupWizard → `POST /api/brokers`) cannot succeed.
- **F7 — New Google-only claimant cannot complete.** A brand-new Google claimant is created by the NextAuth `signIn` callback with `role: 'USER'` and **`emailVerified` defaulting to `false`**. `completeClaimForUser` requires `user.emailVerified === true` (line 25). The Google flow on the claim page never sends a verification email, so the user is permanently `INELIGIBLE`. The contract allows Google-only claimants with provider reauth (no password). Only *existing, already-verified* Google users can claim. **Contract violation / functional gap.**
- **F8 — Google reauth without CSRF/state for provider callback.** The Google reauthentication path (`/claim-broker/continue?provider=google`) trusts that completing the Google OAuth flow re-authenticated the same browser. Combined with F7 it is currently unreachable for new accounts.
- **F9 — Email verification page entry without token.** After claim-setup, mode `verify` links to `/auth/verify-email` (no token/email in URL). The page shows the resend form; the actual verification link is emailed. Acceptable UX, slightly indirect.

---

## 5. Claim Ownership Completion

`lib/claim-completion.ts` → `completeClaimForUser(context, userId, sessionEmail)`.

### What completion DOES (verified)

- Re-reads invitation inside the tx; binds `tokenHash` to context; requires ACTIVE/unexpired; rejects REVOKED/USED/EXPIRED. ✔
- Requires `context.reauthenticatedAt` within 10 minutes and `context.email == sessionEmail` (case-insensitive). ✔
- Requires User active + `emailVerified` + not ADMIN. ✔
- Rejects if User already owns a *different* Broker (CONFLICT). ✔
- **Conditional ownership attach**: `broker.updateMany({ where: { id, userId: null }, data: { userId } })` — if `count !== 1` → OWNED. **Never creates a second Broker. Preserves Broker id/slug/profile/reviews/leads/subscription/verification/visibility.** ✔
- Marks claim COMPLETED + `completedAt` + `completedByUserId`. ✔
- Marks invitation USED + `usedAt`. ✔
- COMPLETED event with `{ ownership: 'attached' }`. ✔
- Promotes User role → BROKER if not already. ✔
- Subscription untouched (FREE retained). ✔

### What completion does NOT do (verified)

- No second Broker / no duplicate profile. ✔
- No silent ownership replacement (conditional `userId: null`). ✔
- No verification change. ✔
- No subscription change. ✔
- No Broker.email overwrite. ✔

### Findings

- **F10 — Completion does not use the Redis lock.** Revoke/issue serialize via `withBrokerClaimLock`, but completion relies solely on the DB transaction + conditional update. This is safe *only if* the partial unique index exists (see §6). Without it, a race between two completions of the same broker is still guarded by the conditional `userId:null` update inside a transaction — acceptable, but the index is the designed backstop.

---

## 6. Claim Security / Race Conditions

### Concurrency design

| Scenario | Mechanism | Verdict |
|---|---|---|
| Two claimants / same invitation | conditional `updateMany userId:null` in tx; one wins, loser OWNED | ✔ |
| Two completions | same conditional update | ✔ |
| Two invitations | Redis lock + tx (one ACTIVE remains) | ✔ |
| Admin revoke during claim | revoke conditional on ACTIVE inside lock+tx; completion re-reads ACTIVE | ✔ |
| Expiry during completion | `expiresAt <= now` checked inside tx | ✔ |
| Admin edits broker during claim | completion re-reads source/owner/status | ✔ |
| User created twice | unique email/phone (claim-setup uses `findUnique` + 409) | ✔ |
| User claims two Brokers | precheck `findUnique({ userId })` + unique ownership index | ⚠ depends on index |

### Findings (security)

- **F11 — CRITICAL: ownership index is not remediated in the configured database.** The contract and `36-OWNERSHIP-INDEX-REMEDIATION-REPORT.md` require the **partial** unique index `brokers_userId_non_null_unique` (`{ userId: 1 }` unique, partial `{ userId: { $type: 'objectId' } }`). The live `homeloan-listing-demo` database still has the **non-partial** `brokers_userId_key` unique index. Consequences:
  - Only **one** unowned (`userId: null`) Broker can exist in the whole collection — the core "unlimited ADMIN_CREATED unowned profiles" model is **broken** in this DB.
  - `tests/phase-7-claim.integration.test.ts` **FAILS** against this DB: the second unowned Broker creation throws `Unique constraint failed on brokers_userId_key` (verified by execution).
  - `scripts/ensure-ownership-index.ts` + `npm run db:ensure-ownership-index` exists but **has not been run** on this database.
  - `prisma/schema.prisma` still declares `userId String? @unique` — a fresh `prisma db push` would recreate the bad index. The remediation is a manual operational script, not encoded in schema.
- **F12 — No explicit CSRF/origin checks.** No claim or admin claim mutation route verifies `Origin`/CSRF token. Mitigation is only `SameSite=Lax` on cookies. Contract §16 requires CSRF/origin protection. **Deviation.**
- **F13 — Rate limiting gaps.** In-memory email limit on email-submit and claim-setup Redis limit exist. **No rate limit** on: preview (GET), start, reauth, complete, admin single-issue/resend/revoke. Contract §13/§16 requires IP + token-digest limits on preview/start/complete. Partial compliance.
- **F14 — In-memory `checkEmailRateLimit` is per-instance** (a `Map` + `setInterval`). In a multi-instance/Serverless deployment it is not a real distributed limit; acceptable in single-instance dev, not production-grade.
- **F15 — Generic errors.** Preview/start/email/complete use generic messages (good, no enumeration). ✔

---

## 7. Customer Registration

Trace: `/register` → Home Buyer card → Google (`callbackUrl "/"`) OR email (`CustomerEmailSignup` → `POST /api/auth/register/user`).

### Verified behavior

- Role = `USER`. ✔ (`register/user` sets `role: 'USER'`, `emailVerified: false`)
- No Broker created. ✔
- Duplicate email → 409 "An account with this email already exists." ✔ (email-only check)
- Google sign-in for an existing USER email: `signIn` callback checks existing user and does not re-create; adapter links the Google Account. ✔
- Password hashed with bcrypt (10 rounds). ✔
- Email verification policy: verification email sent; `emailVerified` gating only enforced at login for BROKERs — a USER with unverified email **can** still sign in (credentials authorize does not block `USER` on emailVerified). ⚠ documented behavior; note the asymmetry.
- Redirect: after signup → `/auth/verify-email?email=...`; on verified email with no claim/broker → `/`. ✔
- Authenticated USER blocked from broker-only routes: proxy redirects `/broker*` → `/` for non-BROKER. ✔ (**HTTP-verified**)
- USER can browse brokers: `/brokers` public. ✔
- USER can contact/review per existing rules: ✔ (contact/lead + review routes are separate from this audit; not re-verified here).

### Findings (customer registration)

- **F16 — Customer registration rate limit uses generic `customerRegisterRateLimit` (3/30min/IP).** Present and correct. ✔
- **F17 — Google USER sign-in does not set `emailVerified`.** A Google-created customer is permanently `emailVerified=false` unless they use an email-verification flow. For a USER this is mostly harmless (login not blocked), but it carries forward into the claim flow (F7) and broker verification logic. Deviation from the contract's Google-only-claimant allowance.

---

## 8. Self-Registered Broker

Trace: `/register` → Mortgage Broker → Google (`callbackUrl "/setup"`) or email (`/auth/signup` → `POST /api/auth/register/broker`).

### Email path (`register/broker` + `createBrokerAccount`) — the only fully working self-registration

- User created with `role: 'BROKER'`, `isActive: true`, `emailVerified: false`. ✔
- Broker created **exactly once**, `creationSource: 'SELF_REGISTERED'`, `userId = user.id`, `isVisible: true`, `UNVERIFIED`, `FREE`. ✔
- FREE subscription created **inside the same transaction** (nested `subscription.create`, `plan FREE`, `isActive true`). ✔
- Duplicate email/phone → 409 `DuplicateAccountError`. ✔
- CAPTCHA + terms enforced. ✔ (client-generated, server-checked — see F20)
- No BrokerClaim created. ✔ (verified: `createBrokerAccount` creates no claim row)
- Email verification: `sendBrokerRegistrationEmails` sends verification + admin notification; `emailVerified` required at login (`authorize` returns null for unverified BROKER). ✔
- Redirect after verify: `/setup` (broker profile exists) → setup page sees BROKER+profile → `/broker/dashboard`. ✔
- Onboarding: **skipped for email self-registration** — the wizard is only shown to Users without a profile. Since email registration already collected all profile fields, this is intentional.

### Google path — **broken** (F6)

Google → `/setup` → BrokerSetupWizard → `POST /api/brokers` → 400 (pinCode) / 500 (duplicate subscription). No Broker is ever created.

### Findings (self-registered broker)

- **F18 — `SELF_REGISTERED` broker is created `isVisible: true` but `UNVERIFIED`.** The public predicate (`isPublicBroker` / `GET /api/brokers` for non-admins) requires `verificationStatus === 'VERIFIED'`, so an unverified self-registered broker is not publicly listed until verified. Internally consistent.
- **F19 — `selfRegisteredBrokerDefaults.isVisible: true` vs admin `isVisible:false`.** Deliberate difference (self-registered broker chooses to appear pending verification); consistent with `28-BROKER-REGISTRATION-IMPLEMENTATION-PLAN.md`.
- **F20 — CAPTCHA is trivial.** The "captcha" is generated client-side and the answer is submitted with the request. It is bypassable by anyone reading the form. Not a claim/registration model issue, but it is not a real bot control.

---

## 9. Existing User → Broker

Trace: `POST /api/brokers` (BrokerSetupWizard on `/setup`).

### Verified

- Intended: create Broker for the authenticated User, preserve User, promote role via server authority, `creationSource: 'SELF_REGISTERED'`, FREE subscription, no BrokerClaim, no duplicate User/Broker.
- `createBrokerForExistingUser` (lib) itself is correct: transactional, duplicate-broker guard (`ALREADY_A_BROKER`), slug collision loop, nested FREE subscription, role promotion, no claim row.
- **BUT the route wrapper is broken (F6):** `zipCode`/`pinCode` mismatch → 400; duplicate subscription create → 500; undefined `profileSlug` in response.
- Existing User is preserved. ✔ (no duplicate User creation)
- No BrokerClaim invoked. ✔

**Verdict: the lib is correct; the HTTP route makes the flow non-functional.** Requires a fix in the route (dedupe subscription, accept `pinCode`/`zipCode`, remove redundant role update, fix response) — deferred per audit rules.

---

## 10. Existing Broker

- `/register` for a signed-in BROKER → `roleHome('BROKER')` = `/broker/dashboard`. ✔
- `/setup` for BROKER with brokerProfile → client redirect to `/broker/dashboard`. ✔
- `/auth/signin` with token → `postLoginRedirect` → dashboard. ✔
- Claim routes for an owned broker → `OWNED` generic error; issuance rejected (`userId` set). ✔
- Registration cannot create a second Broker: duplicate email/phone 409; `createBrokerForExistingUser` guards `ALREADY_A_BROKER`; unique ownership index is the backstop (**currently the non-partial index makes a second Broker for the same user fail loudly**). ✔ (the loud failure is the only upside of the unremediated index)

---

## 11. Google Authentication

| Case | Behavior | Verdict |
|---|---|---|
| New Google customer | role USER, `emailVerified=false`; lands on home | ✔ functional |
| Existing Google customer | adapter links account; no duplicate | ✔ |
| New Google broker (via `/register` → `/setup`) | **blocked by F6** (POST /api/brokers broken) | ❌ broken |
| Existing User → broker via Google | blocked by F6 | ❌ broken |
| New Google claimant | blocked by F7 (`emailVerified=false`, no verification email) | ❌ broken |
| Existing verified Google claimant | reauth via provider; works if account already verified | ✔ |
| Google sign-in on `/auth/signin` | callbackUrl → `/auth/signin?callbackUrl=...` then `postLoginRedirect` | ⚠ convoluted but resolves correctly |

**Overall: Google flows for customers work; every Google broker/claimant path is currently non-functional (F6, F7).**

---

## 12. Email Authentication

| Case | Behavior | Verdict |
|---|---|---|
| New customer | USER, unverified; verify → home | ✔ |
| Existing customer | credentials sign-in; not blocked by emailVerified for USER | ✔ (asymmetric policy) |
| New broker | BROKER, unverified; login blocked until verified | ✔ |
| Existing User → broker | broken (F6) | ❌ |
| Existing broker | verified-only login; dashboard | ✔ |
| Claimant (new) | claim-setup → verify → complete | ✔ path exists |
| Claimant (existing) | reauth with password → complete | ✔ |

---

## 13. Redirect Matrix

| Route | Anonymous | USER | BROKER | ADMIN |
|---|---|---|---|---|
| `/register` | 200 page ✔ | 307 → `/` | 307 → `/broker/dashboard` | 307 → `/admin` (**HTTP-verified**) |
| `/auth/signin` | 200 ✔ | 307 → postLogin (callback) | 307 → dashboard | 307 → admin |
| `/auth/signup` | 200 (broker form) | 200 (no auth redirect) | 200 (no auth redirect) | 200 |
| `/setup` | → `/auth/signin` (protected) | wizard | → `/broker/dashboard` | wizard (no role gate) |
| `/broker/dashboard` | → signin | → `/` | 200 | → `/admin` |
| `/claim-broker/:token` | public preview ✔ | preview/claim | preview/claim (subject to OWNED) | preview |
| `/claim-broker/continue` | session required → error | complete flow | complete flow | complete flow (rejected at lib) |
| `/brokers` | public ✔ | public ✔ | public | public |
| `/admin/*` | → signin | → `/` | → `/broker/dashboard` | 200 ✔ |

**Findings (redirects):**
- F5 stale-role redirect after claim/role promotion (USER → dashboard bounce).
- `/auth/signup` has no server-side auth redirect — a signed-in user can open the broker signup form (minor).
- `/setup` has no ADMIN/BROKER server gate; the page self-redirects BROKERs client-side. Minor.

---

## 14. Database State Matrix

| Flow | User | Broker | Broker.userId | Broker.creationSource | BrokerClaim | Invitation | Event | Subscription |
|---|---|---|---|---|---|---|---|---|
| Admin create | — | new | null | ADMIN_CREATED | none until invite | — | — | FREE+active |
| Admin issue invite | — | existing | null | ADMIN_CREATED | INVITED (create/reopen) | ACTIVE (7d) | GENERATED, SENT; REVOKED(SUPERSEDED) for prior | FREE retained |
| Admin revoke | — | existing | null | ADMIN_CREATED | REVOKED | REVOKED | REVOKED | FREE retained |
| Claim start | — | existing | null | ADMIN_CREATED | IN_PROGRESS | ACTIVE | STARTED | FREE retained |
| Claim email | — | existing | null | ADMIN_CREATED | IN_PROGRESS | ACTIVE | EMAIL_SUBMITTED | FREE retained |
| Claim setup (new) | new BROKER, unverified | — | — | — | IN_PROGRESS | ACTIVE | VERIFICATION_PENDING | — |
| Claim complete (USER) | role→BROKER | existing | →User.id | ADMIN_CREATED (unchanged) | COMPLETED + completedByUserId | USED + usedAt | COMPLETED | FREE retained |
| Customer signup | new USER, unverified | — | — | — | — | — | — | — |
| Broker email signup | new BROKER, unverified | new | →User.id | **SELF_REGISTERED** | none ✔ | none ✔ | — | FREE+active (atomic) |
| Existing User → Broker | role→BROKER | new (lib) | →User.id | **SELF_REGISTERED** | none ✔ | none ✔ | — | FREE+active (lib; **route broken F6**) |
| Expired invitation | — | existing | null | ADMIN_CREATED | →EXPIRED | →EXPIRED | EXPIRED | FREE retained |

**Special attention — SELF_REGISTERED vs ADMIN_CREATED:** self-registration (both paths) does **not** create BrokerClaim/invitation rows — matches contract. Admin flow never changes `creationSource`. ✔

**Blocking caveat:** multiple unowned brokers cannot coexist until the index is remediated (F11). Only 1 unowned broker currently exists in the demo DB (verified).

---

## 15. Duplicate Implementations

| Concern | Canonical | Legacy / duplicate / dead | Notes |
|---|---|---|---|
| Registration API | `register/user`, `register/broker` | `POST /api/brokers` (existing-user broker creation) | Duplicate conceptual path; broken (F6) |
| Broker onboarding UI | `BrokerSetupWizard` | — | dead `refreshSession` declaration (unused) |
| Signup UI | `/auth/signup` (broker), `CustomerEmailSignup` (customer) | — | distinct, fine |
| Google button | `GoogleContinueButton` | used by both cards with different callbackUrls | fine |
| Claim classification | `classifyClaimUser` in `lib/claim-flow.ts` | **dead code** — only used by a unit test, never invoked by a route | removal candidate, do not delete per audit rules |
| Auth redirect | `lib/auth-redirect.ts` | duplicate inline logic in `auth.config.ts` `redirect` callback + `proxy.ts` | three similar redirect computations; consistent today |
| Login helpers | `auth.action.ts` (`loginCheckUser`, `LoginWithCredential`) | `loginCheckUser` appears unused by the UI (signin uses `LoginWithCredential` action) | potential dead code; verify before removing |
| Subscription creation | nested in broker create (both libs) | `POST /api/brokers` adds a second manual `brokerSubscription.create` | **the F6 duplicate-subscription bug** |

No deletion performed (read-only). Report only.

---

## 16. Tests Executed

| Suite | Command | Result |
|---|---|---|
| `phase-6-admin-broker.test.ts` | `node --import tsx --test` | ✔ PASS (6) |
| `phase-7-claim.test.ts` | same | ✔ PASS (1) |
| `phase-3b-broker-policy.test.ts` | same | ✔ PASS (7) |
| `phase-15-register-flow.test.ts` (unit, no base URL) | same | ⏭ SKIP (2) |
| `phase-15-register-flow.test.ts` (HTTP, live server) | `REGISTER_BASE_URL=http://localhost:3000 ...` | ✔ PASS (2): /register public + auth redirect; broker-only route protection |
| `phase-7-claim.integration.test.ts` (live replica set) | same | ❌ **FAIL (2)** — `Unique constraint failed on brokers_userId_key` when creating a second unowned Broker (F11) |
| `phase-6.5-integration.test.ts` | not executed | ⏭ would also fail on ownership-index assertions (F11) |

Unit/policy: **16 pass, 0 fail, 2 skip**.
Integration: **0 pass / 2 fail** against the configured DB due to the unremediated ownership index.
HTTP: **2 pass** (registration redirect + broker-route protection).

No live claim email/Google OAuth could be exercised (credentials/environment prevent external delivery; no fake success recorded).

---

## 17. Verified

- Claim preview/start/email/reauth/complete implementation logic (code trace + passing unit tests).
- Atomic conditional ownership completion preserving Broker identity/profile/subscription (code trace; integration test *would* pass with correct index — the two integration tests are the ones that exercise it, and they are blocked by the DB index, not by the completion code itself).
- Invitation issuance/supersede/revoke transaction and events.
- Admin broker management UI↔API↔DB wiring (code trace).
- Self-registration email path (User+Broker+SELF_REGISTERED+FREE atomic; no claim row).
- Customer registration (role USER, no broker, duplicate handling, verify flow).
- Auth/role redirects for `/register`, `/broker/dashboard`, `/admin` (**HTTP-verified**).
- No BrokerClaim created for self-registration (DB + code).
- Token digest-only storage and unique `tokenHash`.

## 18. Partially Verified

- Existing User → Broker lib (`createBrokerForExistingUser`) — code-verified correct, but route broken (F6) so **not end-to-end verified**.
- Claim completion for existing USER/Google — logic verified; Google new-claimant broken (F7); completion integration blocked by index (F11).
- Resend/revoke admin routes — code-verified; not HTTP-exercised.
- Email delivery (claim invitation, verification) — code path verified; **not delivered** in this environment.

## 19. Not Verified

- Live end-to-end claim of an admin-created broker (blocked by F11 index).
- Live Google OAuth (no provider credentials / cannot fake).
- Live email delivery (no send executed).
- Live `/setup` → broker creation (blocked by F6).
- Bulk invitation end-to-end.
- Multi-instance rate-limit behavior (F14).

## 20. Findings (consolidated)

| # | Severity | Finding |
|---|---|---|
| F11 | **CRITICAL** | Ownership index not remediated in `homeloan-listing-demo`; non-partial `brokers_userId_key` blocks multiple unowned brokers; claim integration tests fail; `db:ensure-ownership-index` not run; schema `@unique` would recreate bad index on push |
| F6 | **HIGH** | `POST /api/brokers` broken (zipCode/pinCode 400; duplicate subscription 500; undefined profileSlug) → existing-User→broker and Google-broker onboarding non-functional |
| F7 | **HIGH** | New Google-only claimant cannot complete claim (`emailVerified=false`, no verification email) |
| F5 | **HIGH** | Stale JWT role after claim/role promotion → USER bounced from `/broker/dashboard` to `/` |
| F12 | MEDIUM | No CSRF/origin protection on claim/admin claim mutations |
| F13 | MEDIUM | No rate limits on preview/start/reauth/complete/admin single-issue/resend/revoke |
| F2 | MEDIUM | No per-admin issuance rate limit |
| F1 | LOW | Redis lock keyed by brokerId not brokerClaimId (functionally equivalent) |
| F14 | LOW | In-memory email rate limit is per-instance |
| F20 | LOW | CAPTCHA is client-generated and trivially bypassable |
| — | LOW | Dead links in admin sidebar (`/admin/brokers/{featured,verification,suspended,analytics}`) |
| — | LOW | Dead code: `classifyClaimUser`, possibly `loginCheckUser`; unused `refreshSession` |
| — | LOW | `/auth/signup` has no auth redirect; `/setup` no server role gate |

## 21. Required Fixes (proposed — NOT implemented)

1. **F11:** Run `npm run db:ensure-ownership-index` against the configured database; confirm `brokers_userId_non_null_unique` exists and the non-partial index is dropped. Decide on schema/operational documentation so `prisma db push` cannot silently recreate the bad index (documentation or a guard script; schema change is out of scope for this audit).
2. **F6:** In `app/api/brokers/route.ts` POST — accept `pinCode` (or map `zipCode`), remove the duplicate `brokerSubscription.create` and the redundant `user.update role` (already done inside `createBrokerForExistingUser`), and fix `profileUrl`.
3. **F7:** Allow Google-only claimants who reauthenticated via the provider to complete without `User.emailVerified` (per contract §120), or mark provider-verified Google email as verified at sign-in.
4. **F5:** Refresh the client session (call `session.update()` / `getCurrentUser` revalidation) after claim completion and after role promotion so the `/broker/dashboard` redirect survives middleware role checks.
5. **F12/F13/F2:** Add origin/CSRF checks and token-digest + IP rate limits to claim/admin claim mutations; add per-admin issuance limit.
6. **F1/F14/F20, dead links/code:** minor hardening after core fixes.

## 22. Recommended Next Phase

1. **Fix the ownership index first (F11)** — it is the single blocker for the entire claim system and the claim integration test suite.
2. Fix `POST /api/brokers` (F6) and the Google-claimant verification (F7).
3. Fix stale-session redirect (F5) for both claim completion and role promotion.
4. Add CSRF/origin + rate-limit hardening (F12/F13/F2) and rerun the full integration + HTTP suites.
5. Add focused HTTP tests for the invitation → claim → completion path using a seeded admin, unowned broker, and scripted email token verification (internal, not external delivery).
6. Re-run `phase-7-claim.integration` + `phase-6.5-integration` to green before any production rollout.

---

## Execution Log (read-only)

- Read: claim contract (33), implementation report (39), registration plan (28), ownership-index reports (35/36/38), schema, all claim libs/routes, all admin broker pages/routes, registration routes, auth config/actions/redirects, proxy, wizard, signup/signin/verify pages, tests.
- Ran: unit/policy suites (16 pass), HTTP register-flow suite (2 pass) against live dev server, claim integration suite (2 fail — index), read-only DB index/data inspection (confirmed non-partial unique index; 1 unowned broker; 2 claims; 2 invitations; 0 events).
- No schema, production, or test-file changes were made.

---

# REMEDIATION REPORT (2026-08-09)

This section records the remediation performed after the read-only audit. It follows the findings in the audit above. The architecture was not redesigned; the documented implementation defects were repaired using the canonical existing components.

## Fixes Performed

### F11 — Ownership index (CRITICAL)

- **Action:** Ran the existing `npm run db:ensure-ownership-index` against the configured database `homeloan-listing-demo`.
- **Result:** `brokers_userId_key` (non-partial unique) dropped; `brokers_userId_non_null_unique` (unique + partial `{ userId: { $type: 'objectId' } }`) created. Duplicate owner groups: 0.
- **Verification:** `db.brokers.getIndexes()` confirms the partial unique index and the absence of the non-partial index.
- **Operational requirement (documented):** `prisma/schema.prisma` still declares `userId String? @unique` which Prisma maps to a non-partial unique index. Running `prisma db push` (or a fresh migration) **will recreate `brokers_userId_key`** and re-break multiple unowned Brokers. Therefore `npm run db:ensure-ownership-index` MUST be run after every `prisma db push`/schema sync, and before any claim issuance. No schema field change was made because doing so would deviate from the documented remediation design (see `36-OWNERSHIP-INDEX-REMEDIATION-REPORT.md`). Consider adding the script to the post-migration runbook (documented here; no script change made).

### F6 — `POST /api/brokers` (existing USER → Broker; Google broker onboarding)

- **Action:** Repaired `app/api/brokers/route.ts` POST and the canonical `lib/broker-registration.ts`.
  - `zipCode` (wizard contract) is now accepted and mapped to the canonical `pinCode` schema field — a single canonical address field.
  - Removed the duplicate `brokerSubscription.create` (the canonical `createBrokerForExistingUser` already creates the FREE subscription inside its transaction).
  - Removed the redundant `user.update({ role: 'BROKER' })` (already performed inside `createBrokerForExistingUser`).
  - Fixed the undefined `profileSlug` response reference → uses the returned broker's `profileSlug`.
  - Bank partnerships moved into the canonical `createBrokerForExistingUser` transaction (with proper `BankType` import), keeping the whole operation transactional and fixing an un-imported `BankType` reference in the route.
- **Verified (HTTP):** Existing USER (hannah.moore) → `POST /api/brokers` with wizard payload → 200, broker created once, `creationSource=SELF_REGISTERED`, `userId` attached, 1× FREE subscription, 1× bank, role promoted to BROKER, **0 claim rows**. Second POST → 400 "You already have a broker profile" (no duplicate broker).

### F5 — Stale JWT after role promotion

- **Action:** The Auth.js `jwt` callback already re-reads the User from the DB on every session request (`lib/auth.config.ts`), so a session refresh re-signs the cookie with the fresh role. Wired the existing session-update mechanism into the UI:
  - `BrokerSetupWizard` now awaits `useSession().update()` (already-declared `refreshSession`) before navigating to `/broker/dashboard`.
  - `app/claim-broker/[token]/page.tsx` and `app/claim-broker/continue/page.tsx` now `await useSession().update()` after successful claim completion before `router.push('/broker/dashboard')`.
- **Verified:** Session fetch after a DB role promotion returns the promoted role (jwt callback re-reads DB), confirming `update()` yields a fresh cookie so middleware no longer bounces USER→`/`.

### F7 — Google claimant contract compliance

- **Action:** Per contract §120, a Google-only claimant is allowed when the User is active, Google reauthentication succeeds, and the provider email matches the submitted claim email — no password and no `User.emailVerified` requirement.
  - `lib/claim-context.ts` now carries `reauthenticatedVia?: 'google' | 'credentials'`.
  - `app/api/claims/session/reauth/route.ts` records the provider used.
  - `lib/claim-completion.ts` permits completion when `emailVerified` is false **only if** the claimant reauthenticated via Google AND the account has a Google provider link (identity proven by the Auth.js Google flow). All other cases still require `emailVerified`. ADMIN/inactive/other-owner rules unchanged.
- **Verified (integration):** New Google-linked user with `emailVerified=false` completes the claim and the ADMIN_CREATED Broker becomes owned; identity preserved.

### Security hardening (F12 / F13 / F2)

- **Action:** Added `lib/origin.ts` (`isSameOriginRequest`, `clientIp`) following existing env-based origin patterns, and distributed Upstash Redis rate limiters in `lib/rateLimit.ts`.
  - **Origin/CSRF:** applied to all claim mutations (`start`, `session/email`, `session/reauth`, `session/complete`, `auth/claim-setup`) and all admin claim mutations (issue, bulk, resend, revoke). Mutations without a same-origin header are rejected 403.
  - **Rate limits (Upstash Redis):** `claimPreview`, `claimStart`, `claimEmailSubmission`, `claimReauth`, `claimComplete`, `claimSetup` (per IP+token/invitation), plus per-admin `adminClaimInvitation`, `adminClaimResend`, `adminClaimRevoke`.
  - Generic claim error responses preserved (no enumeration).
- **Verified (HTTP):** POST to `session/complete` without Origin → 403; with same-origin Origin → passes to session guard (401 without session); with malicious Origin → 403. Admin/broker routes unaffected in normal browser flows.

### Admin sidebar dead links

- **Action:** Removed non-existent navigation targets `/admin/brokers/featured`, `/verification`, `/suspended`, `/analytics` from `components/layout/admin/sideBarData.ts`. They were intentionally not invented as pages; the surviving broker-management entries (`All Brokers`, `Create Broker`) reflect the existing implemented routes.

## Tests Performed

All commands run from the repository root. Integration suites run against a fresh isolated database `homeloan-listing-test` (dropped, `prisma db push`, then `db:ensure-ownership-index`).

| Suite | Command | Result |
|---|---|---|
| Prisma validate | `npx prisma validate` | PASS |
| Prisma generate | `npx prisma generate` | PASS |
| TypeScript | `npx tsc --noEmit` | PASS (clean) |
| Focused unit/policy | `node --import tsx --test tests/phase-7-claim.test.ts tests/phase-6-admin-broker.test.ts tests/phase-3b-broker-policy.test.ts` | 16 pass / 0 fail |
| Login redirect / admin auth | `phase-13.2-login-redirect`, `phase-13.3a-admin-auth` | 6 pass / 0 fail (3 HTTP-skipped) |
| Subscription / demo-data | `phase-8.1-subscription`, `phase-13.5-demo-data` | 4 pass / 0 fail (5 HTTP-skipped) |
| Claim integration (isolated) | `phase-7-claim.integration.test.ts` | 2 pass / 0 fail |
| Ownership index integration (isolated) | `phase-6.5-integration.test.ts` | 7 pass / 0 fail |
| **New remediation integration** | `tests/phase-7.5-remediation.integration.test.ts` | 11 pass / 0 fail |
| HTTP registration flow (live) | `REGISTER_BASE_URL=http://localhost:3000 node --import tsx --test tests/phase-15-register-flow.test.ts` | 2 pass / 0 fail |
| HTTP origin guard | curl POSTs to claim endpoints | 403 no-origin / 403 evil-origin / 401 same-origin-no-session ✔ |
| HTTP F6 onboarding | live login + `POST /api/brokers` (wizard payload) | 200; DB assertions ✔ |

Note: `phase-6.5` and `phase-7` integration suites share one Prisma process/DB; running them in a single `node --test` invocation makes phase-6.5's first test (`user.count()===0`) fail because phase-7 created users first. Each passes independently against a pristine DB. This is a test-harness isolation property, not a product defect.

## Database Verification (final state, `homeloan-listing-demo`)

- Ownership index: `brokers_userId_non_null_unique` present (unique, partial `{userId:{$type:'objectId'}}`); non-partial `brokers_userId_key` absent.
- Unowned Brokers: 1 (ADMIN_CREATED) — multiple-unowned coexistence proven by integration test A and the HTTP admin two-broker creation test (both 201).
- Duplicate non-null owner groups: 0; brokers with >1 subscription: 0.
- SELF_REGISTERED Brokers (6): 0 BrokerClaim rows.
- BrokerClaims (2): both belong to ADMIN_CREATED brokers (INVITED, COMPLETED); no self-registration contamination.
- Claimed Broker retains `creationSource=ADMIN_CREATED` and its original identity/subscription.
- All temporary test data (HTTP F6 broker, HTTP claim seed, HTTP admin test brokers) removed; demo DB restored to its 8-broker / 2-claim / 2-invitation seed state.

## Remaining Limitations

- Google OAuth cannot be exercised end-to-end (no provider credentials); the contract-compliant behavior is covered by the new integration test J at the service layer.
- Real email delivery (claim invitation, verification) is not sent in this environment; delivery logic unchanged and not externally verified.
- The `prisma db push` → `brokers_userId_key` recurrence requires the documented post-push `db:ensure-ownership-index` step.
- `classifyClaimUser` remains dead code (test-only); `loginCheckUser` may be dead; `checkEmailRateLimit` remains per-instance. Not removed per audit discipline.
- `/auth/signup` still has no server-side auth redirect; `/setup` has no server role gate (client-side redirect only). Low risk, unchanged.

## Operational Requirements

1. Run `npm run db:ensure-ownership-index` after every `prisma db push`/schema sync and before enabling claim issuance.
2. Keep Upstash Redis (`UPSTASH_REDIS_REST_URL`/`TOKEN`) configured; claim/admin claim mutation rate limiting and the invitation lock depend on it.
3. `NEXT_PUBLIC_APP_URL`/`NEXTAUTH_URL`/`AUTH_URL` must reflect the public origin; the origin guard derives allowed origins from them.

## Final Status

**READY WITH NON-BLOCKING LIMITATIONS.**

Acceptance criteria met: multiple unowned Brokers ✔, partial unique ownership index ✔, admin invitation lifecycle ✔, claim lifecycle ✔, existing USER claim ✔, new claimant ✔, Google claimant (contract, service-level) ✔, claim-completion role/session refresh ✔, existing USER→Broker onboarding ✔ (HTTP), Google broker registration wiring ✔ (same route; OAuth not externally exercised), email customer registration ✔, email broker registration ✔, no duplicate Broker ✔, no duplicate subscription ✔, self-registration creates no BrokerClaim ✔, admin-created claim does not create a second Broker ✔, Broker identity/profile/subscription preserved ✔, revoked/expired/used blocked ✔, race conditions protected ✔, rate limits present ✔, origin/CSRF protection present ✔, integration tests pass ✔, HTTP verification passes ✔, database assertions pass ✔.

