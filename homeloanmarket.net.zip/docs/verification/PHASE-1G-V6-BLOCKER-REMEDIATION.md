# PHASE 1G — V6 BLOCKER REMEDIATION

Scope: V6 findings for Stripe customer authorization, alternate login hardening, generic current-user safety, reset-token expiry, and alternate checkout idempotency.

## 1. Findings Confirmed

1. `createStripeCustomer` was exported as a server action without authentication or server-derived identity.
2. `loginCheckUser` accepted an optional IP and returned account-state-specific responses, creating an alternate throttling/enumeration weakness.
3. `getCurrentUser()` selected default User scalars and spread the result, retaining password and reset/verification token fields for any unsanitized caller.
4. Password reset accepted a matching token when `resetPasswordTokenExpiry` was null.
5. The alternate server-action checkout path created Stripe Checkout Sessions without idempotency.

Advertisement/media findings were reviewed but were not directly required for these five V6 security/payment blockers. They remain classified separately as operational SHOULD-FIX or infrastructure risks.

## 2. Root Causes

### Stripe customer authorization

The server action accepted caller-supplied email/name/metadata and created a Stripe customer without resolving the authenticated user.

### Alternate login

The helper guarded rate limiting with `if (ip)`, so callers could omit the IP. It also returned distinct messages/error types for unverified and inactive accounts.

### Generic current user

The loader used Prisma’s default User scalar selection and `{ ...user }`, relying on every future caller to remember to sanitize the object before client serialization.

### Reset expiry

The expiry branch was conditional: a null expiry bypassed the expiration check and allowed token use.

### Alternate checkout

The server action used `stripe.checkout.sessions.create` without a Stripe idempotency option, unlike the primary API route.

## 3. Canonical Source of Truth

- Authentication identity: `getCurrentUser()` and Auth.js server session state.
- Active credential login boundary: `LoginWithCredential` in `actions/auth.action.ts` and `brokerLoginRateLimit`.
- Generic user data: explicit scalar `select` in `lib/currentUser.ts`; client pages use explicit DTOs.
- Reset lifecycle: `actions/email.action.ts` issuance and `app/api/auth/reset-password/route.ts` validation/invalidation.
- Checkout plan/price: `lib/stripe.ts` and `validatePlanPrice`.
- Stripe subscription state: `SubscriptionService` and signed webhook processing.

## 4. Exact Fixes

### `createStripeCustomer`

`actions/subscription.ts` now calls `getCurrentUser()` before any Stripe mutation, rejects unauthenticated callers, derives email/name/metadata from the trusted user, and retrieves an existing stored customer when present. Caller-supplied identity arguments were removed.

### Alternate login helper

`loginCheckUser` now requires an IP argument and always invokes `loginRateLimit` before database lookup/password comparison. Missing credentials, invalid credentials, unverified brokers, and inactive users all return the generic `Invalid email or password.` response. OAuth behavior was not changed.

### Generic current-user selection

`lib/currentUser.ts` now explicitly selects safe User scalars: ID, name, email, phone, image, role, active state, email verification state, creation time, and the existing broker relation required by server consumers. Password, reset-token, email-verification-token, account, and contact-message fields are not selected by the generic loader. Existing server-required broker/subscription behavior was preserved.

### Reset expiry

`app/api/auth/reset-password/route.ts` now rejects and clears a token when expiry is null or not in the future. Hash comparison, bcrypt update, single-use clearing, and generic responses remain unchanged.

### Alternate checkout idempotency

`actions/subscription.ts:createCheckoutSession` now supplies Stripe a key derived from authenticated user ID, customer ID, validated plan/price, and a server-generated ten-minute bucket. It does not accept a client idempotency key and retains existing user/customer and plan/price validation.

## 5. Security Preservation

- Stripe customer creation cannot be performed anonymously or for a caller-selected user.
- Alternate login attempts cannot omit rate-limit identity and no longer disclose account state.
- Generic User scalar credentials/tokens cannot enter results through default Prisma selection.
- Null-expiry reset records fail closed and are invalidated.
- Alternate checkout remains authenticated, customer-bound, and plan/price validated.
- Stripe webhook signature, event ordering, and event-id idempotency were not changed.
- C1-C3, H1-H7, Phase 1A-1F, claims, broker ownership, advertisements, and media behavior were not otherwise modified.

## 6. Authentication Changes

The active `LoginWithCredential` path remains unchanged and rate-limited. The alternate `loginCheckUser` helper now follows the same required-IP limiter contract and generic failure semantics. OAuth provider actions were not changed.

## 7. Current-User DTO Boundary

The generic loader now explicitly selects User scalars instead of default Prisma User fields. It continues to provide the broker relation and subscription information required by server-only billing/entitlement callers. Known client pages use explicit personal, owner, public, or admin DTOs; the Phase 1F company-edit DTO remains intact.

Focused tests verify that password, token, account, and contact-message fields are absent from the generic loader selection. Live RSC/browser serialization was unavailable.

## 8. Password-Reset Expiry Handling

The reset endpoint now requires:

```text
reset token exists
AND resetPasswordTokenExpiry exists
AND resetPasswordTokenExpiry > now
```

Null and expired records are cleared and rejected. Issuance still uses a cryptographically random token, stores only a SHA-256 digest, sends the correct reset URL, and clears the token after successful use.

## 9. Checkout Idempotency

Both the primary checkout API and alternate server-action checkout now use server-derived Stripe idempotency keys. The key includes authenticated identity/customer, validated plan/price, and a server time bucket. A client cannot cause cross-user key collisions or bypass authentication/plan validation. Stripe webhook event-id idempotency remains independent.

## 10. Variant Search

Repository searches were performed for:

- `createStripeCustomer`, `stripe.customers.create`, and customer creation.
- `signIn("credentials")`, `LoginWithCredential`, `loginCheckUser`, and login limiters.
- `getCurrentUser`, `currentUser`, `accounts`, OAuth token names, and `contactMessages`.
- `passwordResetToken`, reset expiry, raw-token logging, and reset routes.
- `stripe.checkout.sessions.create`, checkout actions, `idempotency`, and `idempotencyKey`.

The primary remaining broad-data observations are server-only broker/subscription relations retained by `getCurrentUser()` for billing/entitlement callers and existing authenticated billing DTOs. No new password/OAuth/contact-message client leak was found in the focused boundary review.

## 11. Regression Tests

Added `tests/phase-1g-v6-blocker-remediation.test.ts` with **5 passing tests** covering:

1. Authenticated server-derived Stripe customer identity.
2. Required-IP rate limiting and generic alternate-login errors.
3. Explicit generic current-user scalar exclusion.
4. Null reset expiry rejection and token lifecycle controls.
5. Alternate checkout server-derived idempotency and plan validation.

Final combined regression command: **109 passed, 0 failed, 2 skipped**.  
Advertisement/media command: **65 passed, 0 failed, 3 skipped**.

## 12. Validation

| Check | Result |
| ----- | ------ |
| `yarn prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS |
| Phase 1G focused suite | PASS — 46 passed, 0 failed, 0 skipped |
| Combined security/subscription/auth/broker/claim suite | PASS — 109 passed, 0 failed, 2 skipped |
| Advertisement/media suite | PASS — 65 passed, 0 failed, 3 skipped |
| Changed-file ESLint | FAIL — three pre-existing `no-explicit-any` errors in `actions/subscription.ts` |
| Full `yarn lint` | FAIL — existing repository lint errors/warnings |
| `npx next build` | PASS — 93 static pages generated |
| Live HTTP | UNAVAILABLE |
| Browser automation | UNAVAILABLE |
| Stripe E2E | UNAVAILABLE |
| Email/Redis/OAuth E2E | UNAVAILABLE |

No tests were weakened or deleted. No validation failure was hidden.

## 13. Limitations

- No live HTTP application/database fixture was supplied.
- Browser/RSC payload behavior was not executed in a real browser.
- Stripe Checkout/payment/webhook/retry behavior was not exercised against Stripe.
- Email delivery and token interception were not live-tested.
- Redis failure and multi-instance rate-limit/lock behavior were not live-tested.
- Full lint remains blocked by pre-existing repository debt.

## 14. Regression Audit

| Area | Result | Evidence |
| ---- | ------ | -------- |
| C1-C3 | INTACT | Combined security tests pass; generic current-user scalar selection is safer. |
| H1-H7 | INTACT | Combined regression tests pass. |
| Phase 1A | INTACT | H5 creation tests pass. |
| Phase 1B | INTACT | Login/forgot/resend and email-change tests pass. |
| Phase 1C | INTACT | Signup and email-change verification tests pass. |
| Phase 1D | INTACT | C3/profile and public checkout tests pass. |
| Phase 1E | INTACT | Verify endpoint and owner DTO tests pass. |
| Phase 1F | INTACT | Company edit DTO, upgrade reconciliation, idempotency, and email binding tests pass. |
| Stripe webhook | INTACT | Webhook source unchanged; ordering/idempotency tests pass. |
| Broker ownership/contact | INTACT | Broker policy/public contact tests pass. |
| Claims | INTACT | Claim recipient/policy tests pass. |
| Advertisements/media | INTACT | 65 tests pass; no advertisement/media files changed. |

## 15. Remaining Risks

1. `getCurrentUser()` still returns server-required broker/subscription relation data; future callers must continue using explicit client DTOs.
2. Full billing/payment DTO minimization and admin broker DTO minimization remain separate cleanup work.
3. Advertisement/media lifecycle, URL validation, click controls, and local storage durability remain unresolved.
4. Reset completion throttling/password policy and webhook Redis fail-open behavior remain.
5. Live external integration behavior remains unverified.

## 16. Final Remediation Status

| V6 Finding | Status |
| ---------- | ------ |
| `createStripeCustomer` authorization | **FIXED** |
| Alternate login bypass/account-state exposure | **FIXED** |
| Generic `getCurrentUser()` unsafe User scalar selection | **FIXED** for credential/token scalar exposure |
| Reset null expiry | **FIXED** |
| Alternate checkout idempotency | **FIXED** |

Production files changed: **YES**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **YES**  
Documentation changed: **YES — only this Phase 1G report**

Final recommendation:

**READY FOR NEXT INDEPENDENT PRODUCTION AUDIT**

This phase does not claim production readiness. The next step is `FINAL-PRODUCTION-READINESS-AUDIT-V7`.
