# FINAL PRODUCTION READINESS AUDIT V8

Audit date: 2026-08-10  
Repository: HomeLoanMarket US  
Mode: READ-ONLY / AUDIT-ONLY

## 1. Executive Verdict

**NO-GO**

The Phase 1H changes are present: claim credential sign-ins are covered by the Auth.js limiter, Stripe customer creation uses authenticated identity and Stripe idempotency, checkout keys are deterministic, and the admin broker page uses a narrow DTO.

The current implementation still has a production-blocking subscription integrity issue. Both checkout paths permit a broker with an existing subscription to create another independent Stripe subscription. The local data model has one `BrokerSubscription` per broker and `updateSubscriptionFromStripe` rejects a different Stripe subscription once `stripeSubId` is populated. A second paid subscription can therefore be charged by Stripe while webhook reconciliation fails or local entitlement no longer has an unambiguous source.

Additional HIGH/medium risks remain around Stripe customer persistence/ownership, direct verification/cancellation mutation, claim/login and reset controls, and media lifecycle. The decision is based on these application findings, not lint debt or unavailable E2E infrastructure.

## 2. Validation Summary

| Check | Result | Evidence |
|---|---|---|
| Documentation inventory | PASS with contradictions | V1-V7 and Phase 1A-1H reports exist; current claim contract is `docs/business/33-CLAIM-CONTRACT.md`; requested `docs/CLAIM-CONTRACT.md` is absent. |
| Security/subscription/auth regression suite | PASS with skips | 113 passed, 0 failed, 2 skipped. |
| Advertisement/media suite | PASS with test-run limitation | 65 passed, 3 skipped; `phase-13.13-media-selector.test.tsx` timed out after 120 seconds in the combined run and again after 240 seconds when isolated. |
| Prisma validate | PASS | `yarn prisma validate`. |
| Prisma generate | PASS | `npx prisma generate`. |
| TypeScript | PASS | `npx tsc --noEmit`. |
| Production build | PASS | `npx next build`; 93 static pages generated. |
| Changed-scope ESLint | FAIL | Existing `no-explicit-any` errors in `actions/subscription.ts` and existing auth-config warnings. |
| Full lint | FAIL | Existing repository-wide lint errors/warnings. |
| Live HTTP | UNAVAILABLE | No running app/database fixture. |
| Browser automation | UNAVAILABLE | No browser runtime. |
| Stripe E2E | UNAVAILABLE | No real Stripe session/payment/webhook fixture. |
| Email/Redis/OAuth E2E | UNAVAILABLE | No provider/deployment fixture. |

## 3. Previous Blocker Verification

### C1

**Status:** VERIFIED/FIXED.

**Evidence:** JWT callback does not merge client `session.user`; claims refresh from trusted Prisma state. Direct claim credential sign-ins now pass through the Auth.js `authorize` limiter.

**Affected workflow:** Authentication/session/claims.

**Regression test:** C1 tests and Phase 1H claim-auth test pass.

### C2

**Status:** VERIFIED/FIXED.

**Evidence:** Public contact resolves canonical profile slug, validates public eligibility, rejects absent identifiers, and stores against resolved Broker.

**Affected workflow:** Anonymous public lead creation.

**Regression test:** Phase 16 C2 tests pass; live HTTP unavailable.

### C3

**Status:** PARTIAL — known admin variant remains.

**Evidence:** Personal/company-edit/dashboard/owner DTO paths are explicit and generic User credential/token scalars are excluded. `app/admin/brokers/[id]/page.tsx` now selects limited fields and passes `brokerDto`, but `lib/currentUser.ts` still returns server-required broker/subscription relations and must not be treated as a universal client DTO.

**Affected workflow:** Admin broker detail and future generic-loader callers.

**Regression test:** C3/Phase 1H tests pass; live RSC/browser serialization unavailable.

### H1

**Status:** VERIFIED/FIXED.

**Evidence:** Public broker serializers omit protected contact data unless server-derived paid/owner/admin permission permits it.

**Affected workflow:** Public broker listing/detail/contact.

**Regression test:** Phase 17 tests pass.

### H2

**Status:** VERIFIED/FIXED on canonical routes.

**Evidence:** Broker/company ID/slug mutations use ownership checks and field allowlists. `/api/brokers/me` remains a separate manual implementation but current privileged fields are excluded.

**Affected workflow:** Broker profile/company mutation.

**Regression test:** Phase 17/18 tests pass.

### H3

**Status:** VERIFIED with residual abuse controls.

**Evidence:** Reset tokens are cryptographically generated, SHA-256 hashed, require non-null future expiry, bcrypt-update the password, and clear token/expiry on use. Completion endpoint has no dedicated limiter/password policy.

**Affected workflow:** Password recovery.

**Regression test:** H3/Phase 1G tests pass.

### H4

**Status:** VERIFIED/FIXED.

**Evidence:** No invalid verification enum/field writes found; schema state remains `UNVERIFIED | VERIFIED`.

**Affected workflow:** Broker verification.

**Regression test:** Phase 18 tests pass.

### H5

**Status:** VERIFIED/FIXED.

**Evidence:** `assertServiceCityLimit` is applied before existing-user Broker creation and update paths use paid entitlement. FREE is one city; FEATURED/paid is unlimited.

**Affected workflow:** Broker creation/service areas.

**Regression test:** Phase 18/19 tests pass.

### H6

**Status:** VERIFIED with residual ordering risk.

**Evidence:** Webhook signatures, unique event IDs, PROCESSING/PROCESSED/FAILED states, stale checks, and Redis lock/fallback are present. Equal-second event timestamps and fail-open lock fallback remain.

**Affected workflow:** Stripe webhook lifecycle.

**Regression test:** H6/webhook tests pass; live concurrency unavailable.

### H7

**Status:** VERIFIED/FIXED.

**Evidence:** Recipient matching is enforced during claim email submission and completion, with token status/expiry, reauth, origin, and transactional ownership checks.

**Affected workflow:** Broker claim.

**Regression test:** H7/claim tests pass.

## 4. Phase 1A–1H Verification

| Phase | Finding | Current Status | Evidence |
|---|---|---|---|
| 1A | H5 creation limit | VERIFIED/FIXED | Server-side creation check and Phase 19 tests pass. |
| 1B | Auth hardening | PARTIAL | Main paths are limited; reset completion and trusted-proxy assumptions remain. |
| 1C | Email-change verification | VERIFIED/FIXED | Target-bound digest, collision, expiry, single-use, verified/unverified tests pass. |
| 1D | C3/profile + public checkout request | VERIFIED/FIXED | Safe personal DTO and `{ priceId, plan }` contract pass tests. |
| 1E | Verify route + owner DTO | VERIFIED on intended paths | Verify route validates Stripe state; owner DTOs are explicit. |
| 1F | Company DTO + upgrade/idempotency/email binding | PARTIAL | Targeted changes pass; multiple-subscription and alternate mutation risks remain. |
| 1G | V6 blockers | VERIFIED on changed paths | Customer auth, generic scalar selection, reset null expiry, alternate key tests pass. |
| 1H | V7 blockers | PARTIAL | Claim limiter/admin DTO/customer idempotency pass, but checkout permits multiple independent subscriptions. |

## 5. Equivalent / Variant Findings

| Finding | File/Path | Severity | Impact | Classification |
|---|---|---|---|---|
| Multiple independent checkout subscriptions allowed for one broker | `app/api/subscription/checkout/route.ts:41-92`, `actions/subscription.ts:51-91` | HIGH | Multiple paid Stripe subscriptions can be created while one local BrokerSubscription cannot represent them safely; webhook reconciliation can fail or become ambiguous | A. MUST FIX BEFORE PRODUCTION |
| Stripe customer ID is nullable/non-unique and webhook uses `findFirst` | `prisma/schema.prisma:253-271`, `lib/subscription.ts:202-214` | HIGH conditional | Misbound/duplicated customer ID can direct webhook state to wrong Broker | B. SHOULD FIX BEFORE PRODUCTION |
| Verification and cancellation mutate entitlement outside webhook-only authority | `app/api/subscription/verify/route.ts:48-58`, `lib/subscription.ts:239-275` | HIGH conditional | Browser-triggered verification/cancellation can race or diverge from Stripe lifecycle | B. SHOULD FIX BEFORE PRODUCTION |
| Alternate Stripe actions do not verify Stripe object customer | `actions/subscription.ts:107-145` | MEDIUM | Local ID match is relied on without independently checking Stripe customer ownership | B. SHOULD FIX BEFORE PRODUCTION |
| Checkout customer ID is trusted from local state without Stripe object validation | `app/api/subscription/checkout/route.ts:41-69` | MEDIUM | Stale/misbound local ID is passed to Stripe Checkout | B. SHOULD FIX BEFORE PRODUCTION |
| Stable checkout keys differ across API/action namespaces | `app/api/subscription/checkout/route.ts:72-92`, `actions/subscription.ts:87-89` | MEDIUM | Same logical request through alternate paths is not deduplicated cross-path | B. SHOULD FIX BEFORE PRODUCTION |
| Claim direct credential paths bypass form action but hit Auth.js limiter | `app/claim-broker/[token]/page.tsx`, `app/claim-broker/continue/page.tsx`, `lib/auth.config.ts` | D. ALREADY FIXED | Shared `authorize` limiter covers direct signIn calls | D. ALREADY FIXED |
| Admin broker full model client boundary | `app/admin/brokers/[id]/page.tsx` | D. ALREADY FIXED | Explicit admin action DTO now excludes subscription relation/identifiers | D. ALREADY FIXED |
| Advertisement restore/move routes absent | `hooks/useAdminAds.ts`, `app/api/admin/media` | MEDIUM/HIGH functional | Admin media recovery/move actions return 404 | B. SHOULD FIX BEFORE PRODUCTION |
| Deleted media remains publicly retrievable | `app/uploads/[...path]/route.ts`, `mediaRepository.ts` | MEDIUM | Soft-deleted media URLs remain available and consume storage | B. SHOULD FIX BEFORE PRODUCTION |

## 6. Stripe Customer Verification

### Creation paths

- Primary: `/api/subscription/checkout` checks current authenticated user and Broker, retrieves stored `stripeCustomerId`, otherwise calls Stripe customer creation with `stripe_customer_${user.id}` and persists via BrokerSubscription upsert.
- Alternate: `actions/subscription.ts:createStripeCustomer` checks authenticated user/Broker, reuses stored ID, otherwise uses the same server-derived idempotency key and persists via BrokerSubscription upsert.
- No admin/background customer creation path was found.

### Authentication/ownership

Both known paths derive identity from `getCurrentUser`. Metadata includes authenticated user/Broker IDs. Existing IDs are used without retrieving/validating the remote Stripe customer object.

### Idempotency/persistence

The Stripe customer key is deterministic and stable per user. New IDs are persisted. This protects retries at Stripe, but Stripe creation and database persistence remain separate operations; a DB failure after Stripe success leaves an orphan until retry. No durable creation-attempt record exists.

### Concurrency

Concurrent calls using the same Stripe idempotency key should resolve to one Stripe customer, but real Stripe concurrency was not executed. Application-level locking/unique customer association is not present. `stripeCustomerId` is not unique in Prisma, and webhook lookup uses `findFirst`.

### Classification

Primary customer auth/idempotency: VERIFIED. Complete duplicate/ownership integrity: NOT FULLY VERIFIED; HIGH conditional risk remains.

## 7. Checkout Verification

- **Entry points:** Public pricing page and broker subscription page call `/api/subscription/checkout`; alternate `createCheckoutSession` server action also creates sessions.
- **Price/plan:** `validatePlanPrice` requires exact active catalog plan/price pair; FREE has no paid price and is rejected.
- **Idempotency:** Primary/action keys are deterministic, server-derived, authenticated identity/customer/plan/price scoped. They differ by namespace across paths and do not use a persisted checkout intent.
- **Ownership:** Primary route requires authenticated Broker; verification checks Stripe customer and metadata ownership. Alternate action checks local user/customer IDs.
- **Success:** Success URL points to `/broker/subscription/success`; `/api/subscription/verify` requires complete/paid session and active/trialing Stripe subscription, then derives price from Stripe.
- **Webhook:** Signature and event ID/ordering controls remain; direct verification also updates state through `updateSubscriptionFromStripe`.
- **Duplicate sessions:** Different plan/price values or alternate path namespaces can create separate sessions. No active-subscription/open-checkout guard exists.

## 8. Authentication / Session Verification

Auth.js Credentials `authorize` now rate-limits all direct credential calls, including claim pages. `LoginWithCredential` remains rate-limited. Generic errors are preserved in the alternate helper. JWT identity refresh is database-derived and no client session merge exists. OAuth is separate. Live proxy/header/Redis behavior is unavailable.

## 9. DTO / Privacy Boundary Verification

Personal, company-edit, company display, dashboard, owner subscription, and admin broker page paths use explicit or selected fields. Generic currentUser excludes User password/token/accounts/contact-message fields. Public broker DTO strips IDs/ownership/claim/subscription/contact relations. `getCurrentUser` still includes server-required broker/subscription relations for server callers, so its result is not an unrestricted client DTO. Billing invoice responses expose broad Stripe-derived identifiers and URLs to authenticated clients.

## 10. Subscription Verification

FREE/FEATURED entitlement helpers are server-side and expired FEATURED falls back to FREE. Upgrade reconciles from Stripe after customer ownership validation. However, checkout does not prevent a Broker with an existing Stripe subscription from creating another subscription. `BrokerSubscription` has one record per Broker but no unique Stripe subscription ID; later webhook binding can reject a different subscription. Cancellation can mark local inactive even when Stripe cancellation fails. Trial status handling differs between some service paths.

## 11. Claim Verification

Invitation tokens are hashed and status/expiry checked. Recipient email is checked at session submission and completion. Completion requires reauth and uses conditional unowned Broker update in a transaction. Direct claim credential sign-ins now pass through Auth.js `authorize` rate limiting. Generic errors and revocation/used checks remain. Live claim/browser/email/Redis concurrency unavailable.

## 12. Broker / Ownership Verification

Canonical broker/company mutations use ownership and allowlists. `/api/brokers/me` remains a parallel manual allowlist/validation path. Admin mutations are role-protected. Public contact writes against resolved Broker. The main unresolved ownership-integrity risk is Stripe customer ID ambiguity in webhook resolution.

## 13. Advertisement / Media Verification

### Admin CRUD

Admin role checks and create/update/archive/delete/enable/schedule routes exist. Media restore/move controls do not have matching routes.

### Media

Upload MIME/size/Sharp/path controls pass tests. Deleted files remain independently served; local filesystem durability and orphan cleanup are unresolved.

### Placement

Date/device/enabled/archive/delete filtering exists. Current source/tests identify several intentionally unused inventory placements; older seven-unmounted claims are stale.

### Format

Creative format/dimension contracts and bounded slot heights pass tests. Direct fallback-media update validation remains incomplete.

### Carousel

Single/multiple rendering, controls, and reduced motion pass tests.

### Responsive layout

Literal fixed slots prevent natural image dimensions from controlling layout; no stale 200px rule found.

### Tracking

Impressions have limited five-second deduplication; clicks have no server-side rate limiting/deduplication. A media selector test timed out in the current environment.

### Anonymous delivery

Public ad route does not require authentication and applies lifecycle/device filters; live HTTP unavailable.

### Lifecycle

Scheduling/archive/disable/delete filters exist. Restore/move, deleted URL revocation, durable storage, and some update validation remain operational gaps.

## 14. API Authorization Verification

- Admin APIs generally re-resolve current user and require ADMIN.
- Broker/company mutations check current ownership/admin and use allowlists, with `/api/brokers/me` as a drift-prone parallel path.
- Claim mutations use same-origin checks, signed context, rate limits, recipient binding, and completion transactions.
- Subscription checkout/verify/upgrade/cancel/portal are authenticated and Broker-scoped; alternate server actions use local identity checks but not all remote Stripe customer checks.
- Public broker contact and public ads are intentionally anonymous and server-filtered.
- Media upload/admin ad APIs require ADMIN.

## 15. Medium Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
|---|---|---|---|---|---|
| Multiple independent subscriptions per Broker | Present | HIGH | Duplicate paid subscriptions and local/webhook reconciliation failure | A. MUST FIX BEFORE PRODUCTION |
| Stripe customer ID nullable/non-unique | Present | HIGH conditional | Ambiguous webhook ownership if IDs duplicate/misbind | B. SHOULD FIX BEFORE PRODUCTION |
| Direct verification/cancellation entitlement writes | Present | HIGH conditional | Local state can diverge from Stripe authority | B. SHOULD FIX BEFORE PRODUCTION |
| Alternate subscription actions remote customer validation | Missing | MEDIUM | Local ID relationship is trusted without remote comparison | B. SHOULD FIX BEFORE PRODUCTION |
| Upgrade idempotency | Missing | MEDIUM | Retry/proration duplication | B. SHOULD FIX BEFORE PRODUCTION |
| Billing DTO breadth | Present | MEDIUM | Payment identifiers/URLs reach authenticated browser | B. SHOULD FIX BEFORE PRODUCTION |
| Reset completion limiter/password policy | Missing | MEDIUM | Abuse/weak passwords | B. SHOULD FIX BEFORE PRODUCTION |
| Webhook Redis fail-open/equal timestamps | Present | MEDIUM | Concurrent/order edge cases | C/F. ACCEPTABLE RISK / INFRASTRUCTURE GAP |
| Missing media restore/move and invalid fallback updates | Present | MEDIUM/HIGH functional | Admin media workflow and creative integrity fail | B. SHOULD FIX BEFORE PRODUCTION |
| Deleted media/public local storage | Present | MEDIUM | Privacy, storage, deployment availability | B/F. SHOULD FIX BEFORE PRODUCTION / INFRASTRUCTURE |
| Ad click abuse controls | Missing | MEDIUM | Analytics/event-volume poisoning | B. SHOULD FIX BEFORE PRODUCTION |

## 16. Low / Informational Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
|---|---|---|---|---|---|
| Full repository lint debt | Existing | LOW | No direct runtime defect established | F. INFRASTRUCTURE / TESTING GAP | Reduce incrementally |
| Media selector timeout | Reproduced | INFO | Media test coverage cannot complete in this environment | F. INFRASTRUCTURE / TESTING GAP | Isolate/harden test runtime |
| Equal-second Stripe timestamps | Present | LOW | Rare tie ambiguity | C. ACCEPTABLE DOCUMENTED RISK | Add tie-breaker if required |
| Review write path absent | Existing | LOW/MEDIUM | Product copy/FAQ mismatch | C. ACCEPTABLE DOCUMENTED RISK | Product decision |
| Currency/PREMIUM documentation drift | Existing | INFO | Commercial confusion | C. ACCEPTABLE DOCUMENTED RISK | Reconcile docs/config |
| Process-local email idempotency | Existing | LOW/MEDIUM | Restart/multi-instance behavior | C/F | Durable provider idempotency if needed |

## 17. Regression Findings

1. No Phase 1H regression was found in the executed C1-H7/Phase 1A-1H tests.
2. Phase 1H claim limiter coverage is present, but multiple-subscription creation remains a new/current payment-integrity issue not addressed by Phase 1H.
3. Admin broker DTO fix remains present and tested.
4. Advertisement/media unit tests pass; the media selector test timeout is an infrastructure/test-run failure, not a source regression demonstrated here.

## 18. Test Evidence

### passed

- `yarn prisma validate`.
- `npx prisma generate`.
- `npx tsc --noEmit`.
- Combined security/auth/subscription/broker/claim/Phase 1A-1H suite: **113 passed**.
- Advertisement/media suite completed tests: **65 passed**.
- `npx next build`.

### failed

- `yarn lint`: full-tree lint errors/warnings.
- `phase-13.13-media-selector.test.tsx`: timed out after 120 seconds in the normal suite and 240 seconds in isolated retry; 4 preliminary tests passed before timeout in the retry.

### skipped

- Combined application suite: **2 skipped**, environment-gated registration/broker checks; live behavior remains unverified.
- Advertisement suite: **3 skipped**, live public/admin/media checks requiring runtime/base URL.

### unavailable

- Live HTTP.
- Browser automation.
- Stripe payment/webhook E2E.
- Email delivery/interception E2E.
- Redis outage/concurrency E2E.
- Staging/production deployment validation.

## 19. Build / Type / Lint

- `yarn prisma validate`: **PASS**.
- `npx prisma generate`: **PASS**.
- `npx tsc --noEmit`: **PASS**.
- `npx next build`: **PASS**, 93 static pages generated.
- Changed-scope lint: **FAIL** only for existing `actions/subscription.ts` explicit `any` errors and existing auth-config warnings.
- Full `yarn lint`: **FAIL** due existing repository lint debt.

## 20. Infrastructure Limitations

### Application defects

Multiple subscription creation, ambiguous Stripe customer ownership, direct non-webhook state mutation, billing DTO breadth, and media lifecycle/tracking issues are application findings.

### Test infrastructure

There is no package test script. Direct Node/tsx commands were used; environment-gated tests require live fixtures. Media selector test hangs in this environment.

### Browser automation

Unavailable; RSC/browser payloads and responsive behavior were source/unit-tested only.

### Live HTTP

Unavailable; no application/database runtime supplied.

### Stripe E2E

Unavailable; no real Checkout Session/payment/webhook/concurrency test.

### Email

Unavailable; no provider delivery/interception test.

### Redis

Unavailable; no multi-instance lock/rate-limit failure test.

### Staging/production availability

Unavailable; proxy trust, secret management, durable media storage, provider configuration, and deployment topology were not verified.

## 21. Remaining Production Risks

1. A Broker can initiate multiple independent Stripe subscriptions because checkout lacks an existing-active/open-checkout guard.
2. One local BrokerSubscription cannot represent multiple Stripe subscriptions safely, and webhook customer/subscription resolution remains ambiguous.
3. Verification/cancellation can mutate local entitlement outside strict webhook-only authority.
4. Alternate server actions lack complete remote Stripe customer validation.
5. Reset completion abuse controls and webhook concurrency edge cases remain.
6. Advertisement/media lifecycle, deleted-file delivery, storage durability, and click controls remain incomplete.
7. Live external workflow behavior remains unverified.

## 22. Required Before Production

1. Prevent multiple active/pending Stripe subscriptions for one Broker and define safe handling of existing/open checkout state.
2. Ensure Stripe customer/subscription ownership and local Broker association are unambiguous for webhook and alternate mutation paths.
3. Reconcile browser-triggered verification/cancellation with the authoritative subscription lifecycle so local paid state cannot diverge.
4. Resolve media restore/move and invalid fallback creative handling if the media admin workflow is part of launch scope.

## 23. Recommended After Production

1. Add upgrade idempotency, remote Stripe price-property validation, and durable checkout-attempt tracking.
2. Add reset completion throttling/password policy and normalize trial/cancellation semantics.
3. Add click/impression abuse controls, deleted-media revocation, durable storage, and orphan cleanup.
4. Reconcile billing DTOs, review-write scope, product currency/plan terminology, and stale documentation.
5. Establish isolated integration, browser, HTTP, Stripe, email, OAuth, Redis, and deployment tests.

## 24. Final GO/NO-GO Reasoning

The Phase 1H fixes are present and the application regression suite passes 113 tests. C1-C3, H1-H7, Phase 1A-1H, TypeScript, Prisma, and the production build are substantially healthy. The V8 audit nevertheless found a concrete high-impact payment integrity defect: checkout creation does not prevent a Broker with an existing subscription from creating another Stripe subscription. The local model has one BrokerSubscription and rejects a different Stripe subscription ID during synchronization, so duplicate paid operations can leave Stripe and local entitlement state inconsistent.

Customer ownership ambiguity, direct non-webhook state mutations, and media lifecycle defects add residual risk. The decision is **NO-GO** based on the multiple-subscription/payment-integrity issue and related ownership/state risks, not on lint debt, test timeout, or unavailable external infrastructure.

Production files changed: **NO**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **NO**  
Documentation changed: **YES — only `docs/verification/FINAL-PRODUCTION-READINESS-AUDIT-V8.md`**  
Final verdict: **NO-GO**
