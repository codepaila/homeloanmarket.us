# Advertisement Seed Creative Verification

## Dataset

The demo seed uses the existing `SEED_OWNED` marker and reconciles only seed-owned advertisement/media records. Ambiguous or unmarked records are preserved.

- Advertisements: 18
- Populated placements: 13
- Seed media assets: 31
- Seed creative assignments: 35
- Active analytics fixtures: 673 events
- Duplicate advertisements: 0
- Orphaned ad events: 0

## Format Coverage

- `HORIZONTAL`: wide home, broker, footer, and announcement creatives.
- `RECTANGLE`: calculator and blog-inline creatives.
- `VERTICAL`: broker sidebar creatives.
- `SQUARE`: featured homepage creatives.
- `MOBILE`: mobile alternatives for active responsive campaigns.

## Carousel Coverage

- `HOMEPAGE_HERO`: 3 active campaigns.
- `BROKER_LISTING_SIDEBAR`: 2 active campaigns.
- `BLOG_INLINE`: 2 active campaigns.
- `HOMEPAGE_FEATURED`: 2 active campaigns.
- `MOBILE_HEADER_BANNER`: 1 mobile campaign.

## Image Verification

- All seed creative URLs use stable `images.unsplash.com` URLs.
- All 31 unique seed media URLs returned successful HTTP HEAD responses.
- URLs use deterministic `auto=format`, `fit=crop`, quality, width, and height parameters.
- Images are selected from mortgage, residential, home-interior, and financial-consultation subjects.

## Idempotence

The seed was executed twice against an isolated demo database. Both runs converged to the same counts, with zero duplicate advertisements, zero duplicate subscriptions, and zero orphaned ad events.

## Limitations

Browser pixel certification is not available in the repository environment. Data, URL, format, lifecycle, public API, build, and focused rendering checks were performed.
