# PHASE 1L — STRIPE BILLING CONCURRENCY REMEDIATION

Scope: V11 Stripe billing concurrency, webhook durability, cancellation idempotency, ownership, and checkout/upgrade payload integrity only.

## 1. V11 Findings

The confirmed V11 findings addressed were:

1. Fixed non-renewed billing locks could expire during long operations.
2. Fresh `PROCESSING` webhook events could be acknowledged as duplicates after a crash.
3. Cancellation lacked deterministic Stripe idempotency.
4. Alternate cancellation relied on webhook delivery for local reconciliation.
5. Checkout/upgrade and checkout API/action payload/key contracts were not fully separated/consistent.
6. Portal, invoice, and alternate billing ownership checks were inconsistent.

## 2. Root Causes

- Billing locks used fixed leases without renewal and webhook processing had a separate lock implementation.
- A recent PROCESSING ledger record was treated as a duplicate with HTTP success even when the original worker could have crashed.
- Cancellation used provider calls without operation-specific idempotency.
- Alternate cancellation did not immediately reconcile trusted Stripe state.
- Upgrade metadata changed on each retry while its idempotency key remained stable; checkout payloads also differed across paths.
- Several alternate billing operations relied on local IDs without central remote ownership validation.

## 3. Canonical Source of Truth

- Billing lock: `SubscriptionService.withBillingLock` in `lib/subscription.ts`.
- Checkout/upgrade/cancel coordination: Broker-scoped billing lock.
- Customer ownership: `SubscriptionService.assertStripeCustomerOwnership`.
- Plan/price: `validatePlanPrice` in `lib/stripe.ts`.
- Subscription reconciliation: `syncWithStripe` and `updateSubscriptionFromStripe`.
- Webhook event authority: `app/api/stripe/webhook/route.ts` with signature/event ledger.

## 4. Files Changed

- `lib/subscription.ts`
- `app/api/stripe/webhook/route.ts`
- `app/api/subscription/checkout/route.ts`
- `app/api/subscription/upgrade/route.ts`
- `app/api/subscription/portal/route.ts`
- `app/api/subscription/invoices/route.ts`
- `actions/subscription.ts`
- `tests/phase-22-stripe-billing-concurrency.test.ts`
- `tests/phase-22-stripe-final-integrity.test.ts`
- `docs/verification/PHASE-1L-STRIPE-BILLING-CONCURRENCY-REMEDIATION.md`

No Prisma schema, migrations, advertisements, media, claims, or unrelated business-rule files were changed.

## 5. Billing Lock Durability

`withBillingLock` now uses an owner token, a finite lease, periodic owner-checked renewal through Redis scripting, and owner-safe release. Renewal stops in `finally`; cleanup failures do not release another owner’s lock. Renewal failure raises a billing-unavailable error rather than treating the operation as safely serialized.

Checkout, upgrade, cancellation, and webhook subscription scopes use the shared lock mechanism. The lock remains finite and does not become unbounded.

## 6. Webhook PROCESSING Recovery

Fresh PROCESSING events are now retryable rather than acknowledged as duplicates. Stale PROCESSING records continue through the existing reclaim/retry path. PROCESSED remains terminal, FAILED remains retryable, and Stripe event ID remains the idempotency identity.

Webhook processing uses the shared renewing billing lock for subscription scopes. Redis lock failure/contestion remains retryable rather than silently continuing unsafe concurrent processing.

## 7. Cancellation Idempotency

Canonical cancellation now uses a deterministic key derived from customer/subscription identity. The alternate cancellation action also uses an operation-specific deterministic key and remote ownership validation. A provider failure does not write local inactive state.

## 8. Alternate Cancellation Reconciliation

The alternate cancellation action now:

1. authenticates the current user;
2. validates the canonical customer/subscription relationship;
3. acquires the Broker billing lock;
4. retrieves and verifies the remote subscription customer;
5. cancels through Stripe with idempotency;
6. calls `syncWithStripe` after success.

The webhook remains the asynchronous lifecycle authority. If immediate reconciliation fails, the operation does not fabricate local entitlement state.

## 9. Checkout/Upgrade Idempotency Namespaces

Checkout uses a checkout-specific key containing authenticated user/customer/plan/price. Upgrade uses a separate upgrade-specific key containing user/subscription/target price. Upgrade metadata no longer includes a retry-varying timestamp. Checkout API and alternate action include matching subscription metadata and billing-address parameters, avoiding Stripe idempotency-parameter conflicts.

## 10. Stripe Ownership

Portal and invoice routes now call `assertStripeCustomerOwnership`. Alternate `getSubscription`, `cancelSubscription`, `updateSubscription`, and customer-subscription listing paths validate local Broker/customer association and remote Stripe customer identity. Checkout and upgrade retain their ownership checks.

No client-provided customer, subscription, Broker, or user ID is accepted as authoritative.

## 11. Concurrency

The shared lock covers checkout, alternate checkout, upgrade, cancellation, and webhook subscription processing. Its critical sections include relevant conflict/ownership reads and provider/local mutation sequences. Owner tokens prevent an expired/replaced lock from being released by the old operation.

Real multi-instance Redis behavior, network timeouts, long-running Stripe calls, and DB persistence failures were unavailable for execution.

## 12. Regression Tests

Added `tests/phase-22-stripe-billing-concurrency.test.ts` with **10 passing tests** covering:

- owner token, lease renewal, and cleanup;
- Redis acquisition failure;
- fresh and stale PROCESSING behavior;
- cancellation idempotency and alternate reconciliation;
- stable upgrade/checkout namespaces;
- shared locks and H5/H6 preservation.

Existing Phase 1J Phase 22 tests and final-integrity tests were retained and updated only where the shared webhook lock implementation changed their source assertion. Combined Phase 1A-1J security/subscription tests pass **118/118**, with 2 environment-gated skips. Phase 1L-focused tests pass **45/45**.

## 13. Validation

| Check | Result |
| ----- | ------ |
| `yarn prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS |
| Phase 1L focused tests | PASS — 45 passed, 0 failed, 0 skipped |
| Combined security/subscription regression tests | PASS — 118 passed, 0 failed, 2 skipped |
| Advertisement/media tests | 65 passed, 3 skipped; media selector timeout separately observed |
| Changed-scope ESLint | FAIL — existing `no-explicit-any` errors in billing actions/routes |
| Full `yarn lint` | FAIL — existing repository lint debt |
| `npx next build` | PASS — 93 static pages generated |

## 14. Limitations

- Live Stripe E2E unavailable.
- Live Redis lock renewal/failure/multi-instance E2E unavailable.
- Live HTTP/database integration unavailable.
- Browser automation unavailable.
- Email provider E2E unavailable.
- Network timeout/DB failure after Stripe success was not simulated against production infrastructure.
- Media selector test timeout remains unrelated to this phase.

## 15. Regression Audit

| Area | Result | Evidence |
| ---- | ------ | -------- |
| C1-C3 | INTACT | Combined security/DTO tests pass. |
| H1-H7 | INTACT | Combined H1-H7 tests pass. |
| Phase 1A-1H | INTACT | Existing phase regression tests pass. |
| Phase 1I | INTACT/expanded | Phase 1I and Phase 1L billing tests pass. |
| H5 entitlement | INTACT | H5 tests and Phase 1L H5 assertion pass. |
| H6 ordering | INTACT/expanded | Existing webhook tests and PROCESSING/lock tests pass. |
| Advertisements/media | INTACT | No ad/media files changed; normal suite passes except timeout. |

## 16. Final Status

Phase 1L targeted fixes are implemented and source/regression verified. Live Stripe/Redis concurrency and provider-failure certification remain unavailable, so this phase does not claim production readiness.

Production files changed: **YES**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **YES**  
Documentation changed: **YES — only this Phase 1L report**

Final recommendation: **READY FOR NEXT INDEPENDENT PRODUCTION AUDIT V12**
