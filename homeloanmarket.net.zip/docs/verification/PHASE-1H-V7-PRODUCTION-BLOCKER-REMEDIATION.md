# PHASE 1H — V7 PRODUCTION BLOCKER REMEDIATION

Scope: five V7 findings only: claim login rate limiting, Stripe customer authorization/association/race, alternate checkout idempotency, and admin broker DTO boundary.

## 1. Findings

1. Claim pages directly called `signIn('credentials')` outside the canonical rate-limited login action.
2. The alternate `createStripeCustomer` action did not persist new customer IDs or prevent duplicate creation.
3. Primary checkout customer creation could race when concurrent requests observed no stored customer.
4. Alternate checkout idempotency was time-bucketed and not stable for the same logical intent.
5. Admin broker detail passed a broad Broker/subscription object to a Client Component.

## 2. Root Causes

### Claim login

Rate limiting existed in `LoginWithCredential`, but direct Auth.js credential calls in claim pages bypassed that action. Auth.js `authorize` had no shared limiter.

### Stripe customer association/race

Customer creation checked local state and then called Stripe without a shared idempotency key. The alternate server action returned the new customer without persisting its ID. The primary route independently used the same check/create pattern.

### Alternate checkout

The alternate server action used a timestamp bucket in its key. The primary route also used a time bucket, allowing the same logical request to receive a different key after the bucket changed.

### Admin DTO

The admin page queried full relations and passed the Prisma Broker object directly to `AdminBrokerActions`, even though that component required only profile fields and claim invitations.

## 3. Canonical Sources of Truth

- Credential authentication: Auth.js Credentials `authorize` in `lib/auth.config.ts`, with `brokerLoginRateLimit` as the shared server boundary; `LoginWithCredential` remains the form action boundary.
- Stripe customer association: authenticated current user plus `BrokerSubscription.stripeCustomerId`.
- Checkout plan/price: `lib/stripe.ts` and `validatePlanPrice`.
- Subscription lifecycle: `SubscriptionService`, signed webhook processing, and Stripe event idempotency.
- Admin broker UI contract: `AdminBrokerActions` prop shape in `app/admin/brokers/[id]/AdminBrokerActions.tsx`.

## 4. Exact Remediation

### 4.1 Claim login rate limiting

Added server-derived IP rate limiting to the shared Auth.js Credentials `authorize` callback in `lib/auth.config.ts`. This covers direct `signIn('credentials')` calls from both claim pages while preserving the existing limiter on `LoginWithCredential`. The limiter fails open consistently with the existing Phase 1B policy, and Auth.js continues returning generic credential failures.

### 4.2 Alternate Stripe customer creation

`actions/subscription.ts:createStripeCustomer` now:

- requires `getCurrentUser()` and a broker profile;
- ignores client identity arguments by removing them from the function signature;
- reuses the stored customer when present;
- creates with metadata derived from the authenticated user/broker;
- uses `stripe_customer_${user.id}` as Stripe idempotency key;
- persists the new customer ID through `BrokerSubscription.upsert`.

### 4.3 Primary Stripe customer race

`app/api/subscription/checkout/route.ts` now uses the same deterministic `stripe_customer_${user.id}` Stripe idempotency key for customer creation. Concurrent primary/alternate customer creation requests therefore share Stripe’s idempotency scope and both persist the same returned customer ID through the existing subscription upsert. No schema or distributed lock was introduced.

### 4.4 Alternate checkout idempotency

`actions/subscription.ts:createCheckoutSession` now uses the deterministic server-derived key:

```text
checkout_action_${user.id}_${customerId}_${plan}_${priceId}
```

The primary API route similarly uses:

```text
checkout_${user.id}_${user.brokerProfile.id}_${plan}_${priceId}
```

Both retain authentication/customer ownership and server plan/price validation. No client idempotency key is accepted. Stripe webhook authority is unchanged.

### 4.5 Admin broker DTO boundary

`app/admin/brokers/[id]/page.tsx` now uses an explicit Prisma `select` and constructs a `brokerDto` containing only fields consumed by `AdminBrokerActions`: profile display/contact/address fields, visibility, and claim invitation data. Subscription identifiers, full subscription relation, claim events, unrelated ownership/internal fields, and other Broker relations no longer cross the Client Component boundary.

## 5. Security Preservation

- Direct claim credential authentication remains server-verified and now passes through the shared rate-limit boundary.
- Existing C1 session identity protection and generic Auth.js credential failures remain unchanged.
- Stripe customer/session identity remains server-derived and authenticated.
- Plan and price remain validated through the authoritative catalog.
- Stripe webhook signature, event ordering, event status, and event-ID idempotency were not changed.
- Customer and checkout idempotency do not bypass authentication or subscription ownership.
- Admin role authorization remains server-side; only the client payload was narrowed.
- C2, H1-H7, Phase 1A-1G behavior and advertisements/media code were not changed.

## 6. Regression Tests

Added `tests/phase-1h-v7-production-blocker-remediation.test.ts` with **4 passing tests** covering:

1. Claim credential pages are covered by the shared Auth.js credential limiter.
2. Stripe customer creation is authenticated, persisted, and idempotent.
3. Primary and alternate checkout intents use deterministic server-derived keys.
4. Admin broker page passes an explicit action DTO without full subscription relation.

The existing Phase 1F idempotency assertion was updated to reflect the intentional deterministic-key change rather than the removed time bucket.

Final combined regression run: **113 passed, 0 failed, 2 skipped**.  
Advertisement/media suite: **65 passed, 0 failed, 3 skipped in the normal run**; a separate retry of `phase-13.13-media-selector.test.tsx` exceeded the 240-second timeout and is recorded as an infrastructure/test-run failure.

## 7. Validation

| Check | Result |
| ----- | ------ |
| `yarn prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS |
| Phase 1H focused tests | PASS — 4 passed, 0 failed, 0 skipped |
| Combined security/auth/subscription/claim/broker regression tests | PASS — 113 passed, 0 failed, 2 skipped |
| Advertisement/media normal suite | PASS — 65 passed, 0 failed, 3 skipped |
| `phase-13.13-media-selector.test.tsx` retry | FAIL/TIMEOUT — pending promise after 240 seconds |
| Changed-file ESLint | FAIL — 3 pre-existing `no-explicit-any` errors in `actions/subscription.ts` and existing auth-config warnings |
| Full `yarn lint` | FAIL — existing repository lint errors/warnings |
| `npx next build` | PASS — 93 static pages generated |
| Live HTTP | UNAVAILABLE |
| Browser automation | UNAVAILABLE |
| Stripe E2E | UNAVAILABLE |

## 8. Limitations

- Live Stripe customer/session concurrency was not executable; Stripe idempotency was verified by source/tests only.
- Browser automation and RSC payload inspection were unavailable.
- Live HTTP/database integration was unavailable.
- Redis failure and multi-instance rate-limit/lock behavior were unavailable.
- Email provider and claim login E2E were unavailable.
- The media selector timeout is an existing test/runtime infrastructure issue; no media code was changed.
- Full lint remains blocked by existing repository debt.

## 9. Regression Audit

| Area | Result | Evidence |
| ---- | ------ | -------- |
| C1-C3 | INTACT | Combined tests pass; User/profile/admin DTO checks pass. |
| H1-H7 | INTACT | Combined tests pass. |
| Phase 1A | INTACT | H5 creation tests pass. |
| Phase 1B | INTACT | Login/forgot/resend and email-change tests pass. |
| Phase 1C | INTACT | Signup and email-change verification tests pass. |
| Phase 1D | INTACT | C3/profile and checkout contract tests pass. |
| Phase 1E | INTACT | Verification/owner DTO tests pass. |
| Phase 1F | INTACT | Company DTO, Stripe upgrade, checkout idempotency, and email-binding tests pass. |
| Phase 1G | INTACT | Customer auth, alternate login, currentUser, reset expiry, and alternate checkout tests pass. |
| Webhook | INTACT | Webhook source unchanged; ordering/idempotency tests pass. |
| Claims | INTACT | Claim policy/recipient tests pass; direct credential calls now share Auth.js limiter. |
| Advertisements/media | INTACT | Normal advertisement suite passes; no ad/media code changed. |

## 10. Final Status

| V7 Finding | Status |
| ---------- | ------ |
| Claim login rate-limit bypass | **FIXED** |
| Alternate Stripe customer creation | **FIXED** for authentication, persistence, and Stripe idempotency |
| Primary Stripe customer race | **FIXED** at Stripe idempotency/application association level; live concurrency unavailable |
| Alternate checkout idempotency | **FIXED** with deterministic server-derived key |
| Admin broker DTO boundary | **FIXED** |

Production files changed: **YES**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **YES**  
Documentation changed: **YES — only this Phase 1H report**

Changed files:

- `lib/auth.config.ts`
- `actions/subscription.ts`
- `app/api/subscription/checkout/route.ts`
- `app/admin/brokers/[id]/page.tsx`
- `tests/phase-1g-v6-blocker-remediation.test.ts`
- `tests/phase-1f-final-remediation.test.ts`
- `tests/phase-1h-v7-production-blocker-remediation.test.ts`
- `docs/verification/PHASE-1H-V7-PRODUCTION-BLOCKER-REMEDIATION.md`

No advertisements/media files, Prisma schema, migrations, or unrelated business rules were changed.

Final recommendation:

**READY FOR NEXT INDEPENDENT PRODUCTION AUDIT**

This remediation does not claim production readiness. The next step is `FINAL-PRODUCTION-READINESS-AUDIT-V8`.
