# Seed Data Remediation

## Canonical Command

`yarn seed` is the only seed command. It executes `prisma/seed/index.ts`, reads `process.env.DATABASE_URL`, validates the MongoDB protocol, and writes to that exact Prisma datasource. The package entrypoint loads optional `.env` and `.env.local` files without replacing shell or deployment-injected variables.

The same command works for `mongodb://` local connections and `mongodb+srv://` Atlas connections. The seed does not inspect, rewrite, or append to the connection string. It prints only the protocol, hostname, and database path as a safe target identity; credentials, query parameters, and the full connection string are never printed.

## Dataset

- One configured admin user, five deterministic broker users, and ten deterministic buyer users.
- Six broker profiles with valid user relations, deterministic profile slugs, companies represented by the schema's `companyName`, service cities, specialties, profile metadata, and local subscription state.
- One completed claim attached to an owned broker and one active invited claim for an unowned `ADMIN_CREATED` broker.
- Seed-owned media folders and remote Unsplash metadata using the existing `MediaAsset` model.
- Validated advertisement creatives across the existing placement and format rules, with deterministic slugs, admin ownership, and media relations.
- Mortgage blog posts, FAQs, and required bootstrap settings.
- Reviews and contact messages reconciled by deterministic broker/user/content keys.

No Company model exists in the schema, so no fabricated company records are created. No OAuth accounts, access tokens, verification secrets, analytics events, or live financial objects are seeded. Claim invitations store only deterministic hashes, as required by the actual claim schema; no raw invitation token is printed or persisted.

## Idempotency And Safety

This testing seed intentionally clears all 27 Prisma model collections in dependency-safe order with model-level `deleteMany()` calls, then recreates the fixture. It never drops another database, runs MongoDB shell commands, rewrites `DATABASE_URL`, or runs migrations. Repeated runs therefore produce the same clean fixture and cannot retain stale unique records.

Broker subscriptions use the existing local `BrokerSubscription` model and preserve any existing Stripe identifiers. The seed never imports or calls Stripe and never creates Stripe customers, subscriptions, or payment records. Advertisements and media are created/updated with the configured admin's user ID because the admin API requires `role === ADMIN`.

When `NODE_ENV=production`, destructive execution additionally requires `SEED_ALLOW_DESTRUCTIVE=true`. This is a confirmation guard only; it does not select or rewrite a database.

Seed passwords use the existing `hashPassword` implementation and are never logged. The configured admin is required for the admin-owned fixture resources. Output contains counts and status only; it never prints connection strings, credentials, password hashes, tokens, or API keys.

## Validation

- `npx prisma validate`: passed.
- `npx tsc --noEmit`: passed.
- Focused canonical seed tests: passed, 13/13 with the disposable database relationship test enabled.
- Changed-file ESLint: passed.
- Live seed validation database: disposable local MongoDB at a safe validation target; first and second executions completed successfully.
- Production database modified: NO.

## Files Changed

- `package.json`
- `prisma/seed/index.ts`
- removed `prisma/seed/seed-demo.ts`, `prisma/seed/demo-index.ts`, and `prisma/seed/production.ts` entrypoints
- `tests/production-seed.test.ts`
- `tests/phase-2-seed-policy.test.ts`
- `tests/phase-13.8-clean-seed.test.ts`
- `docs/verification/SEED-DATA-REMEDIATION.md`

Supporting image/helper modules remain available to the canonical seed; no alternate seed entrypoint or package command remains.
