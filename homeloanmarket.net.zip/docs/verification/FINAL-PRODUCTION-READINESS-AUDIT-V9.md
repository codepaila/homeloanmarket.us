# FINAL PRODUCTION READINESS AUDIT V9

Audit date: 2026-08-10  
Repository: HomeLoanMarket US  
Mode: READ-ONLY / AUDIT-ONLY

## 1. Executive Verdict

**NO-GO**

The Phase 1I checkout lock, existing-subscription guard, customer ownership helper, deterministic customer idempotency, and cancellation failure handling are present. The focused tests pass.

The independent V9 audit found that Phase 1I does not fully enforce the one-subscription/one-checkout invariant:

- The primary API and alternate server-action checkout use different idempotency key namespaces, so the same logical purchase through different entry points can create distinct Stripe sessions.
- `findCheckoutConflict()` blocks on any local `stripeSubId`, including a canceled subscription, so a broker can become permanently unable to re-subscribe.
- Webhook reconciliation rejects a new Stripe subscription whenever an old local `stripeSubId` exists, including after cancellation.
- Checkout, upgrade, and cancellation are not mutually serialized, and Redis failure causes checkout failure without a durable fallback.

These are concrete payment/subscription integrity and availability findings. The decision is **NO-GO** based on the duplicate/re-subscription and reconciliation risks, not on lint debt or unavailable external infrastructure.

## 2. Validation Summary

| Check | Result | Evidence |
| ----- | ------ | -------- |
| Documentation inventory | PASS with contradictions | V1-V8 and Phase 1A-1I reports exist; current claim contract is `docs/business/33-CLAIM-CONTRACT.md`; requested `docs/CLAIM-CONTRACT.md` is absent. |
| Combined security/subscription regression suite | PASS with skips | 118 passed, 0 failed, 2 skipped. |
| Advertisement/media suite | PASS with timeout | 65 passed, 3 skipped; `phase-13.13-media-selector.test.tsx` timed out after 120 seconds. |
| Prisma validate | PASS | `yarn prisma validate`. |
| Prisma generate | PASS | `npx prisma generate`. |
| TypeScript | PASS | `npx tsc --noEmit`. |
| Production build | PASS | `npx next build`; 93 static pages generated. |
| Changed-scope ESLint | FAIL | Existing `no-explicit-any` errors in `actions/subscription.ts`. |
| Full lint | FAIL | Existing repository-wide lint errors/warnings. |
| Live HTTP | UNAVAILABLE | No running application/database fixture. |
| Browser automation | UNAVAILABLE | No browser runtime. |
| Stripe E2E | UNAVAILABLE | No real Stripe payment/webhook/concurrency fixture. |
| Redis/email E2E | UNAVAILABLE | No provider failure/concurrency fixture. |

## 3. C1–C3 Status

### C1

**Status:** VERIFIED/FIXED.

**Evidence:** Auth.js JWT refresh never merges client `session.user`; claims refresh from trusted database state. Auth.js `authorize` now applies the broker login limiter, covering direct claim-page credential calls.

**Affected workflow:** Authentication/session/claims.

**Regression test:** C1 tests and Phase 1H claim-limiter tests pass.

### C2

**Status:** VERIFIED/FIXED.

**Evidence:** Public contact resolves by canonical slug, rejects missing identifiers, checks public eligibility, and stores against resolved Broker. Anonymous submission remains intentional.

**Affected workflow:** Public broker leads.

**Regression test:** Phase 16 C2 tests pass; live HTTP unavailable.

### C3

**Status:** VERIFIED on audited client boundaries with residual server-loader caution.

**Evidence:** Personal/company/dashboard/company-edit/admin broker pages use explicit or selected DTOs. Generic `getCurrentUser` excludes User credential/token/accounts/contact-message fields. Broker/subscription relations remain available to server consumers and must not be treated as client DTOs.

**Affected workflow:** Authenticated profile/dashboard/admin data.

**Regression test:** C3, Phase 1G, and Phase 1H DTO tests pass. Browser/RSC runtime unavailable.

## 4. H1–H7 Status

| Finding | Status | Evidence | Affected workflow | Regression test |
| ------- | ------ | -------- | ---------------- | --------------- |
| H1 contact paywall | VERIFIED/FIXED | Public DTO and route entitlement/owner/admin gates. | Public broker data | Phase 17, pass |
| H2 mass assignment | VERIFIED on canonical paths | Ownership checks and allowlists; `/api/brokers/me` remains a parallel manual path. | Broker/company mutation | Phase 17/18, pass |
| H3 password reset | VERIFIED with residual controls | Hash, mandatory future expiry, bcrypt, single-use clearing. Completion throttling/password policy absent. | Recovery | H3 tests, pass |
| H4 verification enum | VERIFIED/FIXED | No invalid enum/field writes. | Verification | Phase 18, pass |
| H5 service cities | VERIFIED/FIXED | Creation/update FREE and FEATURED limits. | Broker service areas | Phase 18/19, pass |
| H6 webhook ordering | VERIFIED with residual race risk | Signature, event ID, event statuses, stale check, Redis lock/fallback. | Stripe lifecycle | H6/webhook tests, pass |
| H7 claim binding | VERIFIED/FIXED | Recipient, expiry, revocation, used state, reauth, transactional ownership. | Claims | H7 tests, pass |

## 5. Phase 1A–1I Status

| Phase | Status | Evidence | Regression |
| ----- | ------ | -------- | ---------- |
| 1A H5 creation path | VERIFIED/FIXED | `assertServiceCityLimit` before creation. | Phase 19 pass |
| 1B auth hardening | PARTIAL | Primary/claim login and forgot/resend limiters; fail-open Redis and reset controls remain. | Phase 20 pass |
| 1C email change | VERIFIED/FIXED | Target-bound digest, collision/expiry/single use. | Phase 20 pass |
| 1D C3/checkout | VERIFIED/FIXED | Personal DTO and pricing request contract. | Phase 1D pass |
| 1E verification/owner DTO | VERIFIED on known paths | Verification route and owner DTOs exist. | Phase 1E pass |
| 1F checkout/email/company | PARTIAL | Targeted changes pass; cross-path checkout conflicts remain. | Phase 1F pass |
| 1G V6 blockers | VERIFIED on changed paths | Auth customer, safe scalar loader, reset expiry, alternate key. | Phase 1G pass |
| 1H V7 blockers | PARTIAL | Customer auth/lock/admin DTO pass; key namespace and cancellation/re-subscription issues remain. | Phase 1H pass |
| 1I Stripe integrity | PARTIAL / BLOCKED | Shared lock/conflict helper exists, but stale `stripeSubId`, cross-path key mismatch, and webhook replacement failure remain. | Phase 1I pass |

## 6. Equivalent / Variant Findings

| Finding | File/Path | Severity | Impact | Classification |
| ------- | --------- | -------- | ------ | -------------- |
| API/action idempotency namespaces differ | `app/api/subscription/checkout/route.ts:77`, `actions/subscription.ts:95` | HIGH | Same logical purchase through alternate paths can create distinct Stripe sessions/subscriptions | A. MUST FIX BEFORE PRODUCTION |
| Canceled local `stripeSubId` permanently blocks new checkout | `lib/subscription.ts:65-66`, webhook cancellation retains ID | HIGH | Broker cannot re-subscribe after cancellation | A. MUST FIX BEFORE PRODUCTION |
| New subscription webhook rejected when old local `stripeSubId` exists | `lib/subscription.ts:274-276` | HIGH | Stripe paid state may fail reconciliation after replacement subscription | A. MUST FIX BEFORE PRODUCTION |
| Checkout lock expires after 60 seconds | `lib/subscription.ts:19-38` | HIGH conditional | Long Stripe operation can overlap a second checkout after lock expiry | B. SHOULD FIX BEFORE PRODUCTION |
| Redis failure disables checkout; webhook fallback remains concurrent | `lib/subscription.ts:19-38`, `app/api/stripe/webhook/route.ts:34-55` | HIGH availability / MEDIUM integrity | Checkout outage or webhook race during Redis failure | B. SHOULD FIX BEFORE PRODUCTION |
| Upgrade/cancel not mutually serialized with checkout | `app/api/subscription/upgrade/route.ts`, `lib/subscription.ts:303-338` | MEDIUM/HIGH | Concurrent lifecycle operations can produce stale decisions | B. SHOULD FIX BEFORE PRODUCTION |
| Portal/invoice/alternate billing paths lack central remote customer verification | `app/api/subscription/portal/route.ts`, `app/api/subscription/invoices/route.ts`, `actions/subscription.ts` | MEDIUM | Stale/misbound local customer IDs are trusted | B. SHOULD FIX BEFORE PRODUCTION |
| Browser verification directly mutates subscription state | `app/api/subscription/verify/route.ts:48-58` | MEDIUM | Second entitlement mutation authority can race webhook | B. SHOULD FIX BEFORE PRODUCTION |
| Media restore/move routes missing | `hooks/useAdminAds.ts`, `app/api/admin/media` | MEDIUM/HIGH functional | Admin media recovery/move returns 404 | B. SHOULD FIX BEFORE PRODUCTION |

## 7. Medium Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Stripe customer ID nullable/non-unique | Present | HIGH conditional | Ambiguous webhook customer ownership if duplication/corruption occurs | B | Enforce unique/consistent association through safe migration or operational invariant |
| Subscription price properties not verified against Stripe | Application ID comparison only | MEDIUM | Misconfigured inactive/wrong-currency price can be accepted | B | Validate remote price/product/currency in controlled configuration flow |
| Cancellation UI disconnected from cancel API | Present | MEDIUM | Visible billing cancel control may not execute cancellation | B | Reconcile UI/API contract |
| Trial status semantics inconsistent | Present | MEDIUM | UI/service entitlement state can disagree for trialing subscriptions | B | Normalize status policy |
| Reset completion limiter/password policy | Missing | MEDIUM | Weak password/resource abuse risk | B | Add endpoint controls |
| Broker `/me` duplicate validation path | Present | MEDIUM | Data/allowlist drift | C | Consolidate later |
| Public ad tracking abuse | Missing | MEDIUM | Analytics/storage volume poisoning | B | Add server-side controls |
| Media deletion/storage/move lifecycle | Present | MEDIUM | Deleted public files, orphan growth, failed admin operations | B/F | Add lifecycle and durable storage policy |

## 8. Low / Informational Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Full repository lint debt | Existing | LOW | No direct runtime defect established | F. INFRASTRUCTURE / TESTING GAP | Reduce incrementally |
| Media selector timeout | Reproduced | INFO | One UI test cannot complete in this environment | F. INFRASTRUCTURE / TESTING GAP | Isolate test runtime |
| Equal-second Stripe timestamps | Present | LOW | Rare ordering ambiguity | C. ACCEPTABLE DOCUMENTED RISK | Add tie-breaker if needed |
| Process-local email idempotency | Present | LOW/MEDIUM | Restart/multi-instance behavior | C/F | Durable provider idempotency if needed |
| Review write path absent | Present | LOW/MEDIUM | FAQ/product mismatch | C. ACCEPTABLE DOCUMENTED RISK | Product decision |
| Currency/PREMIUM/documentation drift | Present | INFO | Commercial/operational confusion | C. ACCEPTABLE DOCUMENTED RISK | Reconcile docs/config |

## 9. Regression Findings

1. Phase 1I introduced a checkout lock/conflict guard but its implementation does not fully preserve re-subscription: any existing local `stripeSubId` blocks checkout, including canceled subscriptions.
2. Phase 1I’s report overstates cross-path idempotency: API and action keys differ by Broker ID versus customer ID and do not share an exact namespace.
3. Phase 1I does not serialize upgrade/cancellation with checkout.
4. No regression was found in C1-C3, H1-H7, Phase 1A-1H focused tests.
5. Advertisement/media tests pass except the recurring media selector timeout; no ad/media remediation regression was introduced.

## 10. Security Boundary Verification

### Authentication

Auth.js credential authorize and LoginWithCredential rate-limit; claim pages are covered. Redis failure behavior is fail-open for authentication and fail-closed for checkout lock.

### Authorization

Admin/broker handlers generally enforce roles/ownership. Billing alternate routes require current user but do not all perform central remote Stripe customer verification.

### Ownership

Broker ownership and claim attachment are guarded. Stripe customer/subscription ownership is source-checked in checkout/upgrade/verify but inconsistent in portal/invoices/actions, and webhook uses `findFirst` on nullable customer ID.

### Sessions

C1 identity refresh is trusted and no client session merge exists. Deleted-user/stale-JWT behavior remains a test gap.

### PII

Known profile/admin DTOs are explicit; billing DTOs still contain broad Stripe-derived payment metadata. Public broker DTOs strip private contact/ownership fields.

### Tokens

Reset/verification/claim token hashing, expiry, and clearing are present. Reset completion lacks dedicated throttling/password policy.

### Claims

Recipient binding, invitation status/expiry, reauth, generic errors, origin, and transactional ownership attach are present.

### Payments

Primary checkout is authenticated/validated/locked but allows re-subscription state bugs and cross-path key mismatch. Verification/cancellation remain secondary local state writers.

### Subscriptions

FEATURED/paid and FREE calculations are centralized, but one-Broker subscription integrity is not complete after cancellation/replacement.

### Admin

Admin routes enforce role; admin broker page uses explicit DTO. Media restore/move operations are incomplete.

## 11. Business Workflow Verification

### Broker signup

`/api/auth/register/broker` and `/api/brokers` create FREE broker/user state transactionally. Tests pass; live activation unavailable.

### Broker profile

Personal/company/admin edit DTOs are explicit. Mutation ownership/allowlist tests pass.

### Contact / lead generation

Public broker form resolves slug, validates public state, writes ContactMessage, increments leads, and sends notifications. Live HTTP unavailable.

### Subscription checkout

Public/broker pricing uses validated plan/price; checkout lock checks existing Stripe/local state and open sessions. Cross-path keys differ, and canceled local IDs can block new purchases.

### Stripe customer creation

Primary and alternate paths authenticate, use stable customer idempotency, and persist IDs. Stripe/DB failure and multi-instance concurrency are not live-tested; local customer IDs are not unique in schema.

### Subscription upgrade

API validates ownership, updates Stripe, and syncs from Stripe. No shared checkout lock/idempotency protects upgrade concurrency.

### Subscription cancellation

Stripe cancellation is attempted; local state is not changed on provider failure after Phase 1I. Webhook/concurrent cancellation lifecycle is not live-tested.

### Stripe webhook

Signature, event ID, PROCESSING/PROCESSED/FAILED, stale checks and lock/fallback exist. Equal timestamps and Redis failure races remain.

### Claim

Invitation -> recipient session -> credential/Google -> reauth -> completion is source-verified. Live email/browser/Redis unavailable.

### Advertisement

Admin/public CRUD, lifecycle, rendering, and bounded slots are tested. Tracking/media operational findings remain.

### Admin advertisement management

Admin checks and CRUD routes exist; media restore/move routes absent.

### Media

Upload/picker/Sharp/path controls pass; deleted-file delivery, storage durability, and move/restore remain.

### Reviews

Published reads exist; public write route absent.

### Password recovery

Hash/expiry/single-use/bcrypt flow passes; reset completion controls remain.

### Email verification

Signup and target-bound email-change verification pass focused tests; live delivery unavailable.

## 12. Advertisement Verification

- **Admin CRUD:** Role-protected create/update/archive/delete/enable/schedule paths exist.
- **Authorization:** Admin media/ad APIs require ADMIN; public delivery/tracking are intentionally anonymous.
- **Media picker/upload:** MIME/size/Sharp/SVG/AVIF/path controls pass tests.
- **Placement:** Date/device/status filters and intentional unused placements are present; duplicate mount tests pass.
- **Format:** Creative format/dimension contracts pass; direct fallback update validation remains incomplete.
- **Carousel:** Multiple-ad carousel and reduced motion tests pass.
- **Responsive layout:** Fixed literal heights and no natural overflow pass tests; no stale 200px rule found.
- **Tracking:** Impression deduplication is limited; click lacks distributed rate controls.
- **Anonymous delivery:** Public API serves eligible anonymous ads; live HTTP unavailable.
- **Lifecycle:** Schedule/archive/delete filters exist; media restore/move/deleted-file cleanup remain gaps.

## 13. Media Verification

- **Ownership/authorization:** Admin-only mutations are enforced.
- **Validation:** MIME/content/size validation and Sharp rasterization pass tests; metadata/pagination validation gaps remain.
- **Processing:** UUID WebP output and DB-failure cleanup exist.
- **Delivery:** Runtime upload delivery has traversal protection but does not revoke deleted files independently of disk state.
- **Deletion:** Soft/hard DB deletion does not remove all physical files or revoke existing URLs.
- **Fallback:** Invalid fallback media can be attached through update paths.
- **Orphans:** Hard-delete/orphan cleanup is incomplete; local filesystem durability is deployment-dependent.
- **Missing routes:** Media restore/move hooks call absent API routes; valid move validation also uses wrong ID.
- **Failure behavior:** Some bulk media actions do not await failures; media selector test times out in this environment.

## 14. Test Evidence

### passed

- `yarn prisma validate`.
- `npx prisma generate`.
- `npx tsc --noEmit`.
- Combined security/auth/subscription/broker/claim/Phase 1A-1I suite: **118 passed**.
- Advertisement/media completed tests: **65 passed**.
- `npx next build`.

### failed

- `yarn lint`: existing full-tree lint errors/warnings.
- `tests/phase-13.13-media-selector.test.tsx`: timed out after 120 seconds with pending promise.

### skipped

- Combined application suite: **2 skipped**, environment-gated registration/broker checks; impact is unavailable live route validation.
- Advertisement suite: **3 skipped**, live public/admin/media checks requiring runtime/base URL; impact is unavailable live delivery validation.

### unavailable

- Live HTTP.
- Browser automation.
- Stripe E2E.
- Redis E2E.
- Email E2E.
- Staging/production deployment validation.

## 15. Build / Type / Lint

- `yarn prisma validate`: **PASS**.
- `npx prisma generate`: **PASS**.
- `npx tsc --noEmit`: **PASS**.
- `npx next build`: **PASS**, 93 static pages generated.
- Changed-scope lint: **FAIL**, existing `no-explicit-any` errors in `actions/subscription.ts`.
- Full `yarn lint`: **FAIL**, existing repository lint debt.

## 16. Infrastructure Limitations

### Application defects

Multiple/replacement subscription integrity, cross-path checkout idempotency, stale subscription blocking, webhook replacement behavior, alternate billing ownership checks, and media lifecycle issues are application findings.

### Test infrastructure

No package test script exists; direct tsx test commands were used. Environment-gated tests require live fixtures. Media selector hangs under the supplied runtime.

### Browser automation

Unavailable; RSC/browser boundaries and responsive behavior were source/unit-tested only.

### Live HTTP

Unavailable; no app/database environment supplied.

### Stripe E2E

Unavailable; no real Checkout Session, cancellation, replacement subscription, or webhook concurrency test.

### Redis E2E

Unavailable; no lock expiry/failure/multi-instance test.

### Email E2E

Unavailable; no delivery/interception test.

### Staging/production availability

Unavailable; proxy trust, secret management, durable media storage, provider configuration, and deployment topology were not verified.

## 17. Remaining Production Risks

1. Cross-path checkout idempotency keys are not identical, permitting duplicate logical sessions.
2. Canceled subscriptions retain local `stripeSubId`, permanently blocking new checkout in `findCheckoutConflict`.
3. New subscription webhooks are rejected when an old local `stripeSubId` remains.
4. Checkout/upgrade/cancellation are not mutually serialized; Redis failure has unsafe/availability edge behavior.
5. Stripe customer/subscription IDs are nullable/non-unique and webhook ownership uses `findFirst`.
6. Billing alternate routes do not all verify remote customer ownership.
7. Media restore/move, deleted-file revocation, storage durability, and tracking controls remain incomplete.

## 18. Required Before Production

1. Unify checkout idempotency and correctly handle canceled/replaced subscriptions so one Broker cannot create conflicting subscriptions and can safely re-subscribe.
2. Make webhook reconciliation accept a valid replacement subscription without ambiguous local ownership and define one canonical subscription state transition.
3. Serialize or otherwise coordinate checkout, upgrade, and cancellation operations and define safe Redis failure behavior.
4. Complete remote Stripe customer ownership validation across portal/invoice/alternate subscription actions.

## 19. Recommended After Production

1. Normalize Stripe price properties/status/trial/cancellation semantics and add durable checkout-attempt tracking.
2. Add reset completion throttling/password policy and stale-JWT/deleted-user tests.
3. Add ad click controls, media recovery/deletion/storage cleanup, and metadata validation.
4. Reconcile billing DTO breadth, review-write scope, currency/PREMIUM terminology, and stale docs.
5. Establish live HTTP/browser/Stripe/email/Redis integration and isolate the media selector test timeout.

## 20. Final GO/NO-GO Reasoning

The repository passes Prisma, TypeScript, production build, and 118 application/security regression tests. C1-C3, H1-H7, Phase 1A-1H, and much of Phase 1I are implemented and source-verified.

The current Phase 1I checkout guard does not fully satisfy the one-canonical-subscription invariant. The API and alternate action use different idempotency key inputs, canceled local subscriptions remain blocking solely because `stripeSubId` exists, and webhook reconciliation rejects a new subscription ID when the old one remains. This creates a concrete path to duplicate paid Stripe operations and inconsistent local entitlement state. The checkout, upgrade, and cancellation paths are also not mutually serialized.

The final decision is **NO-GO**. This decision is based on subscription/payment integrity and reconciliation findings, not ordinary lint debt, media cosmetics, or unavailable external infrastructure.

Production files changed: **NO**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **NO**  
Documentation changed: **YES — only `docs/verification/FINAL-PRODUCTION-READINESS-AUDIT-V9.md`**  
Final verdict: **NO-GO**
