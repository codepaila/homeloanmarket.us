# FINAL PRODUCTION READINESS AUDIT V6

Audit date: 2026-08-10  
Repository: HomeLoanMarket US  
Mode: READ-ONLY / AUDIT-ONLY

## 1. Executive Verdict

**NO-GO**

Phase 1F fixes are present and pass focused tests: company-edit now uses an explicit DTO, upgrade reconciliation uses Stripe state, the primary checkout route supplies server-derived Stripe idempotency, and email-change tokens bind the normalized target email.

The repository is not production-ready because independent V6 review found additional exploitable/high-impact paths:

- `actions/subscription.ts:createStripeCustomer()` is an exported server action that creates arbitrary Stripe customers without authentication or ownership checks.
- `actions/auth.action.ts:loginCheckUser()` is an exported authentication helper with optional IP throttling and account-state-specific responses, creating an alternate rate-limit/enumeration path if invoked.
- `app/api/auth/reset-password/route.ts` accepts a matching reset token when expiry is null.
- The generic `getCurrentUser()` remains broad and unsafe-by-default, and an admin broker page still passes a full Broker/subscription object to a Client Component.
- The alternate server-action checkout path lacks the Phase 1F idempotency protection.

These are concrete application/security/payment-boundary findings, not ordinary lint debt or unavailable E2E infrastructure.

## 2. Validation Summary

| Check | Result | Evidence |
| ----- | ------ | -------- |
| Documentation baseline | PASS with contradictions | V1-V5 and Phase 1A-1F reports inventory; current claim contract is `docs/business/33-CLAIM-CONTRACT.md`; requested `docs/CLAIM-CONTRACT.md` is absent. |
| Security/subscription regression suite | PASS with skips | 104 passed, 0 failed, 2 skipped, including Phase 1F and C1-H7 suites. |
| Advertisement/media regression suite | PASS with skips | 65 passed, 0 failed, 3 skipped. |
| Prisma validate | PASS | `yarn prisma validate`. |
| Prisma generate | PASS | `npx prisma generate`. |
| TypeScript | PASS | `npx tsc --noEmit`. |
| Production build | PASS | `npx next build`; 93 static pages generated. |
| Changed-scope ESLint | PASS in Phase 1F remediation | Phase 1F changed-file lint command completed without output/errors. |
| Full lint | FAIL | `yarn lint` reports existing full-tree errors/warnings. |
| Live HTTP | UNAVAILABLE | No running application/database fixture supplied. |
| Browser automation | UNAVAILABLE | No browser runtime supplied. |
| Stripe E2E | UNAVAILABLE | No real Stripe session/payment/webhook fixture supplied. |
| Email/Redis/OAuth E2E | UNAVAILABLE | No provider or deployment fixture supplied. |

## 3. Phase 1F Verification

### Company Edit DTO

**Status:** VERIFIED/FIXED.

**Evidence:** `app/broker/company/edit/page.tsx` now queries only Broker scalar fields, constructs `brokerDto`, and passes `<EditBrokerProfile broker={brokerDto} />`. It no longer includes `user`, `bankPartners`, or `subscription` relations. The DTO contains the fields consumed by the edit form, including registration/tax fields currently required by that UI.

**Affected workflow:** Broker company profile editing.

**Regression test:** Phase 1F C3 test and Phase 1D/Phase 1E C3 tests pass.

**Remaining risk:** `lib/currentUser.ts` still returns broad User scalar fields, and `app/admin/brokers/[id]/page.tsx` remains a separate broad admin Broker/subscription client boundary.

### Upgrade State Integrity

**Status:** FIXED for the audited upgrade route; alternate payment paths remain open.

**Evidence:** `app/api/subscription/upgrade/route.ts` verifies Stripe customer ownership and calls `SubscriptionService.syncWithStripe` instead of directly writing local paid plan state. The synchronization derives plan/status from Stripe.

**Affected workflow:** Authenticated broker plan upgrade.

**Regression test:** Phase 1F upgrade test and combined subscription suite pass.

**Remaining risk:** The alternate `actions/subscription.ts:createCheckoutSession` path and direct `createStripeCustomer` action remain separately exported. Upgrade itself has no Stripe idempotency key.

### Checkout Idempotency

**Status:** PARTIALLY FIXED.

**Evidence:** `app/api/subscription/checkout/route.ts` uses a server-derived key containing authenticated user ID, broker ID, validated plan/price, and a ten-minute server bucket. It does not accept a client idempotency identity.

**Affected workflow:** Public pricing and broker checkout route.

**Regression test:** Phase 1F idempotency test passes.

**Remaining risk:** `actions/subscription.ts:createCheckoutSession` also calls `stripe.checkout.sessions.create` and has no idempotency key. The time-bucket approach also permits a new key after the bucket changes. The alternate path must be dispositioned before production payment traffic.

### Email Verification Binding

**Status:** VERIFIED/FIXED for new tokens.

**Evidence:** Email-change issuance hashes `${rawToken}:${target}` after server normalization. Verification first checks the raw SHA-256 digest for signup tokens, then target-bound digest for email-change tokens. A modified `email` parameter cannot match an email-change token, and a signup token cannot enter the email-change branch.

**Affected workflow:** Signup verification and authenticated email change.

**Regression test:** Phase 1F email-binding tests and Phase 1C/Phase 1B email tests pass.

**Remaining risk:** Existing email-change tokens issued before the binding change are not target-bound. The shared token field remains a combined storage field, although the digest formats now distinguish purposes.

## 4. C1–C3 Status

### C1 — Session Identity Integrity

**Status:** FIXED / VERIFIED.

**Evidence:** `lib/auth.config.ts` does not merge client `session.user` into JWT claims. Claims refresh from trusted Prisma state keyed by trusted token email. No request-controlled role/email/userId identity merge found.

**Affected workflow:** Authentication/session refresh.

**Regression test:** C1 Phase 16 tests, pass.

### C2 — Public Broker Contact

**Status:** FIXED / VERIFIED with legacy fallback.

**Evidence:** `/api/contacts/send` resolves by broker slug, validates missing identifiers, checks public eligibility, and stores against resolved broker ID. Anonymous access is intentional. The retained brokerId fallback still resolves/validates the server-side Broker.

**Affected workflow:** Public lead creation.

**Regression test:** C2 Phase 16 tests, pass; live HTTP unavailable.

### C3 — Sensitive Data Boundaries

**Status:** PARTIAL — NEW VARIANTS remain.

**Evidence:** Personal edit, company display, dashboard, and company-edit paths now use explicit DTOs in the tested paths. Public DTOs strip contact/ownership/subscription data. However:

- `lib/currentUser.ts:13-94` uses default User scalar selection and returns `{ ...user }`, retaining `password`, email-verification token fields, and reset-token fields for any future unsanitized caller.
- `app/admin/brokers/[id]/page.tsx` loads `subscription: true` and passes the full broker object to a client component, exposing Stripe identifiers in an authenticated admin payload.

No OAuth access/refresh/ID tokens or `accounts` relation were found in the audited public/personal/company/dashboard DTOs. The C3 boundary is not fully safe-by-default.

**Affected workflow:** Generic server loader, admin broker management, future client callers.

**Regression test:** Existing C3/Phase 1F tests pass but do not cover generic loader scalar exclusion or admin broker client serialization.

## 5. H1–H7 Status

| Finding | Status | Evidence | Affected workflow | Regression test |
| ------- | ------ | -------- | ---------------- | --------------- |
| H1 contact paywall | FIXED / VERIFIED | `toPublicBrokerRecord` and public routes gate protected contact fields by entitlement/owner/admin. | Public broker contact | `phase-17`, pass |
| H2 mass assignment | FIXED on canonical routes | Broker policy allowlists and ownership checks exist; `/api/brokers/me` remains a separate manual implementation without equivalent schema validation. | Broker/company mutation | `phase-17`/`phase-18`, pass |
| H3 password recovery | PARTIAL | Hashing, expiry field, bcrypt, correct URL, and single-use clearing exist; null expiry is accepted. | Password reset | H3 tests pass; null-expiry case absent |
| H4 verification | FIXED / VERIFIED | No invalid enum/field writes; schema supports `UNVERIFIED | VERIFIED`. | Admin verification | `phase-18`, pass |
| H5 service-city limit | FIXED / VERIFIED | Creation and update paths enforce FREE=1/FEATURED unlimited through canonical helpers. | Broker service areas | `phase-18`/`phase-19`, pass |
| H6 Stripe ordering | FIXED with residual race risk | Signature, event ID, PROCESSING/PROCESSED/FAILED, stale guard, and Redis lock exist; lock failure is fail-open. | Webhook lifecycle | H6/webhook tests pass |
| H7 claim recipient binding | FIXED / VERIFIED | Recipient checked at session email and completion, with expiry/revocation/used/reauth/transactional ownership. | Claims | H7/claim tests pass |

## 6. Equivalent / Variant Findings

| Finding | File/Path | Severity | Impact | Classification |
| ------- | --------- | -------- | ------ | -------------- |
| Unauthenticated exported Stripe customer creation server action | `actions/subscription.ts:16-26` | HIGH | Arbitrary callers can create Stripe customers without account/customer ownership checks | A. MUST FIX BEFORE PRODUCTION |
| Alternate login helper accepts optional IP and returns state-specific errors | `actions/auth.action.ts:89-222` | HIGH | Alternate invocation can bypass intended rate limiting and enumerate account state | A. MUST FIX BEFORE PRODUCTION |
| Reset token with null expiry accepted | `app/api/auth/reset-password/route.ts:38-51` | HIGH conditional | Matching malformed/legacy token can remain valid indefinitely | B. SHOULD FIX BEFORE PRODUCTION |
| Generic `getCurrentUser()` exposes sensitive scalar fields | `lib/currentUser.ts:13-94` | HIGH defense-in-depth | Future unsanitized client boundary can expose password/reset/verification fields | A. MUST FIX BEFORE PRODUCTION |
| Full admin Broker/subscription object passed to Client Component | `app/admin/brokers/[id]/page.tsx` | MEDIUM | Stripe identifiers/private fields reach authenticated admin browser unnecessarily | B. SHOULD FIX BEFORE PRODUCTION |
| Alternate checkout server action lacks idempotency | `actions/subscription.ts:28-67` | HIGH conditional | Duplicate checkout sessions/subscriptions remain possible through alternate path | A. MUST FIX BEFORE PRODUCTION |
| Upgrade operation lacks Stripe idempotency | `app/api/subscription/upgrade/route.ts:56-70` | MEDIUM | Concurrent retries can duplicate proration/update operations | B. SHOULD FIX BEFORE PRODUCTION |
| Cancellation diverges local state after provider failure | `lib/subscription.ts:255-269` | MEDIUM | Local inactive state may not match Stripe | B. SHOULD FIX BEFORE PRODUCTION |
| Advertisement media lifecycle and URL validation gaps | Media routes, delivery, validation | MEDIUM | Deleted media remains public; move/restore unavailable; malformed destination/storage risks | B. SHOULD FIX BEFORE PRODUCTION |

## 7. Medium Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Reset null-expiry invariant | Present | MEDIUM/HIGH conditional | Token expiry is not fail-closed for malformed records | B | Reject and clear missing-expiry records |
| Reset completion controls | Missing | MEDIUM | Unlimited bcrypt work and no server password policy | B | Add endpoint throttling and server policy |
| Broker `/me` manual validation | Present | MEDIUM | Malformed profile values can diverge from canonical routes | B | Align validation/allowlist implementations |
| Bank replacement non-atomicity | Present | MEDIUM | Failure after delete can lose bank partnerships | B | Use a transaction or safe replacement operation |
| Invoice/payment DTO breadth | Present | MEDIUM | Internal payment identifiers/URLs reach authenticated browser | B | Return only UI-required billing fields |
| Webhook lock fail-open | Present | MEDIUM | Concurrent multi-instance processing can race | C/F | Confirm deployment Redis guarantees or add fail-closed policy |
| Subscription sync route referenced but missing | `hooks/useSubscription.ts:153-169` | MEDIUM | Manual sync action returns 404 | B | Remove or implement canonical sync path |
| Alternate server-action checkout | Present | MEDIUM/HIGH conditional | Duplicate checkout authority and no idempotency | A | Remove/deprecate or secure and align it |
| Stripe hard-coded price fallback | `lib/stripe.ts:6-9` | MEDIUM | Misconfiguration can select unintended price | B | Require explicit production configuration |
| Public ad click abuse | `app/api/ads/click/route.ts` | MEDIUM | Analytics/event volume poisoning | B | Add server-side validation/rate controls |
| Media lifecycle/storage | Media repository/uploads route | MEDIUM | Deleted URLs remain retrievable; local disk may be non-durable | B/F | Add lifecycle checks and deployment storage policy |

## 8. Low / Informational Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Full lint debt | Existing | LOW | No direct runtime defect established | F | Reduce incrementally |
| Email delivery idempotency | Process-local | LOW/MEDIUM | Multi-instance/restart behavior can duplicate or suppress retries | C/F | Use durable provider idempotency if required |
| Equal-second Stripe ordering | Present | LOW | Rare ordering tie ambiguity | C | Add deterministic tie-breaker if required |
| Unmounted ad placements | Documented/tested intentional | INFO | Inventory slots do not display ads | C | Keep inventory explicit |
| Review write path | Read-only | LOW/MEDIUM | FAQ/product promise exceeds implementation | C | Make product decision explicit |
| US vs India/Nepal currency/content drift | Present | INFO | Commercial confusion | C | Reconcile product copy/configuration |
| Browser/live provider testing | Unavailable | INFO | External behavior unverified | F | Establish staging CI |

## 9. Regression Findings

1. Phase 1F company-edit DTO, upgrade reconciliation, primary checkout idempotency, and email target binding are present and pass focused tests.
2. Phase 1F did not secure the exported alternate `createStripeCustomer` server action or alternate `createCheckoutSession` action.
3. Phase 1F did not make the generic `getCurrentUser()` safe-by-default or sanitize the admin broker client page.
4. No regression was found in C1, C2, H1, H2, H4, H5, H6, or H7 focused tests.
5. Advertisement/media regression tests pass, but operational lifecycle and URL/durability findings remain.

## 10. Security Boundary Verification

### Authentication

Primary credential/Google paths are server-side and broker login requires verification. An alternate exported `loginCheckUser` helper accepts optional IP and state-specific responses; this is an authentication hardening defect.

### Authorization

Admin handlers generally re-check role and broker routes check ownership. `createStripeCustomer` lacks an explicit authentication/ownership boundary.

### Ownership

Claim ownership is conditional and transactional. Public contact is slug-resolved. Primary checkout verification binds customer/metadata to current broker. Alternate Stripe customer creation is not bound.

### Sessions

C1 session identity integrity remains fixed; no client session merge found.

### PII

Public DTOs and primary owner DTOs are narrowed, but generic currentUser and admin broker client paths remain broad. Invoice data exposes payment metadata.

### Tokens

Email-change target binding is fixed for new tokens. Reset token null-expiry remains. Raw reset/email verification tokens were not found in logs.

### Claims

Recipient checks, hashed invitation tokens, expiry, revocation, used state, reauth, origin, and transactional ownership checks remain.

### Payments

Primary checkout and verification validate Stripe state. Alternate unauthenticated customer creation and alternate checkout action are unsafe payment boundaries.

### Subscriptions

Upgrade now syncs Stripe state, but cancellation divergence, alternate actions, and webhook lock fail-open behavior remain.

### Admin

Admin role checks exist, but admin broker client payload is broader than necessary.

## 11. Business Workflow Verification

### Broker signup

Entry points are `/api/auth/register/broker` and `/api/brokers`; server transaction creates FREE Broker/User state. Focused tests pass; live activation unavailable.

### Broker profile

Personal/company display DTOs are explicit; company-edit is fixed. Generic/admin client payload breadth remains.

### Contact / lead generation

Public contact resolves by slug, checks public broker policy, writes ContactMessage, increments leads, and notifies. Live HTTP unavailable.

### Subscription

FREE/FEATURED entitlement helpers are centralized. Client cannot set paid state through primary checkout/verification. Alternate customer/checkout actions remain.

### Checkout

Pricing sends validated plan/price; primary route creates Stripe session with server idempotency and success URL. Alternate server action remains unprotected/idempotency-free.

### Stripe webhook

Signature, event ID, stale checks, and lifecycle branches exist. Redis failure fallback remains best-effort.

### Claim

Invitation through completion enforces recipient binding and conditional ownership. Tests pass; live provider/browser unavailable.

### Advertisement

Admin/public lifecycle and rendering tests pass. Tracking, media lifecycle, URL validation, and local storage risks remain.

### Admin management

Admin ad/media/broker APIs check role. Admin broker page DTO remains broad.

### Media

Upload MIME/content/size/Sharp/path controls pass tests. Deleted-file delivery, storage durability, move/restore, and metadata validation remain.

### Reviews

Published public reads exist; no public write route found.

### Password recovery

Hashing/expiry/single-use flow exists, but null expiry is accepted and completion is unthrottled.

### Email verification

Signup raw-token verification and new email-change target-bound verification pass tests. Existing pre-binding email-change tokens are a migration/expiry consideration.

## 12. Advertisement Verification

- **Admin CRUD:** ADMIN checks and lifecycle routes exist; no changes were made.
- **Picker/upload:** Reusable picker, MIME/content/size validation, SVG rejection, Sharp conversion, and UUID paths pass tests.
- **Ownership:** Admin-only mutation boundary exists; no separate per-asset ownership model.
- **Format:** Placement/creative assignment validation exists; direct fallback media update validation is incomplete.
- **Placement/targeting:** Schedule, device, enabled/archive/delete filtering and bounded slots exist. Several configured slots are intentionally unused.
- **Carousel/responsive:** Carousel, reduced motion, literal bounded heights, and no natural image overflow pass tests.
- **Tracking:** Impressions have limited deduplication; clicks lack server-side rate limiting/deduplication.
- **Anonymous delivery:** Public delivery routes do not require auth; live HTTP unavailable.
- **Lifecycle/fallback:** Media restore/move routes, deleted media revocation, local durability, and banner destination semantics remain operational risks.

## 13. Test Evidence

### passed

- `yarn prisma validate`.
- `npx prisma generate`.
- `npx tsc --noEmit`.
- Security/subscription/auth/broker/claim Phase 1A-1F command: **104 passed**.
- Advertisement/media command: **65 passed**.
- `npx next build`.

### failed

- `yarn lint`: full repository lint failure with existing errors/warnings.

### skipped

- Security command: **2 skipped**, environment-gated registration/broker tests; impact is unavailable live route validation.
- Advertisement/media command: **3 skipped**, environment-gated live public/admin/media tests; impact is unavailable live delivery validation.

### unavailable

- Live HTTP.
- Browser automation.
- Stripe E2E/provider delivery.
- Email interception/delivery E2E.
- Redis outage/concurrency E2E.
- Staging/production deployment validation.

## 14. Build / Type / Lint

- `yarn prisma validate`: **PASS**.
- `npx prisma generate`: **PASS**.
- `npx tsc --noEmit`: **PASS**.
- `npx next build`: **PASS**, 93 static pages generated.
- Changed Phase 1F files ESLint: **PASS**.
- `yarn lint`: **FAIL** due existing repository lint debt.

## 15. Infrastructure Limitations

### Application defects

Unauthenticated Stripe customer server action, optional-IP alternate login helper, null reset expiry, generic broad currentUser, admin broad Broker DTO, alternate checkout idempotency, cancellation divergence, and ad/media lifecycle issues are application findings.

### Test infrastructure

No package test script exists; direct `node --import tsx --test` commands were used. Environment-gated tests require live base URL/database fixtures.

### Browser automation

Unavailable; RSC/client payloads were source-tested only.

### Live HTTP

Unavailable; no running app/database supplied.

### Stripe E2E

Unavailable; no real Checkout Session/payment/webhook/cancellation test.

### Email E2E

Unavailable; no provider delivery/interception fixture.

### Redis E2E

Unavailable; lock/failover/concurrency behavior not exercised in deployment.

## 16. Remaining Production Risks

1. Exported `createStripeCustomer` server action has no authentication/ownership check.
2. Exported optional-IP `loginCheckUser` provides an alternate throttling/enumeration weakness.
3. Generic `getCurrentUser` and admin broker page remain unsafe-by-default client-boundary sources.
4. Reset tokens with null expiry remain usable.
5. Alternate checkout action lacks idempotency and upgrade retries lack idempotency.
6. Cancellation can diverge local state from Stripe after provider failure.
7. Advertisement/media lifecycle, URL validation, click controls, and storage durability remain incomplete.

## 17. Required Before Production

1. Secure or remove the unauthenticated `createStripeCustomer` server action and verify all exported subscription actions have authorization.
2. Remove or secure the alternate `loginCheckUser` path so all credential attempts require the active rate limiter and generic responses.
3. Make the generic current-user loader and admin broker client boundary safe-by-default with explicit DTOs/exclusions.
4. Reject reset tokens with null expiry.
5. Secure the alternate checkout path and add idempotency to upgrade/payment mutations, or remove unreachable duplicate authorities.

## 18. Recommended After Production

1. Reconcile cancellation semantics and webhook lock failure policy.
2. Add server-side ad click controls, media deletion revocation, durable storage, move/restore routes, and metadata/dimension validation.
3. Reconcile billing DTO minimization, currency/product copy, historical PREMIUM terminology, review-write scope, and stale docs.
4. Establish isolated integration, browser, HTTP, Stripe, email, OAuth, and Redis staging tests.
5. Reduce repository lint debt.

## 19. Final GO/NO-GO Reasoning

The Phase 1F targeted remediation is substantially correct and the combined source/regression suite passes. The primary checkout route, verification route, company-edit DTO, upgrade reconciliation, and email target binding are present and tested.

The repository still contains production-impacting alternate authorities and security paths. In particular, an exported server action can create Stripe customers without authentication, an alternate login helper can bypass the intended limiter, reset tokens can be accepted without expiry, and the generic current-user/admin broker boundaries remain unsafe-by-default. The alternate checkout action also lacks the idempotency protection verified for the primary route. These findings affect authentication, payment ownership, credential/token safety, and payment integrity.

The final decision is **NO-GO**. This is based on concrete application findings, not full-lint debt or unavailable external infrastructure.

Production files changed: **NO**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **NO**  
Documentation changed: **YES — only `docs/verification/FINAL-PRODUCTION-READINESS-AUDIT-V6.md`**  
Final verdict: **NO-GO**
