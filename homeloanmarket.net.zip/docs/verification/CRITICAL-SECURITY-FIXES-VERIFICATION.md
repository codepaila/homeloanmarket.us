# Critical Security Fixes Verification (C1 / C2 / C3)

Scope: remediation of the three CRITICAL findings from the production-readiness audit. No advertisement, media, Stripe, claim-flow, or broker mass-assignment logic was changed.

## C1 — JWT `session.update()` privilege escalation

- **Finding:** `lib/auth.config.ts` merged client-supplied `session.user` into the JWT (`token = { ...token, ...session.user }`) before the server-side identity refresh, letting an authenticated user redirect the DB refresh to another account (email/role/id takeover).
- **Root cause:** the `jwt` callback trusted the client for identity claims.
- **Remediation:** removed the client merge entirely. Identity claims are now derived only from (a) the server-issued `user` at sign-in and (b) the trusted database refresh keyed by the server-issued `token.email`.
- **Consumers verified:** every in-app `useSession().update()` call (`app/claim-broker/continue/page.tsx`, `app/claim-broker/[token]/page.tsx`, `components/sections/broker/BrokerSetupWizard.tsx`) invokes `refreshSession()` with **no arguments** purely to re-sync the JWT with the database, so removal preserves legitimate behavior.
- **Business rules preserved:** login, session refresh, claim completion, and broker setup flows unchanged.

## C2 — Public broker contact form broken (lead creation 500)

- **Finding:** `lib/public-broker.ts` strips the broker `id` from the public record; the public profile passed `undefined brokerId` to the contact form; `app/api/contacts/send` did `findUnique({ where: { id: undefined } })` → 500. `proxy.ts` additionally blocked anonymous `/api/contacts/send`.
- **Root cause:** the contact API resolved the target by an identifier the public surface intentionally never exposes.
- **Remediation:** the contact API now resolves the target by the canonical public identifier `profileSlug` (unique) with an `id` fallback, guards requests with no identifier (400), and stores the lead against the resolved broker only. The contact form already submits `brokerSlug`. `proxy.ts` now allows anonymous `/api/contacts/send` (public lead submission is the documented business rule; broker-facing contact routes remain protected).
- **IDOR preserved:** the slug uniquely selects the target broker; a nonexistent/non-public broker returns 404; a lead cannot be attributed to another broker.
- **Business rules preserved:** anonymous public contact submission, rate limiting, broker visibility gating, email notifications, and `totalLeads` increment.

## C3 — OAuth tokens and lead PII serialized into client payloads

- **Finding:** `lib/currentUser.ts` loaded `accounts` (OAuth access/refresh/id tokens) and `brokerProfile.contactMessages` (lead PII), and `app/broker/company/page.tsx` / `app/broker/profile/page.tsx` passed the full object to client components.
- **Root cause:** the canonical user loader included secret/sensitive relations and pages spread the entire object into RSC payloads.
- **Remediation:**
  - `lib/currentUser.ts` no longer loads `accounts` or `contactMessages`; the claim flows that need accounts query them explicitly server-side.
  - `app/broker/company/page.tsx` passes an explicit safe DTO (id/email/role + sanitized broker without `contactMessages`); lead counts are passed as integers only.
  - `app/broker/profile/page.tsx` builds an explicit `profileUser` subset; `EditPersonalProfile` prop type narrowed to that safe subset.
- **UI preserved:** broker company page and personal profile render from the reduced DTOs (verified by render test).
- **Business rules preserved:** broker ownership, company/profile editing, subscription display.

## Regression tests

`tests/phase-16-critical-security-fixes.test.tsx` (10 tests, all passing):

- C1: no `session.user` merge; DB identity refresh retained; all legitimate `refreshSession()` calls are no-argument.
- C2: public broker record carries `profileSlug` and strips `id`/`userId`/`contactMessages`; contacts/send resolves by slug, guards missing identifiers, stores against resolved broker; form sends `brokerSlug`; proxy allows anonymous submission.
- C3: `getCurrentUser` excludes accounts/contactMessages; company page passes a safe DTO; profile page builds a safe subset; `EditPersonalProfile` renders from the reduced DTO.

## Validation results

- `prisma validate`: PASS
- `tsc --noEmit`: PASS (0 errors)
- Focused C1/C2/C3 suite: 10/10 pass
- Advertisement + auth + form + subscription regression suites: 89/89 pass
- ESLint on changed files: 0 errors
- Production build: PASS

## H1 / H2 / H3 — High findings remediation

### H1 — Contact-detail paywall bypass (server-enforced)

- **Finding:** `lib/public-broker.ts` kept `phone`, `whatsapp`, `email`, `website`, `officeAddress`, `pinCode` in public responses regardless of the FEATURED contact entitlement; `canShowContact` was UI-only.
- **Root cause:** the canonical public DTO did not enforce the entitlement.
- **Canonical rule:** only a FEATURED (paid) subscription (`hasPaidEntitlement`), the broker owner, or an admin is entitled to contact details (`lib/stripe.ts` "Direct contact details shown"; `lib/broker-policy.ts`).
- **Remediation:** `toPublicBrokerRecord(value, { includeContact })` now omits the six protected fields unless `includeContact` is true. All four public routes pass the entitlement flag: listing (`hasPaidEntitlement`), detail routes (`paid || owner || admin`), and featured feed (`true` — all featured brokers are paid). The featured feed now uses the canonical DTO instead of leaking raw broker/account records.
- **Preserved:** public visibility rules, `profileSlug` resolution (C2), `canShowContact` flag, admin/owner entitlements.

### H2 — Broker API mass assignment / ownership transfer

- **Finding:** `app/api/brokers/[id]` and `app/api/company/[slug]` PATCH copied arbitrary body keys (blacklist only), letting a broker set `userId` (ownership transfer), `brokerStatus`, `avgRating`, `totalLeads`, `profileViews`, `featuredRank`, etc.
- **Root cause:** blacklist-based field copying with no schema of allowed fields.
- **Remediation:** canonical allowlists in `lib/broker-policy.ts` (`BROKER_EDITABLE_FIELDS`, `BROKER_ADMIN_FIELDS`) and a single helper `pickBrokerEditableFields(body, isAdmin)` used by both routes. Ownership, metrics, status, verification, and system-managed fields are never accepted from client input; admins may set the four admin-managed fields but never `userId`/metrics. The buggy `verificationDocuments`/`'PENDING'` write (non-schema) is gone.
- **Preserved:** ownership checks (non-owner → 403), legitimate profile editing, slug uniqueness, service-city and bank-partnership handling, admin verification/featured derivation.

### H3 — Broken password recovery / token logging

- **Finding:** reset email linked `/auth/reset?token=…` (page is `/auth/reset-password`); the raw reset URL (containing the token) and email-send result were `console.log`ged.
- **Root cause:** wrong route constant + debug logging.
- **Remediation:** `actions/email.action.ts` now builds `/auth/reset-password?token=${rawToken}&email=${encodeURIComponent(email)}` (the page reads those params) and no longer logs the reset URL or send result.
- **Preserved:** SHA-256 token hashing, expiry enforcement, single-use clearing, bcrypt(12) password hashing in `app/api/auth/reset-password/route.ts` (unchanged).

### Regression tests

`tests/phase-17-high-fixes.test.tsx` (13 tests, all passing) — H1 DTO stripping/entitlement and route wiring; H2 allowlist behavior for brokers and admins (ownership/metrics/status rejected, legitimate fields applied) and route ownership checks; H3 correct reset URL, no token logging, and reset-endpoint hashing/expiry/bcrypt/consumption.

### Validation results (H1/H2/H3 pass)

- `prisma validate`: PASS
- `tsc --noEmit`: PASS (0 errors)
- Focused H1/H2/H3 suite: 13/13 pass
- Combined regression suites (C1/C2/C3 + H1/H2/H3 + advertisement + auth + form + subscription): 102/102 pass
- ESLint on changed files: 0 errors (12 pre-existing warnings)
- Production build: PASS

## H4 / H5 / H6 / H7 — HIGH/MEDIUM remediation

### H4 — Invalid verification schema writes (already fixed — no production change)

- **Finding:** `app/api/brokers/[id]` previously wrote `verificationStatus: 'PENDING'` (not in the `UNVERIFIED | VERIFIED` enum) and a non-schema `verificationDocuments` field → Prisma 500.
- **Confirmation:** already remediated by the H2 allowlist change, which removed the `verificationDocuments`/`'PENDING'` block. Repo-wide scan confirms zero `'PENDING'`/`verificationDocuments` writes remain; the schema enum is `UNVERIFIED | VERIFIED`; `verificationStatus`/`verifiedAt` are not broker-editable; admin verification uses the canonical `'VERIFIED'` value with server-derived `verifiedAt`.
- **Preserved:** admin verification workflow; brokers cannot forge verification state.

### H5 — FREE-tier service-city limit enforced

- **Finding:** `effectiveSubscription.isActive` is true for every FREE plan, so `!hasActiveSubscription` guards never triggered and FREE brokers could submit unlimited service cities.
- **Root cause:** the limit was gated on account subscription state instead of paid entitlement.
- **Canonical rule:** FREE = 1 service city, paid FEATURED = unlimited (encoded in the app's own intended logic).
- **Remediation:** new canonical helper `maxServiceCitiesForEntitlement` (`lib/broker-policy.ts`) derived from `hasPaidEntitlement`; both `/api/brokers/me` and `/api/company/[slug]` PATCH now enforce `serviceCities.length > maxServiceCities` server-side.
- **Preserved:** paid/FEATURED behavior, cancellation/expiry collapse to FREE (effectiveSubscription), account `isActive` reporting.

### H6 — Stripe webhook out-of-order race

- **Finding:** the stale check only consulted `PROCESSED` events, so two concurrently delivered events could let an older event overwrite newer subscription state.
- **Root cause:** ordering guard missed in-flight events and checked before registering the current event.
- **Canonical ordering signal:** Stripe `event.created` timestamp.
- **Remediation (`app/api/stripe/webhook/route.ts`):** the event is registered as in-flight (`PROCESSING`) BEFORE the ordering check; the ordering guard (`hasNewerAppliedEvent` → pure `isStaleEvent`) considers both `PROCESSED` and `PROCESSING` rows strictly newer than the current event; processing is serialized per subscription via a best-effort Redis lock (`withWebhookSubscriptionLock`) that falls back to the ordering guard if Redis is unavailable. Newer state can no longer be regressed by an older event.
- **Preserved:** Stripe signature verification (`stripe.webhooks.constructEvent`), unique-`eventId` idempotency (`P2002`), `PROCESSED` duplicate short-circuit, retry/FAILED handling, cancellation/renewal/reactivation lifecycle transitions.

### H7 — Claim invitation recipient binding

- **Finding:** `recipientEmail` was recorded but completion only checked self-consistency, so a forwarded/leaked claim link could be completed by a different account.
- **Root cause:** completion never compared the claimant to the intended recipient.
- **Remediation:** canonical `isClaimRecipientMatch` (`lib/claim-policy.ts`, case-insensitive) enforced at (a) the claim email step (`/api/claims/session/email`) and (b) authoritatively at completion (`lib/claim-completion.ts`), both throwing `INELIGIBLE` with a generic message that never reveals the intended address.
- **Preserved:** 256-bit token generation, SHA-256 hashing, HMAC claim cookie, reauth window, rate limiting, expiry/used/revoked checks, atomic ownership attach (`userId: null` guard).

### Regression tests

`tests/phase-18-high-medium-fixes.test.ts` (15 tests, all passing) — H4 proof (no invalid writes, enum, non-editable verification, admin path); H5 unit tests on `hasPaidEntitlement`/`maxServiceCitiesForEntitlement` and route wiring; H6 unit tests on `isStaleEvent` (newer-then-older → stale, older-then-newer → not stale), in-flight visibility, register-before-check, lock, signature/idempotency; H7 unit tests on `isClaimRecipientMatch` and both enforcement points.

### Validation results (H4–H7 pass)

- `prisma validate`: PASS
- `tsc --noEmit`: PASS (0 errors)
- Focused H4–H7 suite: 15/15 pass
- Combined regression suites (C1–C3, H1–H3, H4–H7, advertisement, auth, form, subscription): 117/117 pass
- ESLint on changed files: 0 errors (1 pre-existing warning)
- Production build: PASS

## Remaining limitations

- Live HTTP verification of broker PATCH limits, webhook ordering, and claim completion was not executed (requires a running server + seeded DB + Stripe test events); behavior is covered by unit tests on the canonical helpers (`hasPaidEntitlement`, `maxServiceCitiesForEntitlement`, `isStaleEvent`, `isClaimRecipientMatch`, `pickBrokerEditableFields`) plus source-level wiring guards. No browser automation was run.
- The webhook per-subscription lock is best-effort; when Redis is unavailable or the lock is contended, the ordering guard alone protects sequential delivery (no worse than prior behavior).
- `app/broker/profile/edit/page.tsx` still passes `getCurrentUser()` to the client component; after the C3 root fix this object contains no `accounts`/`contactMessages`.
- The MEDIUM/LOW cluster (proxy role checks, email re-verification, rate limiting on forgot-password/tracking endpoints, missing DB indexes, non-atomic writes, admin 401/403 inconsistency, dead client endpoints) remains intentionally untouched.
