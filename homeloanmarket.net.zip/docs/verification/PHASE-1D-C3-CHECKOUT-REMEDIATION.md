# PHASE 1D — C3 + PUBLIC CHECKOUT REMEDIATION

Audit basis: `docs/verification/FINAL-PRODUCTION-READINESS-AUDIT-V3.md`  
Mode: tightly scoped remediation; no production-readiness decision is made here.

## 1. Findings

### C3 sensitive data exposure

The finding was confirmed. `app/broker/profile/edit/page.tsx` loaded `getCurrentUser()` and passed the complete returned object to the Client Component `EditPersonalProfile`. `lib/currentUser.ts` intentionally excludes `accounts` and `contactMessages`, but its default Prisma User selection still includes server-only User fields such as `password`, email-verification token fields, and reset-token fields. A TypeScript prop type does not remove runtime properties from RSC serialization.

### Public subscription checkout contract

The mismatch was confirmed. `PricingCard` invokes the public pricing page callback with `(stripePriceId, planName)`. `app/(public)/subscription/page.tsx` discarded `planName` and sent only `{ priceId }`. `app/api/subscription/checkout/route.ts` requires `{ priceId, plan }` and validates the pair with `validatePlanPrice`, returning HTTP 400 when `plan` is absent. The pricing page is public, while the existing checkout API remains authenticated and broker-scoped; this remediation preserves that authorization boundary.

## 2. Root Cause — C3

`getCurrentUser()` is a broad server-side loader used by many API/server workflows. The alternate profile-edit server page treated its result as if the Client Component prop type were a runtime serializer. It was not. The page therefore created a server-to-client boundary without an explicit projection.

Equivalent-path review found:

- `app/broker/profile/page.tsx` already constructs an explicit safe `profileUser` DTO.
- `app/broker/company/page.tsx` strips `contactMessages` and builds an explicit client object.
- `accounts: true` remains only in server-side authentication/claim reauthentication queries, not generic client DTOs.
- No `access_token`, `refresh_token`, or `id_token` was found in client-bound application props.
- Other `getCurrentUser()` uses inspected in APIs/server loaders remain server-side; the broker dashboard passes broker-profile data, not the full User object, to its Client Component.

## 3. Root Cause — Checkout

The UI callback contract already carried the selected plan name, but the public pricing page serialized only the Stripe price ID. The API contract requires both values to validate the authoritative plan-price pair. This was a client request-shape omission, not a Stripe webhook, entitlement, or secret-management defect.

The server remains authoritative through `validatePlanPrice(plan, priceId)`. The client-supplied price ID is not trusted independently and cannot select an arbitrary Stripe price.

## 4. Exact Fix — C3

Changed only `app/broker/profile/edit/page.tsx`:

- Added the same explicit safe `profileUser` projection used by `app/broker/profile/page.tsx`.
- Included only `id`, `name`, `email`, `phone`, `image`, `role`, `createdAt`, `emailVerified`, and `isActive`.
- Passed `<EditPersonalProfile user={profileUser} />` instead of the full `user` object.

No shared authentication loader, session behavior, schema, authorization, or profile-edit client behavior was changed.

## 5. Exact Fix — Checkout

Changed only `app/(public)/subscription/page.tsx`:

- Changed the request body from `{ priceId }` to `{ priceId, plan: planName }`.
- Preserved the existing `/api/subscription/checkout` endpoint, response handling, browser redirect, server-side plan-price validation, authenticated broker requirement, Stripe customer/session creation, and webhook lifecycle.

## 6. Security Preservation

- OAuth account records and provider credentials remain excluded from `getCurrentUser()` and client DTOs.
- `password`, verification tokens, reset tokens, and private relations do not cross the fixed profile-edit boundary.
- `contactMessages` remain excluded from generic User DTOs; server-only lead queries remain server-side.
- Session identity remains server-derived; no `session.user` merge was introduced.
- Checkout still requires an authenticated user with a broker profile.
- `validatePlanPrice(plan, priceId)` remains the canonical server-side plan/price check.
- Arbitrary client price IDs are rejected when they do not match the authoritative catalog.
- Stripe secret credentials are server-only.
- Webhook ordering, subscription entitlement mapping, and Prisma schema were not changed.

## 7. Regression Tests

Added `tests/phase-1d-c3-checkout.test.ts` with five assertions covering:

1. The alternate profile-edit page constructs and passes an explicit safe DTO.
2. The generic current-user loader excludes OAuth/private relations and token names.
3. The public pricing UI sends the selected plan with its price to `/api/subscription/checkout`.
4. The checkout route retains authoritative plan-price validation and rejects a tampered price.
5. The API returns `url: checkoutSession.url`, matching the UI browser redirect contract.

The existing C1-C3, H1-H7, Phase 1A, Phase 1B, Phase 1C, subscription, webhook, and advertisement regression tests were also executed.

## 8. Validation

| Check | Result | Evidence |
| ----- | ------ | -------- |
| Phase 1D focused tests | PASS | 5 passed, 0 failed, 0 skipped |
| C1-C3/H1-H7/Phase 1A-1C/subscription/webhook suite | PASS | 80 passed, 0 failed, 0 skipped |
| Advertisement regression suite | PASS with skips | 65 passed, 0 failed, 3 skipped; skips are live HTTP tests gated on unavailable runtime configuration |
| `yarn prisma validate` | PASS | Current schema valid |
| `npx prisma generate` | PASS | Prisma Client generated |
| `npx tsc --noEmit` | PASS | No TypeScript errors |
| Changed-file ESLint | FAIL | Existing `any` error and warnings in `app/(public)/subscription/page.tsx`; no new C3-specific lint issue |
| `yarn lint` | FAIL | Existing full-repository lint errors, including explicit `any`, unescaped entities, and hook rule findings |
| `npx next build` | PASS | Production build compiled and generated 92 static pages |
| Live HTTP | UNAVAILABLE | No supplied running application/database fixture |
| Browser automation | UNAVAILABLE | No browser runtime supplied |
| Stripe E2E | UNAVAILABLE | No Stripe delivery/test fixture supplied |

No failures were hidden. The full lint failure is unrelated repository debt and was not expanded into scope. No live checkout session or RSC payload was claimed because live infrastructure was unavailable.

## 9. Regression Audit

| Area | Result | Evidence |
| ---- | ------ | -------- |
| C1 session identity | INTACT | Existing C1 tests pass; no session callback changes |
| C2 public broker contact | INTACT | Existing C2 tests pass; slug resolution and resolved broker ownership unchanged |
| C3 private data | FIXED for confirmed variant | Phase 1D safe-DTO test passes; equivalent source search found no alternate full User-to-client path |
| H1 contact paywall | INTACT | Existing H1 tests pass |
| H2 mutation allowlists | INTACT | Existing H2 tests pass |
| H3 password recovery | INTACT | Existing H3 tests pass; no reset flow changes |
| H4 verification state | INTACT | Existing H4 tests pass |
| H5 service-city limit | INTACT | Phase 1A/`phase-19` tests pass |
| H6 Stripe webhook ordering | INTACT | Existing H6/webhook tests pass; webhook code unchanged |
| H7 claim recipient binding | INTACT | Existing H7 tests pass |
| Phase 1B auth hardening | INTACT | Login, forgot-password, resend-verification tests pass |
| Phase 1C email-change verification | INTACT | Verified/unverified branch and token tests pass |
| Advertisement subsystem | INTACT | 65 advertisement regression tests pass; 3 live tests skipped |

## 10. Remaining Findings

This phase did not remediate unrelated V3 findings. They remain outside scope, including full lint debt, live HTTP/browser/Stripe verification gaps, ad tracking abuse controls, media lifecycle issues, reset-token null-expiry handling, and the public site-contact endpoint mismatch.

The checkout endpoint still requires authentication and a broker profile, as it did before this phase. The public pricing page is not an anonymous payment session endpoint; it is a public selection UI that directs authenticated broker users into the existing checkout flow.

## 11. Final Status

### C3 sensitive data exposure

**FIXED** for the confirmed `/broker/profile/edit` variant. The narrow server-side DTO boundary is in place and regression-tested. A fresh independent audit is still required.

### Public subscription checkout contract

**FIXED** for the confirmed request-shape mismatch. The selected plan now reaches the existing authenticated checkout route, which retains authoritative server-side price validation and returns the URL shape consumed by the UI. Live Stripe checkout was unavailable and remains unclaimed.

Exact files changed:

- `app/broker/profile/edit/page.tsx`
- `app/(public)/subscription/page.tsx`
- `tests/phase-1d-c3-checkout.test.ts`
- `docs/verification/PHASE-1D-C3-CHECKOUT-REMEDIATION.md`

Production files changed: **YES**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **YES**  
Documentation changed: **YES — only this Phase 1D report**

The two scoped blockers are fixed in current source. This report does not claim production readiness; the next step is a fresh independent FINAL PRODUCTION READINESS AUDIT V4.
