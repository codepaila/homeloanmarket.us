# Admin Advertisement Authentication & Media Upload Verification

Scope: the admin advertisement management authentication path, the media upload pipeline, and the public top-banner presentation contract.

## 1. Root Cause of the "You must be logged in" Error

**Symptom:** An authenticated administrator edits an advertisement and the UI shows `You must be logged in` before the request reaches the API.

**Root cause:** `components/admin/ads/AdvertisementForm.tsx` gated submission on an eagerly-read client `useSession()` snapshot:

```ts
if (!user?.id) { toast.error('You must be logged in'); return }
```

`user` came from `useCurrentUser()` → `next-auth/react` `useSession()`, which is `null` while the session is loading (or whenever the client session has not hydrated). A valid server session could therefore be misreported as "not logged in" on the client. The server-side authorization itself was **correct** — every admin mutation route authorizes via `getCurrentUser()` (→ `auth()` → DB role check) and HTTP verification confirmed an authenticated admin can update advertisements and upload media.

**Fix:** the client gate is now session-status aware — it blocks only on a genuine `unauthenticated` status, treats `loading` as a wait state (submit button disabled), and the server remains the authority (ADMIN-only). `CODE VERIFIED` + `HTTP VERIFIED`.

## 2. Canonical Authentication Path

- Client: `next-auth/react` `useSession()` / `useCurrentUser()` (session snapshot for UI only).
- Server: `lib/currentUser.ts` → `lib/auth.ts` `auth()` (single Auth.js v5 config; `strategy: "jwt"`) → Prisma user lookup by `session.user.email` → role check.
- Every admin advertisement/media route calls `getCurrentUser()` and requires `user.role === "ADMIN"` (401 for anonymous/other roles). No client-provided role, no `admin=true`, no hardcoded admin bypass.
- No duplicate Auth.js configuration; no `getServerSession`/`auth()` mismatch.

## 3. Middleware (proxy) Behavior

`proxy.ts` now returns **401 JSON** for anonymous protected `/api/*` requests instead of a login redirect (previously the generic redirect ran first and masked the 401). Anonymous page navigation still redirects to `/auth/signin`. `HTTP VERIFIED`.

## 4. Media Upload Contract

| Item | Value | Source |
|---|---|---|
| Route | `POST /api/admin/media` (+ `GET/PUT/DELETE /api/admin/media/[id]`) | `CODE VERIFIED` |
| Auth | ADMIN only (`getCurrentUser().role === "ADMIN"`) | `HTTP VERIFIED` |
| Storage | Local filesystem `public/uploads/media/*.webp` (+ `@200x200.webp` thumbnail) | `CODE VERIFIED` |
| Processing | `sharp` rasterizes every upload to WebP (quality 85); thumbnail 200×200 cover | `CODE VERIFIED` |
| Supported input formats | **JPEG, PNG, WebP, GIF** | `CODE VERIFIED` + `HTTP VERIFIED` |
| Maximum file size | **10 MB** (enforced server-side; middleware body limit raised to 12 MB so oversized uploads reach validation) | `CODE VERIFIED` + `HTTP VERIFIED` |
| Dimension validation | Upload accepts any measurable dimensions; placement compatibility (aspect ratio within 25% tolerance) validated at advertisement create/update via `validateCreativeDimensions` | `CODE VERIFIED` |
| Failed-upload cleanup | Files written before the DB reference are deleted if the DB insert fails | `CODE VERIFIED` |

## 5. Supported Image Formats (security stance)

- **Accepted:** `image/jpeg`, `image/png`, `image/webp`, `image/gif` — all rasterized to safe WebP output by `sharp`.
- **Rejected: `image/avif`** — not supported by the server pipeline; client `accept` attributes aligned (no longer offered).
- **Rejected: `image/svg+xml`** — the previous pipeline stored the original SVG bytes unsanitized under a `.webp` filename (script/XSS risk and broken extension/MIME). The upload now rejects SVG with a clear message, and `processImage` always rasterizes (no raw passthrough). `CODE VERIFIED` + `HTTP VERIFIED`.
- Client-side file selection and server-side MIME validation are both enforced (the browser `accept` attribute is not relied upon).

## 6. Top Banner Height Contract

- Canonical slot heights from `lib/advertisements/placementSpecs.ts` + `components/advertisements/ad-layout.ts`:
  - `HOMEPAGE_HERO` and full-width top placements: **90px mobile / 120px tablet / 150px desktop** (150px desktop cap, mobile < tablet < desktop).
- The slot is the single height owner; `object-contain` + `overflow-hidden` keep the 1600×300 (16:3) HORIZONTAL creative from expanding the page. The slot classes are emitted as complete literal strings (`h-[90px] sm:h-[120px] lg:h-[150px]`) so Tailwind v4 compiles them.
- Regression tests assert desktop ≤ 150px, mobile < tablet < desktop, no stale 200px desktop rule, and the single-fixed-height slot. `CODE VERIFIED` + `HTTP VERIFIED` (homepage SSR shows `h-[90px] sm:h-[120px] lg:h-[150px]`).

## 7. AdvertisementCard Data Boundary

`AdvertisementCard` validates via `isValidPublicAd` before any property access and returns `null` for `undefined`/`null`/malformed ads; the renderer layer (`PublicAdvertisement`, `AdvertisementCarousel`, `usePublicAd` fetcher) filters invalid entries. The `ad.buttonLabel` runtime crash path is closed at the canonical boundary (`lib/advertisements/public.ts`). `CODE VERIFIED` (tests) + `HTTP VERIFIED` (pages render without the error).

## 8. Security Validation Summary

- Anonymous → admin ad mutation: **401** (no redirect).
- USER → admin ad mutation: **403**. BROKER → admin ad mutation: **403**.
- Anonymous → media upload: **401**.
- MIME spoofing (non-image content labeled `image/png`): **400**.
- SVG / AVIF / oversized uploads: **400**.
- No stack traces or internal storage errors are returned to clients.

## 9. Tests Performed

| Suite | Result |
|---|---|
| `tests/phase-15.7-admin-ad-auth-media.test.ts` (unit + HTTP auth/media matrix) | 17/17 pass |
| `phase-15.5` advertisement safety | pass |
| `phase-14-public-ad-ui`, `phase-15-placement-size-contract`, `phase-15.6-top-banner-height`, `phase-15-advertisement-formats`, `advertisement-management` | pass |
| `phase-13.11-form-context`, `phase-13.12-admin-ads-dto`, `phase-13.13-media-selector`, `phase-13.2-login-redirect` | pass |
| `phase-13.9b-admin-ads-lifecycle`, `phase-13.11-admin-ads-list` (live server + DB) | pass |
| `prisma validate` | pass |
| `tsc --noEmit` | pass |
| ESLint (changed files) | 0 errors (pre-existing warnings only) |
| `yarn build` (production) | pass |
| HTTP: `/`, `/brokers`, `/blog`, `/faq`, `/calculator`, `/guides`, `/terms-of-service` | 200 |
| HTTP: anonymous `/api/admin/*` → 401 (was 307); authenticated ADMIN → update/upload success | verified |

## 10. Verification Labels

- **CODE VERIFIED** — implementation inspected/traced.
- **HTTP VERIFIED** — exercised against the live `next start` server with the real credentials session (admin@homeloanmarket.com) and real DB.
- **DATABASE VERIFIED** — Prisma schema validated; uploads produce a DB media reference plus storage object.
- **EXTERNALLY NOT VERIFIED** — Google OAuth, email delivery, CDN/external storage, and browser-pixel rendering were not exercised in this environment.

---

# Addendum — "Upload from Device" Preview/Selection Fix

## A. Root Cause

Uploaded images could not be previewed or rendered. HTTP tracing showed:

- `POST /api/admin/media` returned a complete `MediaAsset` (`fileUrl`, `thumbnailUrl`, `width`, `height`, …). The upload itself succeeded. **(A. upload succeeds)**
- `GET /uploads/media/<uuid>.webp` returned:
  - **307 redirect to `/auth/signin`** for anonymous requests (the `proxy.ts` middleware intercepted `/uploads/*` and required a session token), and
  - **404** for the logged-in admin, because Next.js only serves `public/` files that existed at build time — files written to `public/uploads/media/` **after** the build were not served. **(E. DB/storage succeeds but returned URL is invalid)**

So the failure was upstream of the form: the canonical media URL was never loadable, so the device-upload preview and any public ad rendering of uploaded media broke. The working "Select from Assets" picker used the same `/uploads/*` URLs but only ever displayed **pre-existing** (build-time) media files, which is why it appeared to work.

## B. Canonical MediaAsset Shape

Both "Select from Assets" and "Upload from Device" now produce the same canonical `MediaAsset`:

```
{ id, fileName, originalName, fileUrl, thumbnailUrl, mimeType, extension, fileSize, width, height, altText, title, folderId, uploaderId, isDeleted, createdAt, updatedAt }
```

Both paths call `MediaSelector.onChange(asset)` and store the same form field value (`mediaAssetId`), so downstream preview/selection is identical.

## C. Files Changed (this fix)

- `app/uploads/[...path]/route.ts` (new) — streams uploaded media from `public/uploads` with correct `Content-Type`; path-traversal guarded; works for runtime-added files and anonymous requests.
- `proxy.ts` — `/uploads` excluded from the middleware matcher and added to public paths (no more 307 on media URLs).
- `components/admin/media/MediaSelector.tsx` — immediate temporary blob preview (`URL.createObjectURL`) while the device file uploads, then swap to the canonical server URL; object URL revoked on success/error/unmount.
- `tests/phase-15.7-admin-ad-auth-media.test.ts` — added storage-serving regression tests.

## D. Device Preview Behavior

Local File → temporary `blob:` preview → `POST /api/admin/media` → canonical `MediaAsset` → persistent `/uploads/media/<uuid>.webp` preview. The blob URL is never stored; the DB keeps the canonical media reference. The object URL is revoked after upload and on unmount.

## E. Storage URL Verification (`HTTP VERIFIED`)

- `GET /uploads/media/<uuid>.webp` (anonymous) → **200**, `image/webp`.
- `GET /uploads/media/<uuid>@200x200.webp` thumbnail (anonymous) → **200**, `image/webp`.
- Pre-existing `public/uploads/media/*.webp` → **200**.
- Path traversal (`/uploads/media/..%2f..%2fpackage.json`) → **404**.
- Missing file → **404**.

## F. Create / Edit Verification (`HTTP VERIFIED`)

- Create ad → upload 1600×300 device image → `POST /api/admin/ads` with `creativeAssignments` → 201; public `/api/ads/public` returns the uploaded creative URL; anonymous GET of that URL → 200.
- Edit ad → `PUT /api/admin/ads/[id]` with a new device-uploaded HORIZONTAL creative → 200; reload `GET /api/admin/ads/[id]` shows the new `desktopMediaId` **persisted**.
- "Select from Assets" picker unchanged and still returns the same `MediaAsset` shape.

## G. Tests

- `tests/phase-15.7-admin-ad-auth-media.test.ts` — **20/20 pass** (auth matrix + media matrix + storage-serving: 200 content-type, no middleware redirect, traversal 404).
- Existing advertisement/media/form suites remain green.
- `tsc --noEmit` pass; ESLint 0 errors; `prisma validate` pass; `yarn build` pass.
- Browser automation: **NOT EXECUTED** (no browser tooling in this environment); the flow is covered by live HTTP + API tests.
