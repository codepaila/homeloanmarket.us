# PHASE 1A — H5 CREATION-PATH REMEDIATION

## 1. Finding

The FINAL PRODUCTION READINESS AUDIT reported H5 as **PARTIALLY FIXED — NEW VARIANT**: the PATCH/update paths enforce the FREE service-city limit, but the broker **creation** path accepted unlimited `serviceCities`.

Independently confirmed in source:

- `app/api/brokers/route.ts` (POST, ~line 213) → `createBrokerForExistingUser` (`lib/broker-registration.ts`)
- `lib/broker-registration.ts:190` → `serviceCities: data.serviceCities || []` with **no length limit**
- New brokers are always created with a `FREE` subscription (`plan: 'FREE', isActive: true`)

Result: an authenticated existing USER could `POST /api/brokers` with `serviceCities: [N cities]` and obtain a FREE broker listing N service cities, bypassing the intended FREE = 1 city allowance.

## 2. Root Cause

The service-city limit was enforced only on broker **update** paths (`/api/brokers/me` PATCH, `/api/company/[slug]` PATCH), not on the broker **creation** boundary (`createBrokerForExistingUser`). The creation function persisted `serviceCities` verbatim.

## 3. Canonical Business Rule

- FREE (no paid entitlement): maximum **1** service city.
- FEATURED / paid entitlement (`hasPaidEntitlement`): **unlimited** service cities.
- Entitlement is always determined from **trusted server-side subscription state** — never from client claims (`req.body.isFeatured`, `req.body.subscription`, `req.body.plan`, etc.).
- A newly created broker always starts on FREE, so the FREE allowance (1) applies at creation.

Canonical helpers (reused, no new rule):
- `hasPaidEntitlement` — `lib/broker-policy.ts`
- `maxServiceCitiesForEntitlement` — `lib/broker-policy.ts`
- `assertServiceCityLimit` — `lib/broker-policy.ts` (added this phase)

## 4. Affected Creation Paths

| Creation Path | Actor | Service fn | serviceCities accepted | Entitlement at creation | Limit enforced |
|---|---|---|---|---|---|
| `POST /api/brokers` (existing user becomes broker; also used by the broker setup wizard) | authenticated USER | `createBrokerForExistingUser` | YES | FREE | **FIXED this phase** |
| `POST /api/auth/register/broker` (full broker signup) | public | `createBrokerAccount` | NO (`BrokerRegistrationInput` has no `serviceCities`) | FREE | N/A (0 cities) |
| `POST /api/admin/brokers` (admin create) | ADMIN | `lib/admin-broker.ts` | YES | FREE (admin-managed) | Admin-controlled/trusted (not a user bypass) |
| Claim completion (ownership attach) | claimer | `lib/claim-completion.ts` | NO (does not set serviceCities) | inherited | N/A |

The only user-facing bypass was `POST /api/brokers` → `createBrokerForExistingUser`, now closed.

## 5. Implementation

- **`lib/broker-policy.ts`** — added pure, testable `assertServiceCityLimit(serviceCities, subscription?)` returning `{ ok, max, reason? }`; resolves a `null`/missing subscription (creation) to the FREE allowance (1).
- **`lib/broker-registration.ts`** — `createBrokerForExistingUser` now calls `assertServiceCityLimit(data.serviceCities, null)` before the transaction/persistence and throws a named `ServiceCityLimitError` when the FREE allowance is exceeded.
- **`app/api/brokers/route.ts`** — the POST catch maps `ServiceCityLimitError` to HTTP **403** with the canonical `error: 'SUBSCRIPTION_LIMIT'` (same error contract as the PATCH paths).

No schema, migration, subscription policy, or unrelated code changed.

## 6. Security / Business Integrity

- Server-side enforcement before persistence — frontend/UI limits are not relied upon.
- Client cannot claim paid entitlement: the creation check always evaluates entitlement as `null` (FREE), regardless of anything in the request body.
- Malformed (non-array) `serviceCities` is not counted (matches the PATCH-path convention); arrays over the allowance are rejected.
- No trust placed in `req.body.isFeatured`/`subscription`/`plan`/`hasPaidEntitlement`/`maxServiceCities`.
- Admin creation remains admin-gated and trusted; the full broker signup path does not accept `serviceCities`.

## 7. Regression Tests

`tests/phase-19-h5-creation-limit.test.ts` — 11 tests, all passing:

- FREE (null entitlement) + 1 city → allowed.
- FREE + 2 cities → rejected (reason includes canonical message).
- FREE + many cities → rejected.
- Paid FEATURED + multiple cities → allowed (unlimited).
- Expired paid entitlement → collapsed to FREE → rejected.
- Non-array `serviceCities` not counted.
- Creation boundary enforces the limit before persistence (`assertServiceCityLimit(data.serviceCities, null)` + `ServiceCityLimitError`).
- Route maps the error to 403 `SUBSCRIPTION_LIMIT`.
- Alternate self-registration (`register/broker` / `BrokerRegistrationInput`) cannot accept `serviceCities`.
- Admin creation remains admin-gated.
- PATCH/update paths retain the entitlement helper (regression guard; existing `phase-18` H5 tests also cover PATCH behavior).

## 8. Validation

| Check | Result |
|---|---|
| `yarn prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS (0 errors) |
| Focused H5 creation suite (`phase-19`) | 11/11 pass |
| Combined regression suites (C1–C3, H1–H7, H5-create, advertisement, auth, form, subscription, media) | **148 tests → 134 pass / 0 fail / 14 skipped** |
| ESLint on changed files | 0 errors |
| `npx next build` | PASS |
| Live HTTP (`POST /api/brokers` FREE+1 / FREE+2 / FEATURED) | NOT EXECUTED — no running server + DB in this environment (stated explicitly). Unit tests exercise the canonical creation logic. |
| Stripe E2E / browser automation | UNAVAILABLE |

Skipped (14): live-HTTP auth/media cases in `phase-15.7` gated on `ADMIN_ADS_BASE_URL`; infra gap, not a defect.

## 9. Secondary Findings Reviewed

| Finding | Current State | Classification | Production Impact |
|---|---|---|---|
| Login rate limiting | Active `LoginWithCredential` unthrottled; limiter wired only in dead `loginCheckUser` | B — SHOULD FIX | Brute-force/abuse risk (bcrypt mitigates); no auth bypass |
| Forgot-password rate limiting | `forgotPasswordRateLimit` defined but unused | B — SHOULD FIX | Email bombing / spam |
| Resend-verification rate limiting | No limiter on route | B — SHOULD FIX | Email bombing |
| Email-change re-verification | `PATCH /api/user/profile` updates email after duplicate check only | B — SHOULD FIX | Account email rotation without proof (authenticated only); low takeover |
| STRIPE_STANDARD_PRICE_ID presence | `.env` sets it; `lib/stripe.ts:8` falls back to the same configured price | C — acceptable/config risk | A deployment missing the env still charges the intended (configured) price; correct billing preserved |
| Missing feature routes | Admin media bulk `move`/`restore`, broker `me/upload`, broker `[id]/banks`, `subscription/verify`, `subscription/sync`, `reviews/my`, dead `/guides/*` links | B (active-UI) / C (dead/legacy) | Broken admin/broker UI actions and dead links; availability/UX, not security |
| Live HTTP / Stripe E2E infrastructure | Not present | F — INFRASTRUCTURE/TESTING GAP | Verification gap only |

None of the secondary items creates an authentication bypass, account takeover, financial loss, subscription-state corruption, credential leak, or data exposure in a correctly-configured deployment; they are abuse/UX/availability hardening items.

## 10. Remaining Limitations

- Live HTTP verification of `POST /api/brokers` (FREE+1 allowed, FREE+2 rejected) was not executed (no server + DB fixture); covered by unit tests on the canonical `assertServiceCityLimit` logic plus source-level guards.
- Admin broker creation is admin-trusted and not limited by the FREE allowance (internal path; not a user bypass). If product later wants admin-created FREE brokers capped, it can reuse `assertServiceCityLimit`.
- The secondary hardening items (login/forgot-password/resend rate limits, email-change re-verification, missing feature routes, price-ID fail-closed) remain scheduled work — this phase reviewed and classified them only.

## 11. Production Blocker Status

- H5 creation-path bypass: **FIXED**
- Other production blockers discovered in this phase: **NONE** (secondary items are MEDIUM hardening, not blockers)

---

Explicit state:
- Production files changed: **YES** (`lib/broker-policy.ts`, `lib/broker-registration.ts`, `app/api/brokers/route.ts`)
- Prisma/schema changed: **NO**
- Migrations changed: **NO**
- Tests changed: **YES** (`tests/phase-19-h5-creation-limit.test.ts` added)
- Documentation changed: **YES** (this document)

H5 creation-path bypass: **FIXED**

Other production blockers discovered: **NO**

Final recommendation: **READY FOR NEXT AUDIT**
