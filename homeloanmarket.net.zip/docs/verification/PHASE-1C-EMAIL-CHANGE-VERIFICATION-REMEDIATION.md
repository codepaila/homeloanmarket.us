# PHASE 1C — EMAIL-CHANGE VERIFICATION REMEDIATION

## 1. Finding

`FINAL-PRODUCTION-READINESS-AUDIT-V2.md` documented a MEDIUM functional finding: `app/api/auth/verify-email/route.ts:72` gated the email-change verification branch on `user.emailVerified && ...`. For an authenticated user whose current email was **not** yet verified:

1. `PATCH /api/user/profile` correctly created the email-change token and emailed the new address.
2. Clicking the verification link hit the route; because `user.emailVerified === false`, the email-change branch was skipped.
3. The request fell through to the signup-verification branch: the account could become verified, but the requested email change was **not** applied.

## 2. Root Cause

The route discriminated "email change" from "signup verification" using the user's **current `emailVerified` state** rather than the token's authoritative purpose. The email-change token is stored in the same `emailVerificationToken` field as the signup token, and the new target email is carried in the verification URL — so the correct discriminator is "the stored token plus a target email that differs from the current email," not the user's verification status.

## 3. Canonical Source

- Token purpose/binding: the stored `emailVerificationToken` (SHA-256 hash) is bound to the user via `prisma.user.findFirst({ where: { emailVerificationToken: hashedToken } })`; the route updates only `where: { id: user.id }`.
- Target email: carried in the verification URL (`?email=<new>`, echoed by `app/(public)/auth/verify-email/page.tsx` as `JSON.stringify({ token, email })`).
- Send helper: `sendEmailChangeVerificationEmail` (`actions/email.action.ts`) mints the 256-bit token, stores the hash + 1h expiry, and emails the new address.
- No separate token-type/purpose column exists; the token + differing target email is the authoritative signal.

## 4. Minimal Fix

`app/api/auth/verify-email/route.ts`:

- Branch condition changed from `user.emailVerified && requestedEmail && requestedEmail !== (user.email || '').toLowerCase()` to `requestedEmail && requestedEmail !== (user.email || '').toLowerCase()` — the email-change branch is now recognized by the token and a differing target email, independent of the user's current `emailVerified` state.
- The email-change update now also sets `emailVerified: true` (the token proves control of the new address; a no-op for already-verified users). This keeps the verification contract consistent for previously-unverified users.
- Comment updated to document the canonical discriminator.

No schema, migration, token architecture, signup-verification semantics, authorization, or unrelated code changed.

## 5. Security Preservation

The following checks remain enforced and were not weakened:

- Token lookup by SHA-256 hash (no forged tokens).
- Expiry check before either branch (expired tokens rejected and cleared).
- Single-use semantics (token cleared on use).
- User binding (update scoped to `where: { id: user.id }`; a token cannot change another user's email).
- Collision check (`email: requestedEmail, id: { not: user.id }` → 409).
- Target email format validation (400 on invalid).
- Generic invalid/expired responses (no account-existence or operation-type leakage).
- No raw token logging.
- Signup verification path unchanged: when no differing target email is present, the existing branch sets `emailVerified: true`, clears the token, and preserves the broker-welcome + claim-redirect behavior.
- Changing email still requires possession of the verification token that was emailed to the new address (the same trust boundary as before); removing the `emailVerified` gate does not enable arbitrary/unauthorized changes.

## 6. Regression Tests

Extended `tests/phase-20-auth-hardening.test.ts` (email-change block). New/updated tests (all passing):

1. `verify-email applies the change regardless of current emailVerified state` — asserts the branch is no longer gated on `emailVerified`, recognized by token + differing email, applies the new email, checks collisions, sets `emailVerified: true`, and clears the token.
2. `expired / invalid / used tokens still rejected` — expiry precedes both branches; invalid/expired responses preserved.
3. `signup verification path remains unchanged` — signup branch still flips `emailVerified`, preserves broker-welcome and claim-redirect flow.
4. `the change is scoped to the token-bound user only` — update scoped by `id: user.id`; token matched by stored hash.

Existing email-change tests (PATCH never mutates `User.email`, send helper hashes/expires/emails new address without logging, verify page sends the target email, no client-controlled `emailVerified`) remain and pass.

Full phase-20 count: **20 tests, 20 pass / 0 fail.**

## 7. Validation

| Check | Result |
|---|---|
| `yarn prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS (0 errors) |
| ESLint (changed files: verify-email route, phase-20 tests) | 0 errors |
| Targeted auth/email-verification suite (`phase-20`) | 20/20 pass |
| Combined regression suites (C1–C3, H1–H7, Phase 1A, Phase 1B, advertisement, auth, form, subscription, media) | **168 tests → 154 pass / 0 fail / 14 skipped** |
| `npx next build` | PASS |

## 8. Limitations

- Live HTTP verification of the email-change flow (verified/unverified users) was not executed — no running server + DB + email fixture in this environment. Behavior is covered by source-level regression guards on the canonical branch logic and the existing token/security properties.
- Browser automation and Stripe E2E are unavailable.
- The new target email remains URL-carried (no stored pending-email column; no schema change), so possession of the verification link authorizes setting that address — the same trust boundary as email verification generally (unchanged, documented in Phase 1B).

## 9. Regression Audit

Confirmed intact (verified by the passing regression suites and targeted source greps):

- C1 session identity: no client `session.user` merge.
- C2 public broker contact: slug resolution + guarded identifiers.
- C3 private user data: no `accounts`/`contactMessages` in `getCurrentUser`.
- H1 contact paywall: `includeContact` DTO on all public broker endpoints.
- H2 broker/company allowlists: `pickBrokerEditableFields`.
- H3 password recovery: `/auth/reset-password`, hashed/expiring/single-use token, no logging.
- H4 verification enum: no `'PENDING'`/`verificationDocuments` writes.
- H5 service-city limits incl. creation path: `assertServiceCityLimit(data.serviceCities, null)`.
- H6 Stripe webhook ordering: `withWebhookSubscriptionLock` + ordering guard.
- H7 claim recipient binding: `isClaimRecipientMatch`.
- Phase 1A H5 creation-path limit: intact.
- Phase 1B login / forgot-password / resend-verification rate limits: intact.
- Phase 1B email-change collision protection: intact.

## 10. Final Status

**EMAIL-CHANGE UNVERIFIED-USER BUG: FIXED**

---

Production files changed: **YES** — `app/api/auth/verify-email/route.ts` (branch condition + `emailVerified: true` in the change update + comment)
Prisma/schema changed: **NO**
Migrations changed: **NO**
Tests changed: **YES** — `tests/phase-20-auth-hardening.test.ts` (email-change block updated/added)
Documentation changed: **YES** — `PHASE-1C-EMAIL-CHANGE-VERIFICATION-REMEDIATION.md` (this file); `FINAL-PRODUCTION-READINESS-AUDIT-V2.md` untouched
