# Public Advertisement System Verification

## Implemented

- One canonical public `AdvertisementRenderer`/`PublicAdvertisement` path.
- Existing placement enum mapped to placement-specific bounded slots.
- Explicit responsive slot heights for wide, inline, sidebar, footer, announcement, popup, and mobile placements.
- Embla carousel for multiple eligible ads with autoplay, controls, dots, touch support, hover/focus pause, hidden-tab pause, and reduced-motion behavior.
- Single ads render without carousel controls.
- Public delivery remains anonymous and uses existing active/archive/schedule/device rules.
- Existing impression and click tracking remain connected to visible ad cards.
- Broken image sources collapse to a contained neutral card instead of creating oversized layout space.
- Public pages use the shared renderer; duplicate broker/mobile header placements were removed.
- `AdvertisementWrapper` calls its tracking hooks (`useImpressionTracker`, `useClickTracker`) unconditionally before its null guard, satisfying the React Rules of Hooks. Previously the hooks ran only after an early `return null`, which would throw "Rendered more hooks than during the previous render" if a mounted wrapper ever transitioned from an invalid to a valid ad. Behavior for valid ads is unchanged; invalid ads still render nothing and produce no impression.

## Admin Form UI Refinement

The admin create/edit form (`components/admin/ads/AdvertisementForm.tsx`) was refined without changing any business rule, API contract, or canonical height:

- **Placement picker** (`components/admin/ads/PlacementPicker.tsx`): the placement dropdown is now a premium card grid grouped by category. Each card reads its label, description, page, responsive display heights (mobile/tablet/desktop), and supported formats from the canonical sources (`placementPreviews.ts`, `placementSpecs.ts`, `formats.ts`). No height is hardcoded or editable.
- **Form hierarchy**: Basic Info now groups Title/Description plus Status (enabled/archived/dismissible) and Schedule (start/end). The Display tab groups Priority & Order and Device Targeting. Existing fields and their API contract are unchanged (fields were moved between tabs only).
- **Creative Requirements** (Media tab): reorganized into a Responsive Display Height summary (Desktop/Tablet/Mobile tiles + "Maximum Displayed Height" note), a per-format creative size table, and placement "appears on" context — all values from canonical getters.
- **MediaSelector** (`components/admin/media/MediaSelector.tsx`): selected assets now show dimensions, file size, and file type, plus a three-state compatibility indicator (✓ Compatible / ⚠ Needs attention / ✕ Not compatible) mirroring the server's ±25% `validateCreativeDimensions` rule. Device upload and asset picker still resolve to the same `MediaAsset` contract.
- **Live preview**: mirrors production rendering (same `getAdvertisementLayout` slot height, `object-contain`, `overflow-hidden`) and now overlays title/description/button like the production `AdvertisementCard`.
- No admin-configurable height field, no database height field, and no dynamic Tailwind height classes were introduced. Public rendering, tracking, media validation, and authentication are unchanged.

## Placement Mount Status

Each placement is mounted exactly once per public page surface. The `FOOTER` placement is owned by the `Footer` component (`components/layout/Footer.tsx`, above the copyright bar) and is no longer double-mounted by the public layout. One mount means exactly one rendered slot and exactly one impression opportunity per page.

The following placements are configured in the canonical placement specifications but are intentionally **not mounted** in any public page (configured-but-unused):

- `HOMEPAGE_SEARCH` — documented "below search bar"; no current page mounts it.
- `HOMEPAGE_SERVICES` — documented "services section"; no current page mounts it.
- `HOMEPAGE_BANKS` — documented "bank partners section"; no current page mounts it.
- `BROKER_LISTING_SIDEBAR` — documented "right sidebar of broker listing"; the broker listing page has no dedicated sidebar container, so mounting would require a page layout change that is out of scope.

These placements remain selectable in the admin form and fully renderable if a page later mounts them; no ad eligibility, rotation, or dimension rules change.

## Verified

- `yarn prisma validate`
- `yarn prisma generate`
- `yarn tsc --noEmit`
- `yarn build`
- Targeted advertisement, format, broker, review, and form-context tests.
- Anonymous HTTP `200` for home, brokers, broker profile, blog, article, FAQ, about, contact, public ads, and public reviews.
- Admin advertisement routes remain protected.
- Seeded format and carousel data remains deterministic and idempotent.

## Placement Rules

Slot dimensions are centralized in `components/advertisements/ad-layout.ts`. No public advertisement is allowed to size itself from its natural image dimensions. Images are contained within the configured slot and use the existing media/resolution fallback strategy.

The canonical responsive height contract lives in `lib/advertisements/placementSpecs.ts` (`FULL_WIDTH_BANNER_DISPLAY` / each placement `display` triple) and is turned into a single slot-height class by `ad-layout.ts` — the one component responsible for the slot height. No renderer, page wrapper, or global CSS sets a competing banner height.

### Canonical top / full-width announcement banner contract

The full-width top banner is a compact premium strip, never a tall hero:

| Device | Maximum displayed height |
|---|---|
| Desktop | 150px |
| Tablet | approximately 120px |
| Mobile | approximately 90px |

- mobile < tablet < desktop is always maintained.
- The strip stays full width (`mx-auto w-full max-w-[1280px]`) with `overflow-hidden`.
- Creatives are letterboxed with `object-contain` — never cropped or distorted.
- The slot classes (`h-[90px] sm:h-[120px] lg:h-[150px]`) are emitted as complete literal class names in `ad-layout.ts` so Tailwind v4's content scanner compiles them. Template-interpolated class names are never generated because Tailwind cannot detect them, which previously left the banner at its natural (200px+) image height on desktop.

### Verified

- `yarn prisma validate`
- `npx tsc --noEmit`
- `npx next build` (compiled CSS confirmed to contain `.h-[90px]{height:90px}`, `.sm:h-[120px]{height:120px}`, `.lg:h-[150px]{height:150px}`)
- `npx eslint` on the advertisement components (0 errors; the `AdvertisementWrapper` Rules-of-Hooks violation is fixed)
- Advertisement unit/render suites: `tests/phase-15.6-top-banner-height.test.tsx`, `tests/phase-15.8-placement-integration.test.tsx`, `tests/phase-15.9-admin-form-ui.test.tsx`, `tests/phase-15-placement-size-contract.test.ts`, `tests/phase-14-public-ad-ui.test.tsx`, `tests/phase-15-advertisement-formats.test.ts`, `tests/phase-15.5-advertisement-safety.test.tsx`, `tests/advertisement-management.test.ts`, `tests/phase-15.7-admin-ad-auth-media.test.ts`, `tests/phase-13.11-form-context.test.tsx` — 81 pass / 0 fail / 14 skipped (skipped = live-server HTTP cases)
- Placement integration suite (`tests/phase-15.8-placement-integration.test.tsx`) proves FOOTER is mounted exactly once, layout-chain placements are never double-mounted, the four configured-but-unused placements stay unmounted, canonical announcement/footer/full-width heights remain 50/60/70, 60/70/80, and 90/120/150 respectively, no admin-configurable height field exists, and `AdvertisementWrapper` calls its hooks before its null guard.
- Admin UI suite (`tests/phase-15.9-admin-form-ui.test.tsx`) proves the placement picker renders canonical heights/formats with no editable height input, and `MediaSelector` renders asset details (dimensions, size, type) with ✓/⚠/✕ compatibility states.
- Server-render smoke of `PublicAdvertisement` for `HOMEPAGE_HERO` confirms the bounded slot classes and `overflow-hidden` appear in the rendered markup with no stale 200px rule.

## Limitations

- Browser pixel/viewport automation is not configured in this repository; responsive behavior is covered by centralized slot classes, render tests, build checks, and HTTP verification.
- Full repository lint and regression suites retain pre-existing unrelated failures in legacy ownership/integration code.
- Public targeting remains placement-based; no separate arbitrary URL targeting model was introduced.
