# FINAL PRODUCTION READINESS AUDIT V7

Audit date: 2026-08-10  
Repository: HomeLoanMarket US  
Mode: READ-ONLY / AUDIT-ONLY

## 1. Executive Verdict

**NO-GO**

Phase 1G fixes are present for the exact paths they changed: authenticated Stripe customer creation, required-IP alternate helper throttling, explicit User scalar selection, null reset-expiry rejection, and alternate checkout idempotency.

The independent V7 audit found remaining production blockers/variants:

- Both claim pages call `signIn('credentials', ...)` directly, bypassing `LoginWithCredential` and its intended IP limiter.
- The alternate `createStripeCustomer` action authenticates but does not persist a newly created customer ID; the primary checkout path can also race when creating a customer, leaving duplicate/orphan Stripe customers.
- Alternate checkout idempotency is only time-bucketed and no durable logical checkout attempt prevents a later duplicate operation.
- The generic current-user scalar leak is fixed, but the admin broker page still passes a broad Broker/subscription object to a Client Component.

These are concrete authentication/payment/data-boundary findings. The decision is not based on lint debt or unavailable external infrastructure.

## 2. Validation Summary

| Check | Result | Evidence |
| ----- | ------ | -------- |
| Documentation inventory | PASS with contradictions | V1-V6 and Phase 1A-1G reports exist; current claim contract is `docs/business/33-CLAIM-CONTRACT.md`; requested `docs/CLAIM-CONTRACT.md` is absent. |
| Security/subscription/auth regression suite | PASS with skips | 109 passed, 0 failed, 2 skipped. |
| Advertisement/media suite | PASS with skips | 65 passed, 0 failed, 3 skipped. |
| Prisma validate | PASS | `yarn prisma validate`. |
| Prisma generate | PASS | `npx prisma generate`. |
| TypeScript | PASS | `npx tsc --noEmit`. |
| Production build | PASS | `npx next build`; 93 static pages generated. |
| Changed Phase 1G ESLint | FAIL | Three pre-existing `no-explicit-any` errors in `actions/subscription.ts`; no new Phase 1G-specific rule failure. |
| Full lint | FAIL | Existing repository-wide lint errors/warnings. |
| Live HTTP | UNAVAILABLE | No running application/database fixture. |
| Browser automation | UNAVAILABLE | No browser runtime supplied. |
| Stripe E2E | UNAVAILABLE | No real Stripe session/payment/webhook fixture. |
| Email/Redis/OAuth E2E | UNAVAILABLE | No provider/deployment fixture. |

## 3. V6 Blocker Verification

### createStripeCustomer authorization

**Status:** PARTIAL / NEW HIGH VARIANT.

**Evidence:** `actions/subscription.ts:createStripeCustomer()` now calls `getCurrentUser()`, rejects missing authenticated email, derives customer email/name/metadata from the trusted user, and retrieves an existing stored customer when available. Client identity arguments were removed.

The action does not persist the newly created Stripe customer ID. Repeated calls can create orphan customers. `app/api/subscription/checkout/route.ts:42-66` independently creates customers when no local ID exists and can race under concurrent requests before the database upsert. No durable customer-creation idempotency or atomic claim was found.

**Affected workflow:** Stripe customer creation and all checkout paths.

**Regression test:** Phase 1G authorization test passes, but no concurrency/persistence test exists; live Stripe unavailable.

**Variant search result:** `actions/subscription.ts` and checkout route both call `stripe.customers.create`; the alternate action remains duplicate-prone.

### Alternate login hardening

**Status:** PARTIAL — HIGH REGRESSION/VARIANT.

**Evidence:** `loginCheckUser` now requires an IP and applies `loginRateLimit` before database/password work, with generic errors. However, `app/claim-broker/[token]/page.tsx:51-55` and `app/claim-broker/continue/page.tsx:15` directly call `signIn('credentials', ...)` from client components. These calls bypass `LoginWithCredential` and its IP limiter. Auth.js credential `authorize` in `lib/auth.config.ts:45-86` has no limiter of its own.

**Affected workflow:** Existing-account claim authentication; credential brute-force resistance.

**Regression test:** Main login/Phase 1G tests pass but do not cover direct claim-page credential sign-in. Live claim authentication unavailable.

**Variant search result:** Direct credential sign-in calls exist in both claim pages and are not routed through the canonical limited action.

### getCurrentUser safety

**Status:** PARTIAL — scalar credential leak FIXED; broad relation/admin boundary remains.

**Evidence:** `lib/currentUser.ts` now explicitly selects User scalars and excludes password, reset/verification tokens, accounts, and contactMessages. Personal/company/dashboard/owner DTO paths are explicit.

`app/admin/brokers/[id]/page.tsx:10-47` still queries `subscription: true` and passes the full `broker` object to `AdminBrokerActions`. This exposes unnecessary subscription/Stripe identifiers and internal Broker fields in an authenticated admin client payload. `getCurrentUser` also retains server-required broker/subscription relation data, so future callers must not treat its result as a universal client DTO.

**Affected workflow:** Admin broker management and future generic current-user callers.

**Regression test:** Phase 1G generic loader tests pass; no admin broker RSC serialization test exists.

**Variant search result:** Admin Broker page is an equivalent full-model-to-client boundary.

### Reset-token expiry

**Status:** FIXED / VERIFIED.

**Evidence:** `app/api/auth/reset-password/route.ts` rejects when `resetPasswordTokenExpiry` is null or not in the future, clears token/expiry, and preserves SHA-256 storage, bcrypt update, single-use invalidation, and generic errors.

**Affected workflow:** Password recovery.

**Regression test:** Phase 1G/Phase 1B-H3 tests pass; live reset/email unavailable.

**Variant search result:** No alternate reset endpoint accepting null expiry was found.

### Alternate checkout idempotency

**Status:** PARTIAL — primary protection present, durable/complete protection absent.

**Evidence:** Primary `/api/subscription/checkout` and `actions/subscription.ts:createCheckoutSession` now use server-derived keys scoped by user/customer/plan/price/time bucket. Authentication and plan-price validation remain present.

The keys change every ten minutes and no persistent checkout-attempt key exists. Customer creation can race before session creation. Upgrade mutation has no Stripe idempotency key. Therefore duplicate financial operations are reduced but not fully controlled.

**Affected workflow:** Checkout, upgrade, Stripe customer/subscription creation.

**Regression test:** Phase 1G idempotency tests pass; concurrency and real Stripe retries unavailable.

**Variant search result:** Both checkout creation paths were found; upgrade is a separate Stripe mutation without idempotency.

## 4. C1–C3 Status

### C1 — Session Integrity

**Status:** FIXED / VERIFIED.

**Evidence:** `lib/auth.config.ts` does not merge client session claims; JWT identity is refreshed from trusted Prisma state. No role/email/userId request merge was found.

**Affected workflow:** Login/session refresh/claims.

**Regression test:** Phase 16 C1 tests pass.

### C2 — Public Contact

**Status:** FIXED / VERIFIED.

**Evidence:** `/api/contacts/send` resolves canonical broker slug, validates identifiers/public eligibility, and stores lead against resolved Broker. Anonymous access remains intentional.

**Affected workflow:** Public broker contact.

**Regression test:** Phase 16 C2 tests pass; live HTTP unavailable.

### C3 — Private Boundaries

**Status:** PARTIAL — NEW admin variant.

**Evidence:** Personal, company-edit, company display, and dashboard DTOs are explicit. Generic User credential/token scalars are excluded. The admin broker page still passes a full Broker with subscription relation to Client code.

**Affected workflow:** Admin broker detail management.

**Regression test:** C3/Phase 1G tests pass but do not cover admin broker RSC serialization.

## 5. H1–H7 Status

| Finding | Status | Evidence | Affected workflow | Regression test |
| ------- | ------ | -------- | ---------------- | --------------- |
| H1 contact paywall | FIXED / VERIFIED | Public DTO and route entitlement/owner/admin gates. | Public broker data | Phase 17, pass |
| H2 mass assignment | FIXED on canonical routes | Ownership checks and field allowlists; `/api/brokers/me` remains a separate manual path. | Broker mutations | Phase 17/18, pass |
| H3 password recovery | FIXED for null expiry, residual controls | Token hash/expiry/single-use/bcrypt present; completion remains unthrottled. | Password reset | H3 tests pass |
| H4 verification state | FIXED / VERIFIED | No invalid enum/field writes. | Admin verification | Phase 18, pass |
| H5 service-city limit | FIXED / VERIFIED | FREE creation/update limit and paid entitlement helper. | Broker service areas | Phase 18/19, pass |
| H6 webhook ordering | FIXED with residual race risk | Signature, event ID, stale guard, PROCESSING state, Redis lock/fallback. | Stripe lifecycle | H6/webhook tests pass |
| H7 claim binding | FIXED at invitation/session/completion | Recipient match, expiry, revocation, used state, reauth, transactional attach. | Claim ownership | H7 tests pass |

## 6. Phase 1A–1F Regression Status

| Phase | Status | Evidence |
| ----- | ------ | -------- |
| Phase 1A H5 creation path | VERIFIED | `assertServiceCityLimit` and Phase 19 tests pass. |
| Phase 1B auth hardening | PARTIAL | Main login/forgot/resend paths pass; claim-page direct credential sign-in bypasses main limiter. |
| Phase 1C email change | VERIFIED | Target-bound token digest and verified/unverified tests pass. |
| Phase 1D C3/public checkout | VERIFIED on audited paths | Personal DTO and pricing `{priceId, plan}` contract tests pass. |
| Phase 1E verify/owner DTO | PARTIAL | Verification route and owner DTO pass; admin Broker full-model client boundary remains. |
| Phase 1F company/upgrade/idempotency/email binding | PARTIAL | Targeted fixes pass; customer persistence/race, claim login bypass, and upgrade idempotency remain. |

## 7. Equivalent / Variant Findings

| Finding | File/Path | Severity | Impact | Classification |
| ------- | --------- | -------- | ------ | -------------- |
| Direct credential sign-in bypasses canonical limiter | `app/claim-broker/[token]/page.tsx:51-55`, `app/claim-broker/continue/page.tsx:15` | HIGH | Claim authentication attempts are not subject to intended IP throttling | A. MUST FIX BEFORE PRODUCTION; auth variant |
| Stripe customer creation is not persisted/idempotent in alternate action | `actions/subscription.ts:16-31` | HIGH | Orphan/duplicate Stripe customers and broken ownership association | A. MUST FIX BEFORE PRODUCTION; payment variant |
| Primary checkout customer creation races | `app/api/subscription/checkout/route.ts:42-66` | HIGH conditional | Concurrent requests can attach sessions to different customers | B. SHOULD FIX BEFORE PRODUCTION |
| Alternate checkout idempotency is only time-bucketed | `actions/subscription.ts:71`, checkout route | MEDIUM | New sessions can be created after bucket changes | B. SHOULD FIX BEFORE PRODUCTION |
| Full admin Broker/subscription object reaches client | `app/admin/brokers/[id]/page.tsx:10-47` | MEDIUM | Unnecessary Stripe/private fields in admin browser payload | B. SHOULD FIX BEFORE PRODUCTION |
| Upgrade Stripe mutation has no idempotency | `app/api/subscription/upgrade/route.ts:56-70` | MEDIUM | Retry/proration duplication risk | B. SHOULD FIX BEFORE PRODUCTION |
| Reset completion has no endpoint throttle/password policy | `app/api/auth/reset-password/route.ts` | MEDIUM | Resource abuse and weak password acceptance | B. SHOULD FIX BEFORE PRODUCTION |
| Cancellation can diverge from Stripe after provider failure | `lib/subscription.ts:255-269` | MEDIUM | Local entitlement state may not match provider | B. SHOULD FIX BEFORE PRODUCTION |
| Media lifecycle/move/restore and ad update validation gaps | Media routes/repository/services | MEDIUM | Admin operations fail and invalid creatives can persist | B. SHOULD FIX BEFORE PRODUCTION |

## 8. Medium Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Admin broker DTO breadth | Present | MEDIUM | Internal subscription identifiers reach authenticated admin browser | B | Use explicit admin DTO |
| Upgrade idempotency | Missing | MEDIUM | Repeated Stripe update/proration operations | B | Add server-derived idempotency |
| Cancellation semantics | Divergence possible | MEDIUM | Local/provider state mismatch after failure | B | Reconcile from Stripe state |
| Password reset completion controls | Missing | MEDIUM | Unlimited token attempts/bcrypt work and no server policy | B | Add endpoint limiter/policy |
| Webhook Redis fail-open | Present | MEDIUM | Concurrent processing can race during lock failure | C/F | Confirm deployment risk acceptance or strengthen lock policy |
| `/api/subscription/sync` client call | Route absent | MEDIUM | Manual sync action returns 404 | B | Remove or implement canonical path |
| Broker `/me` duplicate validation path | Present | MEDIUM | Future allowlist/validation drift | C | Consolidate when product scope permits |
| Ad tracking abuse controls | Missing | MEDIUM | Analytics/event volume poisoning | B | Add server-side validation/rate controls |
| Media deleted-file delivery/storage | Present | MEDIUM | Deleted assets remain public; ephemeral storage risk | B/F | Add lifecycle/storage policy |

## 9. Low / Informational Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Full-tree lint debt | Existing | LOW | No direct runtime defect established | F | Reduce incrementally |
| Email idempotency process-local | Existing | LOW/MEDIUM | Restart/multi-instance duplicate/suppression behavior | C/F | Durable provider idempotency if needed |
| Equal-second Stripe event timestamps | Existing | LOW | Rare ordering tie ambiguity | C | Add tie-breaker if required |
| Unmounted ad inventory | Documented/tested intentional | INFO | Ads assigned there do not render | C | Keep inventory explicit |
| Review write path absent | Existing | LOW/MEDIUM | FAQ/product expectation mismatch | C | Product decision |
| US versus India/Nepal currency/content drift | Existing | INFO | Commercial confusion | C | Reconcile product copy/config |
| Browser/live provider E2E | Unavailable | INFO | External runtime behavior unverified | F | Establish staging CI |

## 10. Regression Findings

1. Phase 1G’s direct fixes pass focused and combined tests.
2. Phase 1G did not address direct credential sign-in calls in claim pages; this is a pre-existing alternate-path variant of the login-rate-limit finding.
3. Phase 1G did not persist newly created Stripe customer IDs in the alternate server action; duplicate/orphan customer risk remains.
4. No regression was found in C1, C2, H1, H2, H4, H5, H6, or H7 tests.
5. Advertisement/media tests pass; lifecycle/tracking/storage findings remain operational gaps.

## 11. Security Boundary Verification

### Authentication

Primary credential login is rate-limited and generic. Claim pages directly call Auth.js credentials sign-in and bypass the canonical limiter. Google OAuth remains separate.

### Authorization

Admin and broker handlers generally enforce role/ownership. Alternate Stripe customer creation now authenticates but does not persist/claim the resulting customer safely.

### Ownership

Broker contact and claims are scoped correctly. Primary checkout verification binds customer/metadata. Customer-creation races can break association integrity.

### Sessions

C1 identity claims remain server-derived; no session-user merge found.

### PII

Generic User credentials/token scalars are excluded. Public/owner DTOs are explicit. Admin Broker page remains broad.

### Tokens

Reset null expiry is fixed. Email-change target binding is fixed for new tokens. Raw tokens were not found in logs. Existing pre-binding email-change tokens require expiry/reissue handling.

### Claims

RecipientEmail checks, invitation lifecycle, reauth, token hashing, expiry, revocation, used state, and transactional ownership attach remain.

### Payments

Primary checkout/verify paths validate Stripe state and price. Alternate customer creation and claim-page auth/payment-adjacent paths remain production risks.

### Subscriptions

Upgrade syncs Stripe state; cancellation and retry/idempotency semantics remain incomplete. Webhook remains signed/idempotent/stale-guarded but lock fallback is best-effort.

### Admin

Admin APIs role-check server-side. Admin broker client DTO is broader than required.

## 12. Business Workflow Verification

### Broker signup

`/api/auth/register/broker` and `/api/brokers` create FREE broker state transactionally. Focused tests pass; live activation unavailable.

### Broker profile

Personal/company edit DTOs are explicit. Admin broker detail remains a broad client boundary. Mutation ownership/allowlists pass tests.

### Contact / lead generation

Public form -> slug-resolved contact API -> ContactMessage/broker counter/notifications. Anonymous route is intentional; live HTTP unavailable.

### Authentication

Primary login is rate-limited; claim-page direct credential sign-ins bypass it.

### Password recovery

Forgot -> hashed token email -> reset endpoint -> bcrypt/clear token. Null expiry is rejected; completion throttling remains absent.

### Email verification

Signup raw-token verification and target-bound email-change verification pass source tests. Live email unavailable.

### Email change

Profile PATCH sends target challenge without mutating current email; verification validates collision/expiry/single-use and applies email. New token target binding is present.

### Subscription

FREE/FEATURED canonical helpers exist. Upgrade reconciles Stripe; cancellation can diverge after provider error. Alternate customer/checkout paths remain.

### Checkout

Primary/alternate checkout validates plan/price and uses idempotency keys. Primary customer creation can race; alternate customer creation does not persist new ID.

### Stripe webhook

Signature, event ID, event statuses, stale checks, and lifecycle handling exist. Redis lock failure and real provider delivery are unverified.

### Claim

Invitation -> recipient session -> reauth/verification -> transactional completion is source-verified. Claim login limiter bypass is a remaining auth issue.

### Advertisement

Admin/public CRUD and rendering pass unit tests; tracking/media lifecycle operational risks remain.

### Admin management

Admin ad/media/broker APIs role-check server-side; admin broker RSC DTO breadth remains.

### Media

Upload validation/Sharp/path controls pass tests; restore/move, deletion revocation, durable storage, and metadata validation remain.

### Reviews

Published review reads exist; public review write path is absent.

## 13. Advertisement Verification

### Admin CRUD

ADMIN checks and lifecycle routes exist; update attribution and some lifecycle controls remain incomplete.

### Media

Picker/upload/MIME/size/Sharp validation pass. Restore/move routes are missing; deleted files remain publicly retrievable and local storage durability is deployment-dependent.

### Placement

Placement/date/device filters and intentional unused inventory are tested. Duplicate mount tests pass.

### Format

Horizontal/vertical/square/rectangle/mobile contracts and creative dimension tests pass; direct fallback update validation remains incomplete.

### Carousel

Single/multiple ad rendering and reduced motion tests pass.

### Responsive layout

Bounded literal slot heights pass; no stale 200px rule or natural image overflow was found.

### Tracking

Impressions have limited deduplication; clicks lack server-side rate limiting/deduplication.

### Anonymous delivery

Public ad route and lifecycle filters do not require auth; live HTTP unavailable.

### Lifecycle

Enabled/archive/delete/schedule filters exist; media recovery and storage cleanup remain gaps.

## 14. Test Evidence

### passed

- `yarn prisma validate`.
- `npx prisma generate`.
- `npx tsc --noEmit`.
- Combined security/auth/subscription/broker/claim/Phase 1A-1G suite: **109 passed**.
- Advertisement/media suite: **65 passed**.
- `npx next build`.

### failed

- `yarn lint`: full repository lint failure.

### skipped

- Combined security suite: **2 skipped**, environment-gated registration/broker checks; live route behavior remains unverified.
- Advertisement/media suite: **3 skipped**, live public/admin/media checks requiring runtime/base URL; live delivery remains unverified.

### unavailable

- Live HTTP.
- Browser automation.
- Stripe E2E/provider delivery.
- Email E2E.
- Redis failure/concurrency E2E.
- Staging/production deployment validation.

## 15. Build / Type / Lint

- `yarn prisma validate`: **PASS**.
- `npx prisma generate`: **PASS**.
- `npx tsc --noEmit`: **PASS**.
- `npx next build`: **PASS**, 93 static pages generated.
- Changed Phase 1G ESLint: **FAIL**, three pre-existing `no-explicit-any` errors in `actions/subscription.ts`.
- Full `yarn lint`: **FAIL**, existing repository errors/warnings.

## 16. Infrastructure Limitations

### Application defects

Claim-page credential rate-limit bypass, Stripe customer association/race, alternate checkout durability, admin DTO breadth, reset completion controls, cancellation divergence, and media/ad operational findings are application risks.

### Test infrastructure

No package test script exists; direct `node --import tsx --test` commands were used. Environment-gated tests require a running deployment/database.

### Browser automation

Unavailable; client/RSC boundaries were source-tested only.

### Live HTTP

Unavailable; no running application/database supplied.

### Stripe E2E

Unavailable; no real session/payment/webhook/retry/cancellation execution.

### Email E2E

Unavailable; no delivery/interception fixture.

### Redis E2E

Unavailable; no multi-instance limiter/lock failure exercise.

### Staging/production availability

Unavailable; proxy, secret management, durable storage, provider settings, and deployment topology were not verified.

## 17. Remaining Production Risks

1. Claim-page credential sign-in bypasses the intended login limiter.
2. Alternate Stripe customer creation does not persist new IDs or prevent duplicates; primary creation can race.
3. Alternate checkout idempotency is time-bucketed rather than durable and upgrade lacks idempotency.
4. Admin broker page exposes a broad Broker/subscription object to a Client Component.
5. Reset completion throttling/password policy and webhook lock fail-open behavior remain.
6. Advertisement/media lifecycle, click controls, URL validation, and storage durability remain incomplete.

## 18. Required Before Production

1. Route claim-page credential authentication through the canonical rate-limited/generic login boundary or enforce equivalent controls in Auth.js authorization.
2. Persist and safely associate newly created Stripe customers, close the customer-creation race, and ensure all customer-creation paths are idempotent and authorized.
3. Complete durable checkout/upgrade idempotency and verify duplicate requests cannot create duplicate payment operations.
4. Replace the admin broker full-model client payload with an explicit DTO.

## 19. Recommended After Production

1. Add reset completion throttling and server-side password policy.
2. Reconcile cancellation semantics, trial status semantics, webhook lock failure policy, and missing subscription sync route.
3. Add media recovery/cleanup/durable storage and ad click-abuse controls.
4. Reconcile stale business/advertisement/currency documentation and review-write product scope.
5. Establish live HTTP/browser/Stripe/email/OAuth/Redis staging tests and reduce lint debt.

## 20. Final GO/NO-GO Reasoning

The Phase 1G targeted fixes are present and the current combined regression suite reports 109 passed tests with only two environment-gated skips. Prisma validation, TypeScript, build, and advertisement/media unit suites pass. The V6 headline implementation paths are substantially improved.

V7 independently found that the canonical login limiter is not the only credential path: both claim pages call `signIn('credentials')` directly. It also found that the alternate Stripe customer action does not persist a newly created customer, while the primary route can race customer creation. These are concrete authentication and payment ownership/integrity risks. The admin Broker full-model client payload is an additional C3 boundary variant.

The final decision is **NO-GO**. This decision is based on the direct credential-limiter bypass and Stripe customer association/idempotency risks, not on ordinary lint debt or unavailable external infrastructure.

Production files changed: **NO**  
Prisma/schema changed: **NO**  
Migrations changed: **NO**  
Tests changed: **NO**  
Documentation changed: **YES — only `docs/verification/FINAL-PRODUCTION-READINESS-AUDIT-V7.md`**  
Final verdict: **NO-GO**
