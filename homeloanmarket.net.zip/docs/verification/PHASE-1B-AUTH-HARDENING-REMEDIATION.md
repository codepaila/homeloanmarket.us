# PHASE 1B — AUTH HARDENING REMEDIATION

## 1. Scope

Server-side hardening of four authentication/recovery flows: (1) credential login rate limiting, (2) forgot-password rate limiting, (3) resend-verification rate limiting + enumeration fix, and (4) email-change re-verification. No Prisma schema, migration, advertisement subsystem, media, claim flow, Stripe webhook ordering, subscription policy, or C1–C3/H1–H7 behavior was modified.

## 2. Login Rate Limiting

### Previous State
The active login path `LoginWithCredential` (`actions/auth.action.ts`, bound to the sign-in form via `useActionState`) called `signIn("credentials", ...)` with no server-side throttle. The existing `brokerLoginRateLimit` (5 attempts / 10 min) was wired only into the dead `loginCheckUser` function.

### Root Cause
The limiter existed but was not invoked on the active login path.

### Implementation
`LoginWithCredential` now invokes `brokerLoginRateLimit.limit('login:${ip}')` (IP from `x-forwarded-for`/`x-real-ip` via `next/headers`) before `signIn`. On `success:false` it returns the generic throttled error; limiter/Redis errors are caught and **fail open** so a Redis outage does not cause an authentication outage. OAuth login (`AdminLogin`/`UserLogin` → `signIn(provider)`) is untouched.

### Security Behavior
Server-side throttling of repeated credential attempts; generic responses (no account-existence leak); legitimate OAuth unaffected; valid credentials work after the window (sliding 5/10 min per IP). Fail-open policy documented: rate-limit outages expose transient brute-force surface, never a login outage.

### Tests
`tests/phase-20-auth-hardening.test.ts` — login block (4 tests): active path invokes limiter keyed by IP; fail-open on limiter errors; generic error; limiter policy defined.

## 3. Forgot-Password Rate Limiting

### Previous State
`app/api/auth/forgot-password/route.ts` had no rate limit; `forgotPasswordRateLimit` (5 requests / 60 min per IP) existed but was unused.

### Root Cause
Existing limiter not wired to the route.

### Implementation
The route now calls `forgotPasswordRateLimit.limit('forgot:${ip}')` (fail-open) and returns 429 when throttled, before sending. The generic "If an account exists with this email, a password reset link has been sent." response for unknown accounts is preserved (no enumeration). Reset-token lifecycle (SHA-256 hash, 1h expiry, single-use, never logged) is unchanged (H3 preserved).

### Security Behavior
Limits email-provider abuse / reset-token churn; enumeration-resistant; password recovery not blocked during a Redis outage (fail-open).

### Tests
Forgot-password block (4 tests): route invokes limiter with 429; generic response preserved; no raw token logging; token lifecycle secure (hash/expiry/single-use).

## 4. Resend-Verification Rate Limiting

### Previous State
`app/api/auth/resend-verification/route.ts` had no rate limit and revealed verification state via `"Email is already verified"` (enumeration).

### Root Cause
No limiter; enumeration signal in the verified-account branch.

### Implementation
Added `resendVerificationRateLimit` (3 requests / 60 min per IP) to `lib/rateLimit.ts` and wired it (fail-open, 429 when throttled). The verified-account branch now returns the same generic 200 message as the unknown-account branch (no email sent to verified accounts).

### Security Behavior
Limits email abuse; removes the verification-state enumeration side channel; preserves legitimate resend for unverified users.

### Tests
Resend block (3 tests): route invokes limiter; verified accounts no longer leak state; limiter defined.

## 5. Email Change Re-Verification

### Previous State
`PATCH /api/user/profile` mutated `User.email` directly after only a duplicate check — an attacker with an authenticated session could change the account email to their own and establish persistent control.

### Root Cause
Email change was persisted without verification of the new address.

### Implementation (no schema change)
- **Initiate** (`app/api/user/profile`): when the authenticated user submits a new email, the route validates format, checks it is not taken, sends a verification link to the **new** address (`sendEmailChangeVerificationEmail`), and returns `emailChangePending: true`. `User.email` is **not** mutated; the old email stays authoritative.
- **Send** (`actions/email.action.ts`): `sendEmailChangeVerificationEmail` generates a 256-bit token, stores the SHA-256 hash + 1h expiry (reusing the existing `emailVerificationToken` fields), and emails the new address with `{appUrl}/auth/verify-email?token=…&email=<new>`. Raw token never logged.
- **Verify** (`app/api/auth/verify-email`): finds the user by the hashed token; for an **already-verified** account with a differing `email` param it validates the new address, rejects taken addresses (409), atomically applies `User.email = requestedEmail`, clears the token (single-use), and returns success. The first-time signup verification path (set `emailVerified`, broker welcome, claim redirect) is preserved unchanged.
- **Page** (`app/(public)/auth/verify-email/page.tsx`): includes the URL `email` param in the verify POST so the change target is known.

### Security Behavior
Old email remains authoritative until the new one is verified; a fresh token is required; token is hashed, expires in 1h, single-use, tied to the requesting user; another user cannot claim a pending email (taken-check); client input cannot set `emailVerified` or role; session identity remains server-derived (C1 unchanged); login/password-reset continue to key on the (now-verified) email. Residual documented limitation: the new email is carried in the verification URL rather than a stored pending-email field (no schema change), so possessing the verification link for the intended address authorizes setting that address — the same trust boundary as email verification generally.

### Tests
Email-change block (7 tests): PATCH never writes `updateData.email` and signals pending; send function hashes/expires/emails new address without logging; verify route applies the email only on verification with collision check + single-use; signup path preserved; page sends target email; client cannot set `emailVerified`; C1/H3 behavior intact.

## 6. Equivalent Variant Audit

| Pattern | Result | Evidence |
|---|---|---|
| `updateData.email = body.email` in any route | CLEAN — none remain | `app/api/user/profile/route.ts` (only verification flow) |
| Client-controlled `emailVerified` write | CLEAN — only Prisma `select` reads | `user/profile` GET/PATCH selects; `verify-email` reads |
| `User.email` mutation outside email-change flow | CLEAN — only `verify-email` (verified path) applies it | grep of `prisma.user.update` across routes |
| Raw reset/verify token logging | CLEAN | no `Reset URL generated` / token logs |
| `session.user` merge (C1) | CLEAN — no equivalent | `lib/auth.config.ts` comments + output only |
| H5 creation-path service-city limit | INTACT | `assertServiceCityLimit` in `createBrokerForExistingUser` + route 403 mapping |
| H7 recipient binding | INTACT | `isClaimRecipientMatch` in completion |

## 7. Previous Security Fix Regression Check

| Finding | Result | Evidence |
|---|---|---|
| C1 trusted session identity | NONE | no client merge; no-arg refresh |
| C2 public broker contact | NONE | slug resolution + guarded identifiers |
| C3 safe client DTOs | NONE | no accounts/contactMessages in `getCurrentUser` |
| H1 contact paywall | NONE | all public endpoints use `includeContact` DTO |
| H2 broker mutation allowlists | NONE | `pickBrokerEditableFields` unchanged |
| H3 password reset | NONE | hashed/expiring/single-use; correct URL; no logging |
| H4 verification enum | NONE | no `'PENDING'`/`verificationDocuments` writes |
| H5 FREE service-city limit (incl. POST /api/brokers) | NONE | create-path limit intact (verified) |
| H6 Stripe ordering | NONE | no webhook changes |
| H7 claim recipient binding | NONE | recipient match intact |

## 8. Validation

| Check | Result |
|---|---|
| `yarn prisma validate` | PASS |
| `npx prisma generate` | PASS |
| `npx tsc --noEmit` | PASS (0 errors) |
| Focused auth-hardening suite (`phase-20`) | 17/17 pass |
| Combined regression suites (C1–C3, H1–H7, H5-create, auth-hardening, advertisement, auth, form, subscription, media) | **165 tests → 151 pass / 0 fail / 14 skipped** |
| ESLint on changed files | 0 errors (2 pre-existing warnings) |
| `npx next build` | PASS |

## 9. Skipped / Unavailable Tests

| Test | Reason | Production Impact |
|---|---|---|
| Live HTTP auth/media matrix (`phase-15.7`, 14 tests) | `ADMIN_ADS_BASE_URL` unset (no running server + DB) | None — unit/source coverage compensates for validation rules; boundaries covered by guards |
| Live HTTP of login/forgot/resend/email-change | No running server + DB + email fixture | None — logic covered by source guards and unit tests on the security properties |
| Browser automation / Stripe E2E | Not available in this environment | Verification gap only |

## 10. Remaining Risks

1. Rate-limit fail-open during a Redis outage: login/recovery proceed unthrottled transiently (chosen over an auth outage); documented.
2. Per-IP limiters can be evaded by distributed sources (CAPTCHA not added — out of scope).
3. Email-change new address is URL-carried (no pending-email column); possession of the verification link authorizes the change (email-verification trust boundary).
4. Login limiter (5/10 min per IP) may temporarily block a legitimate user who mistypes several times (documented policy).

## 11. Production Blocker Status

No new CRITICAL or HIGH issues were discovered. All four targeted hardening items are implemented, regression-tested, and validated. The prior CRITICAL/HIGH findings remain fixed with no regression.

---

Production files changed: **YES** (`lib/rateLimit.ts`, `lib/email-templates.ts`, `actions/auth.action.ts`, `actions/email.action.ts`, `app/api/auth/forgot-password/route.ts`, `app/api/auth/resend-verification/route.ts`, `app/api/user/profile/route.ts`, `app/api/auth/verify-email/route.ts`, `app/(public)/auth/verify-email/page.tsx`)
Prisma/schema changed: **NO**
Migrations changed: **NO**
Tests changed: **YES** (added `tests/phase-20-auth-hardening.test.ts`)
Documentation changed: **YES** (this document; the FINAL-PRODUCTION-READINESS-AUDIT.md was not modified)

Login rate limiting: **FIXED**
Forgot-password rate limiting: **FIXED**
Resend-verification rate limiting: **FIXED**
Email-change re-verification: **FIXED**

C1 regression: NONE · C2: NONE · C3: NONE · H1: NONE · H2: NONE · H3: NONE · H4: NONE · H5: NONE · H6: NONE · H7: NONE

New CRITICAL findings: 0 · New HIGH findings: 0 · New MEDIUM findings: 0

Final recommendation: **READY FOR NEXT INDEPENDENT AUDIT**
