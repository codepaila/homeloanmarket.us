# Implementation Plan

This is a design plan only. No phase authorizes changes during the current documentation phase.

## Phase 1: Database/schema
Design nullable ownership, creation source, ownership state, claim state, publication/account safety state, FREE entitlement defaults, audit/history, token metadata, and unique/index constraints. Backfill current owned brokers without changing IDs/slugs.

## Phase 2: Claim token infrastructure
Implement server-only random token generation, digest storage, expiry/revocation/consumption, rate limits, generic errors, and audit events for admin-created profiles only.

## Phase 3: Admin claim management
Add authorized create, resend, supersede, revoke, inspect, and assisted-resolution operations. Never expose raw tokens after email delivery.

## Phase 4: Direct broker registration
Evolve/reuse `POST /api/auth/register/broker` to validate, rate-limit, hash, transactionally create user/profile/FREE, set `SELF_REGISTERED + OWNED + NOT_REQUIRED`, and send verification. Do not create a claim.

## Phase 5: Claim landing page
Add token preview and invalid-state handling. GET validates but does not consume and reveals only safe profile fields.

## Phase 6: Account setup and email verification
Support new/existing claim accounts through existing NextAuth, Credentials/Google, bcrypt, verification, and reset mechanisms. Gate both dashboard paths on activation policy; never email passwords.

## Phase 7: Broker ownership attachment
Atomically consume an eligible admin invitation and attach the unchanged profile. Enforce owner uniqueness and preserve all profile history.

## Phase 8: FREE and premium subscription integration
Guarantee FREE entitlement for successful direct activation and successful claim; separately support paid checkout, webhook reconciliation, cancellation, and premium expiry to FREE.

## Phase 9: Broker dashboard integration
Converge both owned paths on the same dashboard and owner APIs. Remove assumptions that every profile has a user and distinguish FREE from paid feature permissions.

## Phase 10: Public profile integration
Centralize publication policy for self-registered and unowned admin-created profiles; hide suspended/disabled profiles; preserve contact/review/URL behavior.

## Phase 11: Security hardening and testing
Test IDOR, CSRF, enumeration, replay, races, duplicate registration, token leakage, account state, Stripe idempotency, migration rollback, email delivery, and all documented state transitions.

## Future Files Likely Affected
`prisma/schema.prisma`; existing broker registration/auth routes; claim/admin routes and pages; broker dashboard/profile routes; `lib/auth.config.ts`, `lib/currentUser.ts`, `lib/tokens.ts`, `lib/rateLimit.ts`, email actions/templates, subscription/public query services, and tests. Exact changes require schema/design review.
