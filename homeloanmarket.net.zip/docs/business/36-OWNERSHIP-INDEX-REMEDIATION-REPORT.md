# Ownership Index Remediation Report

## 1. Problem

Prisma schema field:

```prisma
userId String? @unique @db.ObjectId
```

caused MongoDB/Prisma to create a normal unique index named `brokers_userId_key`. In the actual MongoDB deployment, this prevented multiple Brokers with `userId=null`, blocking the required ADMIN_CREATED unowned profile model.

## 2. Existing Index and Data Validation

Before remediation, the configured database `homeloan-listing` was inspected read-only:

- Brokers: **38**
- Owned Brokers (`userId != null`): **38**
- Unowned Brokers: **0**
- Duplicate non-null owner groups: **0**
- Existing index: unique normal `brokers_userId_key` on `{ userId: 1 }`

No ownership conflicts existed. Existing ownership values were preserved.

The isolated Phase 6.5 test database reproduced the blocker: a second `userId=null` Broker failed with `brokers_userId_key`.

## 3. Why It Violated the Business Model

The finalized model requires unlimited unowned ADMIN_CREATED profiles:

```text
Broker A -> userId null
Broker B -> userId null
Broker C -> userId null
```

At the same time, actual non-null ownership must remain unique:

```text
User A -> Broker A
User A -> Broker B  # must fail
```

A normal unique MongoDB index on a nullable field cannot provide both requirements.

## 4. Chosen Remediation

The Prisma logical model remains unchanged:

```prisma
userId String? @unique @db.ObjectId
```

Because Prisma 6.19.3 does not express the required MongoDB partial unique index through the current schema workflow, an explicit idempotent MongoDB index reconciler was added:

`scripts/ensure-ownership-index.ts`

It creates:

```text
name: brokers_userId_non_null_unique
key: { userId: 1 }
unique: true
partialFilterExpression: { userId: { $type: "objectId" } }
```

This enforces uniqueness only for actual ObjectId owners and permits unlimited null/missing owner values.

## 5. Prisma Limitation and Operational Requirement

Prisma schema validation/generation still requires the logical nullable unique relation for `findUnique({ userId })` typing and relation semantics. However, Prisma `db push` creates the normal `brokers_userId_key` index again.

Therefore deployment/index initialization must run:

```bash
npx prisma db push --skip-generate
npm run db:ensure-ownership-index
```

The reconciler is idempotent and safe to rerun. It must be part of deployment/database initialization after any Prisma schema synchronization. Running Prisma `db push` without the reconciler would reintroduce the blocker.

## 6. Safe Reconciliation Order

The script performs this order:

1. Aggregate non-null `userId` values and stop if duplicates exist.
2. Inspect existing ownership indexes.
3. Create the replacement partial unique index first.
4. Verify the replacement index exists with the correct partial filter.
5. Drop only the old normal `brokers_userId_key` index.
6. Verify no normal unique ownership index remains.
7. Print database/index status without exposing secrets or data.

If duplicate non-null owners are found, the script exits before any index operation. It never deletes, merges, or changes Broker ownership.

## 7. Database/Index Changes

Configured database final state:

```text
brokers_userId_non_null_unique
unique: true
partialFilterExpression.userId.$type: objectId
```

`brokers_userId_key` was removed only after replacement verification. No unrelated indexes were changed.

The isolated test database was also reconciled using the same script.

## 8. Production Safety Procedure

Before production execution:

1. Back up/verify restore capability.
2. Run the script in read-only validation mode or inspect duplicate ownership groups.
3. Confirm zero duplicate non-null owner groups.
4. Confirm target database name and replica set.
5. Run the reconciler during a controlled deployment window.
6. Inspect final indexes and ownership counts.
7. Monitor duplicate-key errors and ownership writes.

The actual configured database was remediated after read-only validation. No Broker documents, ownership values, subscriptions, reviews, leads, slugs, or profile data were modified.

## 9. Existing-Data Validation

Configured database before and after remediation:

- Brokers: 38
- Owned: 38
- Unowned: 0
- Duplicate non-null owner groups: 0

No existing ownership values changed.

## 10. Test Results

Isolated MongoDB replica-set integration suite:

- Admin-created Broker + FREE transaction: passed.
- Subscription failure rollback: passed.
- Multiple unowned Brokers: passed.
- Duplicate non-null owner rejection: passed.
- Ownership attachment followed by another unowned Broker: passed.
- Final index inspection: passed.
- Invitation persistence/lifecycle: passed.
- Expiration/self-registration separation: passed.

Result: **7 passed, 0 failed**.

Focused regression/policy suite: **15 passed, 0 failed**.

## 11. Validation Results

- `npx prisma validate`: **PASS**
- `npx prisma generate`: **PASS**
- ownership-index reconciler: **PASS** on isolated and configured databases
- focused ESLint: **PASS**
- TypeScript: **FAIL due to pre-existing errors only**

Existing TypeScript failures:

- six missing `.next/dev/types/validator.ts` route modules;
- existing `prisma.config.ts` `seed` property typing issue.

No new ownership-index TypeScript errors were introduced.

## 12. Remaining Non-Blocking Issues

- The partial index is managed operationally rather than expressible solely through Prisma schema.
- Deployment documentation/runbooks must ensure the reconciler follows every Prisma index synchronization.
- Redis invitation concurrency and HTTP authorization integration tests remain environment-dependent.
- Claimant-side Phase 7 functionality remains unimplemented.

## 13. Phase 7 Readiness Decision

**READY FOR PHASE 7**, subject to the deployment requirement that `db:ensure-ownership-index` runs after any Prisma database synchronization.

The ownership index now supports multiple unowned ADMIN_CREATED Brokers while preserving uniqueness for non-null owners. Existing data and self-registration compatibility are preserved.
