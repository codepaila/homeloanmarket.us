# Phase 7.5 Integration Readiness Audit

## Scope

Read-only baseline audit before remediation of build, email, OAuth, and browser integration. No business rules or claim contract decisions were changed.

## Classification

### A. Real defects

- `prisma.config.ts` used an unsupported `seed` property for the installed Prisma config type, blocking build/typecheck.
- `/claim-broker/continue` used `useSearchParams()` without the required Suspense boundary, causing production prerender failure.
- Claim-context production fallback secret weakened fail-closed behavior when `NEXTAUTH_SECRET` was absent.
- Claim email submission/account setup lacked explicit rate limiting.

### B. Pre-existing repository problems

- Full lint has 209 errors and 285 warnings across unrelated legacy components, data-fetch helpers, advertisements, billing, seed files, and type declarations.
- The existing Prisma seed configuration was also a typecheck issue; the unsupported config entry was removed while preserving the existing `npm run seed` script.

### C. Missing test infrastructure

- No Playwright configuration or `@playwright/test` package exists.
- No authenticated browser fixture, mail sink, or HTTP auth integration harness exists.
- No automated Google OAuth callback/provider fixture exists.

### D. Environment/configuration limits

- Local MongoDB replica-set integration environment is available and used.
- No isolated email sink/test recipient is configured, so no real email was sent.
- No Google OAuth credentials/test callback environment is configured for controlled external OAuth.

### E. External-provider limitations

- Resend delivery was not executed to avoid uncontrolled external email.
- Google provider login/claim was not executed against Google.

## Baseline Findings

Before remediation, build failed on Prisma config typing and claimant continuation prerendering. TypeScript also read stale `.next/dev/types` route references. Full lint was already broadly failing outside Phase 7. The current Prisma schema and MongoDB ownership index validated successfully.

The Phase 7 audit also identified two security/abuse hardening gaps: production claim-context signing had a development fallback secret, and claim email/setup endpoints lacked explicit rate limiting.

## Remediation Scope

The concrete defects were fixed without changing the claim contract:

- removed unsupported Prisma config `seed` key;
- removed stale `.next/dev/types` inclusion from `tsconfig.json`;
- replaced claimant continuation `useSearchParams()` with browser query parsing in an effect;
- made claim context fail closed in production without `NEXTAUTH_SECRET`;
- added claim email/setup rate limiting;
- rechecked invitation status/expiry inside start and completion transactions.
- added signed claim reauthentication state for password/Google provider paths.

## Provider/Test Status

| Area | Result | Explanation |
|---|---|---|
| TypeScript | PASS | Clean after configuration fix and `.next/dev` exclusion. |
| Production build | PASS | Next production build completed successfully. |
| Prisma validate/generate | PASS | Both completed successfully. |
| Phase 7 unit tests | PASS | Account classification and claim policy tests pass. |
| MongoDB claim integration | PASS | Atomic completion and concurrent claimant race pass in isolated replica set. |
| Full lint | FAIL pre-existing | 209 unrelated repository-wide errors remain; targeted Phase 7 lint passes. |
| Browser E2E | NOT EXECUTED | No Playwright infrastructure/package exists. |
| Real email | NOT EXECUTED | No safe test mailbox/sink; no uncontrolled email sent. |
| Real Google OAuth | NOT EXECUTED | No configured controlled OAuth test environment. |

## Safety Conclusion

Application build/type safety is now clean for the repository baseline. Database claim behavior is integration-tested. Provider and browser verification remain environment/infrastructure gaps rather than silently claimed passes.
