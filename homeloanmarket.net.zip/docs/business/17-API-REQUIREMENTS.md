# API Requirements

The exact claim routes, payloads, transitions, error model, and rate limits are finalized in `33-CLAIM-CONTRACT.md`. That contract supersedes the candidate-only claim entries below for implementation.

All target APIs are conceptual. They require server authorization, input validation, rate limits, CSRF strategy for mutations, safe errors, audit events, idempotency where applicable, and no raw token logging.

| Endpoint capability | Requirement |
|---|---|
| `POST /api/auth/register/broker` | Reuse/evolve the existing route; validate account/profile data, normalize email, prevent enumeration, hash password, create user + broker + FREE transactionally, associate ownership immediately, set `SELF_REGISTERED`/`NOT_REQUIRED`, rate-limit, and send verification. |
| `POST /api/admin/brokers` | Create `ADMIN_CREATED` profile without user, initialize ownership/claim/FREE, validate and audit. |
| `PATCH /api/admin/brokers/:id` | Editorial/admin state changes with reasons. |
| `POST /api/admin/brokers/:id/claim-invitations` | Generate/send invitation only for eligible unowned admin-created profile; return no raw token. |
| `POST /api/admin/claim-invitations/:id/revoke` | Revoke active invitation. |
| `GET /api/claims/:opaqueId` | Safe validation/preview; no consumption. |
| `POST /api/claims/:opaqueId/email` | Begin new/existing account verification/setup; generic responses. |
| `POST /api/claims/:opaqueId/complete` | Verified authenticated completion and atomic attachment. |
| `POST /api/auth/claim-setup` | Secure password setup/reset for claim flow; never email plaintext passwords. |
| `GET/PATCH /api/brokers/me` | Resolve owner by authenticated user and support active FREE/paid owners. |
| Public broker APIs | Central publication predicate; support eligible unowned profiles without dereferencing null user. |
| Subscription APIs/webhook | Owner/admin authorization, FREE default, paid upgrade, signed Stripe events, event idempotency, expiry-to-FREE. |

Direct registration and claim registration converge into the same authenticated `User` model and broker dashboard. A normal user registration endpoint, if present, must not create broker ownership unless the broker flow is explicitly selected.
