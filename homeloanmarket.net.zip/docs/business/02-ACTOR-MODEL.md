# Actor Model

| Actor | Identity or state | Authority |
|---|---|---|
| Public borrower/user | Visitor or normal authenticated `USER` | Browse published profiles, submit leads, use normal account features. |
| Registering broker | Visitor who explicitly selects broker registration | Submit broker/account data; receives owned FREE profile after activation policy. |
| Active FREE broker | Active verified user with owned profile and FREE entitlement | Dashboard, permitted profile edits, leads, account management, optional upgrade. |
| PREMIUM/FEATURED broker | Active owner with paid entitlement | FREE capabilities plus paid plan features. |
| Unowned admin-created profile | `creationSource=ADMIN_CREATED`, `ownership=UNOWNED` | No owner authority; admin controls it; public only under policy. |
| Claimed broker | Admin-created profile with `ownership=OWNED`, claim completed | Owner manages the same profile and subscription. |
| Admin | Active `User.role=ADMIN` | Platform governance, publication, verification, invitations, suspension, billing assistance, audit. |

Ownership is a relation, not a role shortcut. Authorization must check actor capability and target profile ownership. A valid claim invitation grants entry to a claim workflow, not general admin or profile authority before completion.
