# Business Model

HomeLoanMarket monetizes discovery and qualified borrower contact for mortgage brokers and companies. Profiles are durable marketplace assets. Admin-curated profiles can precede account ownership; self-registered brokers can create their own profile. Free publication is distinct from paid ranking, lead limits, analytics, support, or featured placement. Ownership is established either by direct broker registration or by a secure claim of an eligible admin-created profile, never by payment or a matching email string.

## Current Evidence
The current schema has one required `Broker.userId`, one optional `BrokerSubscription`, public broker APIs, reviews, contact messages, and the active Stripe plans `FREE` and `FEATURED`. Historical PREMIUM values remain only for migration compatibility. Verification, broker status, and visibility are independent from subscription entitlement.

## Target Value Flows
- Admin supplies trusted market inventory.
- Borrower searches by city, specialization, rating, and publication state.
- Borrower submits a contact message to a published profile.
- Owner receives and manages leads from the same profile record.
- Owner purchases paid entitlements independently of claim state.
- Platform controls safety, trust, editorial visibility, billing reconciliation, and auditability.
