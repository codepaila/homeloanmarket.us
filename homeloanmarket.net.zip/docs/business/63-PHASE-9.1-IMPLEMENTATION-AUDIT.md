# Phase 9.1 Implementation Audit

## Scope

Audit of the frozen Phase 9.0C contract before implementation. No Phase 9.1 code changes are recorded in this audit document.

## Implementation Matrix

| Area | Existing | Required | Gap | Action |
|---|---|---|---|---|
| Authentication | NextAuth JWT/Credentials/Google; `getCurrentUser()` | Reuse current auth/session | No dashboard HTTP/browser harness | Preserve; test in Phase 9.1 |
| Ownership | Direct registration attaches `Broker.userId`; claim completion conditionally attaches | Same owner model for both paths | No divergence found in route architecture | Preserve; test convergence |
| Nullable ownership | Owner `/me` routes resolve by authenticated User; unowned Broker is not owner target | No null-owner dashboard assumptions | Generic consumers require route-level audit | Preserve; test null/unowned cases |
| Dashboard | `/broker/dashboard`, shared layout/sidebar/header/components | One dashboard for both owned paths | Client analytics fetch targets missing route | Remove unsupported fetch and keep basic data |
| Owner APIs | `/api/brokers/me`, dashboard stats, contacts, profile, billing | Server owner resolution and compatibility | No complete HTTP contract suite | Preserve; add tests |
| FREE | Effective FREE resolver and dashboard access | Baseline access without payment | Client permission flags overexpose analytics | Align client projection with contract |
| FEATURED | Effective entitlement and paid placement/billing | Existing FEATURED behavior only | No supported advanced analytics API | Preserve paid placement/billing only |
| Contacts | Existing owner-scoped contacts | Preserve existing behavior, no new limits | No Phase 9-specific HTTP tests | Preserve; test |
| Leads | Existing model/projections | Preserve existing behavior, no new limits | Exact limit not a Phase 9 feature | Out of scope; preserve |
| Reviews | Public review read path and dashboard summary | Existing read behavior | Owner mutations out of scope | Preserve; no new mutation |
| Visibility | Existing profile mutation/publication behavior | No Phase 9 visibility redesign | Current behavior is legacy and outside Phase 9 | Preserve; no change |
| Analytics | Dashboard attempts missing `/api/brokers/me/analytics` | Advanced analytics out of scope; basic stats existing | Broken unsupported fetch and FREE exposure | Remove fetch; keep basic stats |
| Billing | Phase 8.5-certified subscription routes | Reuse | No new dashboard billing behavior required | Preserve |
| Responsive UI | Existing dashboard responsive layout | Preserve desktop/mobile | Browser execution unavailable | Preserve; browser test later |
| Security | Server owner lookup on primary owner APIs | No IDOR/client authority | No authenticated dashboard harness | Preserve; test |
| Tests | Unit/domain/MongoDB suites | Phase 9.1 focused owner/dashboard tests | No dashboard-specific tests | Add focused tests |

## Verified Defect

`BrokerDashboard` invokes `useBrokerAnalytics()` unconditionally. That hook requests `/api/brokers/me/analytics`, but no such route exists. The dashboard also exposes analytics permission for any active subscription, including FREE, while the frozen contract places advanced analytics out of scope.

Phase 9.1 fix: stop the unsupported analytics fetch and do not expose the unsupported analytics tab. Existing basic dashboard statistics remain available through the existing dashboard stats path.

## Implementation Result

Applied in Phase 9.1:

- removed the unsupported `useBrokerAnalytics()` fetch from the dashboard;
- disabled unsupported advanced analytics permission projections;
- aligned client contact-detail/export permission projections with effective FEATURED behavior;
- preserved existing basic dashboard statistics and owner API contracts.

## Non-Changes

- No new API.
- No schema/data change.
- No new analytics.
- No contact/lead limits.
- No ownership/claim/verification/visibility/subscription changes.
