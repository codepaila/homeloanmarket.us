# Permission Matrix

| Action | Public user | Registering broker | Active FREE broker | PREMIUM broker | Unowned profile | Claimed broker | Admin |
|---|---|---|---|---|---|---|---|
| Browse published profile | Yes | Yes | Yes | Yes | Public fields only | Yes | Yes |
| Submit contact/lead | Yes | Yes | Yes | Yes | No owner authority | Yes as permitted | Yes |
| Register as broker | May select flow | Yes | No | No | No | No | May assist |
| Create broker profile | No | Yes, self-registration flow | No | No | Already exists | No new profile | Yes |
| Claim profile | No, absent invitation | Only with valid invitation | No, unless separately invited | No, unless separately invited | No self-authority | No | Assist/approve |
| Edit profile | No | Pending activation only as allowed | Own profile fields | Own profile plus paid fields | No | Own profile fields | Yes |
| View dashboard | No | After activation | Yes | Yes | No | Yes | Yes |
| Manage leads | No | After activation | Yes, free limits | Yes, paid limits | No | Yes | Yes |
| Subscribe/cancel | No | After activation | Own profile upgrade | Own profile billing | No | Own profile billing | Yes with audit |
| Publish/verify/suspend | No | Request only | Request only | Request only | No | Request only | Yes |
| Generate/resend/revoke claim | No | No | No | No | No | No | Yes |
| View claim history | No | No | Own summary if applicable | Own summary if applicable | No | Own summary | Yes |
| Manage account info | Own normal account | Own pending account | Own account | Own account | No | Own account | Support-only with audit |

Registering broker is a temporary onboarding actor. It becomes an Active FREE broker only after activation policy. A self-registered broker is not a claimant.

Every endpoint must enforce actor permission and target profile ownership; role checks alone are insufficient.
