# Phase 6.5 Pre-Claim Hardening Report

## 1. Scope

This phase audited and hardened the Phase 6 admin Broker/invitation foundation. Claimant-side preview, account setup, claim context, authentication, ownership completion, and `Broker.userId` attachment were not implemented.

## 2. Existing Implementation Reviewed

Reviewed:

- admin Broker list/create/detail/edit APIs and pages;
- transactional admin Broker + FREE creation;
- BrokerClaim/Invitation/Event persistence;
- token generation and SHA-256 hashing;
- Redis/Upstash invitation lock;
- invitation email delivery and event recording;
- admin authorization via `getCurrentUser().role`;
- public visibility/null-owner policy;
- self-registration and FREE subscription behavior;
- Prisma schema/indexes;
- existing focused test setup and package scripts.

## 3. Files Changed

- `lib/claim-invitation.ts`
- `lib/claim-policy.ts`
- `app/api/admin/brokers/[id]/claim-invitations/route.ts`
- `app/api/admin/claim-invitations/[id]/resend/route.ts`
- `app/api/admin/claim-invitations/[id]/revoke/route.ts`
- `app/admin/brokers/[id]/AdminBrokerActions.tsx`
- `tests/phase-6-admin-broker.test.ts`
- `tests/phase-6.5-integration.test.ts`
- `docs/business/35-PHASE-6.5-PRE-CLAIM-HARDENING-REPORT.md`

No Prisma schema change was made.

## 4. Hardening Changes

- Revocation now uses the same per-Broker Redis lock as issuance/resend, preventing revoke versus resend races from creating inconsistent active state.
- Lock release checks the lock value before deletion instead of unconditionally deleting a potentially renewed lock.
- Invitation delivery emails now require a valid email format in addition to rate limiting.
- Added a pure invitation-expiry policy helper.
- Added integration coverage for persisted admin Broker/FREE state, rollback, claim records, invitation state, expiration, and self-registration separation.
- Existing invitation supersede logic now records REVOKED events for every prior active invitation.

## 5. MongoDB Test Environment

An existing local MongoDB 8 replica set was available at `127.0.0.1:27017`, replica set `rs0`. Tests used the isolated database:

```text
homeloanmarket_phase65_test
```

The isolated database was reset and synchronized with Prisma using `DATABASE_URL` override. No project-configured or production database was used. No production email was sent.

## 6. Transaction Testing

Executed real MongoDB integration tests:

- Broker + FREE subscription persisted atomically.
- Broker creation followed by forced subscription uniqueness failure rolled back the Broker.
- Persisted admin Broker state was verified as unowned, ADMIN_CREATED, UNVERIFIED, unpublished, and FREE.
- No User owner or Stripe identifiers were created.

Result: **PASS for tested transaction cases**.

## 7. Invitation Lifecycle Testing

Real isolated persistence tests verified:

- BrokerClaim creation for an eligible unowned ADMIN_CREATED Broker;
- ACTIVE invitation creation;
- seven-day expiry window;
- tokenHash persistence without raw token storage;
- GENERATED and REVOKED events;
- previous invitation becoming REVOKED;
- new invitation becoming ACTIVE;
- exactly one ACTIVE invitation in the tested sequential lifecycle;
- Broker identity and `userId=null` preservation.

Result: **PASS for tested sequential lifecycle**.

## 8. Concurrency Testing

The code now serializes issuance/resend/revoke operations through the per-Broker Upstash Redis lock and MongoDB transaction. However, the configured Upstash Redis integration was not available for an end-to-end concurrency run in this environment.

Result: **NOT VERIFIED end-to-end**.

The isolated MongoDB test verified the data model but did not invoke the HTTP route/auth/email/Redis stack concurrently.

## 9. Token Security Testing

Focused tests verified:

- two generated tokens differ;
- raw token decodes to 32 bytes;
- SHA-256 output is 64 lowercase hexadecimal characters;
- digest differs from raw token;
- expiry helper rejects past invitations;
- no token is included in claim event metadata.

Source review confirmed raw tokens are used only to construct the delivery URL and are not returned by the admin API response or persisted in Prisma.

Result: **PASS for unit/static coverage; delivery/log redaction is not externally integration-tested**.

## 10. Authorization and IDOR Testing

All admin endpoints perform server-side `getCurrentUser()` role checks. Invitation issuance additionally verifies target Broker source, null owner, and non-suspended state. Revoke/resend operate by invitation ID and resolve the related Broker server-side.

No HTTP integration test harness exists for impersonating ADMIN, BROKER, USER, and unauthenticated sessions. Therefore authorization behavior is statically verified but not end-to-end tested.

Result: **STATIC PASS; INTEGRATION NOT VERIFIED**.

## 11. Public Visibility and Null-Owner Compatibility

The Phase 3B public policy remains in place. Admin-created Brokers persist `isVisible=false`, and claim preparation does not alter visibility, verification, subscription, or ownership. Existing null-owner policy tests remain passing.

Result: **PASS for existing policy/unit coverage**.

## 12. Self-Registration Compatibility

The isolated integration test created a `SELF_REGISTERED` Broker with a real User and verified that no BrokerClaim was created automatically. Existing Phase 3B and Phase 6 tests also passed.

Result: **PASS for tested model/policy behavior**.

## 13. Subscription Regression

Invitation preparation does not update BrokerSubscription, BrokerStatus, verification, visibility, or ownership. FREE remains the existing entitlement. No Stripe operations are used by the invitation foundation.

Result: **PASS by code review and persisted lifecycle tests**.

## 14. Email Testing

The existing email transport/template path is reused. Invitation email delivery was not executed against a real provider. The implementation uses a safe claim URL, profile identity, expiration, and no password/token hash.

If delivery fails, the committed invitation remains available for resend and the event path records FAILED when the provider returns an unsuccessful result.

Result: **Provider delivery NOT VERIFIED; state/error behavior reviewed**.

## 15. Claim URL Verification

The generated URL follows the finalized Phase 5B contract:

```text
```

The claimant route is intentionally deferred to Phase 7. No placeholder claimant route was created.

Result: **URL contract PASS; claimant route DEFERRED TO PHASE 7**.

## 16. Critical MongoDB Constraint Finding

The isolated database generated this unique index:

```text
brokers_userId_key on { userId: 1 }
```

It is not sparse/partial in the tested deployment. After one unowned Broker exists, attempting to persist a second Broker with `userId=null` fails with:

```text
Unique constraint failed on brokers_userId_key
```

This violates the business requirement that multiple ADMIN_CREATED unowned profiles must be supported. The Phase 1 review identified this as a risk, and Phase 6.5 has now confirmed it in a real MongoDB replica set.

This requires an approved schema/index remediation before Phase 7 or production use of multiple unowned Brokers. No schema change was made in this phase.

## 17. TypeScript Result

`npx tsc --noEmit` still reports only pre-existing repository errors:

- six missing `.next/dev/types/validator.ts` route modules;
- existing `prisma.config.ts` `seed` property type error.

No new Phase 6.5 TypeScript errors were introduced.

Result: **FAIL at repository baseline; no new errors**.

## 18. Lint Result

Focused ESLint checks for the hardened invitation/admin/test files passed with no errors.

Result: **PASS**.

## 19. Prisma Result

- `npx prisma validate`: **PASS**
- `npx prisma generate`: **PASS**
- isolated test database schema synchronization: **PASS**

## 20. Tests Executed

Focused unit/policy tests:

```text
14 passed, 0 failed
```

Isolated MongoDB integration tests:

```text
5 passed, 0 failed
```

The integration suite includes an explicit passing regression test demonstrating the current nullable-unique index limitation when a second unowned Broker is attempted. This is a blocker, not a successful business acceptance case.

## 21. Remaining Limitations

- Upstash Redis concurrency was not end-to-end tested because test Redis credentials/service were unavailable.
- HTTP authorization/IDOR integration tests were not available.
- Real email provider delivery was not executed.
- No production database or email was touched.
- The generated unique MongoDB `Broker.userId` index blocks multiple null owners.
- Claimant-side implementation remains untouched.

## 22. Phase 7 Readiness Decision

**NOT READY FOR PHASE 7**.

The blocking issue is the confirmed MongoDB nullable-owner uniqueness failure. The approved schema currently cannot persist the required second unowned ADMIN_CREATED Broker. Schema/index remediation requires explicit approval and must be performed before Phase 7 claimant implementation.

All other Phase 6.5 gaps are non-blocking verification limitations or require test infrastructure expansion, except the nullable-owner index issue.
