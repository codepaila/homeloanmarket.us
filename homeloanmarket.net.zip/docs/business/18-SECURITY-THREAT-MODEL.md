# Security Threat Model

| Threat | Impact | Required control |
|---|---|---|
| IDOR on broker/contact/admin IDs | Data disclosure or takeover | Target ownership checks, admin authorization, opaque public IDs, tests. |
| Token leakage in URL/log/referrer | Unauthorized claim | HTTPS, referrer policy, no raw logs, short TTL, token rotation, consume once. |
| Replay/brute force | Duplicate/unauthorized claim | High entropy, digest lookup, rate limits, atomic consume, generic errors. |
| Email enumeration | Privacy/security disclosure | Uniform responses/timing and no account existence in claim flow. |
| Account takeover | Ownership theft | Verify submitted email, reauth existing users, secure password setup, session invalidation. |
| Race/duplicate claim | Wrong owner | Conditional transaction and unique owner constraint. |
| CSRF/session confusion | Unauthorized mutation | SameSite cookies plus CSRF/origin checks on state changes. |
| Admin escalation | Platform compromise | Server-side role/capability checks, MFA/admin audit, no client role trust. |
| Verification bypass | Trust harm | Separate review state; no plan-based verification; evidence and audit. |
| Stale/revoked links | Unexpected access | State/expiry checks on every request and revocation. |
| Sensitive database/log exposure | Privacy breach | Least-privilege selects, redaction, encrypted secrets, retention policy. |
| Malicious email/domain claim | Fraudulent ownership | Business verification, support escalation, domain/manual checks where risk warrants. |

Residual risks: compromised company email, admin account compromise, malicious profile content, and external email provider compromise require operational controls, incident response, and support verification.
