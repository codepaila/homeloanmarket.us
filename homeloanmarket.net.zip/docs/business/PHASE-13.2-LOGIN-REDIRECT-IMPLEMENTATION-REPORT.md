# Phase 13.2 Login Redirect Implementation Report

## Files Changed

- `lib/auth-redirect.ts`
- `app/(public)/auth/signin/page.tsx`
- `proxy.ts` (moved from `app/proxy.ts`)
- `lib/auth.config.ts`
- `app/broker/dashboard/page.tsx`
- `actions/auth.action.ts`
- `tests/phase-13.2-login-redirect.test.ts`

## Fixes

### Central Redirect Decision

Added `roleHome()`, `sanitizeCallbackUrl()`, and `postLoginRedirect()`:

- Admin -> `/admin/ads`.
- Broker -> `/broker/dashboard`.
- Normal user/unknown role -> `/`.
- Legacy `/admin/dashboard`, `/dashboard`, `/admin`, and `/broker` targets normalize to existing role homes.
- Cross-role protected callback paths are rejected.

### Sign-In Page

- Removed the universal Broker fallback.
- Credentials login obtains the authenticated session role before redirecting.
- Already-authenticated users visiting sign-in are redirected by role.
- Google callback URLs are sanitized before submission.

### Proxy

- Moved the existing implementation to root `proxy.ts` and exported the required default `proxy` function.
- Authenticated sign-in visits now redirect by role.
- Unauthenticated protected requests retain a sanitized callback path.
- Admin and Broker route families remain independently authorized.
- Nonexistent generic dashboard redirects were removed.
- `robots.txt` and `sitemap.xml` remain public after the proxy activation fix.

### Auth.js and Existing Flows

- Auth.js redirect callback now rejects unsafe origins/URLs safely.
- Server auth actions use `/admin/ads`, `/`, and `/auth/signin` rather than nonexistent dashboard/login paths.
- Broker dashboard's server guard uses role home routing.
- Registration's `/auth/verify-email` intermediate behavior and claim completion's `/broker/dashboard` behavior remain unchanged.

No ownership, claims, subscriptions, advertisements, SEO, schema, or seeded data were changed.
