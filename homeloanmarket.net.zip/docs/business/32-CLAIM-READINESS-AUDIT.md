# Phase 5 Claim Readiness Audit

This historical audit recorded the pre-contract blockers. `33-CLAIM-CONTRACT.md` resolves those business and technical decisions and is authoritative for the next implementation phase.

## 1. Executive Summary

**Overall decision: NOT READY - BLOCKING ITEMS FOUND.**

The Prisma schema contains the core claim persistence structures, and the existing User/NextAuth, bcrypt, email, rate-limit, and nullable Broker ownership foundations can be reused. However, the application contains no claim implementation: no admin Broker creation, invitation service, token issuance, claim routes, account-association flow, claim email templates, claim UI, claim authorization, claim event writes, or claim tests exist.

The database can support the core transition:

```text
Broker(userId=null, creationSource=ADMIN_CREATED)
  -> valid invitation
  -> verified eligible account
  -> atomic Broker.userId=User.id
  -> same Broker remains owned
```

Implementation is blocked until the undefined account-association, admin-account, invitation concurrency, cryptographic choice, and claim-email decisions in this document are approved.

## Readiness Labels

- **[DOCUMENTED]** Directly stated by authoritative business documents.
- **[IMPLEMENTED]** Already supported by current application code.
- **[INFERRED]** Reasonable technical consequence, not an explicit business decision.
- **[UNDEFINED]** Business behavior is not specified.
- **[BLOCKING]** Must be decided before safe implementation.

## 2. Current Architecture

### Prisma

`Broker.userId` is nullable and unique; ownership is therefore derived only from the relation. `Broker.creationSource` is nullable and supports `ADMIN_CREATED`/`SELF_REGISTERED`. `BrokerClaim` is one-to-one with Broker and stores current claim status. `BrokerClaimInvitation` stores a unique `tokenHash`, status, expiry, used/revoked timestamps, and creating admin. `BrokerClaimEvent` stores lifecycle event type, claim/invitation references, optional actor, metadata, and timestamp.

`BrokerSubscription` remains one-to-one with Broker. No claim relation is required for self-registered profiles. No raw claim token field exists.

### Authentication

NextAuth uses JWT sessions, Credentials and Google providers, Prisma User/Account records, bcrypt passwords, `User.isActive`, and `User.emailVerified`. Broker credentials login now requires verified email. Password reset and email verification are existing User flows. There is no claim-specific account setup or reauthentication flow.

### Email

`actions/email.action.ts` and `lib/email-templates.ts` support registration verification, resend verification, password reset, broker notifications, leads, reviews, and subscriptions. No claim invitation, claim verification, claim completion, or existing-account claim notification template exists.

### Admin

No admin Broker creation or Broker claim-management route/page was found. Existing admin UI is focused on advertisements, media, and contacts.

### Current Claim Implementation

No application consumer of `BrokerClaim`, `BrokerClaimInvitation`, or `BrokerClaimEvent` exists. Claim readiness is therefore a design/readiness question, not a partially implemented feature.

## 3. Confirmed Business Rules

- **[DOCUMENTED]** Only `ADMIN_CREATED` profiles with `Broker.userId=null` may be claimed.
- **[DOCUMENTED]** Self-registered profiles are already owned and have claim state `NOT_REQUIRED`.
- **[DOCUMENTED]** Claiming never creates or copies a Broker.
- **[DOCUMENTED]** Claim completion preserves Broker ID, slug, profile data, reviews, leads, counters, subscription, verification, and history.
- **[DOCUMENTED]** Ownership is derived only from `Broker.userId`.
- **[DOCUMENTED]** Claiming requires a valid invitation, verified submitted email, and eligible account context.
- **[DOCUMENTED]** Email matching alone is not ownership proof.
- **[DOCUMENTED]** FREE is created or retained; claiming does not create PREMIUM.
- **[DOCUMENTED]** Public visibility does not inherently require ownership.
- **[DOCUMENTED]** Subscription and verification remain independent of ownership.
- **[DOCUMENTED]** Claim events are append-only and raw tokens are not persisted/logged.
- **[DOCUMENTED]** Direct registration and claiming reuse the same User/authentication/dashboard system.

## 4. Claim State Machine

### BrokerClaim

| Transition | Trigger/actor | Preconditions | Invalid/prevented behavior |
|---|---|---|---|
| no row -> `INVITED` | ADMIN creates/sends first invitation | Broker is ADMIN_CREATED, unowned, eligible | Reject owned/self-registered/suspended-disabled target. |
| `INVITED` -> `IN_PROGRESS` | Claimant opens valid link/starts flow | Invitation ACTIVE, hash matches, not expired, Broker still unowned | Reject invalid, used, revoked, expired, or mismatched invitation. |
| `IN_PROGRESS` -> `COMPLETED` | System transaction after claimant completion | Verified/eligible account, owner still null, invitation ACTIVE, claim non-terminal | Atomic conflict response; no partial ownership. |
| `INVITED/IN_PROGRESS` -> `EXPIRED` | Request-time expiry check or cleanup job | Current time >= applicable expiry | Must not attach owner. Event is appended once. |
| `INVITED/IN_PROGRESS` -> `REVOKED` | ADMIN revoke/supersede | Admin authorization and non-terminal invitation/claim | Used/completed invitation cannot be reactivated. |
| `INVITED/IN_PROGRESS` -> `FAILED` | System after terminal validation/setup failure | Failure reason recorded without ownership mutation | Must not expose sensitive account/token details. |

`COMPLETED` is terminal and cannot reopen. `EXPIRED`, `REVOKED`, and `FAILED` may be reopened to `INVITED` only by an explicit admin fresh-invitation operation; the prior invitation remains terminal and history is preserved.

### BrokerClaimInvitation

| Transition | Trigger |
|---|---|
| no row -> `ACTIVE` | Authorized admin issues invitation and stores digest. |
| `ACTIVE` -> `USED` | Atomic successful claim completion. |
| `ACTIVE` -> `EXPIRED` | Expiry validation/cleanup. |
| `ACTIVE` -> `REVOKED` | Admin revoke or supersede policy. |

No terminal invitation may return to ACTIVE. The current schema supports these states but does not enforce transition rules; the service must.

## 5. Invitation Lifecycle and Security

### Supported by Current Design

- **[DOCUMENTED]** Store only `tokenHash`; never raw token.
- **[DOCUMENTED]** Token must be cryptographically random, high entropy, expiring, revocable, and single-use.
- **[IMPLEMENTED FOUNDATION]** `lib/tokens.ts` generates 32 random bytes using `crypto.randomBytes(32).toString('base64url')` for existing verification tokens.
- **[IMPLEMENTED FOUNDATION]** Existing verification uses SHA-256 digests.
- **[IMPLEMENTED SCHEMA]** `tokenHash` is unique; invitation has expiry, status, usedAt, and revokedAt.
- **[DOCUMENTED]** GET/preview must not consume an invitation.

### Gaps and Blocking Choices

- **[UNDEFINED/BLOCKING]** The claim documents permit SHA-256 or HMAC but do not select one exact claim-token digest construction. Recommendation: use SHA-256 over a 32-byte random base64url token consistently with the existing token architecture, unless threat review requires keyed HMAC.
- **[UNDEFINED/BLOCKING]** Exact token lifetime is not fixed in the business documents. Registration verification uses 24 hours; claim lifetime needs an explicit product/security value.
- **[DOCUMENTED]** Raw tokens must not be logged, persisted, placed in audit metadata, or leaked through referrers. The future claim route must apply a strict referrer policy and redact URLs.
- **[IMPLEMENTATION GAP]** No claim token generation, lookup, rate limiting, audit, or replay handling currently exists.
- **[IMPLEMENTATION GAP]** `BrokerClaimInvitation(status, expiresAt)` supports expiry work, but no database TTL/cleanup behavior exists; validation must enforce expiry synchronously.

## 6. Multiple Invitations

**[DOCUMENTED]** `19-EDGE-CASES.md` says a new invitation supersedes/revokes active prior invitations and records history. `29-BROKER-CLAIM-IMPLEMENTATION-PLAN.md` repeats resend/supersede behavior.

**[UNDEFINED/BLOCKING DETAIL]** The documents do not specify whether superseding is performed before or after the new invitation is stored, nor the exact concurrent-generation winner. The schema has no partial unique constraint for one ACTIVE invitation per claim.

Required implementation decision: perform one admin-authorized transaction that conditionally revokes active invitations, creates the new ACTIVE invitation, and appends events, with a defined deterministic winner for concurrent admin requests. If MongoDB cannot enforce one active invitation through the current index model, application transaction/serialization is mandatory.

## 7. Claim Email and Account Lifecycle

### Documented

- **[DOCUMENTED]** Claimant submits an intended email.
- **[DOCUMENTED]** System may continue an eligible existing account or start a new account.
- **[DOCUMENTED]** New account uses existing account setup/email verification/password mechanisms.
- **[DOCUMENTED]** Existing account requires reauthentication/verified completion.
- **[DOCUMENTED]** Claim completion requires verified submitted email and eligible account context.
- **[DOCUMENTED]** No plaintext password is emailed.

### Undefined/Blocking Scenarios

| Scenario | Status | Required decision |
|---|---|---|
| Email does not belong to a User | Documented at high level | Create a new User with `BROKER`, password setup, verified email, and no duplicate Broker; exact setup/session sequence is undefined. |
| Email belongs to ordinary USER | Partially documented | Decide whether valid invitation upgrades role to BROKER at completion, and whether reauthentication plus email verification is sufficient. |
| Email belongs to BROKER User with no profile | Undefined | Decide whether it may own the invited Broker under one-profile policy. |
| Email belongs to BROKER User with another profile | Documented edge case | Reject or admin-review; exact response/status is undefined. |
| Email belongs to ADMIN | Undefined/blocking | Decide whether ADMIN may claim, must be rejected, or requires an assisted workflow. Least-privilege recommendation is reject ordinary claim completion and require explicit admin-assisted ownership. |
| Claim email equals Broker.email | Undefined | Broker.email is profile contact data, not documented ownership proof. Do not require equality without a new business decision. |
| Broker.email differs from User.email | Undefined | Define which address receives claim/account messages and which becomes authoritative for login. |
| Existing User is unverified | Partially documented | Email verification is required before attachment, but resend/setup and session behavior are unspecified. |
| Existing Google User | Undefined/blocking | Decide whether Google reauthentication satisfies claim identity proof and whether a password is required. |
| Existing User inactive/disabled | Partially documented | Disabled account cannot complete; exact recovery/manual-assistance path is unspecified. |
| Claimant abandons before User creation | Documented | Profile remains unowned; invitation eventually expires/revokes. |
| User created then setup abandoned | Undefined | Define pending User retention, resend, cleanup, and whether the User may later claim another profile. |
| Claim completion session | Undefined | Decide whether to issue a session, redirect to sign-in, or require fresh login. |

These are **BLOCKING** because they define account takeover boundaries and role/ownership changes.

## 8. Ownership Transition

### Required Atomic Operation

The final transaction must re-read and verify:

1. Broker exists and `creationSource=ADMIN_CREATED`.
2. Broker `userId` is still null.
3. Broker is not disabled/suspended under claim policy.
4. BrokerClaim is non-terminal and eligible.
5. Invitation hash matches, is ACTIVE, and is unexpired.
6. User is eligible and email/account verification requirements pass.
7. User ownership uniqueness is still satisfied.

Then, in one transaction, update the existing Broker's `userId`, set claim COMPLETED, set invitation USED, write completion event, and create/retain FREE. No Broker create/copy operation is permitted.

### Race Handling

| Race | Required control | Readiness |
|---|---|---|
| Two people use one invitation | Mongo transaction plus conditional `status=ACTIVE`, `usedAt=null`, Broker `userId=null` update | Planned, not implemented. |
| Two admin sends | Transaction/serialization plus supersede policy; no active-invitation unique index | Blocking implementation detail. |
| Completion twice | Unique owner + terminal invitation/claim status + conditional update | Schema supports constraints; service absent. |
| Revoke during completion | Same transaction/conditional state check; one operation wins, other conflicts | Not implemented. |
| Expire during completion | Compare expiry inside transaction, not only on page open | Not implemented. |
| Admin edits/disables during claim | Completion must re-read eligibility and reject disabled/invalid target | Policy partly documented; exact admin-edit conflict behavior undefined. |
| User created twice | Unique User email/phone plus idempotency/request strategy | Unique constraints exist; idempotency policy undefined. |
| User claims two Brokers | Unique nullable Broker.userId prevents two owned records at database level if Mongo nullable index behaves correctly; explicit user-facing conflict policy still needed | Constraint exists; application handling absent. |

MongoDB transactions require a replica set/deployment capable of transactions. The project already uses `$transaction`, but no claim concurrency test or production index verification exists.

## 9. API Readiness Matrix

The API requirements document defines conceptual capabilities, not finalized HTTP contracts. The following is the minimum proposed surface derived from it, not implemented code:

| Capability | Method/route candidate | Auth | Transition/security |
|---|---|---|---|
| Validate/preview invitation | `GET /api/claims/:opaqueId` | Public token possession | No consumption; generic invalid/expired/revoked response; rate limit; safe profile projection. |
| Start claim/email submission | `POST /api/claims/:opaqueId/email` | Public with valid token, or authenticated existing User | Validate token; record STARTED/EMAIL_SUBMITTED; no owner mutation; prevent enumeration. |
| Claim account setup | Existing auth/setup path or `POST /api/auth/claim-setup` | Valid claim context | New/existing account path; secure password setup; email verification. Exact route is undefined. |
| Complete claim | `POST /api/claims/:opaqueId/complete` | Verified authenticated claimant | Atomic owner attach, USED invitation, COMPLETED claim/event, FREE retention. |
| Admin create invitation | `POST /api/admin/brokers/:id/claim-invitations` | ADMIN | Verify source/unowned; revoke/supersede prior active invitation; create digest/event; email after commit. |
| Admin revoke | `POST /api/admin/claim-invitations/:id/revoke` | ADMIN | ACTIVE -> REVOKED and event; no ownership mutation. |
| Admin status/history | Admin GET routes, exact path undefined | ADMIN | Return status/events without token hashes/raw tokens. |
| Resend | Admin action or invitation endpoint, exact path undefined | ADMIN, possibly support | Must follow single-active-invitation policy and rate limits. |

**[BLOCKING]** Exact routes, response schemas, session handoff, existing-user path, and whether email submission is separate from claim start must be approved before implementation.

## 10. Authentication Readiness

### Ready Foundations

- **[IMPLEMENTED]** NextAuth Credentials and Google providers exist.
- **[IMPLEMENTED]** User email/password, bcrypt, active account, email verification, reset tokens, and OAuth Account relation exist.
- **[IMPLEMENTED]** Broker login requires verified email.
- **[DOCUMENTED]** Claim must not create a second authentication system.

### Missing Decisions

- **[UNDEFINED/BLOCKING]** Whether a new claim User receives a session immediately after setup or must sign in.
- **[UNDEFINED/BLOCKING]** Whether an existing ordinary User changes role to BROKER during completion or only receives Broker ownership capability.
- **[UNDEFINED/BLOCKING]** Whether Google reauthentication is sufficient and whether a password is required for a Google-only claimant.
- **[UNDEFINED]** Whether account email may be changed after claim and whether Broker.email is synchronized.
- **[IMPLEMENTATION GAP]** Claim-specific auth context/token binding does not exist.

## 11. Email Readiness

### Existing Reusable Infrastructure

`sendEmail`, Resend configuration, idempotency keys, verification/reset templates, and email rate-limit helpers exist. Registration verification now stores token expiry and the verification endpoint consumes tokens once.

### Required Claim Templates (not implemented)

1. **Claim invitation:** company/display name, public profile URL, secure claim URL, expiry, explanation, support contact, no password/token in logs.
2. **Claim account setup/verification:** claimant email, setup/verification action, expiry, support, no password.
3. **Claim completion:** profile URL, successful ownership confirmation, dashboard link, FREE entitlement message.
4. **Existing-account claim notification:** only after a safe, authorized event; must not reveal claim details to an unverified/unauthorized address.

Variables, sender identity, resend policy, localization, and delivery failure behavior are not finalized. Raw invitation tokens must never be passed to logs, generic debug output, analytics, or event metadata.

## 12. MongoDB Constraint Analysis

| Invariant | Schema support | Gap |
|---|---|---|
| One current owner per Broker | Nullable unique `Broker.userId` | Verify multiple null index behavior in actual MongoDB. |
| One profile per User | Same unique `Broker.userId` | Application must handle duplicate-key conflicts safely. |
| Invitation digest uniqueness | `tokenHash @unique` | Ready structurally. |
| One Claim per Broker | `BrokerClaim.brokerId @unique` | Ready structurally. |
| One active invitation per Claim | No partial unique active-status constraint | **Blocking** policy/application serialization required. |
| Single claim completion | Used/status fields plus Broker unique owner | Transaction service required. |
| Preserve Broker identity | Child FKs remain Broker-based | Ready structurally. |
| Preserve claim audit | ClaimEvent references and timestamps | Append-only service policy required. |
| Prevent User deletion destroying Broker | Broker User relation `NoAction` | Offboarding behavior still needs implementation. |

## 13. Security Analysis

| Threat | Readiness | Required control |
|---|---|---|
| IDOR | Not ready | Resolve invitation by digest; never accept arbitrary Broker ID as ownership authority; target checks in every mutation. |
| Token leakage | Planned only | No raw logs/storage, HTTPS, strict referrer policy, redacted errors, short explicit TTL. |
| Token enumeration | Not implemented | High entropy, generic status responses, rate limits, consistent timing. |
| Account takeover | Blocking | Reauth existing users, verify submitted email, define Google/admin behavior, atomic completion. |
| Broker takeover | Not implemented | Conditional null-owner update and valid invitation requirement. |
| Email enumeration | Partially ready | Existing reset/registration patterns help; claim email flow needs uniform responses. |
| Privilege escalation | Not implemented | ADMIN-only invitation operations; owner checks by Broker.userId; no client role/source/plan trust. |
| CSRF | Architecture requirement only | Apply existing Next.js mutation protection/origin strategy to claim mutations. |
| Replay | Schema ready, service absent | `USED`/`usedAt` atomic terminal transition. |
| Race conditions | Schema partial | Transaction/conditional updates plus active-invitation policy. |
| Brute force/abuse | Existing rate-limit foundation | Add token/IP/email/invitation-specific limits. |
| Sensitive metadata | Event model allows Json | Sanitize metadata and prohibit token/email/password secrets. |

## 14. Edge-Case Matrix

| Edge case | Status | Reason |
|---|---|---|
| Already claimed Broker | PARTIALLY SUPPORTED | Business rule documented; no endpoint/service implementation. |
| Nonexistent Broker | PARTIALLY SUPPORTED | Generic Broker API patterns exist; claim behavior not implemented. |
| Nonexistent invitation | PARTIALLY SUPPORTED | Unique tokenHash schema exists; lookup behavior absent. |
| Expired invitation | PARTIALLY SUPPORTED | expiresAt exists; no validation/transition worker/service. |
| Revoked invitation | PARTIALLY SUPPORTED | revokedAt/status exist; no mutation service. |
| Used invitation | PARTIALLY SUPPORTED | usedAt/status exist; no atomic consumption. |
| Malformed token | UNDEFINED | Error/status contract not specified. |
| Duplicate claim | PARTIALLY SUPPORTED | BrokerClaim unique and owner unique; no application handling. |
| Duplicate email | PARTIALLY SUPPORTED | User unique email exists; claimant account policy undefined. |
| Existing User | BLOCKING | Existing ordinary/BROKER/ADMIN behavior not fully defined. |
| Inactive User | BLOCKING | Recovery/assisted path undefined. |
| Suspended Broker | PARTIALLY SUPPORTED | Public compatibility hides suspension; claim rejection is planned but not implemented. |
| Disabled Broker | PARTIALLY SUPPORTED | Business rule exists; claim invalidation service absent. |
| Missing Broker email | SUPPORTED | Claim invitation can target submitted/admin delivery address; exact admin form contact policy remains undefined. |
| Invitation resend | BLOCKING | Supersede/revoke is documented but concurrency/route behavior undefined. |
| Claim abandonment | PARTIALLY SUPPORTED | State outcome documented; cleanup/retention undefined. |
| Claim expiration | PARTIALLY SUPPORTED | Schema fields support it; transition service absent. |
| Simultaneous claim | BLOCKING | Requires transaction/conditional implementation and tests. |
| Admin revocation | PARTIALLY SUPPORTED | Status/event fields exist; admin endpoint absent. |
| Password creation | BLOCKING | New versus existing/Google account setup is undefined. |
| Google account | BLOCKING | Reauthentication and password/session behavior undefined. |
| Email verification failure | PARTIALLY SUPPORTED | Existing User verification can be reused; claim continuation behavior undefined. |

## 15. Admin-Created Profile Readiness

No admin creation operation currently exists. The future admin form must collect the required Broker fields: displayName, description, phone, officeAddress, city, state, and pinCode. It may collect companyName, contact email, website, branding, professional details, banks, and publication/verification inputs as separately authorized fields.

Server-controlled creation values:

```text
creationSource = ADMIN_CREATED
userId = null
subscription.plan = FREE
subscription.isActive = true
```

Verification and visibility must follow admin/publication policy. Admin creation must not create a User, password, OAuth account, claim completion, or PREMIUM entitlement.

## 16. Required Implementation Files

Future claim work will likely require:

- New admin Broker management route/page files.
- New claim service/repository under `lib`.
- New admin invitation/revoke/status API routes.
- New public claim preview/start/complete API routes.
- New account setup/association server action or auth route.
- `actions/email.action.ts` and `lib/email-templates.ts` claim templates.
- `lib/tokens.ts` claim token helper or a dedicated server-only claim token module.
- `lib/rateLimit.ts` claim abuse limits.
- `lib/auth.config.ts`/session handling for claim-created or associated accounts.
- Public claim landing and account setup pages.
- Admin claim status/history UI.
- Tests for state transitions, account scenarios, races, security, email, and profile preservation.

No file in this list was modified by this audit.

## 17. Required Tests

- Valid invitation preview does not consume token.
- Invalid/malformed/unknown token returns generic safe response.
- Expired/revoked/used invitations cannot proceed.
- Self-registered Broker cannot enter claim flow.
- Owned Broker cannot be claimed.
- Admin-created unowned Broker can be claimed without creating a second Broker.
- Broker ID/slug/reviews/leads/subscription remain unchanged after claim.
- New claimant account setup and email verification.
- Existing ordinary User reauthentication and role/capability outcome.
- Existing BROKER User with/without another profile.
- ADMIN claimant policy.
- Inactive/disabled User and Broker behavior.
- Google claimant behavior.
- Duplicate email/account handling and enumeration resistance.
- Two simultaneous completions yield one owner.
- Two invitation generations obey active-invitation policy.
- Revoke versus complete race.
- Expire versus complete race.
- Token hash uniqueness and raw-token non-persistence/log redaction.
- Admin-only invitation operations and IDOR protection.
- Claim event completeness and append-only behavior.
- FREE retention and no verification/subscription mutation.

## 18. Blocking Ambiguities

1. Exact claim token digest choice: SHA-256 versus HMAC is not selected.
2. Exact claim invitation lifetime is not specified.
3. Existing ordinary User claim behavior and role transition are not explicit.
4. Existing BROKER User with no profile versus another profile is not fully specified.
5. ADMIN claim eligibility is not specified.
6. Google-only claimant reauthentication/password behavior is not specified.
7. New claim User setup/session issuance and redirect behavior are not specified.
8. User-created-during-abandoned-claim retention and cleanup are not specified.
9. Broker.email versus submitted/User email authority and synchronization are not specified.
10. Exact HTTP routes, payloads, status codes, and separation of claim start/email/complete are not finalized.
11. One-active-invitation enforcement under concurrent admin sends is not enforceable by the current schema alone.
12. Admin edits or disables a Broker while a claim is in progress need conflict semantics.
13. MongoDB deployment/index behavior for nullable unique Broker.userId remains unverified in the target environment.

## 19. Recommended Implementation Order

1. Resolve the blocking business decisions above.
2. Verify MongoDB replica-set transactions and nullable unique index behavior in a non-production environment.
3. Finalize API contracts, status/error responses, rate limits, and event requirements.
4. Implement admin Broker creation with `ADMIN_CREATED`, null owner, and FREE entitlement.
5. Implement claim token issuance/digest validation and invitation state transitions.
6. Implement admin invitation generation, resend/supersede, revoke, and audit operations.
7. Implement public preview/start and account setup/association using existing auth.
8. Implement atomic claim completion and ownership race handling.
9. Implement claim emails and safe delivery/retry behavior.
10. Integrate public profile, dashboard, subscription, and email-owner behavior.
11. Add security, concurrency, account-scenario, migration, and profile-preservation tests.
12. Run a production-like MongoDB rehearsal before enabling the feature.

## 20. Final Readiness Decision

| Area | Decision | Basis |
|---|---|---|
| Prisma model | **READY WITH NON-BLOCKING ITEMS** | Core claim/invitation/event structures exist; active-invitation uniqueness and Mongo index behavior need implementation verification. |
| Authentication | **NOT READY** | Existing foundation is reusable, but existing-user/Google/admin/session claim behavior is undefined. |
| Email system | **NOT READY** | Provider is reusable, but claim templates/variables/delivery policy do not exist. |
| Invitation security | **NOT READY** | Schema supports it, but token implementation choice/lifetime and service do not exist. |
| Ownership transition | **NOT READY** | No atomic claim completion service exists. |
| MongoDB constraints | **READY WITH NON-BLOCKING ITEMS** | Unique digest/claim/owner structures exist; nullable unique and active invitation enforcement need rehearsal. |
| Race handling | **NOT READY** | No claim transactions, conditional updates, locks, or race tests exist. |
| Admin creation | **NOT READY** | No admin Broker creation path exists. |
| API design | **NOT READY** | Conceptual requirements exist, but exact contracts/routes and account scenarios are incomplete. |
| Test strategy | **READY WITH NON-BLOCKING ITEMS** | Required coverage is documented; no claim test harness or tests exist yet. |

**OVERALL CLAIM READINESS: NOT READY — BLOCKING ITEMS FOUND**
