# Database Impact

This document is a design review only. `prisma/schema.prisma`, data, generated clients, and migrations are unchanged.

## Current Schema Findings

### User
`User` is the authentication principal. It has a generated Mongo ObjectId, nullable unique email and phone, optional bcrypt password, image/name, `UserRole` (`USER`, `BROKER`, `ADMIN`), `isActive`, boolean `emailVerified`, one nullable `emailVerificationToken`, one nullable `resetPasswordToken` with `resetPasswordTokenExpiry`, timestamps, OAuth `Account[]`, broker profile, reviews, contacts, notifications, messages, support, and advertisement relations.

Current support:
- Credentials authentication: `email`, `password`, `isActive`.
- Email verification: `emailVerified`, `emailVerificationToken`.
- Password reset: `resetPasswordToken`, `resetPasswordTokenExpiry`.
- Google/OAuth: `Account` with unique `(provider, providerAccountId)`.

Current gap: verification token expiry is not persisted. The email action calculates an expiry but does not save it; verification infers age from `updatedAt`. This is an existing correctness issue relevant to both registration paths.

### Broker
`Broker.userId String @unique @db.ObjectId` is required, and `user User @relation(fields: [userId], references: [id])` is required. Profile slug is unique. Broker owns profile content, contact/review/bank relations, one optional subscription, trust fields, `BrokerStatus`, visibility, counters, and timestamps.

Current ownership is therefore implied by a mandatory one-to-one relation. The schema cannot represent Path A before claim.

### BrokerSubscription
`BrokerSubscription.brokerId` is required, unique, and references Broker. It contains `plan` (`FREE`, `FEATURED`), `isActive`, start/end dates, Stripe customer/subscription IDs, and timestamps. The Prisma enum retains historical `PREMIUM` for migration compatibility, but it is not an active commercial plan. The durable `StripeWebhookEvent` model provides event idempotency and lifecycle state.

### BrokerBank, Review, ContactMessage
- `BrokerBank.brokerId` is required and indexed; bank rows belong to the profile, not the user.
- `Review.brokerId` is required; reviewer `userId` is optional. Reviews survive ownership changes.
- `ContactMessage.brokerId` is required; sender `userId` is optional. This is the implemented lead/contact model. There is no `Lead` model despite an unused `LeadStatus` enum and denormalized `Broker.totalLeads`.
- All three relations should remain anchored to Broker so both onboarding paths converge on one profile identity.

### Authentication Relations
`Account.userId` is required and has explicit `onDelete: Cascade`, so deleting a User deletes OAuth accounts. Other User relations use required foreign keys but generally do not specify explicit delete behavior. The User-Broker relation has no explicit `onDelete`; future behavior must be chosen deliberately rather than inferred from an accidental provider default.

### Verification and Payment
There is no separate database verification model. Broker trust uses `Broker.verificationStatus` and `verifiedAt`; account email verification uses User fields. There is no payment/invoice model; Stripe IDs and current entitlement fields live on BrokerSubscription, with Stripe webhook synchronization in application code.

## Required Ownership Decision

`Broker.userId` must become optional for admin-created unowned profiles:

```text
ADMIN_CREATED before claim: userId = null
SELF_REGISTERED:             userId = User.id
CLAIMED admin profile:       userId = User.id
```

Do not add `isOwned`, `hasOwner`, or `isClaimed`. Ownership is derivable from the nullable current-owner relation. A separate claim status would be redundant and incorrect because self-registered profiles are owned without being claimed. If future multi-owner/team support is introduced, replace the one-to-one relation with an ownership model deliberately; do not pre-build it in this phase.

## Creation Source Recommendation

Store an enum on Broker: `ADMIN_CREATED` or `SELF_REGISTERED`.

It cannot be inferred safely after migration: an existing broker with a user might have been seeded, created through setup, or imported. The source controls whether a claim is permitted, is needed for admin reporting and support, and is part of the durable business history. Add an index only if admin queues/filtering are expected; the recommended compound operational index is creation source with ownership/publication state, not a standalone index by default.

## Claim Data Model Recommendation

Use three layers with distinct responsibilities:

1. `BrokerClaim` stores the current claim process for an admin-created Broker. One-to-one with Broker. It stores current status (`INVITED`, `IN_PROGRESS`, `COMPLETED`, `EXPIRED`, `REVOKED`, `FAILED`), timestamps, and completion user. A self-registered profile has no claim row; its conceptual state is `NOT_REQUIRED`.
2. `BrokerClaimInvitation` stores each issued secure invitation. Many invitations can exist historically for one claim, but only one should be active under the application policy. It stores the token digest, expiry, status, created-by admin, used/revoked timestamps, and timestamps. It does not store plaintext tokens.
3. `BrokerClaimEvent` stores append-only lifecycle events: generated, sent, opened, started, email-submitted, verification-pending, completed, expired, revoked, and failed. It stores broker/claim/invitation references, optional actor user/admin, event type, occurred time, and sanitized metadata. This is the claim audit/history needed for support and security investigations.

A generic platform audit model may also record admin profile edits, publication, verification, suspension, and billing overrides. Do not use the generic audit row as a substitute for the token invitation record: security validation needs a current invitation row and claim history needs structured events.

### Minimal Invitation Fields
Recommended minimum: `id`, `brokerClaimId`, `brokerId` if direct querying is needed, `tokenHash` unique, `status`, `expiresAt`, `usedAt`, `revokedAt`, `createdById`, `createdAt`, and `updatedAt`. Add `consumedByUserId` only if operational reporting needs the user without relying on the completion event. A target-email hash is optional and should not be used as ownership proof.

The current claim status can be stored on BrokerClaim; invitation status records token-specific revocation/consumption. Do not use a single token row as the whole claim history.

## Token Security Storage

- Generate at least 32 cryptographically random bytes and send the raw base64url value only in the HTTPS claim URL.
- Store a SHA-256 digest, or an HMAC digest if a server-side secret is part of the lookup design; never store raw token text.
- Look up by the digest and validate status, expiry, profile creation source, current ownership, and claim eligibility.
- Make `tokenHash` unique. A digest collision is treated as a failed issuance and retried.
- Store `usedAt` and/or terminal status. Completion must atomically change invitation and claim state while conditionally setting Broker.userId only when null.
- Store `revokedAt` for explicit revocation and `expiresAt` for deterministic expiry. Expiration can be materialized by a request/job, but validation must always compare time.
- Do not require a public database identifier in the URL; an opaque raw token is sufficient for lookup. Internal IDs remain server-side.
- Use indexes on token hash, broker claim/status, and expiry. A unique active-invitation constraint may require application-level conditional enforcement because MongoDB/Prisma partial-index behavior must be verified before relying on it.

## Subscription Recommendation

Reuse `BrokerSubscription`; do not add a second FREE subscription system. Every Broker should have one FREE entitlement row at the point required by the finalized activation policy, and paid upgrades update that same row. For Path A, create/retain FREE at profile creation or successful claim according to the final product timing; for Path B, create FREE in the registration transaction. The important invariant is that both paths resolve to one BrokerSubscription row and `PREMIUM` expiry is represented as FREE, not as no ownership or no profile.

Potential additions are status/period fields and a separate processed-Stripe-event model for idempotency. Do not add ownership or claim fields to BrokerSubscription. Do not derive verification from plan. The current `applySubscriptionFeatures` behavior that sets verification and visibility from paid plan is a business-rule violation to correct in a later implementation phase.

## Transaction Boundaries

### Self-Registration
One database transaction should cover:
1. normalized duplicate checks and User creation;
2. Broker creation with `userId`, `SELF_REGISTERED`, and initial profile state;
3. FREE BrokerSubscription creation/upsert;
4. optional initial bank rows if part of the submitted registration.

Email delivery occurs after commit. A provider failure leaves a pending, owned user/profile/FREE record and must be recoverable by resend; it must not roll back a committed identity based on an external side effect.

### Claim
Account creation/find, verification completion, eligibility checks, claim event writes, invitation consumption, claim completion, Broker.userId attachment, and FREE entitlement creation/retention must be coordinated. The ownership mutation and invitation consumption must be one atomic transaction or a conditional compare-and-set sequence with equivalent guarantees. Email delivery is outside the transaction. Do not hold a database transaction open while sending email.

MongoDB transactions require deployment support such as a replica set; this must be verified before implementation because the existing code already uses `$transaction`.

## Downstream Consequences of Nullable userId

Every current `broker.user` dereference becomes nullable and must be reviewed:
- public listing, featured listing, slug page, and `/api/brokers/[id]` currently filter on or read `user.isActive`;
- contact sending rejects brokers without a user and notifications address `broker.user.email`;
- verification and review/subscription emails assume a user email;
- PATCH/DELETE routes compare `broker.userId` and update `user` by that ID;
- `/api/brokers/me`, dashboard, company pages, contact APIs, and subscription routes resolve profiles through a user-owned relation;
- auth session serialization assumes a user-side broker profile but is safe for ordinary users returning null;
- seeds create every Broker with a user and will need explicit source/ownership values later.

Public reads should use a centralized publication predicate and allow null owner only when policy permits. Owner-only operations must reject null ownership. Admin operations must not dereference a user to manage an unowned profile. Email functions must use Broker.email or defer delivery when no owner exists.

## Delete and Cascade Policy

- Deleting a User must not delete the Broker profile by default. The profile is a durable marketplace record; ownership should be detached or the account deletion should be blocked/handled by an explicit support workflow. Do not add cascade from User to Broker.
- Deleting a Broker is not a normal user action. Prefer soft disable/archive and retain reviews, contacts, subscription history, claim events, and audit records. If physical deletion is ever approved, define child retention/anonymization first.
- Deleting/revoking a claim invitation does not delete the BrokerClaim or event history; it invalidates only that invitation.
- Subscription expiry/cancellation updates entitlement state; it does not delete Broker, ownership, reviews, leads, or claim history.
- Existing explicit `Account -> User onDelete: Cascade` is appropriate for OAuth credentials but does not establish a safe policy for Broker or business records.

## Migration Summary

The safe direction is: add new nullable/optional structures first, classify existing records, make ownership optional only after code/query compatibility is prepared, backfill FREE/source values, then enable admin-created records. Full sequencing is in `23-DATABASE-MIGRATION-PLAN.md`.
