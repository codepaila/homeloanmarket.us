# Phase 7 Claim Implementation Report

## Status

**PASS WITH NON-BLOCKING ISSUES**

The claimant-side claim flow is implemented without changing the ownership/subscription business model. Claim completion updates only the existing Broker's `userId`; no replacement Broker is created.

## Routes Created

- `GET /api/claims/:token`
- `POST /api/claims/:token/start`
- `GET /api/claims/session`
- `POST /api/claims/session/email`
- `POST /api/claims/session/reauth`
- `POST /api/claims/session/complete`
- `POST /api/auth/claim-setup`
- `/claim-broker/:token`
- `/claim-broker/continue`

The proxy was updated to allow public claim-link and claim-session routes. No admin invitation-management route was removed or redesigned.

## Services and Infrastructure

- `lib/claim-context.ts`: signed HttpOnly 30-minute claim context cookie.
- `lib/claim-flow.ts`: invitation validation, safe profile projection, event helpers, account classification.
- `lib/claim-completion.ts`: atomic ownership attachment service.
- Existing `lib/tokens.ts`, Prisma models, NextAuth, Credentials, Google, bcrypt, rate limiting, and email transport reused.

## Claim Preview and Start

Claim preview hashes the raw token with SHA-256 and looks up the invitation by digest. It validates invitation status, expiry, claim state, Broker source, ownership, and suspension. Safe Broker profile data is returned without token hashes, leads, admin metadata, or secrets.

Start changes an eligible claim to `IN_PROGRESS`, records STARTED, and establishes a signed Secure HttpOnly 30-minute context. The context contains claim identifiers, token digest binding, expiry, and the claimant email after submission. It contains no password or credential.

## Claimant Account Handling

- New email: `POST /api/auth/claim-setup` creates a BROKER User with bcrypt password and unverified email, without creating a Broker.
- Existing ordinary User: can reauthenticate and complete after verified email; completion promotes the User to BROKER.
- Existing BROKER without a Broker: eligible after verification/reauthentication.
- Existing BROKER with a Broker: rejected.
- ADMIN: rejected from self-service completion.
- Google-only: supported through Google provider reauthentication context without requiring a password.
- Inactive users: rejected.

## Email Verification

Claim setup uses existing User email verification fields and expiry. Verification clears the token/expiry and redirects to claim continuation when a claim context exists. Email verification remains independent from `Broker.verificationStatus`.

Existing ordinary users without a Broker can use the generalized resend verification path.

## Ownership Transaction

`completeClaimForUser` rechecks inside the transaction:

- invitation exists and token digest matches context;
- invitation is ACTIVE and unexpired;
- claim is not completed;
- Broker is still unowned;
- Broker remains ADMIN_CREATED and eligible;
- User is active, email-verified, authenticated, and not ADMIN;
- User does not already own another Broker;
- recent claim reauthentication exists.

Then it atomically:

- conditionally updates `Broker.userId` only where null;
- marks BrokerClaim COMPLETED;
- sets completion user/timestamp;
- marks invitation USED;
- sets `usedAt`;
- records COMPLETED event;
- promotes eligible ordinary User to BROKER.

It does not modify Broker ID, slug, profile data, reviews, leads, subscription, verification, visibility, or payment state.

## Race Handling

The isolated MongoDB integration suite verifies two concurrent claimants produce exactly one successful owner. Final completion re-reads invitation state inside the transaction, preventing stale pre-read completion after revoke/expiry. Unique ownership constraints and conditional `userId=null` update remain final authority.

## Invitation Handling

Existing Phase 6.8 invitation issuance/resend/revoke remains authoritative:

- 32-byte secure token;
- SHA-256 digest only;
- seven-day expiry;
- one active invitation;
- supersede/revoke behavior;
- recipientEmail persistence;
- claim events;
- no claimant completion during admin issuance.

## UI

Claimant UI now provides:

- invitation validation/preview;
- existing profile identity explanation;
- claim start;
- claimant email submission;
- new password account setup;
- existing password account sign-in/reauthentication;
- Google continuation;
- verification pending state;
- claim continuation;
- success redirect to `/broker/dashboard`;
- invalid, expired, revoked, ineligible, and error states.

## Security Controls

- Raw token is hashed immediately and never persisted/logged/evented.
- Claim context is signed, HttpOnly, Secure in production, SameSite=Lax, and expires after 30 minutes.
- Claim completion does not accept Broker ID or User ID from the client.
- Email matching is not ownership proof; invitation context is mandatory.
- Existing-user completion requires recent reauthentication and verified email.
- ADMIN self-claim is rejected.
- Existing ownership conflicts are rejected without detach/transfer.
- Completion is conditional and transactional.
- Claim events contain safe metadata only.
- Production claim contexts fail closed when `NEXTAUTH_SECRET` is absent; no development fallback is used in production.
- Claim email submission and new-account setup reuse existing rate-limit infrastructure.

## Tests Executed

Focused unit/policy tests:

- 16 passed, 0 failed.

MongoDB replica-set integration tests:

- Claim completion profile/subscription preservation: passed.
- Two-claimant race: exactly one winner, passed.
- Prior Phase 6.5 ownership/invitation integration tests: 7 passed.

## Validation

- `npx prisma validate`: PASS
- `npx prisma generate`: PASS
- focused ESLint: PASS
- claim unit tests: PASS
- claim MongoDB integration tests: PASS
- `npx tsc --noEmit`: FAIL due pre-existing errors only

Pre-existing TypeScript errors:

- six missing `.next/dev/types/validator.ts` route modules;
- existing `prisma.config.ts` `seed` property typing issue.

No new Phase 7 TypeScript errors were introduced.

## Known Limitations

- No authenticated HTTP integration harness exists for ADMIN/USER/BROKER/unauthenticated endpoint testing.
- Real Resend/email provider delivery was not executed.
- Google OAuth reauthentication requires configured provider credentials and was not externally exercised.
- Existing ordinary-user verification and claim continuation are implemented through shared routes but need browser/provider integration coverage.
- Claim event cleanup/expiration materialization remains request-time/application responsibility.

The production build reaches successful application compilation but stops at the pre-existing `prisma.config.ts` `seed` typing error. The six existing missing `.next/dev/types/validator.ts` route references also remain.

## Final Phase Boundary

Phase 7 does not redesign subscriptions, verification, visibility, ownership, or self-registration. Admin invitation management remains separate. No Phase 8 work was started.
