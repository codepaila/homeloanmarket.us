# Phase 13.9 Demo Media Rebuild — Audit

## Problem

The project had no images under `public/demo-images`, but legacy references such as `/demo-images/Advertisements/hero-1.webp` returned 404. The seed/media system assumed local placeholder files that did not exist.

## Audit Findings

- `prisma/seed/download-images.ts` generated local placeholder WebP files under `public/demo-images` and referenced that directory.
- `public/demo-images/` contained obsolete placeholder folders (Advertisements, Banks, Brokers, Blog, General, Homepage, Properties, Testimonials).
- `next.config.ts` already allowed `images.unsplash.com` via `remotePatterns`.
- Broker/ad/blog imagery in the seed (Phase 13.8) already used stable `images.unsplash.com` URLs, but scattered as local constants rather than a single catalog.

## Actions

1. Deleted `prisma/seed/download-images.ts` (obsolete local image generator).
2. Deleted `public/demo-images/` (obsolete placeholder assets; legitimate `public/assets` and SVGs retained).
3. Created `prisma/seed/demo-images.ts` as the single authoritative Unsplash catalog.
4. Refactored `prisma/seed/seed-demo.ts` to consume `DEMO_IMAGES` for broker logos/covers, advertisements, blogs, and media records.

## Catalog

- Brokers: 8 professional portraits.
- Broker covers: 5 US city skyline images.
- Advertisements: hero 4, sidebar 3, inline 3, footer 2, announcement 2, popup 1, mobile 2, button 1 (18 total).
- Blogs: 8 mortgage/home-finance images.
- Properties: 6.
- Testimonials: 3.
- Homepage: 5.

All URLs are deterministic HTTPS `images.unsplash.com` URLs with fixed photo IDs (no `source.unsplash.com`, no random endpoints).

## Verification

- Zero `/demo-images` references remain in `prisma`, `app`, `components`, `lib`, `actions`, `hooks`, `tests`, or `next.config.*`.
- Zero references to `hero-1.webp`, `announcement-1.webp`, `broker-1.webp`, `blog-1.webp`, `property-1.webp`, `testimonial-1.webp`.
- `next.config.ts` allows only `images.unsplash.com` (no wildcard hosts).
