# Claim Contract

This document is the authoritative implementation contract for the next claim phase. It resolves the blocking decisions in `32-CLAIM-READINESS-AUDIT.md`. It is design only; no claim functionality is implemented here.

## 1. Purpose

HomeLoanMarket allows an authorized company representative to take ownership of an existing `ADMIN_CREATED` Broker profile through a secure invitation. Claiming updates only the existing Broker's nullable `userId`. It never creates, copies, or replaces a Broker.

## 2. Actors

| Actor | Claim authority |
|---|---|
| ADMIN | Create eligible Broker profiles, issue/resend/revoke invitations, inspect status/history, and perform documented assisted support. |
| Anonymous claimant | Preview/start a valid invitation and submit intended email through the claim context. |
| Existing eligible User | Reauthenticate and complete claim if account rules permit. |
| New claimant | Complete password/account setup, verify email, then complete claim. |
| BROKER User | May claim only if not already connected to another Broker. |
| ADMIN User | May not complete ordinary self-service claims. Admin-assisted handling is separate and audited. |
| Public borrower | No claim authority. |

## 3. Admin Broker Creation

### Required fields

`displayName`, `description`, `phone`, `officeAddress`, `city`, `state`, and `pinCode`.

### Optional fields

`companyName`, `email`, `whatsapp`, `website`, `logo`, `coverImage`, `experienceYears`, `specializations`, `serviceCities`, `languages`, `registrationNumber`, `panNumber`, and publication/verification inputs subject to admin permissions.

### Server-controlled initial values

```text
creationSource = ADMIN_CREATED
userId = null
brokerStatus = FREE
verificationStatus = UNVERIFIED
isVisible = false
BrokerSubscription.plan = FREE
BrokerSubscription.isActive = true
BrokerSubscription.endDate = null
```

The profile is initially unpublished to prevent incomplete admin records from appearing accidentally. Admin may publish it after required data and publication policy pass. Publishing an unowned profile is allowed and does not require a User.

### Slug and duplicates

Generate a URL-safe slug from `companyName` when present, otherwise `displayName`. If the base slug is occupied, append a deterministic numeric suffix. Existing slugs are never overwritten. An exact duplicate business record is an admin review concern; the database identity remains distinct unless the admin explicitly cancels creation.

### Authorization and audit

Only an active ADMIN may create or publish an admin profile. Every creation, edit, publish, verify/unverify, suspend, disable, invitation, revoke, and assisted action must record actor, target, action, reason where applicable, and timestamp using the platform audit mechanism selected for implementation. Claim events cover invitation/claim actions; generic profile audit is a separate operational requirement.

## 4. Broker Initial State

An admin-created profile can be:

```text
Broker.userId = null                 # UNOWNED
Broker.creationSource = ADMIN_CREATED
Broker.verificationStatus = UNVERIFIED
Broker.isVisible = false             # initial publication state
BrokerSubscription = FREE_ACTIVE
BrokerClaim row = absent until first invitation
```

Once explicitly published, `isVisible=true` and the central public predicate applies. Claiming does not alter publication, verification, subscription, profile data, URL, reviews, leads, or counters.

## 5. Invitation Lifecycle

### Issuance

Admin issuance creates or reopens the existing BrokerClaim process and creates one ACTIVE BrokerClaimInvitation. Any previous ACTIVE invitation for that claim is atomically marked REVOKED and receives an INVITATION_REVOKED event with reason `SUPERSEDED`. The new invitation receives GENERATED and SENT events. The normalized operational recipient is persisted as `BrokerClaimInvitation.recipientEmail`; it is not ownership proof. Broker creation itself never issues this invitation.

### Lifetime

An invitation is valid for **7 days** from creation. Expiry is checked on every claim operation. A cleanup job may materialize EXPIRED status, but cleanup is not required for security because request-time expiry is authoritative.

### One active invitation

Only one ACTIVE invitation may exist for a BrokerClaim. Reissue always supersedes older ACTIVE invitations. Concurrent issuance is serialized by a distributed lock keyed by `brokerClaimId` using the existing Redis/Upstash infrastructure, followed by a database transaction. If the lock cannot be acquired, return a retryable conflict without issuing a second invitation.

### Consumption and revocation

Successful completion atomically changes the invitation to USED and sets `usedAt`. Revocation changes ACTIVE to REVOKED and sets `revokedAt`. USED, EXPIRED, and REVOKED invitations cannot be reactivated or consumed. A new invitation may be issued after expiry/revocation.

## 6. Token Security

### Exact strategy

Use **SHA-256**. This matches the existing verification-token architecture and is sufficient because the raw claim token has high entropy and is never used as a low-entropy password.

- Generate 32 cryptographically secure random bytes with `crypto.randomBytes(32)`.
- Encode the raw token as base64url for the HTTPS URL.
- Hash the raw token with SHA-256.
- Store the lowercase hexadecimal digest in `BrokerClaimInvitation.tokenHash` only.
- Look up by digest; never look up by Broker ID supplied by the claimant.
- Enforce the existing unique `tokenHash` constraint.

HMAC is not used for this contract. A future key-management decision would be a separate security change.

### Handling rules

- Raw token is sent only in the claim link.
- Raw token is never stored, logged, placed in event metadata, or sent to analytics.
- Claim URLs use HTTPS and a strict referrer policy.
- Errors are generic and do not reveal whether a Broker, invitation, or account exists.
- Token preview/start/complete endpoints are rate-limited by IP, token digest/session, and account email where available.

## 7. Claimant Account Rules

| Case | Decision |
|---|---|
| Email does not exist | ALLOWED. Create a new User with role BROKER, email, `emailVerified=false`, active pending account, and secure password setup. Complete ownership only after email verification. |
| Email belongs to ordinary USER | ALLOWED with reauthentication. Require the authenticated User email to equal the submitted email, require `emailVerified=true`, then promote role to BROKER in the completion transaction. |
| Email belongs to BROKER with no Broker profile | ALLOWED with reauthentication and verified email. Attach the existing User to the invited Broker. |
| Email belongs to BROKER with another Broker | DENIED under the one-profile-per-User rule. Provide a support/admin-review path without detaching the existing profile. |
| Email belongs to ADMIN | DENIED for ordinary self-service. Admin-assisted transfer is separate, requires explicit support evidence and audit, and is not part of the initial claim flow. |
| Email belongs to inactive User | DENIED. Account must be restored by support before a new claim attempt. |
| Email belongs to Google-only account | ALLOWED if the User is active, Google reauthentication succeeds, and the provider-verified email equals the submitted email. No password is required for a Google-only account. |
| Email belongs to password account | ALLOWED with fresh Credentials reauthentication and verified email. |
| Claimant owns another Broker | DENIED; no silent detach or transfer. |

No claimant may claim by presenting only `brokerId` and an email. The valid invitation and claim context are mandatory.

## 8. Email Rules

`Broker.email` and `User.email` are independent.

- Claim email does not need to match `Broker.email`.
- `Broker.email` is profile contact data, not proof of ownership.
- For a new account, claim email becomes `User.email`.
- For an existing account, submitted email must match `User.email` case-insensitively.
- Claiming does not overwrite or copy `Broker.email`.
- The owner may edit Broker contact email later through normal authorized profile management.
- Invitation delivery address is supplied by the admin and is not authoritative ownership data.

## 9. Authentication Rules

The flow uses existing NextAuth/User/Account/Credentials/Google/bcrypt infrastructure. A short-lived claim context is workflow state, not a second identity system.

### Sequence

1. Anonymous claimant requests invitation preview with token.
2. Server validates digest/status/expiry/profile eligibility without consuming.
3. Claimant starts claim; server records OPENED/STARTED as appropriate and sets a signed HttpOnly claim-context cookie.
4. Claim context lasts **30 minutes**, contains only claim/invitation identifiers, token digest binding, issued-at, and expiry, and is signed with the existing server auth secret. Raw token is not stored in the cookie.
5. Claimant submits email through the claim context.
6. New claimant completes password setup and email verification, or existing claimant reauthenticates/uses Google provider.
7. Authenticated verified claimant completes claim.
8. Server atomically attaches ownership and clears claim context.
9. Server redirects to sign-in for a new account or issues/refreshes the existing authenticated session only after successful completion, according to the existing NextAuth sign-in flow.

Claim context cookies are Secure in production, HttpOnly, SameSite=Lax, scoped to the claim flow, and rejected after expiry, completion, or terminal invitation state.

## 10. Ownership Rules

Ownership is only `Broker.userId`:

```text
null     = UNOWNED
User.id  = OWNED
```

Completion must never create a Broker. It must use a conditional update equivalent to:

```text
update Broker
where id = targetBroker AND userId IS NULL
set userId = eligibleUser.id
```

The same transaction must validate invitation ACTIVE/unexpired, claim eligibility, User eligibility, and one-profile ownership before marking completion. Unique `Broker.userId` remains the database backstop.

## 11. Claim State Machine

| Current | Action | Required condition | Next | Actor | Event |
|---|---|---|---|---|---|
| absent | issue invitation | ADMIN_CREATED, unowned, eligible Broker | INVITED | ADMIN | GENERATED, SENT |
| INVITED | start | ACTIVE invitation, valid digest, before expiry | IN_PROGRESS | claimant | OPENED, STARTED |
| IN_PROGRESS | submit email | claim context valid, input valid | IN_PROGRESS | claimant | EMAIL_SUBMITTED |
| IN_PROGRESS | require verification | new/unverified claimant path | IN_PROGRESS | system | VERIFICATION_PENDING |
| IN_PROGRESS | complete | verified eligible User, Broker still unowned, invitation ACTIVE | COMPLETED | claimant/system | COMPLETED |
| INVITED/IN_PROGRESS | expiry check | now >= 7-day deadline | EXPIRED | system | EXPIRED |
| INVITED/IN_PROGRESS | revoke/supersede | ADMIN authorization | REVOKED, or new invitation reopens to INVITED | ADMIN | REVOKED |
| INVITED/IN_PROGRESS | unrecoverable failure | reason recorded, no ownership mutation | FAILED | system/admin | FAILED |
| EXPIRED/REVOKED/FAILED | reissue | ADMIN creates fresh invitation and Broker remains unowned | INVITED | ADMIN | GENERATED, SENT |
| COMPLETED | any claim/reissue | already owned | invalid/no transition | any | optional FAILED security event |

`FAILED` may be reopened only by an explicit admin reissue. `COMPLETED` can never reopen through the ordinary claim flow.

## 12. Invitation State Machine

| Current | Action | Required condition | Next | Actor | Event |
|---|---|---|---|---|---|
| absent | issue | authorized admin and eligible claim | ACTIVE | ADMIN/system | GENERATED, SENT |
| ACTIVE | open/start | digest valid and before expiry | ACTIVE | claimant | OPENED/STARTED |
| ACTIVE | complete | atomic ownership completion succeeds | USED | claimant/system | COMPLETED |
| ACTIVE | expiry | deadline reached | EXPIRED | system | EXPIRED |
| ACTIVE | revoke | admin revoke/supersede | REVOKED | ADMIN | REVOKED |
| USED/EXPIRED/REVOKED | any reuse | terminal status | no transition | any | generic failure response |

## 13. API Contracts

All mutation routes use JSON, server-side validation, generic security errors, CSRF/origin protection, audit events, and rate limits. No route accepts role, User ID, Broker owner, source, plan, verification, or Stripe fields from a claimant.

### Admin create

`POST /api/admin/brokers`

- **Auth:** active ADMIN.
- **Request:** required/optional profile fields from Section 3; optional `publish` and verification request subject to admin policy.
- **Response 201:** `{ broker: { id, profileSlug, creationSource, userId, verificationStatus, isVisible }, subscription: { plan: "FREE", isActive: true } }`; no secret fields.
- **Errors:** 401, 403, 409 slug/business conflict, 422 validation.
- **Transition:** creates ADMIN_CREATED, unowned, FREE profile.
- **Audit:** admin profile-created event.
- **Rate limit:** admin/profile creation limit, e.g. 20 per admin/hour.

### Issue invitation

`POST /api/admin/brokers/:brokerId/claim-invitations`

- **Auth:** active ADMIN.
- **Request:** `{ deliveryEmail: string }` and optional admin note; note cannot contain secrets.
- **Response 201:** `{ claimId, invitationId, expiresAt, status: "ACTIVE", delivery: "queued" }`; raw token is never returned.
- **Errors:** 401, 403, 404, 409 owned/ineligible, 422 invalid email, 429 rate limit.
- **Transition:** active prior invitation -> REVOKED; new claim -> INVITED; new invitation -> ACTIVE.
- **Audit:** GENERATED, SENT, REVOKED for superseded invitations.
- **Rate limit:** per admin and Broker claim lock.

### Resend/supersede invitation

`POST /api/admin/claim-invitations/:invitationId/resend`

- **Auth:** active ADMIN.
- **Request:** `{ deliveryEmail?: string }`; if absent, admin must provide the stored/approved delivery address from the operational system.
- **Response 201:** new invitation ID and expiry; old invitation is REVOKED.
- **Errors:** 401, 403, 404, 409 completed/owned, 429 abuse/concurrency.
- **Transition:** old ACTIVE -> REVOKED; new -> ACTIVE; claim -> INVITED.
- **Audit:** REVOKED, GENERATED, SENT.

### Revoke invitation

`POST /api/admin/claim-invitations/:invitationId/revoke`

- **Auth:** active ADMIN.
- **Request:** `{ reason: string }`.
- **Response 200:** `{ invitationId, status: "REVOKED" }`.
- **Errors:** 401, 403, 404, 409 already USED/terminal, 422 missing reason.
- **Transition:** ACTIVE -> REVOKED; in-progress claim becomes blocked but remains historically visible.
- **Audit:** REVOKED.

### Preview invitation

`GET /api/claims/:token`

- **Auth:** anonymous.
- **Request:** raw token in HTTPS path; never a Broker ID.
- **Response 200:** safe profile preview, `claimStatus`, invitation expiry, and `canStart`; no owner/private lead/token-hash data.
- **Errors:** generic 404/410 for invalid, malformed, expired, revoked, used, owned, or disabled targets.
- **Transition:** none; GET never consumes.
- **Audit:** no event or optionally OPENED only on explicit start, not preview.
- **Rate limit:** IP plus token digest.

### Start claim

`POST /api/claims/:token/start`

- **Auth:** anonymous or existing authenticated User.
- **Request:** no privileged fields; optional client context is sanitized.
- **Response 200:** `{ claimSession: "established", profile: safePreview, next: "EMAIL" }` with signed HttpOnly cookie.
- **Errors:** generic invalid/expired/revoked/owned responses, 429.
- **Transition:** INVITED -> IN_PROGRESS; invitation stays ACTIVE.
- **Audit:** OPENED and STARTED.

### Submit claim email

`POST /api/claims/session/email`

- **Auth:** valid claim context cookie; existing User may also be authenticated.
- **Request:** `{ email: string }` only.
- **Response 202:** generic `{ next: "ACCOUNT_SETUP_OR_REAUTHENTICATION" }`; never states whether account exists.
- **Errors:** generic 400/404/409/410/429; no email enumeration.
- **Transition:** remains IN_PROGRESS.
- **Audit:** EMAIL_SUBMITTED and, when needed, VERIFICATION_PENDING.

### Claim account setup

`POST /api/auth/claim-setup`

- **Auth:** valid claim context; new-account path only.
- **Request:** `{ password: string }`; email comes from claim context, not client authority.
- **Response 202:** `{ next: "VERIFY_EMAIL" }`.
- **Errors:** generic invalid context, password validation, duplicate/race, 429.
- **Transition:** remains IN_PROGRESS; creates User with BROKER role only within the controlled claim context, but does not attach Broker yet.
- **Audit:** VERIFICATION_PENDING.

### Complete claim

`POST /api/claims/session/complete`

- **Auth:** valid claim context plus authenticated eligible User with required verified email/reauthentication.
- **Request:** no Broker ID or User ID; all target identity comes from claim context/session.
- **Response 200:** `{ success: true, brokerId, profileSlug, subscriptionPlan: "FREE", redirectTo: "/broker/dashboard" }`.
- **Errors:** 401, generic 403/404/409/410, 429. Duplicate completion is a safe conflict.
- **Transition:** Broker userId null -> current User ID; claim -> COMPLETED; invitation -> USED.
- **Audit:** COMPLETED.
- **Transaction:** conditional Broker ownership update, claim completion, invitation consumption, event, and FREE retention.

## 14. Email Contracts

### Claim invitation

- **Recipient:** admin-supplied delivery email.
- **Subject:** “Claim your HomeLoanMarket profile”.
- **Variables:** company/display name, safe public profile URL, claim URL, expires-at/date, support address.
- **CTA:** open claim profile.
- **Security wording:** link is single-use, expires in seven days, do not forward, HomeLoanMarket never emails passwords.

### Claim verification/setup

- **Recipient:** submitted new-account email or existing account email.
- **Variables:** display name, verification/setup URL, expiry, support address.
- **CTA:** verify email or set password.
- **Security wording:** do not share the link; no password is included.

### Claim completion

- **Recipient:** verified User.email.
- **Variables:** profile/company name, unchanged public profile URL, dashboard URL, FREE entitlement.
- **CTA:** open dashboard.

Raw tokens are never included in logs or event metadata. Email delivery occurs after database commits and is retryable.

## 15. Race Conditions

1. **Two claimants/same invitation:** transaction checks invitation ACTIVE and Broker.userId null; conditional owner update permits one winner; loser gets 409.
2. **Two completions:** same conditional update and unique owner constraint; one winner, one conflict.
3. **Two invitations:** Redis claim lock plus transaction; only one ACTIVE remains.
4. **Admin revokes during claim:** revoke and completion both conditionally require ACTIVE; whichever transaction commits first wins, the other conflicts.
5. **Expiry during completion:** compare expiresAt inside transaction; expired invitation cannot complete.
6. **Admin changes Broker:** completion re-reads source, owner, disabled/suspended/policy state; invalid target conflicts.
7. **User created twice:** normalized unique email/phone plus claim-context idempotency key; duplicate-key is safe conflict.
8. **User claims two Brokers:** precheck existing ownership and retain unique `Broker.userId` as final backstop; second completion conflicts.

## 16. Security Requirements

- Never trust claimant-supplied Broker ID, User ID, role, source, plan, verification, or owner values.
- Resolve target solely from validated invitation digest and server-side claim context.
- Use 32-byte random tokens and SHA-256 hex digests.
- Seven-day expiry and one-use terminal status are mandatory.
- Generic errors prevent token/account/Broker enumeration.
- Rate-limit preview, start, email submission, setup, completion, admin issuance, resend, and revoke.
- Use Secure/HttpOnly/SameSite claim context cookies and CSRF/origin protection on mutations.
- Redact tokens, passwords, full URLs, and sensitive email metadata from logs/events.
- Require ADMIN for admin operations and explicit owner checks for post-claim operations.
- Append mandatory claim events with sanitized metadata.
- Never infer ownership from email, verification, subscription, or payment.

## 17. Abandonment and Expiration

- Preview/open without start: no ownership; invitation remains ACTIVE until expiry.
- Email submitted then abandoned: claim remains IN_PROGRESS; invitation remains usable for the same 30-minute claim context and otherwise until seven-day expiry.
- New User created but email not verified: User remains an ordinary pending account with no Broker ownership; invitation/claim expires normally. The account is retained under normal User retention, not deleted as a side effect.
- IN_PROGRESS at seven days: claim and invitation become EXPIRED through request-time validation/cleanup.
- EXPIRED/REVOKED/FAILED: no ownership; admin may issue a fresh invitation, reusing the same BrokerClaim row and preserving event history.
- COMPLETED: no restart or ordinary reissue.
- Restart uses a new invitation and a new claim context; previous tokens never reactivate.

## 18. Audit Events

| Event | Trigger | Actor | Invitation relation | Mandatory metadata |
|---|---|---|---|---|
| GENERATED | Invitation created | ADMIN | New invitation | claim/invitation IDs, target Broker, timestamp, no token |
| SENT | Email accepted/queued | ADMIN/system | New invitation | provider result, timestamp, no address unless sanitized policy permits |
| OPENED | Explicit start/valid link | anonymous/User | Active invitation | claim/invitation IDs, coarse request context only |
| STARTED | Claim context established | anonymous/User | Active invitation | context ID, timestamp |
| EMAIL_SUBMITTED | Claim email accepted | claimant | Active invitation | normalized email hash only, never plaintext unless retention policy approves |
| VERIFICATION_PENDING | New/unverified account path | system/claimant | Active invitation | User ID if created, no password/token |
| COMPLETED | Atomic ownership attach | User/system | USED invitation | Broker/User IDs, timestamp |
| EXPIRED | Expiry observed/materialized | system | Invitation | timestamp/reason |
| REVOKED | Admin revoke/supersede | ADMIN | Invitation | admin ID/reason |
| FAILED | Terminal safe failure | system/admin | Related invitation if known | sanitized reason code |

All events are append-only. No raw token, password, full claim URL, or secret metadata is permitted.

## 19. Error Model

Use generic responses for token/account discovery:

- `400`: malformed input, invalid password, missing required fields.
- `401`: authentication/reauthentication required.
- `403`: actor not authorized or account/admin policy denies action.
- `404`: generic invalid/unknown invitation or inaccessible target.
- `409`: already owned, already used, concurrent completion, duplicate ownership, or invitation conflict.
- `410`: expired/revoked/terminal invitation when the client needs a restart path; wording must not reveal extra account data.
- `422`: semantically invalid admin/profile/email input.
- `429`: rate limit or distributed lock contention.

Public claim errors must not distinguish nonexistent Broker from nonexistent invitation when that distinction enables enumeration.

## 20. Test Requirements

Required tests include:

- admin creation required/optional fields, source, null owner, visibility, verification, FREE, slug collisions, admin authorization;
- token entropy, digest-only storage, uniqueness, seven-day expiry, malformed/unknown/revoked/used handling;
- one-active-invitation supersede and concurrent issuance;
- preview non-consumption and claim-context expiry/binding;
- new User setup, ordinary User reauth/promotion, BROKER without profile, BROKER with profile denial, ADMIN denial, inactive denial, Google reauth, password reauth;
- Broker.email/User.email independence;
- atomic completion preserving Broker ID/slug/profile/reviews/leads/subscription/verification;
- duplicate completion, simultaneous claimants, revoke/complete, expiry/complete, admin-edit/complete races;
- IDOR, enumeration, replay, brute force, CSRF, privilege escalation, log redaction, and rate limits;
- event completeness/append-only behavior;
- FREE retained with no automatic PREMIUM or verification.

## 21. Implementation Sequence

1. Add/confirm the platform's generic admin audit sink for profile creation and publication. Claim-specific lifecycle audit remains in BrokerClaimEvent; this operational audit sink is not an ownership mechanism.
2. Implement admin Broker creation and FREE initialization.
3. Implement claim token utility with SHA-256, seven-day TTL, redaction, and tests.
4. Implement distributed claim lock and invitation issuance/supersede/revoke transaction.
5. Implement claim preview/start and signed 30-minute claim context.
6. Implement existing/new account paths and explicit claimant policy.
7. Implement verification/setup email flows using existing authentication.
8. Implement atomic completion and event writes.
9. Implement public/admin UI and email templates.
10. Run concurrency/security/integration tests against a MongoDB replica set.

## 22. Final Decisions

| Decision | Final contract |
|---|---|
| Admin initial visibility | `isVisible=false`; explicit admin publish required. |
| Initial verification | `UNVERIFIED`; admin trust review is separate. |
| Initial commercial state | Active FREE BrokerSubscription. |
| Token | 32 random bytes, base64url raw delivery, SHA-256 lowercase hex storage. |
| Invitation lifetime | 7 days. |
| Active invitations | One ACTIVE per BrokerClaim; new issue supersedes/revokes prior. |
| New claimant | Create BROKER User, verify email, set password, then attach. |
| Ordinary USER | Allowed with reauth and verified email; promote to BROKER at completion. |
| BROKER without profile | Allowed with reauth and verified email. |
| BROKER with profile | Denied under one-profile policy. |
| ADMIN | Denied self-service; assisted workflow only. |
| Google-only | Allowed with provider reauth and provider-verified email; password not required. |
| Broker.email | Independent profile contact; never ownership proof or overwritten by claim. |
| Claim context | Signed HttpOnly 30-minute cookie, bound to claim/invitation and token digest, cleared on completion. |
| Completion | Atomic conditional Broker.userId update plus invitation/claim/event updates. |
| Abandonment | No ownership; pending User retained normally; invitation expires; fresh admin invitation may restart. |
| Claim completion session | Existing User session may be refreshed; new User is redirected to sign in after verification. |
| Claim readiness | Contract finalized and ready for implementation. The implementation must establish the generic admin audit sink before enabling admin profile creation; it does not change claim ownership/state semantics. |
