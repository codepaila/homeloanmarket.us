# Phase 9.0B Final Contract

## Contract Status

**DRAFT — NO-GO FOR PHASE 9.1**

The supported boundaries below are frozen. Mandatory undefined decisions remain in `57-PHASE-9.0B-PRODUCT-DECISION-REGISTER.md` and must be approved before implementation.

## 1. Objective

Converge directly registered and successfully claimed Brokers on one authenticated Broker dashboard and one owner-API model while safely handling nullable `Broker.userId` and preserving FREE/FEATURED, ownership, claim, verification, visibility, subscription, and Advertisement CMS contracts.

## 2. Scope

- Shared `/broker/dashboard`.
- Existing `/api/brokers/me` and dashboard-stats owner surfaces.
- Server-side User -> Broker ownership resolution.
- Explicitly approved FREE/FEATURED dashboard permissions.
- Dashboard state and authorization handling.
- Authenticated HTTP, security, integration, and browser test contracts.

## 3. Out of Scope

- New plans, PREMIUM, payment providers, or Stripe architecture.
- Ownership/claim/verification/public visibility redesign.
- Advertisement CMS or advertiser features.
- CRM, WhatsApp, Gmail, social, or advertiser workflows.
- Dashboard visual redesign or unrelated refactoring.
- Schema changes unless separately approved after proof of necessity.

## 4. FREE Permissions

Already supported by authoritative sources:

- dashboard access after activation: ALLOW;
- own profile viewing/editing of authorized fields: ALLOW;
- basic dashboard access without payment: ALLOW;
- own contacts/leads within documented policy: LIMITED, exact limits unresolved;
- basic statistics: ALLOW;
- subscription upgrade/billing/cancellation: ALLOW for own account;
- verification, ownership, claim, publication override: DENY.

Advanced analytics, exact contact/lead/review/visibility limits, and review mutations remain PRODUCT DECISION REQUIRED.

## 5. FEATURED Permissions

Already supported by authoritative sources:

- dashboard access: ALLOW;
- own profile viewing/editing of authorized fields: ALLOW;
- FEATURED placement entitlement: ALLOW while effective FEATURED;
- basic statistics: ALLOW;
- own billing/portal/upgrade/cancellation: ALLOW;
- verification, ownership, claim, publication override: DENY.

Advanced analytics, exact paid limits, paid placement controls, and expired/cancelled UX remain PRODUCT DECISION REQUIRED.

## 6. Admin Permissions

- Existing admin Broker/profile/claim operations remain ADMIN_ONLY.
- Admin dashboard impersonation is not defined and is not authorized.
- Admin must not silently impersonate or mutate a Broker owner through the Broker dashboard.
- Admin subscription reconciliation remains the Phase 8.5 operation.

## 7. Ownership Rules

- `Broker.userId: null` means unowned.
- `Broker.userId = User.id` means owned by that User.
- Direct registration attaches ownership transactionally.
- Claim completion conditionally attaches ownership transactionally.
- A User may not own multiple Brokers under the existing unique partial index.
- Client-supplied User/Broker/owner IDs are never ownership authority.

## 8. Authentication Rules

- Reuse NextAuth JWT, Credentials, Google, bcrypt, email verification, active-account, and claim reauthentication infrastructure.
- Unauthenticated, inactive, stale, or invalid sessions cannot access protected dashboard data.
- No second identity/session system is authorized.

## 9. Authorization Rules

```text
Authenticated session
  -> current server User
  -> Broker where Broker.userId = User.id
  -> owner-scoped dashboard/API data
```

Wrong owners are denied. Unowned Brokers have no owner dashboard. Admin behavior remains separate unless a product decision authorizes a dedicated audited view.

## 10. Analytics Rules

- Existing basic statistics remain available to authenticated owners.
- Existing paid analytics behavior must not be expanded or reinterpreted until P9B-001 is approved.
- Public users do not receive owner analytics.
- Analytics must be scoped to the server-resolved Broker.

## 11. Contact/Lead Rules

- Existing owner/contact/lead routes remain server-authorized.
- No artificial new limits may be implemented during Phase 9.1 without decisions P9B-002 through P9B-005.
- Public contact submission remains separate from owner dashboard management.

## 12. Review Rules

- Owners may view reviews where existing API/UI supports it.
- Review response/edit/delete/approve/hide/moderation permissions are undefined and must not be invented.
- Public review visibility remains existing policy.

## 13. Visibility Rules

- Verification, visibility, publication, ownership, and subscription remain separate.
- Admin publication authority remains existing business policy.
- Owner `isVisible` mutation behavior is unresolved because current API accepts it while existing business rules describe admin publication control. P9B-007 blocks final PATCH permission freeze.

## 14. FEATURED Placement Rules

- FEATURED is a commercial placement entitlement only.
- It does not prove ownership, verification, identity, or publication.
- Expired/cancelled/failed/missing/unsupported subscriptions use effective FREE.
- Advertisement CMS is unrelated and remains ADMIN CMS -> public advertisement display -> tracking.
- No owner placement controls are authorized until P9B-009 is decided.

## 15. Owner API Contracts

| API | Method | Auth | Owner check | FREE | FEATURED | Admin | Current contract status |
|---|---|---|---|---|---|---|---|
| `/api/brokers/me` | GET | Authenticated BROKER | `Broker.userId = currentUser.id` | Own data | Own data | 403/separate admin | Existing response, formal fields pending |
| `/api/brokers/me` | PATCH | Authenticated BROKER | `Broker.userId = currentUser.id` | Authorized fields | Authorized fields | 403/separate admin | Visibility/limits unresolved |
| `/api/brokers/me/dashboard-stats` | GET | Authenticated User with Broker | Server current Broker | Basic stats | Basic + approved paid stats | Undefined | Response/analytics unresolved |
| `/api/brokers/[id]/contacts` | GET | Authenticated | Owner or ADMIN | Existing policy | Existing policy | ADMIN | Existing route-specific errors |
| `/api/user/profile` | GET/PATCH | Authenticated current User | Current User | Same | Same | Own admin account | Existing contract |
| Subscription routes | Existing Phase 8.5 | Authenticated owner/admin where specified | Server owner | FREE fallback | FEATURED lifecycle | Reconciliation | Certified |

### Error Contract

The Phase 9.1 implementation must preserve current route-specific response bodies. Status meanings are:

- 400: invalid request;
- 401: unauthenticated/invalid session;
- 403: authenticated but unauthorized;
- 404: missing or intentionally hidden resource;
- 409: current-state conflict where supported;
- 422: validation/business-rule failure where supported;
- 429: rate limit;
- 500: unexpected server error.

Exact body compatibility remains P9B-013 until each owner API is documented.

## 16. Dashboard State Matrix

| State | Dashboard | Profile/data | Contacts/leads | Reviews | Analytics | Subscription | Visibility/FEATURED |
|---|---|---|---|---|---|---|---|
| Unauthenticated | DENY | DENY | DENY | DENY | DENY | DENY | DENY |
| Authenticated no Broker | DENY/SETUP | No Broker | DENY | DENY | DENY | No Broker subscription | No owner controls |
| Owned FREE | ALLOW | Own authorized data | LIMITED, exact limits unresolved | View ALLOW; mutations undefined | Basic ALLOW; advanced undefined | Own billing/upgrade | No paid placement |
| Owned FEATURED | ALLOW | Own authorized data | LIMITED, exact limits unresolved | View ALLOW; mutations undefined | Basic ALLOW; advanced undefined | Own billing/cancel/portal | FEATURED entitlement only |
| Expired FEATURED | ALLOW | Own authorized data | FREE behavior | FREE behavior | FREE behavior | FREE fallback | No FEATURED entitlement |
| Cancelled FEATURED | ALLOW | Own authorized data | FREE behavior | FREE behavior | FREE behavior | FREE fallback | No FEATURED entitlement |
| Unverified owner | Activation policy | Own data if access allowed | Existing policy | Existing policy | Existing policy | Existing owner billing policy | No verification implication |
| Verified owner | ALLOW | Own authorized data | Existing policy | Existing policy | Existing policy | Existing policy | Verification separate |
| Unowned Broker | DENY owner dashboard | Admin/public only | No owner authority | Public policy only | No owner analytics | No owner billing | Subscription independent |
| Admin | Separate admin UI | Admin APIs | Admin policy | Admin policy | Admin policy | Reconciliation | No automatic impersonation |
| Wrong owner | DENY | DENY | DENY | DENY | DENY | DENY target billing | DENY |
| Missing/deleted Broker/User | DENY | 404/401/403 | DENY | DENY | DENY | DENY | DENY |

## 17. Security Requirements

- No IDOR across Broker owner APIs.
- No client-controlled owner/subscription/permission authority.
- No subscription-to-ownership or subscription-to-verification coupling.
- No admin escalation through Broker dashboard routes.
- No unowned Broker owner match.
- Existing claim, session, rate-limit, CSRF, transaction, and uniqueness protections remain intact.

## 18. Test Requirements

Before Phase 9.1 GO:

- isolated authenticated HTTP harness;
- direct and claimed owner fixtures;
- FREE/FEATURED/expired/cancelled/missing subscription fixtures;
- wrong-owner/admin/unauthenticated/stale-session cases;
- all owner API success/validation/auth/not-found/conflict behavior;
- IDOR and client-ID tampering;
- desktop/mobile/loading/empty/error dashboard states;
- registration/claim/ownership/verification/visibility/subscription/advertisement regressions;
- browser E2E when infrastructure exists.

## 19. Explicit Unresolved Decisions

P9B-001 through P9B-015 in document 57 remain unresolved. These are not implementation defaults.

## Contract Status

**NO-GO — CONTRACT NOT FROZEN FOR PHASE 9.1**
