# Phase 13.0 Demo Data Matrix

This matrix is the frozen target for Phase 13.1. Counts are intentionally modest and deterministic; they are not production-volume data and do not create SEO landing pages.

## Core Dataset

| Dataset | Target | Required characteristics | Stable key |
|---|---:|---|---|
| Demo admin | 1 | Active ADMIN, synthetic email, local-only deterministic password | fixed email |
| Normal demo users | 6 | Active USER accounts, synthetic credentials, no OAuth | fixed email |
| Owned Brokers | 12 | US cities/states, verified/visible, explicit SELF_REGISTERED source, FREE or active FEATURED | `profileSlug` |
| Unowned public Broker | 1 | ADMIN_CREATED, `userId=null`, verified/visible, non-suspended, FREE | `profileSlug` |
| Non-public Broker fixtures | 3 | One hidden, one unverified, one suspended; never public/sitemap eligible | `profileSlug` |
| Broker subscriptions | 13+ | FREE baseline; selected owned profiles FEATURED; no PREMIUM/provider IDs | `brokerId` |
| Broker-bank relationships | 2-4 per selected Broker | Existing `BrokerBank`, not a new relation | broker + bank name |
| Bank catalog | 8 | US-oriented synthetic/real-world bank names used as demo content, active | unique name |
| Loan products | 2 per bank | USD/rate/term data, active | bank + product name |
| Properties | 18 | Apartments, houses, condos, townhomes, land; USD; real US city/state combinations; images | `slug` |
| Reviews | 2 per eligible public Broker | Published, ratings 4-5, synthetic reviewer or null User | broker + ordinal |
| Contacts | 12 | Valid Broker IDs, synthetic names/emails/phones, safe lead statuses | broker + ordinal |
| Blog posts/guides | 8 | Published representative US mortgage content, stable cover paths | `slug` |
| FAQs | 10 | Active US mortgage/property questions | question key/content hash |
| Testimonials | 6 | Synthetic names, ratings 4-5, US cities, active | fixed ordinal/content key |
| Settings | approved subset only | US site/SEO/contact values required by current app; no secrets | `key` |

## Broker Location Matrix

| Broker | City | State | Plan | Ownership/publication |
|---|---|---|---|---|
| 1 | New York | New York | FREE | Owned, verified, visible |
| 2 | Los Angeles | California | FEATURED | Owned, verified, visible |
| 3 | Miami | Florida | FREE | Owned, verified, visible |
| 4 | Chicago | Illinois | FEATURED | Owned, verified, visible |
| 5 | Houston | Texas | FREE | Owned, verified, visible |
| 6 | Dallas | Texas | FEATURED | Owned, verified, visible |
| 7 | Phoenix | Arizona | FREE | Owned, verified, visible |
| 8 | Seattle | Washington | FEATURED | Owned, verified, visible |
| 9 | Denver | Colorado | FREE | Owned, verified, visible |
| 10 | San Francisco | California | FEATURED | Owned, verified, visible |
| 11 | Boston | Massachusetts | FREE | Owned, verified, visible |
| 12 | Atlanta | Georgia | FREE | Owned, verified, visible |
| 13 | Austin | Texas | FREE | Unowned ADMIN_CREATED, verified, visible |

The three negative Broker fixtures must remain out of public listing, profile metadata, JSON-LD, internal linking, and sitemap output. No city/state pages are generated.

## Property Matrix

Use 18 stable slugs across New York, Los Angeles, Miami, Chicago, Houston, Dallas, Phoenix, Seattle, Denver, and San Francisco. Include at least:

- 6 apartments/condos;
- 5 houses/townhomes;
- 3 luxury/villa-style homes represented by the existing string `propertyType` field;
- 2 commercial properties;
- 2 land/development properties.

Each record needs a valid local image path, USD currency, price, city, location, features, active state, and deterministic featured flag. There is no current public Property detail route, so this matrix validates records and future/API consumers only.

## Advertisement Placement Matrix

| Placement | Renderer | Target ads | Creative plan | Mobile behavior |
|---|---|---:|---|---|
| HOMEPAGE_HERO | Hero | 2 | Desktop hero plus one lower-priority fallback | Existing mobile source where supplied |
| HOMEPAGE_SEARCH | Banner | 1 | Wide CTA banner | Desktop fallback permitted |
| HOMEPAGE_FEATURED | Banner | 1 | Broker discovery banner | Desktop fallback permitted |
| HOMEPAGE_SERVICES | Banner | 1 | Consultation banner | Desktop fallback permitted |
| HOMEPAGE_BANKS | Banner | 1 | Bank comparison banner | Desktop fallback permitted |
| HOMEPAGE_CTA | Banner | 1 | Final CTA banner | Desktop fallback permitted |
| BROKER_LISTING | Banner | 1 | Directory banner | Desktop fallback permitted |
| BROKER_PROFILE_HEADER | Hero | 1 | Profile-header banner | Existing mobile source |
| BROKER_LISTING_SIDEBAR | Sidebar | 2 | Priority ordering/fallback test | Desktop/tablet |
| LOAN_CALCULATOR | Banner | 1 | Calculator CTA | Desktop fallback permitted |
| BLOG_INLINE | Inline | 1 | Guide inline banner | Desktop fallback permitted |
| FOOTER | Footer | 1 | Footer banner | Desktop fallback permitted |
| ANNOUNCEMENT_TOP | Banner | 1 | Dismissible announcement | All supported devices |
| ANNOUNCEMENT_BOTTOM | Banner | 1 | Dismissible announcement | All supported devices |
| POPUP_OVERLAY | Popup | 1 | Dismissible session popup | Existing session behavior |
| MOBILE_HEADER_BANNER | Banner | 1 | Mobile-specific banner | Mobile-filtered |

All destinations must be safe relative or HTTP(S) URLs. Demo destinations should use existing public routes such as `/brokers`, `/calculator`, `/guides`, or `/about`, never `#` as a fake business destination. All ads should be publishable, scheduled around a fixed seed timestamp, non-archived, non-deleted, and admin-created.

## Media Folder and Manifest Matrix

| Folder | Purpose | Target assets | Source/storage |
|---|---|---:|---|
| Demo Properties | Property images | 6 reusable | Local generated WebP |
| Demo Brokers | Profile/logo/cover images | 6 reusable | Local generated WebP |
| Demo Blog | Guide covers | 4 reusable | Local generated WebP |
| Demo Advertisements | Desktop creative | 8 reusable | Local generated WebP or approved free source with manifest |
| Demo Advertisements/Mobile | Mobile creative | 2 reusable | Local generated WebP |
| Demo Logos | Site/bank logos | 4 reusable | Local generated WebP or approved source |
| Demo General | Placeholder/avatar | 2 reusable | Local generated WebP |

Each manifest row in Phase 13.1 must record: placement or entity purpose, dimensions, source URL or `generated-local`, attribution requirement, local path, MIME type, and whether it is desktop/mobile. Do not commit large external downloads or hotlink third-party assets in production-oriented seed data.

## Analytics Matrix

Default: zero seeded `AdEvent` rows. First run through the public pages should create real impressions/clicks. If admin analytics screens require history, seed at most 3 events per selected ad with fixed dates, synthetic request metadata, and an explicit demo marker in the implementation log. Never seed hundreds of random events or mix them with production metrics.

## Dependency Matrix

| Order | Prerequisite | Dependents |
|---:|---|---|
| 1 | Admin | Users, media uploader, advertisements |
| 2 | Users | Owned Brokers, reviews/contacts |
| 3 | Banks | Loan products and optional BrokerBank names |
| 4 | Media folders/assets | Broker images, properties, guides, testimonials, advertisements |
| 5 | Brokers/subscriptions | Reviews, contacts, public SEO checks |
| 6 | Properties/content | Public/API content checks |
| 7 | Advertisements | Optional demo analytics |
| 8 | Settings | Configuration/UI checks |

## Acceptance Criteria

- Dataset is US-oriented and uses only deterministic synthetic data.
- Every repeated seed run produces the same counts, keys, relationships, and public eligibility states.
- No duplicate unique records or uncontrolled child-record growth occurs.
- All public Brokers intended for discovery pass `isPublicBroker()`; negative fixtures do not.
- Only FREE and FEATURED subscriptions exist in new demo data, with no provider identifiers.
- Every active Advertisement uses an actual enum placement and valid local creative/destination.
- Every MediaAsset path exists, uses supported MIME, and has correct dimensions.
- No artificial SEO pages, production credentials, private tokens, or real personal data are seeded.
