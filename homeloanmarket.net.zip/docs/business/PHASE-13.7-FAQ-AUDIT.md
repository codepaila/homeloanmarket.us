# Phase 13.7 FAQ Audit

## Existing Architecture

- Prisma `FAQ` model: `id`, `question`, `answer`, `category?`, `displayOrder` (default 0), `isActive` (default true), `createdAt`, `updatedAt`.
- The public `/faq` page was a client component with hardcoded `faqs` constants and categories.
- No admin FAQ management existed.

## Schema Decision

Reused the existing `FAQ` model with **no schema change**:

- Published/Draft  -> `isActive`
- Sort order       -> `displayOrder`
- Category         -> `category`

No duplicate FAQ model or new fields were introduced.

## Seed FAQ Issues Found

A Prisma-on-MongoDB `startsWith('[Demo]')` filter treated `[` as a regex character class, so it never matched literal `[Demo]` prefixed records and could match clean questions starting with a letter. The seed cleanup was corrected to use exact JavaScript prefix filtering before deletion.

## Reused Components

- Admin shell, `Card`, `Badge`, `Button`, `Input` patterns, `useActionState` form pattern (matching Settings/Content).
- Server-action pattern from `actions/content.ts`.
- Public page design preserved via a new client `FaqAccordion` that keeps the existing accordion/search/category UI.
- Existing `lib/seo.ts` `canonicalUrl`/`safeJsonLd` helpers.

## Public Page (before)

Hardcoded 12 FAQ constants, no database connection, no JSON-LD.

## Public Page (after)

- Server component reads only published FAQs (`isActive === true`), ordered `displayOrder ASC, createdAt ASC`.
- Same accordion/search/category UI, with categories derived from the database.
- FAQPage JSON-LD generated from published FAQs only.
- Safe empty state when no FAQs exist; drafts never rendered.
