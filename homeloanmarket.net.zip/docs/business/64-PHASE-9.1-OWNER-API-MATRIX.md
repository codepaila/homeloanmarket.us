# Phase 9.1 Owner API Matrix

## Matrix

| Endpoint | Auth | Ownership | Role | FREE | FEATURED | Mutation | Error behavior |
|---|---|---|---|---|---|---|---|
| `GET /api/brokers/me` | Required | `Broker.userId = currentUser.id` | BROKER | Own data/effective FREE | Own data/effective FEATURED | No | 401 unauthenticated, 403 wrong role, 404 no owned Broker, 500 unexpected |
| `PATCH /api/brokers/me` | Required | `Broker.userId = currentUser.id` | BROKER | Existing authorized fields | Existing authorized fields | Yes | 401, 403, 404, 400 existing validation/conflict, 500 |
| `GET /api/brokers/me/dashboard-stats` | Required | Server current Broker profile | Authenticated User with Broker | Existing basic stats | Existing basic stats | No | 401 missing session/profile, 500 unexpected |
| `GET /api/brokers/[id]/contacts` | Required | Broker owner or ADMIN | Owner/ADMIN | Existing contact behavior | Existing contact behavior | No | 401, 403 wrong owner, 404 missing Broker, 500 |
| `POST /api/contacts/[id]/read` | Required | Server message owner check | Owner/ADMIN per route | Existing behavior | Existing behavior | Yes | Existing route contract |
| `POST /api/contacts/[id]/responded` | Required | Server message owner check | Owner/ADMIN per route | Existing behavior | Existing behavior | Yes | Existing route contract |
| `GET/PATCH /api/user/profile` | Required | Current User session | Authenticated User | Same | Same | PATCH | Existing route contract |
| `/api/subscription/details` | Required | Current User -> Broker | Owner | FREE fallback | FEATURED state | No | Phase 8.5 contract |
| `/api/subscription/usage` | Required | Current User -> Broker | Owner | FREE limits/current behavior | FEATURED limits/current behavior | No | Phase 8.5 contract |
| `/api/subscription/checkout` | Required | Current User Broker | Owner | Request FEATURED only | No higher plan | Yes | 401/400/404/500 existing |
| `/api/subscription/upgrade` | Required | Current User Broker | Owner | Upgrade to FEATURED | No higher plan | Yes | 401/400/409/500 existing |
| `/api/subscription/cancel` | Required | Current User Broker | Owner | Existing behavior | Effective FREE after cancel | Yes | 401/404/500 existing |
| `/api/subscription/portal` | Required | Current User Stripe customer | Owner | Own portal | Own portal | Yes | 401/400/500 existing |

## Rules

- No client-provided `brokerId`, `ownerId`, `userId`, plan, entitlement, verification, or ownership field is authority.
- Existing route-specific response bodies are preserved.
- Advanced analytics has no Phase 9.1 API.
- Contact/lead limits are not added.
- Review mutations are not added.
- Visibility/publication behavior is unchanged.
