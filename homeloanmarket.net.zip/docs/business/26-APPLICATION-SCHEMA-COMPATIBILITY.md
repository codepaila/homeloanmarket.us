# Application Schema Compatibility Audit

## Scope and Method

Read-only audit after the Phase 2 Prisma schema change. No application code, schema, seed, UI, API, auth, or subscription logic was modified. The audit searched `app`, `actions`, `lib`, `components`, `hooks`, and `prisma` for Broker/User ownership, User session, subscription, verification, visibility, registration, public query, email, and claim usage. `node_modules` and generated Prisma client output are excluded from the application inventory.

## Result Summary

Counts are unique files tagged by primary audit category; one file can carry multiple secondary tags.

| Category | Count | Meaning |
|---|---:|---|
| Total affected files | 61 | Directly use affected models/statuses or must change to support nullable ownership. |
| NULL UNSAFE | 13 | Dereference/filter required Broker User data or use a nullable owner ID as required. |
| OWNERSHIP | 14 | Resolve or authorize a broker through `userId`/`brokerProfile`. |
| SUBSCRIPTION | 24 | Read/write BrokerSubscription, plan features, or paid access gates. |
| VERIFICATION | 18 | Read/write account or Broker verification state. |
| PUBLIC VISIBILITY | 10 | Control or consume public publication/visibility predicates. |
| ADMIN | 2 | Admin-side shared/status consumers; no admin Broker creation implementation exists. |
| AUTH | 10 | Session, User account, role, activation, or broker-profile auth behavior. |
| CLAIM | 0 current | No existing application code consumes BrokerClaim, BrokerClaimInvitation, or BrokerClaimEvent. |

The category counts overlap. `CLAIM=0` means no claim behavior currently exists, not that claim work is optional.

## Classification Legend

- **A SAFE:** already null-safe or only handles a User-side optional broker profile.
- **B NULL UNSAFE:** assumes Broker User exists or filters unowned profiles out unintentionally.
- **C OWNERSHIP LOGIC:** uses owner relation for permissions or owner-side lookup.
- **D SUBSCRIPTION LOGIC:** uses plan/activity/status for commercial access or projection.
- **E VERIFICATION LOGIC:** uses account or Broker verification.
- **F PUBLIC VISIBILITY:** controls/filters public exposure.
- **G CLAIM RELATED:** new claim models or future claim integration.

## Affected File Inventory

### Broker APIs and Public Queries

| File | Tags | Finding |
|---|---|---|
| `app/api/brokers/route.ts` | B/C/D/E/F | Non-admin listing adds `where.user.isActive`, excluding unowned profiles; POST creates Broker with `userId`, creates FREE separately, and uses `BrokerStatus.FREE`. |
| `app/api/brokers/featured/route.ts` | B/D/E/F | Requires `user.isActive`; featured query cannot return an eligible unowned profile. |
| `app/api/brokers/[id]/route.ts` | B/C/D/E/F | Reads `broker.user.isActive`; owner authorization compares `userId`; DELETE updates User by nullable ID; subscription controls contact/featured behavior. |
| `app/api/company/[slug]/route.ts` | B/C/D/E/F | Includes User, authorizes by `userId`, updates User during admin delete, and mixes status/verification/subscription presentation. |
| `app/(public)/brokers/[slug]/page.tsx` | B/F | Includes User for initial public rendering but has no publication predicate itself. |
| `app/(public)/brokers/page.tsx` | A/D/E/F | Uses optional owner contact fields, but relies on API-filtered results and exposes contact based on active subscription. |
| `app/api/brokers/[id]/contacts/route.ts` | A/C | Reads contacts by broker ID but currently does not enforce that caller owns the Broker; User on each contact is optional and unrelated to Broker ownership. |
| `app/api/company/[slug]/reviews/route.ts` | A | Reviews are Broker-owned and reviewer User is optional; no Broker owner assumption in the query. |
| `app/api/admin/contact/route.ts` | A | Admin contact query is Broker-ID based; no owner relation required. |

### Owner/Dashboard and Contact Paths

| File | Tags | Finding |
|---|---|---|
| `app/api/brokers/me/route.ts` | C/D/E | Correctly resolves an owner-side Broker by `userId`; only valid for owned users, but free/paid behavior is mixed with subscription activity. |
| `app/api/brokers/me/dashboard-stats/route.ts` | C/D | Resolves `user.brokerProfile`; assumes active broker dashboard context and treats analytics as subscription-gated. |
| `app/broker/dashboard/page.tsx` | C/D | Requires User-side broker profile; blocks analytics when subscription is inactive, which risks treating FREE as unavailable. |
| `app/broker/company/page.tsx` | C/E/F | Resolves User-side Broker and projects verification/visibility/status. |
| `app/broker/company/edit/page.tsx` | C | Finds Broker by `userId`; appropriate for owner editing, not for unowned admin editing. |
| `app/api/contacts/my/route.ts` | C | Resolves leads through authenticated User's broker profile. |
| `app/api/contacts/[id]/read/route.ts` | C | Authorizes contact mutation through User's broker profile. |
| `app/api/contacts/[id]/responded/route.ts` | C | Same owner-side lookup and authorization pattern. |
| `app/api/contacts/send/route.ts` | B | Rejects a Broker without a User, preventing approved unowned profiles from receiving contacts; notification behavior also needs a no-owner branch. |

### Authentication, Registration, and Email

| File | Tags | Finding |
|---|---|---|
| `app/api/auth/register/broker/route.ts` | C/D/E/H | Creates only User, not Broker or FREE entitlement; direct-registration profile creation remains a later compatibility task. |
| `app/api/auth/verify-email/route.ts` | C/E/H | Uses optional User.brokerProfile safely, then assumes a Broker User exists for notification; new expiry field is not yet used. |
| `app/api/auth/resend-verification/route.ts` | C/E/H | Uses User.brokerProfile; does not yet use persisted verification expiry. |
| `app/api/auth/reset-password/route.ts` | A/H | Uses existing User reset fields; no Broker ownership assumption. |
| `actions/auth.action.ts` | E/H | Checks Broker email verification and active account; duplicate/legacy paths remain. |
| `actions/email.action.ts` | B/C/E/D | Several broker notification paths dereference `broker.user.email`, `broker.user.id`, or `review.broker.user.email`; unowned profiles cannot be notified until an owner exists. Registration email checks for a broker profile that the current registration route has not created. |
| `lib/auth.config.ts` | A/C/D/E/H | User-side optional `brokerProfile` is guarded; session includes status/plan but no ownership/creation-source/claim state. Credentials require active account/password; Google defaults to USER. |
| `lib/auth.ts` | A/H | NextAuth wrapper/cookie configuration; no direct Broker ownership query. |
| `lib/currentUser.ts` | A/C/D/E | User-side Broker is optional and guarded, but helper booleans expose status/plan projections and `canShowContact` based on plan. |
| `app/proxy.ts` | A/H | Enforces token active state and role/path access; does not verify Broker ownership for routes. |

### Subscription and Commercial Consumers

| File | Tags | Finding |
|---|---|---|
| `app/api/subscription/checkout/route.ts` | C/D | Uses User's Broker to create/update checkout entitlement; requires an owner profile. |
| `app/api/subscription/details/route.ts` | D | Reads helper subscription fields from current User. |
| `app/api/subscription/upgrade/route.ts` | C/D/E/F | Updates entitlement, then changes `brokerStatus`, `verificationStatus`, rank, and verified timestamp from plan limits. This violates separation. |
| `app/api/subscription/cancel/route..ts` | C/D | Sets entitlement inactive and resets `brokerStatus`; ownership is not changed, which is correct. |
| `app/api/subscription/usage/route.ts` | C/D | Resolves Broker from User and reads plan limits. |
| `app/api/subscription/invoices/route.ts` | D | Billing projection consumer; must continue using entitlement, not ownership. |
| `app/api/subscription/portal/route.ts` | C/D | Owner-side Stripe portal access. |
| `lib/subscription.ts` | C/D/E/F | Central service reads BrokerSubscription but `applySubscriptionFeatures` changes BrokerStatus, verification, and visibility from plan. This is the largest separation violation. |
| `actions/subscription.ts` | D | Stripe operations typed by SubscriptionPlan; no ownership mutation. |
| `lib/stripe.ts` | D | Maps plans to feature limits and uses paid plan for ranking/features. Commercially appropriate, but must not be used as ownership/trust proof. |
| `lib/email-templates.ts` | D | Displays plan and plan-derived features in subscription emails. |
| `app/broker/subscription/page.tsx` | C/D/E | Owner-side plan/feature page; presentation treats verification badge and placement as plan features. |
| `components/sections/subscriptions/Usagestats.tsx` | D/E | Displays plan limits and verification badge as commercial features. |
| `components/sections/subscriptions/BillingClient.tsx` | D | Displays invoice/subscription plan. |
| `components/sections/subscriptions/BillingHistory.tsx` | D | Displays invoice/subscription plan. |
| `components/sections/subscriptions/SubscriptionPlan.tsx` | D | Presents commercial plans. |
| `components/sections/landing/FeaturedBrokers.tsx` | D/F | Sorts/presents featured brokers by subscription-derived data. |

### Status, Verification, and Shared UI

| File | Tags | Finding |
|---|---|---|
| `components/brokers/FeaturedBrokerRowCard.tsx` | A/D/E/F | Uses optional User display fallback; uses plan/status for featured/verified presentation. |
| `components/sections/broker/BrokerDetailClient.tsx` | A/D/E/F | Owner contact fields are optional, but plan/status controls featured/contact presentation. |
| `components/sections/broker/BrokerDashboard.tsx` | A/D/E | Displays BrokerStatus and verification; optional User email fallback is safe. |
| `components/sections/broker/BrokerProfile.tsx` | A/D/E | Displays User-side Broker and status/plan/verification. |
| `components/sections/broker/CompanyProfile.tsx` | D/E/F | Allows/editors status-related profile fields and subscription restrictions. |
| `components/sections/broker/EditProfile.tsx` | D/E/F | Handles visibility and verification presentation; not ownership. |
| `components/layout/admin/sideBarData.ts` | C/D/E | Builds sidebar from User Broker and status/plan. |
| `components/layout/admin/SubscriptionBadge.tsx` | D | Displays subscription/featured state. |
| `hooks/useCurrentUser.ts` | C/D/E | Derives broker permissions and plan/status helper flags from current User. |
| `hooks/useSubscription.ts` | D | Client plan/expiry/feature logic. |
| `lib/fetchClient.ts` | E | Passes verification filter to public broker API. |
| `lib/fetchServer.ts` | D/E | Subscription and verification data fetch helpers. |

### Seeds

| File | Tags | Finding |
|---|---|---|
| `prisma/seed.ts` | C/D/E | Every seeded Broker has a User and subscriptions; no unowned example exists. |
| `prisma/seed/seed-brokers.ts` | C/D/E | Creates/upserts every Broker with `userId`, randomly assigns BrokerStatus/VerificationStatus and subscription plans. |
| `prisma/seed/helpers.ts` | H | Creates active/email-verified Users used by seeded Brokers. |

## Claim Model Search

No application code currently references `BrokerClaim`, `BrokerClaimInvitation`, or `BrokerClaimEvent`. There are no claim APIs, pages, actions, token consumers, admin invitation controls, or claim tests. This is expected after Phase 2 but means the schema models are currently inert.

## Admin Creation Search

No admin Broker creation route/page was found. Existing Broker creation is in `app/api/brokers/route.ts` for an authenticated self-service flow, plus seed files. The future admin flow can create `Broker` with `userId=null`, but no current code does so.

## Public Visibility Finding

The following current queries require a related active User and therefore exclude or fail for `userId=null`:

- `app/api/brokers/route.ts`: `where.user.isActive`.
- `app/api/brokers/featured/route.ts`: `user: { isActive: true }`.
- `app/api/brokers/[id]/route.ts`: `broker.user.isActive`.
- `app/api/contacts/send/route.ts`: rejects `!broker.user`.

`app/api/company/[slug]/route.ts` and the public slug server page do not consistently apply the public predicate, creating a separate visibility/privacy audit issue.

## Dashboard Finding

Self-registered and future claimed owners can use the current User -> Broker dashboard shape once `userId` is non-null. An unowned profile has no dashboard owner and must be admin-managed only. Current dashboard access is role/profile based and does not itself distinguish claim state; that distinction must be added with claim implementation later.

## TypeScript Compatibility Check

Read-only `npx tsc --noEmit` was run after Prisma Client generation. It failed as expected for the new nullable relation:

- `actions/email.action.ts`: nine `broker.user`/`review.broker.user` possibly-null errors.
- `app/api/brokers/[id]/route.ts`: one `broker.user` possibly-null error and one nullable `userId` passed to User update.
- `app/api/company/[slug]/route.ts`: one nullable `userId` passed to User update.

The command also reported six pre-existing/missing generated `.next/dev/types/validator.ts` route-module references and one unrelated `prisma.config.ts` type error (`seed` is not accepted by the installed Prisma config type). Those are not caused by this audit and were not changed.
