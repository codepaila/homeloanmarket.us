# Database Migration Plan

This sequence is preparatory design only. No migration, Prisma generation, or data mutation has been executed.

## Step 1: Prepare Schema
Review MongoDB deployment prerequisites for Prisma transactions. Design enums, optional Broker ownership, creation source, claim models, invitation digest indexes, event/audit retention, and FREE entitlement invariants. Capture the current schema/index snapshot and backup/restore procedure.

## Step 2: Handle Existing Broker Records
Inventory every Broker, its user, role, verification, visibility, subscription, reviews, contacts, and slug. Detect orphaned or inconsistent records before changing constraints. Classify existing records as legacy/self-created `SELF_REGISTERED` or another explicit legacy source if provenance cannot be proven. Preserve all Broker IDs and slugs.

## Step 3: Make Ownership Optional If Required
Deploy the nullable relation only after affected queries and generated types are prepared in the release plan. Verify the actual MongoDB unique index permits multiple null owner values and still prevents duplicate non-null owners. Do not delete or rewrite existing non-null user IDs.

## Step 4: Add Creation Source
Add the enum/field with a safe temporary default or staged nullable field, backfill deterministic classifications, validate no invalid source/ownership combination, then enforce requiredness if appropriate. Admin-created records must be allowed to remain unowned; self-registered/legacy owned records must be owned.

## Step 5: Add Claim Infrastructure
Create BrokerClaim, BrokerClaimInvitation, and BrokerClaimEvent structures. Backfill no claim rows for self-registered records. Create claim rows only for admin-created profiles that need a claim process. Generate no tokens during migration. Add unique token digest and status/expiry indexes after checking existing collections.

## Step 6: Add FREE Entitlement Support
Audit every BrokerSubscription. Create or repair one FREE entitlement for valid brokers with no current paid entitlement, preserving active paid plans. Do not use a missing subscription to mean unowned. Confirm `brokerId` uniqueness and define paid expiry as a FREE transition.

## Step 7: Validate Existing Records
Run read-only validation for: unique slugs, unique owner IDs, every owned Broker pointing to an existing User, no invalid source/ownership combinations, subscription uniqueness, valid referenced children, and no secret/token plaintext fields. Produce a reconciliation report before enforcement.

## Step 8: Update Affected Queries
After schema readiness, update all null-unsafe queries and serializers: public listing/featured/slug reads, contact email delivery, owner authorization, broker dashboard, admin profile operations, verification emails, subscription routes, and seed/import paths. Centralize publication and owner predicates.

## Step 9: Run Tests
Execute migration rehearsal against a production-like Mongo replica set, rollback/restore rehearsal, direct registration transaction tests, claim race/replay tests, public unowned profile tests, FREE/paid lifecycle tests, auth verification tests, webhook idempotency tests, and permission/IDOR tests. Only then consider production rollout.

## Recommended Release Ordering
1. Read-only inventory and validation.
2. Code/query compatibility release that can tolerate nullable ownership while old data remains owned.
3. Schema/index migration and backfill.
4. Admin-created profile and claim feature behind controlled rollout.
5. Direct-registration transaction/FREE hardening.
6. Public policy and subscription decoupling.

## Rollback Considerations
Do not roll back by deleting new claim/audit history. If feature rollout is disabled, preserve nullable schema and records, stop new invitations, and continue existing owned-broker behavior. Reverting `Broker.userId` to required is unsafe if any unowned profiles have been created; a forward remediation or controlled archive is required.
