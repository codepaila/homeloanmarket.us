# Phase 13.0 Demo Data and Media Seed Audit

## Status

**PHASE 13.0 STATUS: GO WITH NON-BLOCKING LIMITATIONS**

This is an audit and contract phase. No seed was executed, no production database was accessed or mutated, and no source/schema/business behavior was changed.

## Authority Reviewed

The audit reviewed the Phase 1-12.2 business, schema, ownership/claim, subscription, public Broker, Advertisement CMS, security, SEO, and certification records, including the certified Phase 12.2 reports. The following frozen rules apply:

- `isPublicBroker()` remains the public eligibility authority.
- `Broker.userId` is ownership authority; claim completion is the ownership transition.
- Admin-created profiles may be unowned and may be public when otherwise eligible.
- Subscription does not establish ownership, verification, or publication.
- FREE is baseline; FEATURED is the only active paid plan; PREMIUM is unsupported for new demo data.
- Advertisement CMS remains admin-created, admin-controlled, and separate from Broker contacts/inquiries.
- Existing Advertisement placement, lifecycle, tracking, priority, and display-order behavior is reused.
- No artificial SEO/location pages are created.

## Schema Coverage

| Model | Required/optional facts | Relations and constraints | Seed implication |
|---|---|---|---|
| `User` | `id`; optional name/email/phone/password/image; role/activity/verification defaults | Unique email and phone; Broker one-to-one; many auth/support/media/ad relations | Stable demo email is the natural upsert key; never seed real credentials or OAuth rows |
| `Broker` | Required public profile, phone, address, city/state, arrays, publication/verification/status fields; nullable `userId` and optional source/subscription | Unique `profileSlug` and nullable unique `userId`; reviews, banks, contacts, claim, subscription | Stable slug; explicitly model owned and optional unowned admin-created examples; only eligible profiles public |
| `BrokerClaim` | Required broker/status; lifecycle timestamps and optional completion actor | Unique `brokerId`; invitations/events | No claim row for self-registered profiles; only seed a non-sensitive claim scenario if needed |
| `BrokerClaimInvitation` | Required claim, token hash, recipient, status, expiry, creator | Unique token hash; claim and event relations | Do not seed raw tokens; preferably omit claim invitations from demo seed |
| `BrokerClaimEvent` | Required claim/event type/time; optional invitation/actor/JSON metadata | Append-only lifecycle relations | Omit unless a claim UI demonstration is explicitly required; use sanitized metadata |
| `BrokerSubscription` | Required unique broker, plan, active flag, dates; Stripe IDs optional | One current entitlement per Broker | Create only FREE or active FEATURED; all provider IDs null |
| `Review` | Required broker/rating; optional user/comment; publication default true | Broker required, User optional | Stable review keys are not modeled; Phase 13.1 needs deterministic lookup/update strategy |
| `ContactMessage` | Required broker/name/phone/message; optional user and inquiry details; status booleans | Broker required, User optional | Demo contacts must reference valid Brokers and use synthetic contact data; repeated seed must update/reuse |
| `BrokerBank` | Required broker/bank name/type; optional since | Broker relation; brokerId index | This is a profile relationship, not the `Bank` catalog; deterministic replace/upsert by broker/name |
| `Bank` | Required unique name/type; optional logo/description/office/site; active default | LoanProduct one-to-many; unique name | US-oriented catalog names and stable names; no duplicate loan products |
| `LoanProduct` | Required bank/name/rate/features; optional fees/limits/eligibility | Bank required; bankId index; no unique compound constraint | Must implement deterministic delete/reconcile or lookup before create; current `createMany` duplicates |
| `Property` | Required title/slug/type/price/currency/location/city/features/images; optional dimensions/details; active/featured | Unique slug; city/type/featured indexes | Stable US slugs and USD values; note no current public property detail route was found |
| `BlogPost` | Required title/slug/content/author/tags/category; optional SEO/cover; publication fields | Unique slug; publication/category indexes | Stable slug upsert; deterministic published content and existing media paths |
| `FAQ` | Required question/answer; optional category; active/order | Category/order indexes, no unique question | Stable question lookup or deterministic cleanup is required; current `create` duplicates |
| `Testimonial` | Required name/rating/comment; optional photo/city/type; active/order | Active index, no natural unique key | Add deterministic seed key strategy without schema change, or reconcile by fixed order/content |
| `MediaFolder` | Required name/path; optional parent; deletion flags | Unique path; hierarchy and deletion indexes | Stable path upsert; parent paths must exist first |
| `MediaAsset` | Required filename/original/file URL/MIME/ext/size/uploader; optional dimensions/thumbnail/folder/alt/tags | Folder/uploader relations; file URL index; soft delete | Every URL must map to a real supported file; stable folder+filename key; uploader is deterministic admin |
| `Advertisement` | Required title/slug/placement/type/action/creator; optional media/URLs/content; lifecycle/display/schedule flags | Unique slug; media and creator relations; status/schedule indexes | Stable placement slug; actual enum only; valid creative and safe destination; deterministic priority/order |
| `AdEvent` | Required advertisement/type/time; optional request metadata | Advertisement relation with cascade; event/ad and time indexes | Do not fabricate large analytics; omit by default or seed a small explicitly demo-labelled set after ad creation |
| `Setting` | Required unique key/value; optional type/category/description | Unique key | Upsert only approved application keys; do not overwrite deployment secrets |
| `Notification` | Required User/title/message; read default | User relation | Not required for public demo; omit |
| `SupportTicket` / `SupportMessage` | Required authenticated user/ticket/message fields | User/ticket relations; unique ticket number | Not required; omit to avoid private support data |
| `Account` | Required OAuth provider identifiers/tokens | Unique provider/providerAccountId; User cascade | Never seed OAuth accounts or tokens |
| `Message` | Required sender/receiver/conversation/message fields | User relations and conversation index | Not required; omit private messaging data |
| `StripeWebhookEvent` | Required provider event identifiers/status | Unique event ID and provider indexes | Never seed live/provider identifiers |

## Existing Seed Findings

### Reusable

- `prisma/seed/index.ts` already establishes a dependency order.
- `ensureAdmin()`, `upsertUser()`, folder creation, settings upsert, Broker slug upsert, and Blog slug upsert are reusable patterns.
- The exact Advertisement enum placement list is already present in `SEED_CONFIG` and matches the current Prisma enum.
- Existing generated demo image utility uses local WebP assets and Sharp, avoiding external hotlink dependence.

### Verified Defects and Gaps

1. Existing Broker, property, bank, FAQ, blog, testimonial, contact, and settings content is Nepal-oriented, not the required US demo dataset.
2. Users use random email suffixes/phones, so repeated seed runs can create new users.
3. Broker content, subscription values, status, dates, ratings, and relationships use random values. Stable slugs prevent some duplicates but do not provide deterministic results.
4. `BrokerStatus.FEATURED` is randomly assigned independently from the subscription entitlement, which can contradict the certified FREE/FEATURED boundary.
5. Existing Brokers are all created owned/self-registered; there is no explicit unowned admin-created public example.
6. Banks are reused by unique name, but loan products use `createMany()` with no unique constraint or reconciliation and duplicate on every run.
7. Properties use random slug suffixes and therefore duplicate on every run.
8. FAQs, testimonials, contacts, reviews, and ad events use `create()` and duplicate on every run. Contact seeding also increments every Broker's `totalLeads` on every run.
9. Ads use random slug suffixes and random priority/dates, so repeated runs create duplicates and non-deterministic ordering.
10. `seed-media.ts` references flat paths such as `/demo-images/Advertisements/hero-1.webp`, while the repository contains nested generated paths such as `/demo-images/Advertisements/Hero/bank-promotion-hero.webp`; several referenced Blog, Property, Testimonial, and Advertisement files are absent.
11. Advertisement mobile selection searches for `fileUrl.includes('Mobile')`, but the existing seed media list puts `mobile-1.webp` under `Advertisements` and the generated assets under `Advertisements/Mobile`; the current list does not provide a consistent deterministic mobile mapping.
12. Existing media records use random file sizes and one desktop dimension for every asset. The image generator declares `1200x628` desktop and `600x800` mobile sizes but currently writes only the desktop size.
13. Existing settings describe Nepal/NPR and disable email verification, conflicting with a US-oriented demo contract and requiring an explicit Phase 13.1 settings decision.
14. No public Property detail/listing route was found in the current Next route inventory. Property records can exercise data/API consumers, but a property page cannot be claimed until a route exists.
15. The current public FAQ page uses local component constants rather than the `FAQ` model, so seeded FAQ rows do not currently drive that page.

## Advertisement Audit

The exact configured placements are the 16 values in `AdvertisementPlacement` and `lib/advertisements/public.ts`: six homepage placements, three Broker placements, calculator, blog inline, footer, two announcements, popup, and mobile header banner. `AdvertisementRenderer.tsx` maps all 16 to existing components.

The certified selection contract is one highest-ranked publishable ad: `priority ASC`, `displayOrder ASC`, then `createdAt DESC`. No carousel or random rotation may be introduced. Phase 13.1 should seed one deterministic active ad for every placement and a small number of same-placement alternatives only where ordering/fallback needs demonstration.

The current application has no database dimension field or placement-specific dimension contract. The generator defines `1200x628` desktop and `600x800` mobile; component rendering uses responsive width/height-auto behavior. Phase 13.1 must not invent dimensions beyond those existing generator variants. Missing mobile creative falls back to desktop under the certified renderer.

## Environment and Data Safety

- No production database was used or mutated.
- The existing admin demo password is deterministic and must be treated as local-development-only, never a production credential.
- Use reserved synthetic domains such as `example.test` for demo users, synthetic phone numbers, null Stripe fields, and no OAuth/payment/session records.
- Do not seed raw claim tokens, API keys, provider secrets, real contact details, or real analytics identities.
- Seed execution must target an explicit isolated development database and refuse a production-looking environment unless an explicit demo override is supplied.

## Validation Evidence

- Prisma validate: PASS.
- Prisma generate: PASS.
- TypeScript: PASS.
- Production build: PASS.
- Advertisement tests: 2 passed.
- Public Broker tests: 2 passed.
- Phase 12 SEO plus Phase 12.2 SEO tests: 10 passed.
- No seed execution was performed, so seed idempotency is not yet certified.

## Limitations

- No isolated database seed run was authorized in Phase 13.0.
- Existing external/configured database state was not inspected or changed.
- Browser/media visual validation was not executed.
- No property public route or database-backed FAQ/blog UI integration is currently available to certify.
