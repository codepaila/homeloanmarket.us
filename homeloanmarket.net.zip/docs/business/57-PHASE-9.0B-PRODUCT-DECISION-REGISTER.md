# Phase 9.0B Product Decision Register

## Status

**OPEN — PRODUCT APPROVAL REQUIRED**

This register records unresolved mandatory Phase 9.1 decisions. No decision is silently inferred from current UI behavior.

| ID | Decision | Current Evidence | Options | Recommended Option | Business Impact | Security Impact | Phase 9.1 Impact | Status |
|---|---|---|---|---|---|---|---|---|
| P9B-001 | Advanced analytics access/fields | Dashboard fetches 30-day contact aggregates only for paid entitlement; docs only broadly mention permitted/advanced analytics | FEATURED-only; limited FREE; same access | Decide fields and entitlement explicitly; retain basic FREE stats | Dashboard value/paid differentiation | Avoid data exposure | Blocks feature gates/tests | PRODUCT DECISION REQUIRED |
| P9B-002 | FREE contact limits | Permission matrix says free limits, but no authoritative numeric limit or error contract | Existing behavior; numeric limit; no limit | Approve exact limit or explicitly no limit | Contact access/UX | Prevent inconsistent enforcement | Blocks owner API contract | PRODUCT DECISION REQUIRED |
| P9B-003 | FEATURED contact limits | Permission matrix says paid limits, no authoritative numeric limit | Existing behavior; numeric limit; no limit | Approve exact limit or explicitly no limit | Commercial behavior | Prevent client/server divergence | Blocks paid gates | PRODUCT DECISION REQUIRED |
| P9B-004 | FREE lead limits | Matrix says free limits; implementation exposes lead data but no frozen numeric contract | Existing behavior; numeric limit; no limit | Approve exact limit or explicitly no limit | Dashboard/lead access | Prevent overexposure | Blocks API/UI tests | PRODUCT DECISION REQUIRED |
| P9B-005 | FEATURED lead limits | Matrix says paid limits; exact values/fields absent | Existing behavior; numeric limit; no limit | Approve exact limit or explicitly no limit | Paid entitlement | Prevent overexposure | Blocks API/UI tests | PRODUCT DECISION REQUIRED |
| P9B-006 | Review mutations | Sources define review preservation/viewing but not owner response/edit/delete/moderation | Read-only owner; response only; edit/delete; admin-only | Keep owners read-only until explicitly decided | Trust/reputation workflow | Prevent unauthorized moderation | Blocks review API tests | PRODUCT DECISION REQUIRED |
| P9B-007 | Owner visibility editing | `PATCH /api/brokers/me` currently accepts `isVisible`; business rules say admin publishes/controls admin state | Admin-only; owner request; owner edit within policy | Admin-only unless a separate owner request contract is approved | Publication control | Prevent owner publication bypass | Blocks PATCH contract | PRODUCT DECISION REQUIRED |
| P9B-008 | Admin dashboard impersonation | No documented or implemented impersonation flow; admin UI is separate | Deny; audited read-only view; audited mutation-capable impersonation | Deny until separately designed | Support/admin operations | Highest privilege boundary | Blocks ADMIN state/API behavior | PRODUCT DECISION REQUIRED |
| P9B-009 | Paid placement controls | FEATURED grants placement entitlement; no owner control contract beyond billing | Automatic entitlement only; owner controls; admin controls | Automatic entitlement only; no new controls | Commercial placement | Prevent publication coupling | Blocks FEATURED UI contract | PRODUCT DECISION REQUIRED |
| P9B-010 | Expired/cancelled messaging | Resolver falls back to FREE; UI messaging is not specified | Silent fallback; informational banner; redirect | Preserve access and define explicit UX | User expectation | Avoid misleading entitlement | Blocks dashboard state UI | PRODUCT DECISION REQUIRED |
| P9B-011 | Dashboard stats response | `/api/brokers/me/dashboard-stats` returns stats without formal Phase 9 schema | Preserve current; additive envelope; split basic/advanced | Preserve current fields; add only approved additive fields | API compatibility | Avoid data leakage | Blocks API freeze | PRODUCT DECISION REQUIRED |
| P9B-012 | Admin access to Broker dashboard | Admin has separate admin workflows; no Broker-dashboard behavior | Deny; separate read-only route; impersonation | Keep separate admin UI | Admin workflow | Avoid privilege confusion | Blocks dashboard state | PRODUCT DECISION REQUIRED |
| P9B-013 | Error body standardization | Existing routes use different `{message}` and `{success,error}` shapes/statuses | Preserve route-specific; standardize additive; breaking standardization | Preserve existing contracts; document route-specific behavior | Client compatibility | Consistent security errors | Blocks API acceptance if not frozen | PRODUCT DECISION REQUIRED |
| P9B-014 | Authenticated HTTP harness | No project-owned dashboard HTTP harness exists | Add before implementation; add during implementation; manual only | Add isolated harness before final Phase 9.1 certification | Verification cost | Required IDOR proof | Blocks acceptance | PRODUCT DECISION REQUIRED |
| P9B-015 | Browser E2E harness | No Playwright/browser fixture exists | Provision; defer with limitation; manual only | Provision for final certification; do not claim until run | UX confidence | Auth/session proof | Blocks full acceptance, not contract design | PRODUCT DECISION REQUIRED |

## Resolved Boundaries

- FREE is baseline entitlement.
- FEATURED is the only paid entitlement.
- PREMIUM is unsupported.
- Subscription never proves ownership, verification, or publication.
- `Broker.userId` remains ownership authority.
- Claim completion remains ownership transition.
- Advertisement CMS is separate.
- No Phase 9 schema change is currently required.
