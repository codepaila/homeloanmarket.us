# Recipient Email Implementation Report

## Status

Phase 6.8 implements the approved invitation recipient model and hardens invitation management without implementing claimant-side Phase 7 behavior.

## Schema Change

Added the required field:

```prisma
recipientEmail String
```

to `BrokerClaimInvitation`.

`recipientEmail` is operational delivery data and remains independent from `Broker.email` and `User.email`.

## Existing Data Safety

Before adding the required field, both databases were inspected:

Configured database:

- invitations: 0
- invitations with recipient: 0
- invitations without recipient: 0

Isolated test database:

- invitations: 0
- invitations with recipient: 0
- invitations without recipient: 0

No backfill, invented email, history deletion, or placeholder value was required.

## Invitation Creation

Individual invitation issuance now persists normalized `recipientEmail` on the new invitation. Broker eligibility, admin authorization, token hashing, seven-day expiry, one-active-invitation locking, superseding, claim events, and post-commit email behavior remain unchanged.

The explicit issue response now includes `claimLink` only for the authorized admin request that generated it. It is not returned from list/detail APIs or bulk responses.

## Resend

Resend now reads the persisted recipient email by default. The admin may optionally provide a replacement valid email. The new invitation persists the selected normalized recipient email, receives a fresh seven-day expiry/token, and supersedes the previous active invitation.

Corrupt/missing legacy recipient data produces a safe validation error and requires a new explicit recipient email.

## Revoke

Revoke remains ADMIN-only, lock-compatible with issuance/resend, terminal for the invitation, idempotent for terminal state, and history-preserving. No invitation records are deleted.

## Copy Claim Link

The explicit issue/resend response returns the raw claim URL only to the authorized admin caller. The admin detail UI holds it in memory and provides Copy Claim Link. The URL is not persisted, logged, placed in events, returned by normal list/detail APIs, or included in bulk responses. Copying does not send email or create another invitation.

No claimant route or token-consumption behavior was added.

## Bulk Invitations

Added:

`POST /api/admin/brokers/bulk-claim-invitations`

Behavior:

- maximum 50 items;
- ADMIN-only;
- each item has Broker ID and recipient email;
- only eligible unowned ADMIN_CREATED Brokers are accepted;
- each item uses its own lock, transaction, token, expiry, recipient, and email;
- one item failure does not roll back others;
- response contains per-item status/invitation ID/expiry or safe failure code;
- no raw tokens or claim URLs are included in the bulk response.

The admin Broker list now includes bulk selection and per-Broker recipient inputs for eligible unowned profiles.

## Security Validation

- `recipientEmail` is normalized and validated server-side.
- Broker/User/role/plan/verification/ownership fields remain server-controlled.
- Raw tokens remain digest-only in the database.
- Raw URLs are limited to explicit admin issue/resend responses and in-memory clipboard handling.
- Claim events do not contain recipient secrets, raw tokens, raw URLs, or passwords.
- One-active-invitation and Redis lock behavior remains enforced.
- The Phase 6.6 partial owner index remains unchanged.

## MongoDB Ownership Compatibility

The ownership index was not redesigned in this phase. The existing remediation remains:

```text
brokers_userId_non_null_unique
unique: true
partialFilterExpression: { userId: { $type: "objectId" } }
```

Multiple null owners and unique non-null ownership remain supported.

## Tests

Existing unit/policy suite:

- 15 passed, 0 failed.

Isolated MongoDB replica-set integration suite:

- 7 passed, 0 failed.
- recipient email persistence verified;
- multiple unowned Brokers verified;
- duplicate non-null owner rejection verified;
- ownership attachment compatibility verified;
- partial index verified;
- invitation lifecycle verified.

No real production email was sent. HTTP authorization tests remain limited by the absence of an authenticated integration harness.

## Prisma

- `npx prisma format`: PASS
- `npx prisma validate`: PASS
- `npx prisma generate`: PASS
- Production and isolated MongoDB schema synchronization completed without deleting invitation records.
- Ownership index reconciler rerun after synchronization.

## TypeScript and Lint

`npx tsc --noEmit` still reports only pre-existing errors:

- missing `.next/dev/types/validator.ts` route modules;
- existing `prisma.config.ts` `seed` typing issue.

No new recipient-email or invitation-management TypeScript errors were introduced.

Focused ESLint checks pass.

## Remaining Limitations

- Claimant-side Phase 7 remains unimplemented.
- Recipient email persistence now exists, but no historical invitations required backfill.
- Real email provider delivery is not exercised in tests.
- HTTP ADMIN/BROKER/USER/unauthenticated integration tests require an auth test harness.
- Bulk email delivery concurrency depends on configured Redis/email infrastructure.

## Phase 7 Readiness

**READY FOR PHASE 7 — CLAIMANT-SIDE IMPLEMENTATION**

The invitation-management contract is now internally aligned with Prisma, persisted recipient history, resend behavior, copy-link behavior, bulk processing, token security, and the remediated ownership index. No claimant-side implementation was started.
