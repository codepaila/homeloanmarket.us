# Phase 13.0 Seed Implementation Contract

This contract freezes the boundaries for Phase 13.1 implementation. It does not authorize production execution or schema changes.

## Scope

Implement a repeatable isolated-development demo seed for the current schema and application. Reuse current models and APIs. Do not redesign the application, add public routes, add SEO pages, add an advertiser workflow, or alter certified business behavior.

## Required Seed Properties

1. The seed must require an explicit development/demo environment and refuse known production configuration by default.
2. All entity keys must be deterministic. Use fixed emails, profile slugs, content slugs, bank names, media folder paths, media folder+filename pairs, and advertisement slugs.
3. Use upsert/update/reconcile behavior. Do not use uncontrolled `create()` or random suffixes for repeatable demo entities.
4. Use one fixed seed reference time for dates. Do not call `Math.random()` or wall-clock-relative random helpers for persisted demo values.
5. Return stable entity collections from each stage so downstream stages reference the records actually seeded.
6. Do not delete non-demo records. Reconcile only records carrying an explicit demo namespace/key, or use deterministic upserts that leave unrelated data untouched.

## Broker and Ownership Rules

- Seed owned profiles with `creationSource=SELF_REGISTERED`, stable synthetic User ownership, and FREE or active FEATURED subscriptions.
- Seed at least one `ADMIN_CREATED` unowned profile with `userId=null` if the current nullable schema is used. It may be public only when `isPublicBroker()` passes.
- Seed negative visibility/verification/suspension fixtures only when they are clearly namespaced demo records and never public.
- Do not create claim invitations or raw claim tokens by default. If claim UI coverage is required, use hashed deterministic test fixtures without plaintext tokens and preserve the claim state machine.
- Do not use `BrokerStatus.FEATURED` as a substitute for a paid subscription. New FEATURED behavior must be backed by active `BrokerSubscription.plan=FEATURED`; FREE remains the default.
- Do not create PREMIUM records.

## Content Rules

- Use US cities/states and USD property values.
- Keep Broker public fields realistic but synthetic. Do not use real private phone numbers or email addresses.
- Reviews must reference valid Brokers, be published only for intended eligible profiles, and use deterministic ratings/comments.
- Contacts must reference valid Brokers, use synthetic contact identities, and never expose them through public projections.
- Blog, FAQ, and testimonial content must be stable and representative. Existing FAQ page constants are not silently replaced; database-backed UI integration is a separate verified dependency.
- Settings are limited to keys actually consumed by the current app. US/SEO settings may be seeded only after confirming their runtime consumers. Never seed secrets.

## Media Contract

- Use the actual `MediaFolder` and `MediaAsset` schema.
- Create stable folder paths under a demo namespace, including `Demo Properties`, `Demo Brokers`, `Demo Blog`, `Demo Advertisements`, `Demo Advertisements/Mobile`, `Demo Logos`, and `Demo General`.
- Ensure every `fileUrl` and `thumbnailUrl` points to a committed/generated local file that exists before the database row is created.
- Supported demo media is WebP with MIME `image/webp`; record actual byte size and dimensions, not random placeholders.
- Existing generator dimensions are `1200x628` desktop and `600x800` mobile. Use only these variants unless the application adds an approved dimension contract.
- Do not hotlink external images in seeded runtime data. If Unsplash or another free source is used to generate a local asset, record source URL and attribution in a manifest and do not scrape copyrighted assets.
- Never create orphan MediaAssets. Repeated runs must update the same folder/file records.

## Advertisement Contract

- Use exactly the 16 values in `AdvertisementPlacement`; no invented placement names.
- Create a stable ad for every configured placement. Add same-placement alternatives only for deterministic priority/fallback testing.
- Use existing renderer mappings and tracking wrapper. Do not add carousel/rotation architecture.
- Use valid `AdType`, `AdvertisementAction`, and `ButtonVariant` combinations supported by current validation.
- Every published ad must have a valid desktop/mobile MediaAsset or safe fallback banner URL, valid alt text, safe destination, fixed schedule, and admin creator.
- Set deterministic `priority` and `displayOrder`; verify selection order rather than relying on creation timing.
- Keep ad lifecycle fields explicit: enabled, not archived, not deleted, schedule currently publishable.
- Seed zero analytics by default. Any small historical demo events must be deterministic, synthetic, and explicitly separated from production analytics.

## Idempotency Plan

| Model | Idempotency key/strategy |
|---|---|
| User | Fixed email; update demo-owned fields only |
| Broker | Fixed profileSlug; update demo-owned fields and preserve relations |
| Subscription | Fixed brokerId; upsert one current entitlement |
| BrokerBank | Reconcile by brokerId + bankName within demo profiles |
| Bank | Unique name upsert |
| LoanProduct | Reconcile by bankId + stable product name; current schema lacks a unique compound constraint |
| Property | Fixed slug upsert |
| BlogPost | Fixed slug upsert |
| FAQ | Fixed demo key represented by stable question/content; current schema lacks a unique key, so reconcile explicitly |
| Testimonial | Fixed demo key represented by stable ordinal/content; current schema lacks a unique key, so reconcile explicitly |
| ContactMessage | Fixed demo identity/ordinal strategy; update existing demo rows instead of append-only create |
| Review | Fixed broker/ordinal strategy; update existing demo rows instead of append-only create |
| MediaFolder | Unique path upsert/reuse |
| MediaAsset | Folder + filename upsert/reuse |
| Advertisement | Fixed slug upsert |
| AdEvent | Omit by default; if enabled, fixed event fixture strategy and explicit demo scope |
| Setting | Unique key upsert |

The contract must not add schema fields merely to create seed keys unless a later audit proves it is unavoidable. Prefer deterministic reconciliation using existing fields and a namespaced demo set.

## Validation Contract

Phase 13.1 must run against an isolated MongoDB database and capture before/after counts. Required sequence:

1. Prisma validate.
2. Prisma generate.
3. TypeScript.
4. Production build.
5. Existing Advertisement, public Broker, security/public projection, and SEO tests.
6. First seed run.
7. Second seed run with count/key comparison.
8. Third seed run with count/key comparison.
9. Public eligibility/sitemap/robots checks against the seeded records.
10. Media file existence, MIME, dimension, and orphan checks.
11. Advertisement placement, schedule, creative, ordering, and tracking checks.

No production database, production environment, ownership state, subscription state, claim state, or Advertisement data may be mutated during validation.

## Explicit Non-Goals

- No schema migration unless a separate verified compatibility defect stops implementation.
- No production data insertion.
- No public Property route or database-backed FAQ redesign.
- No artificial city/state/location SEO pages.
- No advertiser accounts, inquiry workflow, CRM, payments, analytics vendor, or carousel.
- No changes to authorization, ownership, claims, subscriptions, public eligibility, SEO architecture, or Advertisement behavior.

## Acceptance Criteria

- Matrix targets are represented with stable US demo data.
- Three consecutive isolated runs converge to the same deterministic result.
- No duplicates, broken media paths, orphan media, invalid ad placement, unsafe destination, or private data leakage is demonstrated.
- Certified Phase 1-12.2 tests and business behavior remain unchanged.
- Any unavoidable schema limitation is reported and implementation stops rather than guessing.
