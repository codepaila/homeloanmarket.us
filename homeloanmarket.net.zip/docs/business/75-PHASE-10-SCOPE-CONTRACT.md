# Phase 10 Scope Contract

## 1. Objective

Integrate and harden public Broker profile/listing behavior so all public surfaces consistently apply the existing publication predicate, support approved unowned admin-created profiles, hide suspended/disabled profiles, preserve URLs/reviews/contact behavior, and expose only public profile data.

## 2. Problem Being Solved

The current listing/detail paths use the public predicate, but public reviews and contact submission do not consistently enforce the same publication policy. Some public projections also include User account identifiers. Phase 10 closes these verified consistency/privacy gaps without redesigning publication rules.

## 3. Authorized Users

- Public visitors: read eligible public profiles, reviews, and submit contact requests where existing policy permits.
- Broker owners: existing authenticated owner behavior; no new Phase 10 public authority.
- Admins: existing admin profile/publication/verification authority.

## 4. Admin Capabilities

Existing admin operations remain authoritative:

- create/edit/publish/hide/verify/unverify/suspend/disable Broker profiles;
- manage claim lifecycle separately;
- inspect public/ownership/verification state.

No new admin workflow is introduced.

## 5. Broker Capabilities

No new Broker capability is introduced. Owners retain existing profile/contact/dashboard behavior. Phase 10 does not grant publication or verification authority.

## 6. FREE/FEATURED Capabilities

FREE and FEATURED do not alter public publication eligibility. FEATURED remains commercial placement/entitlement only. Neither plan proves ownership, verification, or publication.

## 7. Public Behavior

Every public Broker listing, slug profile, review response, and contact submission must use the same effective public predicate:

- `isVisible=true`;
- `verificationStatus=VERIFIED`;
- `brokerStatus != SUSPENDED`;
- unowned profiles may pass without a User when admin-approved;
- owned profiles require an active owner account;
- no public response includes owner account identifiers, private claim data, or leads.

Public contact submission must not require a non-null User relation for an approved unowned profile and must reject hidden/ineligible profiles.

## 8. API Requirements

Reuse existing routes without breaking response contracts:

- `GET /api/brokers`;
- `GET /api/brokers/[id]`;
- `GET /api/company/[slug]`;
- `GET /api/company/[slug]/reviews`;
- `POST /api/contacts/send`.

Required bounded fixes:

- apply the shared predicate to public reviews/contact;
- use public-safe projections;
- preserve existing success/error status shapes where practical;
- do not add duplicate routes.

## 9. Database Requirements

**No Phase 10 schema change is currently required.** Existing Broker visibility/verification/status/ownership fields, Review publication, ContactMessage, and profileSlug support the scope.

## 10. Authorization Rules

- Public reads use the shared public predicate.
- Public contact submission can target only an eligible public Broker.
- Owner/admin private APIs retain existing authorization.
- No client field changes ownership, verification, visibility, subscription, or claim state.

## 11. Ownership Rules

No changes. `Broker.userId` remains ownership authority and claim completion remains the ownership transition.

## 12. Subscription Rules

No changes. FREE/FEATURED effective entitlement and PREMIUM rejection remain as certified.

## 13. UI Requirements

No redesign. Existing public listing/profile/review/contact pages should consume the corrected API projections and preserve existing URL/layout behavior.

## 14. Security Requirements

- Prevent hidden-profile review/contact access.
- Prevent owner account identifier leakage in public responses.
- Preserve public URL and profile data behavior.
- Preserve existing rate limits and safe input handling.

## 15. Analytics Requirements

No new analytics. Existing profile counters/reviews/contact counts remain unchanged except that unauthorized public access must not create contact or view side effects.

## 16. Testing Requirements

- public listing eligibility;
- public slug eligibility;
- unowned approved profile;
- suspended/disabled/inactive owner exclusion;
- hidden profile review rejection;
- hidden profile contact rejection;
- unowned approved profile contact acceptance where existing fields support it;
- public response private-field exclusion;
- existing owner/claim/subscription/dashboard/advertisement regressions.

## 17. Migration Requirements

No migration or production data mutation is authorized. If invalid public records are found, classify and report them before any action.

## 18. Explicit Non-Goals

- no new publication states;
- no SEO redesign;
- no advertiser CRM/inquiries;
- no ownership/claim/verification/subscription/dashboard changes;
- no Advertisement CMS changes.

## 19. Acceptance Criteria

- All public Broker surfaces use consistent eligibility policy.
- Approved unowned profiles can be public without User dereference.
- Suspended/disabled/inactive-owner profiles are hidden.
- Hidden profiles cannot receive public review/contact access.
- Public responses omit private owner account/claim data.
- Existing URLs, reviews, contact behavior, and API contracts remain compatible.
- No ownership, claim, verification, visibility, subscription, dashboard, or Advertisement invariant changes occur.
