# Phase 13.1 Seed Idempotency Report

## Deterministic Keys

| Fixture family | Key |
|---|---|
| Admin/demo Users | fixed `demo.*@example.test` email |
| Brokers | fixed `demo-*-mortgage` profileSlug |
| Subscriptions | Broker ID |
| BrokerBank | demo Broker ID plus fixed bank name; demo-scoped reconciliation |
| Banks | unique bank name |
| LoanProducts | bank ID plus fixed product name |
| Properties | fixed slug |
| BlogPosts | fixed slug |
| FAQs | fixed `[Demo]` question |
| Testimonials | fixed name plus fixed comment |
| Reviews | Broker ID plus fixed comment |
| Contacts | Broker ID plus fixed email and subject |
| MediaFolders | `phase13/<stable-folder-name>` path |
| MediaAssets | folder ID plus filename |
| Advertisements | unique stable slug |
| Advertisement events | advertisement ID, event type, page, country, city, and fixed timestamp |
| Settings | unique setting key |

## Dependency Graph

```text
isolated database guard
  -> admin and demo users
  -> Brokers
  -> BrokerSubscriptions and BrokerBank relationships
  -> Banks and LoanProducts
  -> Properties and published content
  -> MediaFolders and verified MediaAssets
  -> Advertisements
  -> Reviews and ContactMessages
  -> deterministic AdEvents
  -> Settings
  -> integrity summary
```

The order resolves all required parent IDs before dependent records are created. Public review/contact fixtures are selected only from Brokers passing the existing publication predicate.

## Repeatability Evidence

The seed was run repeatedly against the isolated MongoDB database:

### Run 1

```text
Users: 17
Brokers: total 16, owned 15, unowned 1, public eligible 13, non-public 3
Subscriptions: FREE 9, active FEATURED 5, expired/cancelled 2, PREMIUM 0
Reviews: 26, orphan 0
Contacts: 19, orphan 0
Advertisements: 20, published 17, placement coverage 16
Media: folders 7, assets 25, missing references 0, invalid folder references 0
Analytics: 6 events, orphan 0
Duplicates: users 0, brokers 0, subscriptions 0, reviews 0, contacts 0, advertisements 0, media 0
```

### Run 2

The exact same counts and duplicate/orphan results were produced. No logical fixture count increased.

### Additional Run

A further execution after the logical duplicate audit was added produced the same counts and zero duplicate/orphan results.

## Event Strategy

Advertisement events have no schema uniqueness constraint. The seed therefore uses a deterministic lookup tuple and creates six small demo events only when the tuple is absent. It does not use random timestamps or append unbounded history.

## Destructive Operation Review

- No `prisma db push`.
- No migration.
- No reset.
- No collection drop.
- No broad delete.
- `BrokerBank.deleteMany` is scoped to each deterministic demo Broker before recreating its two fixed demo relationships. This is safe only behind the local/demo database guard.

## Remaining Limitation

Because FAQ, testimonial, review, contact, LoanProduct, MediaAsset, and AdEvent models lack all desired logical uniqueness constraints, their idempotency is application-level reconciliation rather than database-enforced uniqueness. The deterministic keys and isolated guard are required to preserve this guarantee.
