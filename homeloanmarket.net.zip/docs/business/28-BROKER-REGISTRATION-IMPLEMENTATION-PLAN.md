# Broker Registration Implementation Plan

This is a future implementation plan only. No broker registration behavior was implemented in this audit.

## Current State

`app/api/auth/register/broker/route.ts` validates and rate-limits input, hashes a password, creates a `User` with role `BROKER`, and sends a verification email. It does not create a Broker or BrokerSubscription. A separate authenticated `POST /api/brokers` creates Broker, bank rows, updates role, and creates FREE, but those operations are not one transaction.

## Target Flow

`Register as Broker -> validate -> create User + Broker + FREE atomically -> set userId and SELF_REGISTERED -> persist verification token/expiry -> commit -> send verification -> verify -> activate -> dashboard`.

No claim invitation, BrokerClaim, token, or admin approval is involved.

## Recommended Order

1. Define the broker registration input contract and normalize email/phone.
2. Preserve rate limiting, CAPTCHA, password hashing, and duplicate protection.
3. Use one database transaction for User, Broker, `creationSource=SELF_REGISTERED`, `userId`, and FREE BrokerSubscription.
4. Decide whether initial bank rows belong in the same transaction.
5. Generate/store verification digest and explicit expiry using the new User field.
6. Send email only after commit; delivery failure leaves a recoverable pending account/profile.
7. Keep account login/dashboard activation gated by `emailVerified` and `isActive` policy.
8. Update User-session serialization to expose the owned Broker without treating plan/status as ownership.
9. Give active FREE owners basic dashboard/profile/lead access; gate only paid features.
10. Apply `creationSource` in all direct registration and import paths.
11. Update public predicates, email notifications, and owner authorization for nullable ownership.
12. Add transaction, duplicate, verification, FREE, authorization, and rollback tests.

## Failure Handling

- Duplicate email/phone: safe conflict or recovery response; never a second User.
- User/Broker/FREE transaction failure: roll back all three.
- Email delivery failure after commit: retain pending account and allow rate-limited resend.
- Verification expiry: clear/rotate token and retain profile ownership/FREE state.
- User without Broker: allow normal user behavior; do not infer broker ownership from role alone.

## Explicit Non-Goals

This plan does not include claim invitations, admin-created profiles, claim completion, premium implementation, dashboard UI redesign, or email template implementation. Those are separate phases.
