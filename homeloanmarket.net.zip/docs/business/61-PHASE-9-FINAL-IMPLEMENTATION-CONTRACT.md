# Phase 9 Final Implementation Contract

## 1. Objective

Converge directly registered and successfully claimed Brokers on one authenticated dashboard and one owner API model while preserving ownership, claiming, verification, visibility, subscription, and Advertisement CMS contracts.

## 2. Scope

- Shared `/broker/dashboard`.
- Existing owner APIs and server-side ownership resolution.
- Nullable `Broker.userId` safety.
- Frozen FREE/FEATURED permission matrix from document 60.
- Dashboard authentication/authorization states.
- Existing loading/error/empty/mobile behavior.
- Authenticated HTTP tests and browser certification when infrastructure exists.

## 3. Out of Scope

- Advanced analytics expansion.
- Subscription-specific contact/lead limit invention.
- Review mutations/moderation features.
- Visibility/publication redesign or new owner publication power.
- Admin dashboard impersonation.
- Manual FEATURED placement controls.
- Detailed expired/cancelled messaging redesign.
- New APIs, response redesign, schema changes, new tiers, Stripe changes, Advertisement CMS changes, CRM, advertiser workflows, or unrelated refactoring.

## 4. Ownership

- `Broker.userId` is authoritative ownership.
- Direct registration attaches `Broker.userId` transactionally.
- Claim completion conditionally attaches an unowned admin-created Broker.
- A User cannot own multiple Brokers under the existing partial unique index.
- Client-provided User/Broker/owner IDs are never authority.
- Unowned Brokers have no owner dashboard.

## 5. Authentication

Reuse NextAuth JWT, Credentials, Google, bcrypt, email verification, active-account, and claim reauthentication architecture. Invalid, stale, inactive, or unauthenticated sessions cannot access protected owner data.

## 6. Authorization

```text
Session -> server User -> Broker where Broker.userId = User.id -> owner data
```

Wrong owners are denied. Admin uses separate admin APIs/UI. Subscription is never ownership or verification authority.

## 7. FREE Permissions

- Dashboard: ALLOW after activation.
- Own profile read/edit: ALLOW authorized fields.
- Basic statistics: ALLOW existing fields.
- Contacts/leads: LIMITED by existing behavior; no new subscription cap.
- Reviews: ALLOW existing read behavior; mutations OUT OF SCOPE.
- Billing/upgrade: ALLOW own account.
- Verification, ownership, claim, and publication override: DENY.

## 8. FEATURED Permissions

- Dashboard: ALLOW after activation.
- Own profile read/edit: ALLOW authorized fields.
- Basic statistics: ALLOW existing fields.
- Contacts/leads: LIMITED by existing behavior; no new subscription cap.
- FEATURED placement: ALLOW through effective entitlement only.
- Billing/cancellation/portal: ALLOW own account.
- Advanced analytics, manual placement controls, verification, ownership, claim, and publication override: OUT OF SCOPE/DENY.

## 9. Analytics

Phase 9.1 preserves existing basic dashboard statistics. Advanced analytics expansion is OUT OF SCOPE. No new analytics fields, limits, or storage are introduced.

## 10. Contacts and Leads

No subscription-specific numeric limits are defined by authoritative documentation. Phase 9.1 preserves current behavior and owner authorization. It must not invent FREE or FEATURED caps.

## 11. Reviews

Existing public review read behavior remains. Owner review mutations and new moderation behavior are OUT OF SCOPE. Existing admin review policy remains separate.

## 12. Visibility

Phase 9.1 does not change visibility/publication behavior. Existing admin publication rules remain authoritative. FREE/FEATURED and ownership do not grant publication or verification.

## 13. FEATURED Placement

FEATURED is the paid placement entitlement only. It is not ownership, identity, verification, publication authority, or Advertisement CMS access. Expiry/cancellation/missing/unsupported states use effective FREE.

## 14. Subscription States

| Stored/effective state | Dashboard result |
|---|---|
| Missing subscription | FREE behavior |
| FREE active | FREE behavior |
| FEATURED active | FEATURED behavior |
| FEATURED expired | FREE behavior |
| FEATURED cancelled/inactive | FREE behavior |
| Unsupported/invalid | FREE-safe behavior |

## 15. Dashboard States

| State | Access | Data/API | Permissions |
|---|---|---|---|
| Unauthenticated | DENY | 401/protected route behavior | None |
| Authenticated without Broker | DENY/SETUP | `/api/brokers/me` 404 | None |
| Owned FREE | ALLOW | Own Broker only | FREE matrix |
| Owned FEATURED | ALLOW | Own Broker only | FEATURED matrix |
| Expired/cancelled FEATURED | ALLOW | Own Broker only | FREE matrix |
| Missing subscription | ALLOW | Own Broker only | FREE matrix |
| Unverified owner | Existing activation policy | Existing owner policy | No verification implication |
| Verified owner | ALLOW | Own Broker only | Same entitlement matrix |
| Unowned Broker | DENY owner dashboard | No owner authority | Admin/public only |
| Admin | Separate admin UI | Admin APIs | No impersonation |
| Unauthorized user | DENY | 403/404 existing route behavior | None |
| Missing/deleted Broker | DENY | 404/401/403 existing behavior | None |

## 16. Owner APIs

| API | Method | Auth | Owner check | FREE | FEATURED | ADMIN |
|---|---|---|---|---|---|---|
| `/api/brokers/me` | GET | Authenticated BROKER | `Broker.userId = currentUser.id` | Own data | Own data | 403/separate admin |
| `/api/brokers/me` | PATCH | Authenticated BROKER | `Broker.userId = currentUser.id` | Authorized fields | Authorized fields | 403/separate admin |
| `/api/brokers/me/dashboard-stats` | GET | Authenticated with Broker | Server Broker resolution | Existing basic stats | Existing basic stats | Separate admin |
| `/api/brokers/[id]/contacts` | GET | Authenticated | Owner or ADMIN | Existing behavior | Existing behavior | ADMIN |
| `/api/user/profile` | GET/PATCH | Authenticated current User | Current User | Same | Same | Own admin account |
| Subscription routes | Existing Phase 8.5 | Owner/admin as documented | Server owner resolution | FREE fallback | FEATURED lifecycle | Reconciliation |

### Error Contract

Existing route-specific response bodies are preserved. Status meanings for Phase 9.1 tests are:

- 400 invalid request;
- 401 unauthenticated/invalid session;
- 403 authenticated but unauthorized;
- 404 missing/hidden resource;
- 409 supported current-state conflict;
- 422 supported validation/business failure;
- 429 rate limiting where existing;
- 500 unexpected server failure.

No breaking standardization is authorized.

## 17. Security Invariants

- Subscription does not prove ownership.
- Ownership does not prove verification.
- Verification does not prove publication.
- FEATURED does not grant ownership or verification.
- Claim completion remains ownership transition.
- `Broker.userId` remains ownership authority.
- Admin privileges remain separate from Broker ownership.
- No cross-Broker owner API access.
- No client-controlled entitlement or identity authority.

## 18. Test Requirements

### Unit

- effective FREE/FEATURED resolution;
- expired/cancelled/missing fallback;
- permission projection boundaries.

### Integration

- direct registration/dashboard convergence;
- claim/dashboard convergence;
- owner/non-owner/admin/unauthenticated authorization;
- null/unowned Broker handling;
- existing profile/contact/review/lead/billing regressions.

### HTTP

- authenticated owner;
- wrong owner;
- unauthenticated;
- admin;
- invalid/stale session;
- invalid/missing Broker;
- FREE/FEATURED/fallback states;
- IDOR and client-ID tampering.

### Browser

- direct registration flow;
- claim flow;
- FREE dashboard;
- FEATURED dashboard;
- fallback dashboard;
- wrong-user denial;
- mobile dashboard;
- loading/empty/error states.

Browser infrastructure is required before final Phase 9.1 certification; no browser result is claimed now.

## 19. Acceptance Criteria

- Direct and claimed owners use the same dashboard.
- Owner APIs derive authority server-side.
- Nullable ownership is safe.
- Non-owners are denied.
- FREE/FEATURED matrix is implemented exactly as document 60.
- No artificial contact/lead limits are introduced.
- Advanced analytics and review mutations remain out of scope.
- Visibility/publication behavior remains unchanged.
- Subscription fallback remains FREE-safe.
- Existing API contracts remain compatible.
- HTTP and browser test plans execute or limitations are explicitly reported.
- Registration/claim/ownership/verification/visibility/subscription/advertisement regressions pass.

## 20. Explicit Non-Goals

- No new dashboard product feature without a new contract.
- No advanced analytics expansion.
- No review mutation workflow.
- No admin impersonation.
- No contact/lead cap invention.
- No visibility/publication change.
- No subscription architecture change.
- No Phase 9.1 implementation in this phase.
