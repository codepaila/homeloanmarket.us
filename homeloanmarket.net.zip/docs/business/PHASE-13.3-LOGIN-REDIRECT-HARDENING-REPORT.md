# Phase 13.3 Login Redirect Hardening Report

## Root Cause Fixed

Credentials login used a client-only `redirect: false` flow followed by a client session read and router navigation. This introduced a race between Auth.js cookie/session establishment and destination calculation. The existing server action, which could have returned an Auth.js server redirect, was not connected to the sign-in page.

## Files Changed

- `actions/auth.action.ts`
- `app/(public)/auth/signin/page.tsx`
- `lib/auth-redirect.ts`
- `tests/phase-13.2-login-redirect.test.ts`

## Implementation

### Credentials

The sign-in page now constructs a `FormData` payload and calls the existing `LoginWithCredential` server action. The action:

1. Resolves the stored User role by normalized email.
2. Sanitizes the supplied callback against the configured same-origin base.
3. Applies `postLoginRedirect()` using the stored role, never a client role.
4. Calls Auth.js `signIn('credentials', { redirectTo })` so the server owns the successful redirect.
5. Returns existing AuthError messages for failed credentials.

### OAuth

OAuth returns through `/auth/signin?callbackUrl=...`. The active root proxy sees the authenticated session and performs the server-side role-aware redirect, avoiding a client role race.

### Callback Correction

The centralized helper now distinguishes public `/brokers` from protected `/broker/*` using route boundaries rather than a raw string prefix.

## Preserved Behavior

- Existing Auth.js providers and session/JWT callbacks remain in use.
- Registration verification and claim completion routes are unchanged.
- Ownership, claims, subscriptions, Advertisement CMS, SEO, schema, and seeded data are unchanged.
- No client-side `window.location` workaround was added.
