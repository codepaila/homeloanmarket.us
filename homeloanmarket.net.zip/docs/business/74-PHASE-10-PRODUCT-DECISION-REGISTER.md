# Phase 10 Product Decision Register

## Status

**SCOPE DERIVED — IMPLEMENTATION CONTRACT PENDING FINAL REVIEW**

## Candidate Matrix

| Capability | Source | Existing implementation | Gap | Dependency | Business rule | Status |
|---|---|---|---|---|---|---|
| Central public publication predicate | `IMPLEMENTATION_PLAN.md` Phase 10; `08-PUBLIC-PROFILE-RULES.md` | `isPublicBroker()` exists and is used by primary listing/detail paths | Reviews/contact paths do not consistently use it | Broker fields/policy helper | Visibility independent; suspended/disabled hidden | P0 REQUIRED |
| Approved unowned public profiles | BR-001/020; public rules | Listing/detail predicates can support `userId=null` | Contact/review paths assume User in places | Nullable Broker.userId | Admin-approved unowned profile may be public | P0 REQUIRED |
| Suspended/disabled hiding | BR-019; Phase 10 roadmap | Predicate checks suspension; owner account active check exists | All public surfaces must consistently apply policy | User/Broker status | Suspended/disabled profiles not public | P0 REQUIRED |
| Public contact preservation | `08-PUBLIC-PROFILE-RULES.md`; API requirements | Contact send accepts Broker ID and requires `broker.user` | Unowned approved public profile cannot receive contact; publication not checked | ContactMessage, public predicate | Contact uses same publication predicate | P0 REQUIRED |
| Public reviews preservation | BR-045; public rules | Slug review API filters published reviews but not Broker publication | Hidden profile reviews can be queried by slug | Review/Broker | Public APIs disclose approved public data only | P0 REQUIRED |
| Public profile URL preservation | BR-010/038; claim contract | Slug is unique and retained | No Phase 10 URL redesign required | Broker.profileSlug | Existing profile URL unchanged | PASS/REUSE |
| Public owner-data projection | BR-045; public rules | Several public queries include User email/phone/id | Potential owner account data exposure | User/Broker projection | Public responses omit owner private identifiers | P0 REQUIRED |
| SEO metadata | No explicit Phase 10 requirement found | Existing pages have generic metadata | Detailed SEO contract absent | Next metadata | Not authorized by roadmap | OUT OF SCOPE |
| New publication state enum | No explicit schema requirement | Existing isVisible/verification/status fields | PUBLISHED concept is documentation-only | Prisma schema | Do not invent schema | OUT OF SCOPE |
| Public analytics redesign | No explicit requirement | Existing counters/profile views | No Phase 10 requirement | Broker counters | Preserve existing counters | OUT OF SCOPE |

## Required Decisions Frozen From Existing Authority

- Public eligibility is centralized through existing publication/verification/safety policy.
- Approved unowned profiles may be public without a User.
- Suspended Brokers and Brokers with inactive owner accounts are not public.
- Subscription is not a publication prerequisite.
- Public profile URLs, reviews, and contact behavior are preserved.
- Public responses expose public Broker/profile data only, not owner account identifiers or private claim data.
- No schema change is currently required; existing fields support the bounded fixes.
- Advertisement rendering remains separate and is not changed.

## Explicit Non-Goals

- No new publication workflow beyond existing admin visibility/verification behavior.
- No SEO redesign.
- No CRM, advertiser, inquiry, or communication workflow.
- No ownership, claim, verification, subscription, or dashboard changes.
