# Phase 13.3A Admin Authentication Audit

## Scope

This phase investigated the Admin demo login failure before changing redirect behavior. The audit traced the Phase 13.1 seed, password hashing, User model, Auth.js Credentials provider, `authorize()`, session/JWT callbacks, server login action, sign-in page, and isolated database target.

No schema, migration, production data, ownership, claim, subscription, Advertisement, SEO, or public Broker behavior was changed.

## Authentication Chain

```text
seed Admin password
  -> lib/aes.hashPassword()
  -> User.password
  -> CredentialsProvider.authorize()
  -> bcrypt.compare()
  -> Auth.js session/JWT callbacks
  -> server LoginWithCredential action
  -> role-aware redirect
```

Both seed and runtime use `bcryptjs`; `hashPassword()` uses bcrypt with 10 salt rounds and `authorize()` uses bcrypt comparison. There was no algorithm mismatch and no plaintext fallback.

## Admin Account Verification

The deterministic Admin account was inspected in the isolated database without printing credentials, hashes, or secrets:

- Email exists.
- Role is `ADMIN`.
- Account is active.
- Email is verified.
- Password hash exists.
- Hash is bcrypt-compatible with the seed password.
- Direct `authorize()` returns a user with role `ADMIN` after repair.

The isolated target was `mongodb://localhost:27017/homeloanmarket-phase13-1`. The application and seed were explicitly run against that same target for validation.

## Reproduction and Root Cause

The existing `ensureAdmin()` updated name, role, active state, and verification state for an existing Admin but did not verify or repair its password. If an existing demo Admin had a stale or incompatible hash, rerunning the seed left the account unable to authenticate.

The same stale-password risk existed for existing demo Broker/User accounts in `seed-demo.ts`.

Controlled isolated reproduction:

1. Replace only the isolated Admin hash with a stale bcrypt hash.
2. Real Credentials-provider test rejects the deterministic Admin password.
3. Run the normal isolated seed.
4. Real Credentials-provider test returns role `ADMIN`.

This proves the failure point was stale seeded credentials, not redirect execution.
