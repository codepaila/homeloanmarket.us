# Subscription Model

Subscription is a commercial entitlement on a broker profile, independent of ownership, claim, verification, publication, and account status.

## Default Access
Every valid direct broker registration receives FREE after successful activation policy. Every successfully claimed admin-created profile receives or retains FREE unless an existing commercial entitlement already applies. FREE requires no payment and supports basic profile existence, ownership, verification, dashboard access, and free-plan features.

## Paid Lifecycle
Recommended states: `FREE_ACTIVE -> CHECKOUT_PENDING -> FEATURED_ACTIVE -> PAST_DUE|CANCEL_AT_PERIOD_END -> EXPIRED|CANCELLED`; admin suspension overlays any paid state. Active commercial plans are exactly `FREE` and `FEATURED`. Stripe signed webhook events are authoritative and idempotent.

`FEATURED -> EXPIRED -> FREE` removes paid placement and paid limits only. It preserves owner, profile entity/URL, reviews, leads, and verification unless admin separately changes them. Claiming and registration never create FEATURED. Historical PREMIUM records are migration/audit data only and are not an active commercial option.
