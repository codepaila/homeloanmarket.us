# Phase 12.2 SEO Production Hardening Audit

## Scope and Authority

This audit hardens the existing Phase 12 and Phase 12.1 SEO implementation. Phase 10 public Broker eligibility, Phase 11 security boundaries, and Advertisement CMS separation remain authoritative. No schema, migration, production mutation, ownership, claim, subscription, dashboard, or Advertisement behavior change was authorized or performed.

## Current Implementation Matrix

| Area | Current implementation and evidence | Result |
|---|---|---|
| A. Metadata | Root metadata in `app/layout.tsx`; route metadata for brokers, listings, guides, and legal pages | PASS |
| B. Canonicals | `canonicalUrl()` in `lib/seo.ts`; absolute origin, query/hash removal, trailing-slash normalization | PASS |
| C. robots.txt | `app/robots.ts`; public allow, private/API disallow, canonical sitemap reference | PASS |
| D. sitemap.xml | `app/sitemap.ts`; static public paths plus eligible Broker slugs | PASS |
| E. Broker metadata | Dynamic title, description, canonical, Open Graph, and robots metadata in Broker page | PASS |
| F. JSON-LD | Escaped `LocalBusiness` JSON-LD with factual public profile fields | PASS |
| G. Public Broker projections | API and server/client Broker payloads use `toPublicBrokerRecord()` | PASS after Phase 12.2 fix |
| H. Private route noindex | Admin, broker, auth, claim, and setup layouts emit noindex; broker dashboard redirects unauthenticated users | PASS by code/HTTP |
| I. Query canonicalization | Query and hash are removed by `canonicalUrl()` | PASS |
| J. Trailing-slash normalization | Non-root trailing slashes are removed | PASS |
| K. Absolute URL generation | `canonicalUrl()` and robots/sitemap use `getSiteUrl()` | PASS |
| L. Environment/base URL | Approved URL variables are checked in priority order; unsafe origins are rejected | PASS after Phase 12.2 fix |
| M. Host leakage | localhost, loopback, 0.0.0.0, private IPv4, `.local`, and `.internal` origins rejected | PASS after Phase 12.2 fix |
| N. Internal IDs/private fields | Nested review/bank IDs and known private Broker fields are removed from public projections | PASS after Phase 12.2 fix |
| O. Advertisement isolation | Ads render separately; no ad URLs or JSON-LD are added to sitemap | PASS by code/HTTP |
| P. `isPublicBroker()` | Sitemap, metadata, and public routes reuse the certified predicate | PASS |
| Q. 404/disabled/suspended Brokers | Ineligible profile metadata noindex/not found; sitemap query and predicate exclude them | PASS by code/tests |
| R. Duplicate sitemap URLs | Canonical URL map deduplicates final entries | PASS after Phase 12.2 fix |
| S. Non-canonical sitemap URLs | Entries are passed through `canonicalUrl()` | PASS |
| T. Internal/API/auth/dashboard sitemap URLs | Static list contains only public routes; private paths are excluded | PASS by code/HTTP |
| U. Open Graph/Twitter URLs | Broker OG URL is canonical; root social metadata uses metadata base | PASS |
| V. Image URLs | Broker images are existing profile fields; no SEO-generated image URL was added | PASS by code; external image host validation remains deployment concern |
| W. Structured-data URLs | JSON-LD URL uses canonical Broker URL | PASS |
| X. Public internal linking | Existing public links use Broker slugs; no artificial location pages added | PASS by code |
| Y. SEO tests | Phase 12.2, Phase 12, Phase 12.1 HTTP, and Phase 10 public-profile suites executed | PASS with documented skip/limits |

## Repository Search Findings

- Local development origins remain in `.env`, `utils/baseUrl.ts`, webhook developer scripts, and email/application development paths. These are not used by the SEO URL helper. They must not be treated as production configuration.
- The approved SEO fallback remains `https://homeloanmarket.com`, consistent with existing application metadata, seed settings, and prior Phase 12 certification. No new deployment domain was invented.
- `metadataBase`, canonical, sitemap, robots, JSON-LD, noindex, and Broker eligibility usage were found and audited.
- No Phase 12.2 source change was made to Advertisement code.

## Verified Defects

1. `getSiteUrl()` rejected localhost and `127.0.0.1` but accepted `0.0.0.0`, private IPv4, and internal host origins. This could produce non-public canonical, sitemap, robots, OG, or JSON-LD origins.
2. The server-rendered Broker page removed only top-level Broker IDs. Included reviews and bank partners could still serialize review, Broker-bank, or relation IDs into HTML/client props.
3. The public projection retained known private Broker fields and User account state, and review/bank projections were spread rather than explicitly bounded.
4. Static sitemap entries used `new Date()` on every generation, making output metadata non-deterministic for identical data.

## Non-Defects

- Public eligibility remains centralized through `isPublicBroker()`; no alternative publication rule was introduced.
- Sitemap does not generate city/state/location landing pages.
- No query-string sitemap URLs, private route entries, or advertisement URLs were found.
- JSON-LD contains no fabricated ratings or reviews and does not include phone/email.
- Existing public Broker phone/email rendering was preserved as existing public profile behavior; those fields are not added to JSON-LD.
- No database schema or data mutation was necessary.

## Environment and Validation Limitations

- No staging or production URL is configured/available in this environment.
- Local production HTTP was verified at `http://127.0.0.1:3100`; this is not production crawler certification.
- Browser/Playwright infrastructure is unavailable.
- Google Search Console is unavailable.
- Full ESLint has pre-existing unrelated errors; targeted changed-file lint has no errors.
- Shared MongoDB integration-state interference remains a known prior limitation; no production database was used or mutated for this audit.
