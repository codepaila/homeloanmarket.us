# Phase 13.6 Admin Dashboard Implementation

## Objective

Refine the Admin Dashboard at `/admin` into a polished, operational monitoring console built entirely from the certified real-data aggregation layer. No new analytics services or fabricated metrics were introduced.

## Component Architecture

```
app/admin/page.tsx (server)
  -> getCurrentUser() ADMIN guard
  -> getAdminDashboardData() (server aggregation)
  -> typed AdminDashboardData DTO
  -> components/admin/dashboard/*
```

Components:

- `AdminDashboard.tsx` — section composition.
- `DashboardHeader.tsx` — title, description, reporting context.
- `DashboardSection.tsx` — labeled section wrapper.
- `DashboardEmptyState.tsx` — reusable empty state.
- `DashboardKpiGrid.tsx` / `DashboardKpiCard.tsx` — KPI groups and cards.
- `PlatformGrowthChart.tsx` — combined users/brokers area chart.
- `SubscriptionGrowthChart.tsx` — combined all/FEATURED area chart.
- `ProfileViewsCard.tsx` — total + top brokers + historical note.
- `AdvertisementPerformance.tsx` — impressions/clicks chart, CTR, summary, top ads table.
- `OperationalActivity.tsx` — RecentUsers, RecentBrokers, RecentContacts, RecentClaims, RecentAdvertisements panels.

## Data Layer

`lib/admin/dashboard.ts` remains the single dashboard data service. Added:

- `getTopAdvertisements()` — per-ad impressions/clicks via `adEvent.groupBy` plus ad metadata.
- `getRecentUsers()`, `getRecentBrokers()`, `getRecentContacts()`, `getRecentClaims()`, `getRecentAdvertisements()` — bounded (10) projections.
- `getAdminDashboardData()` now returns `topAdvertisements` and structured `recent` panels in addition to existing fields.

All values derive from Prisma. Revenue remains intentionally absent (no authoritative payment amount in the schema).

## KPI Definitions

- Platform: Total Users, Total Brokers, Public Eligible Brokers (`isPublicBroker` predicate query), Profile Views (counter sum).
- Commercial: Active Subscriptions, FREE, FEATURED, Revenue (N/A).
- Operations: Pending Claims, Recent Inquiries (7d).

## Charts

- Platform Growth: monthly user and broker creation buckets (12 months).
- Subscription Growth: monthly all + FEATURED creation buckets (12 months).
- Advertisement Performance: daily impressions/clicks from AdEvent (30 days), CTR = clicks / impressions.
- Charts use recharts with responsive containers, tooltips, legends, empty states, and `isAnimationActive={false}` (respects reduced motion).

## Profile Views

Shows the existing `Broker.profileViews` counter total and top-viewed brokers, with an explicit note that historical daily view tracking is not available in the current analytics model. No artificial history.

## Operational Monitoring

Compact panels for recent users, brokers, contacts, claims, and advertisements using bounded server-side queries. Contact/Broker names come from safe relations; no private account fields are exposed.

## Authorization

Server page guard requires `role === ADMIN`. Root proxy remains authoritative:
- Unauthenticated `/admin` → `/auth/signin?callbackUrl=/admin`.
- Broker `/admin` → `/broker/dashboard`.
- User `/admin` → `/`.
- Admin `/admin` → 200.

## Data Projection

The DTO serializes counts, slugs, display names, statuses, placement names, and dates only. No passwords, hashes, tokens, OAuth, Stripe, or private fields are passed to the browser.

## Responsive Behavior

- Desktop/laptop: balanced multi-column grid (4 KPI columns, 2-col charts/panels).
- Tablet: collapses to 2-column.
- Mobile: single-column stacked cards; tables scroll horizontally only where needed.

## Error Handling

`app/admin/page.tsx` catches aggregation failures and renders a safe "Unable to load dashboard data." state without exposing internals.
