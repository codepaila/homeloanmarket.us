# Phase 13.3 Login Redirect Audit

## Scope

This phase investigated the reported runtime defect after Phase 13.2. The audit covered the sign-in page, credentials and OAuth calls, server actions, Auth.js callbacks, root proxy, route guards, registration verification, claim completion, logout, callback parameters, seeded demo accounts, and existing redirect tests.

No schema, migration, production data, ownership, claims, subscriptions, advertisements, SEO, or seed data was changed.

## Actual Flow Before Fix

1. The sign-in page called `signIn('credentials', { redirect: false })`.
2. It then called `getSession()` from the client and performed `router.replace(...)`.
3. The authenticated session cookie and client session refresh were asynchronous, so the destination decision could run before the authoritative role was available.
4. The page therefore could remain on sign-in or fall back incorrectly despite the Auth.js callback succeeding.
5. Server-side `LoginWithCredential` existed but was not used by the real sign-in page.

## Reproduced Evidence

The bare HTTP Auth.js credentials callback was executed against the isolated seeded database:

```text
Admin credentials + /admin/ads       -> HTTP 302 /admin/ads
Broker credentials + /broker/dashboard -> HTTP 302 /broker/dashboard
User credentials + /                 -> HTTP 302 /
External callback + https://evil.example -> HTTP 302 local origin
```

The defect was in the page/action execution chain, not credential validation. The fetch-only harness could not persist the returned session cookie for a subsequent authenticated request; browser certification is therefore not claimed.

## Role Matrix

| Role | Destination |
|---|---|
| ADMIN | `/admin/ads` |
| BROKER | `/broker/dashboard` |
| Normal USER | `/` |

## Callback and Authorization Audit

- Same-origin internal paths are accepted.
- External and protocol-relative URLs are rejected.
- `javascript:`, `data:`, malformed, login-loop, and legacy dashboard values are rejected or normalized.
- Admin paths are authorized only for Admin users.
- Broker paths are authorized only for Broker users.
- `/brokers` is treated as the public listing route, not as the protected `/broker` family.
- The root proxy remains the server-side authorization boundary.

## Related Flows

- Direct Broker registration continues to return `/auth/verify-email?...` as its documented intermediate step.
- Claim completion continues to return `/broker/dashboard` after ownership completion.
- Logout destinations remain public and safe.
