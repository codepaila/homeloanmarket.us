# Phase 11 Product Decision Register

## Status

**SCOPE DEFINED — IMPLEMENTATION/TEST INFRASTRUCTURE APPROVAL REQUIRED**

| Capability | Business purpose | Roles | Current evidence | Phase 11 decision | Status |
|---|---|---|---|---|---|
| IDOR/security testing | Prevent cross-user/Broker/admin data access | Public/User/Broker/Admin | Foundations exist; complete cross-system suite absent | In scope: security regression suite and verified fixes only | RESOLVED |
| CSRF/session testing | Protect state-changing routes | Authenticated users/admins | SameSite/auth foundations; complete test coverage absent | In scope: test existing controls; no auth redesign | RESOLVED |
| Claim replay/race testing | Protect ownership transition | Claimants/Admin | Claim integration/races pass; broader replay tests needed | In scope: documented claim/security test coverage | RESOLVED |
| Registration abuse testing | Prevent enumeration/duplicate abuse | Public/registering Broker | Rate limits and duplicate handling exist | In scope: verify and harden demonstrated defects | RESOLVED |
| Token leakage/replay | Protect invitations/reset/claim context | Claimants/Admin | Digest/context controls exist; email/browser evidence limited | In scope: code/test/provider evidence | RESOLVED |
| Account-state testing | Protect disabled/unverified users | Users/Brokers | Auth guards exist; provider/browser coverage limited | In scope: state-transition tests | RESOLVED |
| Stripe idempotency/replay | Protect billing entitlement | Broker/Admin/Stripe | Phase 8.5 certified | Regression only; no subscription redesign | RESOLVED |
| Migration rollback | Safe data operations | Admin/operations | No Phase 11 migration is currently required | In scope only for any approved future migration; otherwise no migration | RESOLVED |
| Email delivery certification | Verify account/claim/security mail | Users/Claimants | Real controlled mailbox/sink unavailable | In scope as environment-limited provider certification | RESOLVED |
| Browser E2E | Verify critical user journeys | Public/User/Broker/Admin | Browser infrastructure unavailable | In scope for test infrastructure; no feature redesign | RESOLVED |
| CI pipeline | Repeatable validation | Engineering | No repository CI configuration found | Separate engineering-operations task; not an authoritative Phase 11 product requirement | OUT OF SCOPE |
| Error monitoring | Production incident visibility | Operations | No authoritative Phase 11 monitoring contract found | Do not add vendor/monitoring product without approval | OUT OF SCOPE |
| Performance budgets | Measured performance guarantees | Public/Broker/Admin | No Phase 11 numeric budget contract found | Measurement only; no invented targets | OUT OF SCOPE |
| Accessibility certification | Validate user access | Public/Broker/Admin | Browser/a11y tooling unavailable | In scope only when tooling is provisioned; no redesign by assumption | RESOLVED |
| Full lint cleanup | Code quality | Engineering | Large pre-existing legacy backlog | Separate maintenance phase | OUT OF SCOPE |

## Required Approval

No mandatory Phase 11 business decision remains unresolved. CI, monitoring, and performance-budget work are separate engineering-operations/product decisions and are outside the frozen Phase 11 scope.
