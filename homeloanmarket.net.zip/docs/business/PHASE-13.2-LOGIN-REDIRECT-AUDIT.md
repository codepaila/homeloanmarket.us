# Phase 13.2 Login Redirect Audit

## Scope

This audit covers login routing, Auth.js redirects, the Next 16 proxy boundary, role separation, callback URLs, registration/claim completion, and logout. No schema, ownership, claim, subscription, Advertisement, SEO, or seed-data changes were made.

## Authoritative Routes

The repository does not contain `/admin/dashboard`, `/dashboard`, or `/login` pages. The actual routes are:

- Admin landing: `/admin/ads`
- Broker dashboard: `/broker/dashboard`
- Sign-in: `/auth/signin`
- Public-user fallback: `/`

Claim completion already returns `/broker/dashboard`. Broker registration intentionally returns `/auth/verify-email?...` as its intermediate completion state.

## Current Redirect Matrix Before Fix

| Case | Observed behavior | Defect |
|---|---|---|
| A. Unauthenticated visitor -> protected route | Proxy intended `/auth/signin?callbackUrl=...`; Broker page independently redirected | Proxy was not active because `app/proxy.ts` was not at the Next 16 root convention |
| B. Admin credentials | Sign-in page defaulted to `/broker/dashboard` | Role-unaware redirect; Admin could be sent to Broker route |
| C. Broker credentials | Default `/broker/dashboard` | Correct only accidentally; no role decision |
| D. Normal User credentials | Default `/broker/dashboard` | Incorrect Broker destination |
| E. Authenticated Admin -> `/auth/signin` | Sign-in path was treated as public | No authenticated-login redirect |
| F. Authenticated Broker -> `/auth/signin` | Sign-in path was treated as public | No authenticated-login redirect |
| G. Admin -> `/broker/dashboard` | Existing proxy logic intended generic `/dashboard`; route does not exist | Wrong/404-prone unauthorized destination |
| H. Broker -> `/admin` | Existing proxy logic intended generic `/dashboard`; route does not exist | Wrong/404-prone unauthorized destination |
| I. Unauthenticated -> Admin | `/admin/ads` returned HTTP 200 because proxy was inactive | Protected admin page boundary failed |
| J. Unauthenticated -> Broker | Broker page returned sign-in redirect | Boundary depended on page guard, not proxy |
| K. Registration completion | API returned `/auth/verify-email?...` | Correct documented intermediate flow |
| L. Claim completion | API returned `/broker/dashboard` | Correct |
| M. Safe callback | Client passed callback value directly to `router.push`/Google sign-in | Not role-authorized |
| N. External callback | Auth.js origin check existed, but client callback was unvalidated and role-unaware | Hardened |
| O. Logout | Server action used nonexistent `/login`; UI sign-outs used public `/` | Inconsistent server-action destination |

## Verified Root Causes

1. `app/(public)/auth/signin/page.tsx` used `'/broker/dashboard'` as the universal fallback and pushed the query-string callback without role evaluation.
2. Authenticated visits to `/auth/signin` returned through the public-path branch instead of redirecting by role.
3. The Auth.js `redirect` callback only checked origin and did not provide role-aware destination enforcement.
4. The route guard was located at `app/proxy.ts`; Next 16 requires the proxy convention at the project root. Consequently `/admin/ads` was publicly reachable at HTTP level.
5. Existing unauthorized redirects targeted nonexistent `/dashboard`; `/admin/dashboard` and `/login` references also did not correspond to actual pages.

## Security Boundary

Callback handling now accepts same-origin internal paths only, rejects external/protocol-relative/dangerous/malformed/login targets, and rejects destinations outside the authenticated role's route family. Server-side proxy authorization remains authoritative after any redirect.
