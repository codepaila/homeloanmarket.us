# Phase 9.0A Permission and API Contract

## Status

**DRAFT CONTRACT — NO-GO FOR PHASE 9.1 IMPLEMENTATION**

This document freezes the supported boundaries and records mandatory product decisions that are still unresolved. It does not authorize application changes.

## 1. Scope

Phase 9.1 is limited to:

- one Broker dashboard for direct and claimed owners;
- server-authoritative owner APIs;
- nullable `Broker.userId` safety;
- FREE/FEATURED permission projections;
- dashboard state/authorization behavior;
- authenticated HTTP and browser test coverage.

Out of scope:

- new tiers or PREMIUM;
- subscription/Stripe redesign;
- ownership or claiming redesign;
- verification/public visibility redesign;
- Advertisement CMS changes;
- CRM, advertiser, WhatsApp, Gmail, social, or external file workflows;
- unrelated admin/dashboard redesign.

## 2. Final FREE/FEATURED Permission Matrix

Status values are intentionally restricted to the requested vocabulary.

| Capability | FREE | FEATURED | ADMIN | PUBLIC |
|---|---|---|---|---|
| Dashboard access | ALLOW | ALLOW | UNDEFINED — PRODUCT DECISION REQUIRED for Broker-dashboard impersonation | DENY |
| Own profile viewing | ALLOW | ALLOW | ADMIN_ONLY | PUBLIC_ONLY for approved public fields |
| Own authorized profile editing | ALLOW | ALLOW | ADMIN_ONLY | DENY |
| Change `Broker.userId` | DENY | DENY | ADMIN_ONLY through separate audited ownership workflow | DENY |
| Change claim state | DENY | DENY | ADMIN_ONLY through claim workflow | DENY |
| Change Broker verification | DENY | DENY | ADMIN_ONLY | DENY |
| Change `User.emailVerified` | DENY | DENY | UNDEFINED — PRODUCT DECISION REQUIRED; existing auth policy remains authoritative | DENY |
| Profile visibility/publication | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | ADMIN_ONLY | PUBLIC_ONLY read of published state |
| View reviews | ALLOW | ALLOW | ADMIN_ONLY/ALLOW where existing admin policy applies | PUBLIC_ONLY approved review data |
| Review mutation/management | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | DENY |
| View/manage contacts | LIMITED by existing owner/contact policy | LIMITED by existing owner/contact policy | ADMIN_ONLY/ALLOW where documented | PUBLIC_ONLY submit through public contact policy |
| View/manage leads | LIMITED by existing free limits | LIMITED by existing paid limits | ADMIN_ONLY | DENY |
| Basic statistics | ALLOW | ALLOW | ADMIN_ONLY | DENY |
| Advanced analytics | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | DENY |
| Advertisement visibility | NOT_APPLICABLE | NOT_APPLICABLE | ADMIN_ONLY through Advertisement CMS | PUBLIC_ONLY rendered ads |
| Featured placement | DENY | ALLOW through active FEATURED entitlement | ADMIN_ONLY separate placement/admin policy | PUBLIC_ONLY if public policy permits |
| Paid placement controls | NOT_APPLICABLE | UNDEFINED — PRODUCT DECISION REQUIRED | ADMIN_ONLY | NOT_APPLICABLE |
| Subscription management | ALLOW own billing | ALLOW own billing | ADMIN_ONLY reconciliation/support where documented | DENY |
| Upgrade | ALLOW to FEATURED | NOT_APPLICABLE | ADMIN_ONLY support only | DENY |
| Cancellation | ALLOW own subscription | ALLOW own subscription | ADMIN_ONLY support/reconciliation only | DENY |
| Billing/portal | ALLOW own billing | ALLOW own billing | ADMIN_ONLY where explicitly authorized | DENY |
| Profile/contact limits | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | ADMIN_ONLY policy | NOT_APPLICABLE |
| Lead limits | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | ADMIN_ONLY policy | NOT_APPLICABLE |
| Review limits | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | ADMIN_ONLY policy | NOT_APPLICABLE |
| Account settings | ALLOW own account | ALLOW own account | ALLOW own admin account | DENY |
| Verification badge entitlement | DENY | DENY | ADMIN_ONLY trust workflow | PUBLIC_ONLY trust result |

### Certified Boundaries

- FEATURED never grants verification, ownership, publication, or claim state.
- FREE remains active baseline entitlement.
- Expired, cancelled, missing, inactive, or unsupported subscriptions use effective FREE behavior.
- PREMIUM remains unsupported.

### Mandatory Product Decisions

Phase 9.1 cannot begin until all `UNDEFINED` entries affecting mandatory dashboard/API behavior are resolved. At minimum this includes:

- exact owner visibility editing behavior;
- review mutation permissions;
- contact and lead limits;
- advanced analytics fields and FREE/FEATURED access;
- review limits;
- admin Broker-dashboard impersonation/access behavior;
- exact paid placement controls;
- exact User email-verification administrative behavior.

## 3. Dashboard State Contract

| State | Auth | Dashboard | Data/API | Edit | Subscription/features | Redirect/error |
|---|---|---|---|---|---|---|
| User without Broker | Authenticated | DENY | `/api/brokers/me` 404 | DENY | None | Existing setup/404 behavior |
| Direct Broker, activation complete | Authenticated active | ALLOW | Own Broker only | ALLOW authorized fields | Effective FREE/FEATURED | Normal dashboard |
| Direct Broker, email pending | Authenticated but pending | LIMITED/gated by activation policy | Protected APIs gated | DENY or LIMITED per existing activation policy | No active owner features | Verification/activation flow |
| Claimed Broker, completion complete | Authenticated active | ALLOW | Same owner APIs as direct path | Same as direct path | Effective FREE/FEATURED | Normal dashboard |
| FREE Broker | Authenticated active | ALLOW | Own data | FREE-defined fields | FREE permissions | Normal dashboard |
| FEATURED Broker | Authenticated active | ALLOW | Own data | FEATURED does not expand admin fields | FEATURED-defined fields | Normal dashboard |
| Expired FEATURED | Authenticated active | ALLOW | Own data | FREE-defined fields | Effective FREE | No loss of baseline access |
| Cancelled FEATURED | Authenticated active | ALLOW | Own data | FREE-defined fields | Effective FREE | No loss of baseline access |
| Missing subscription | Authenticated active | ALLOW | Own data | FREE-defined fields | Effective FREE | No error solely for missing subscription |
| Invalid subscription | Authenticated active | ALLOW | Own data | FREE-defined fields | FREE-safe fallback | No paid feature exposure |
| Unowned Broker | No owner session | DENY owner dashboard | No owner API authority | DENY | No owner entitlement projection | Admin/public path only |
| Non-owner | Authenticated wrong User | DENY | 403/404 per existing route contract | DENY | No target entitlement | Safe denial |
| ADMIN | Authenticated admin | Separate admin UI; impersonation undefined | Admin APIs only | Admin policy | No automatic owner impersonation | Product decision required for impersonation |
| Deleted/inactive User | Invalid/inactive auth | DENY | 401/403 | DENY | None | Sign-in/disabled-account behavior |
| Invalid/stale session | Invalid | DENY | 401 | DENY | None | Sign-in/refresh behavior |
| Invalid Broker reference | Authenticated | DENY for target | 404/403 | DENY | None | Safe not-found/forbidden behavior |

## 4. Owner API Contract

| Method/route | Purpose | Auth | Owner check | FREE/FEATURED |
|---|---|---|---|---|
| `GET /api/brokers/me` | Own Broker/profile surface | Authenticated BROKER | DB `Broker.userId = currentUser.id` | Same owner response; entitlement projection must be effective |
| `PATCH /api/brokers/me` | Own authorized profile mutation | Authenticated BROKER | DB `Broker.userId = currentUser.id` | Only approved field/limit differences |
| `GET /api/brokers/me/dashboard-stats` | Dashboard statistics | Authenticated User with owned Broker | Server-resolved Broker | Basic FREE; advanced behavior requires decision |
| `GET /api/brokers/[id]/contacts` | Owner/admin contacts | Authenticated; owner or ADMIN | Server comparison to Broker.userId | Existing contact policy; limits require decision |
| `GET/PATCH /api/user/profile` | Account profile | Authenticated current User | No client target authority | Same |
| Subscription details/usage/checkout/upgrade/cancel/portal | Own billing | Authenticated current User -> Broker | Server-resolved owner | Phase 8.5 contract |
| Claim session/completion APIs | Claim transition | Existing signed context/auth | Invitation/context/transaction | Independent of plan |

### Request Contract

- Owner routes must derive User/Broker identity from the authenticated session.
- Client `userId`, `brokerId`, `ownerId`, subscription plan, and entitlement are not authority.
- Existing request fields and response shapes remain backward-compatible.
- Mutations validate input and preserve existing rate-limit/CSRF behavior.

### Error Contract

| Status | Meaning | Phase 9.1 requirement |
|---:|---|---|
| 400 | Invalid request | Preserve existing route-specific body; use for malformed input |
| 401 | Unauthenticated/invalid session | Protected dashboard/API requests |
| 403 | Authenticated but unauthorized | Wrong owner/role |
| 404 | Resource absent/intentionally hidden | Missing Broker/owned resource |
| 409 | Current-state conflict | Only where existing route supports conflict semantics |
| 422 | Validation/business rule failure | Preserve existing validation contracts |
| 429 | Rate limit | Existing rate-limited flows |
| 500 | Unexpected failure | Do not expose sensitive details |

Existing routes that use different status/body conventions must be preserved until a specific backward-compatible correction is approved.

## 5. Authorization Contract

```text
NextAuth session
  -> server User lookup
  -> Broker where Broker.userId = User.id
  -> owner-scoped dashboard/API data
```

Claim completion remains the ownership transition. Subscription state is never ownership authority. Admin access is separate from Broker-owner access. Unowned Brokers have no owner dashboard.

## 6. HTTP Integration Test Contract

The Phase 9.1 harness must use:

- isolated MongoDB;
- deterministic Users/Brokers;
- existing NextAuth session architecture;
- owner, wrong-owner, admin, unauthenticated, stale-session fixtures;
- direct-owned, claimed-owned, unowned, FREE, FEATURED, expired/cancelled/missing subscription fixtures.

Required HTTP cases:

- unauthenticated dashboard/API request;
- direct owner dashboard and `/me` APIs;
- claimed owner dashboard and `/me` APIs;
- wrong-owner access;
- unowned Broker access;
- admin dashboard/API behavior;
- invalid Broker/User/reference;
- stale/invalid session;
- FREE/FEATURED/expired/cancelled/missing subscription projections;
- client ID/plan/permission tampering;
- profile/contact/stats mutation authorization.

No HTTP harness was created during Phase 9.0A.

## 7. Browser E2E Contract

When browser infrastructure exists, execute:

1. Direct registration -> activation/login -> `/broker/dashboard` -> own profile/stats.
2. Admin-created Broker -> invitation -> claim completion -> same dashboard/owner APIs.
3. FREE owner -> baseline dashboard permissions.
4. FEATURED owner -> approved paid permissions.
5. Expired FEATURED -> FREE behavior without loss of dashboard access.
6. Wrong User -> denied target Broker dashboard/data.
7. Mobile owner dashboard -> navigation, loading, empty, error, and basic data.

Browser results must not be claimed until executed with a controlled fixture.

## 8. Product Decision Register

| ID | Question | Current evidence | Options | Recommended option | Impact | Blocks 9.1? |
|---|---|---|---|---|---|---|
| P9A-001 | Does a Broker owner edit `isVisible`? | Existing API accepts it; business rules separate publication/admin state | Deny; limited request; allow within policy | Require explicit product decision; default ADMIN_ONLY for safety | API/UI permission | Yes |
| P9A-002 | What are FREE/FEATURED contact limits? | Docs say “free limits/paid limits” without values | Existing implementation; new limits; no limit difference | Freeze existing documented values only after confirmation | Usage/API/UI | Yes |
| P9A-003 | What are FREE/FEATURED lead limits? | Matrix references limits, exact contract absent | Existing implementation; new limits; no limit difference | Product decision required | Data/API/UI | Yes |
| P9A-004 | What is advanced analytics access? | Dashboard gates analytics broadly; docs say paid analytics generally | FEATURED-only; limited FREE; same for both | FEATURED-only only if fields/limits are approved | Dashboard/API | Yes |
| P9A-005 | Can owners mutate reviews? | Docs define reviews/history preservation, not owner mutation | Read-only; owner response; edit/delete | Read-only until explicit contract | API/UI/security | Yes |
| P9A-006 | Can ADMIN impersonate Broker dashboard? | Admin UI is separate; no impersonation contract | Deny; audited read-only; full audited support | Deny until explicitly approved | Auth/security | Yes |
| P9A-007 | What exact dashboard stats response is compatible? | Existing stats route exists, no formal schema | Preserve current; add envelope; split basic/advanced | Preserve current response and define additive fields only | API/test | Yes |
| P9A-008 | What are expired/cancelled feature messages? | Effective FREE is certified; UI message unspecified | Silent fallback; banner; redirect | Silent entitlement fallback plus approved UI state | UX/API | Yes |

No register entry is silently decided by this audit.

## 9. Phase 9.1 Boundary

### In Scope

- shared dashboard;
- shared owner APIs;
- nullable-owner safety;
- approved FREE/FEATURED permissions;
- dashboard states;
- authorization/API contracts;
- authenticated HTTP and browser tests;
- existing registration/claim/subscription regressions.

### Out of Scope

- new subscription tiers/providers;
- ownership/claim/verification/public visibility redesign;
- Advertisement CMS changes;
- advertiser functionality;
- CRM/communications;
- unrelated admin or repository refactoring.

## 10. Acceptance Criteria

- Direct and claimed owners use the same dashboard.
- Owner APIs resolve authority from authenticated User -> Broker ownership.
- Nullable `Broker.userId` is safe.
- Non-owners cannot access another Broker.
- All mandatory FREE/FEATURED permissions are approved and enforced.
- Expired/cancelled/missing subscriptions follow FREE behavior.
- Subscription never proves ownership or verification.
- Existing API success/error contracts remain compatible.
- Dashboard states are defined and tested.
- HTTP test plan and browser test plan execute or are explicitly environment-limited.
- Registration/claim/ownership/verification/visibility/subscription/advertisement regressions pass.

## Contract Decision

**NO-GO — mandatory product decisions remain unresolved.**
