# Phase 9.0C Final Product Decisions

## Status

**DECISIONS FROZEN FOR PHASE 9.1**

The following decisions resolve the Phase 9.0B register without changing application behavior.

| ID | Decision | Evidence | Final Rule | Scope | Security Impact | Implementation Impact | Test Requirement | Status |
|---|---|---|---|---|---|---|---|---|
| P9C-001 | Advanced analytics | Current dashboard exposes basic contact aggregates for paid path; no detailed advanced analytics contract | Advanced analytics expansion is OUT OF SCOPE. Existing basic statistics remain subject to current behavior | OUT OF SCOPE | No new data exposure | No new analytics implementation | Verify existing basic stats authorization | OUT OF SCOPE |
| P9C-002 | FREE contact limits | Sources say contacts are authorization-controlled but give no subscription-specific numeric limit | No subscription-specific FREE contact limit is defined; preserve existing behavior | Phase 9.1 may not invent a cap | Existing owner authorization remains | Verify owner/non-owner behavior | RESOLVED |
| P9C-003 | FEATURED contact limits | No authoritative numeric FEATURED limit exists | No subscription-specific FEATURED contact limit is defined; preserve existing behavior | No new paid limit | Prevents client/server divergence | Verify existing behavior | RESOLVED |
| P9C-004 | FREE lead limits | Permission matrix uses generic “free limits”; no numeric contract or implementation authority is frozen | No subscription-specific FREE lead limit is defined; preserve existing behavior | No new limit work | Existing owner scoping remains | Verify existing behavior | RESOLVED |
| P9C-005 | FEATURED lead limits | Permission matrix uses generic “paid limits”; no numeric contract is frozen | No subscription-specific FEATURED lead limit is defined; preserve existing behavior | No new limit work | Existing owner scoping remains | Verify existing behavior | RESOLVED |
| P9C-006 | Review mutations | Existing public review API is read-only; no authoritative owner mutation contract exists | Owner review mutation is OUT OF SCOPE. Existing public read behavior and separate admin policy remain | No owner response/edit/delete/moderation feature | No new moderation authority | Verify public read/owner isolation | OUT OF SCOPE |
| P9C-007 | Broker visibility editing | Business rules separate publication/admin state; current API behavior is legacy and not a Phase 9 product contract | Phase 9.1 does not grant, remove, or redesign owner visibility/publication powers. Existing visibility behavior is preserved; admin publication rules remain authoritative | Visibility changes are OUT OF SCOPE | No publication bypass may be added | No Phase 9 visibility implementation | Verify no subscription coupling | OUT OF SCOPE |
| P9C-008 | Admin dashboard impersonation | No documented or implemented impersonation flow | Admin impersonation is OUT OF SCOPE. Admin uses separate admin UI/APIs | No impersonation feature | Avoids high-privilege ambiguity | No implementation | Verify Broker dashboard does not impersonate admin | OUT OF SCOPE |
| P9C-009 | FEATURED placement controls | Phase 8.5 certifies FEATURED as paid placement entitlement; no manual owner placement control contract exists | Placement is entitlement-driven. No owner-controlled placement controls are added | Advertisement CMS remains separate | FEATURED never grants publication/verification/ownership | Reuse resolver | Verify FEATURED boundary | RESOLVED |
| P9C-010 | Expired/cancelled messaging | Effective resolver is certified; detailed UI messaging is not specified | Effective state becomes FREE. Detailed banner/redirect/messaging UX is OUT OF SCOPE; existing UI may reflect current state | No new messaging design | No entitlement confusion | Use current effective projection | Verify FREE fallback | RESOLVED / OUT OF SCOPE UX |
| P9C-011 | Owner API response/error compatibility | Existing routes have stable route-specific shapes/statuses but no single unified envelope | Preserve current route-specific response/error contracts. Phase 9.1 must not standardize by breaking existing consumers | Additive changes only if separately justified | Preserve safe auth errors | Document and test current routes | Verify current status/body behavior | RESOLVED |
| P9C-012 | HTTP/browser test strategy | Domain/DB tests exist; no project-owned authenticated dashboard/browser harness exists | Phase 9.1 requires isolated authenticated HTTP tests. Browser E2E is required for final certification when infrastructure is provisioned, but no framework is introduced in 9.0C | Infrastructure prerequisite, not product scope | Required IDOR/session proof | Build harness in Phase 9.1 | Test contract frozen | RESOLVED |

## Frozen Permission Matrix

| Capability | FREE | FEATURED | ADMIN | PUBLIC |
|---|---|---|---|---|
| Dashboard access | ALLOW after activation | ALLOW after activation | ADMIN_ONLY separate UI | DENY |
| Own profile view/edit | ALLOW authorized fields | ALLOW authorized fields | ADMIN_ONLY | PUBLIC_ONLY approved fields |
| Ownership/claim mutation | DENY | DENY | ADMIN_ONLY separate workflows | DENY |
| Verification mutation | DENY | DENY | ADMIN_ONLY | PUBLIC_ONLY result |
| Contacts | LIMITED by existing behavior, no new subscription cap | LIMITED by existing behavior, no new subscription cap | ADMIN_ONLY where existing policy allows | PUBLIC_ONLY submission policy |
| Leads | LIMITED by existing behavior, no new subscription cap | LIMITED by existing behavior, no new subscription cap | ADMIN_ONLY where existing policy allows | DENY owner data |
| Basic statistics | ALLOW existing fields | ALLOW existing fields | ADMIN_ONLY | DENY |
| Advanced analytics | OUT_OF_SCOPE | OUT_OF_SCOPE | OUT_OF_SCOPE for Phase 9.1 | DENY |
| Reviews | ALLOW existing read behavior; mutations OUT_OF_SCOPE | ALLOW existing read behavior; mutations OUT_OF_SCOPE | Existing admin policy | PUBLIC_ONLY published reviews |
| Visibility/publication | OUT_OF_SCOPE; existing behavior unchanged | OUT_OF_SCOPE; existing behavior unchanged | ADMIN_ONLY existing publication policy | PUBLIC_ONLY published state |
| FEATURED placement | DENY | ALLOW through effective entitlement | Separate admin policy | PUBLIC_ONLY when public policy allows |
| Manual placement controls | NOT_APPLICABLE | OUT_OF_SCOPE | Separate Advertisement/administrative policy | NOT_APPLICABLE |
| Subscription/billing | ALLOW own billing | ALLOW own billing | ADMIN_ONLY reconciliation where certified | DENY |
| Verification badge entitlement | DENY | DENY | ADMIN trust workflow | PUBLIC_ONLY trust result |

## Final Contract Result

All mandatory Phase 9.1 decisions are now either RESOLVED or OUT OF SCOPE. Browser infrastructure remains an execution prerequisite, not an unresolved business decision.
