# Phase 11 Scope Contract

## 1. Objective

Perform cross-system security hardening and testing for the completed platform, focusing on documented threats, state transitions, authorization boundaries, replay/race behavior, provider integration evidence, and repeatable regression validation.

## 2. Authoritative Baseline

The roadmap defines Phase 11 as security hardening and testing for IDOR, CSRF, enumeration, replay, races, duplicate registration, token leakage, account state, Stripe idempotency, migration rollback, email delivery, and documented state transitions.

## 3. In-Scope Workstreams

- IDOR and authorization testing across public, owner, and admin APIs.
- CSRF/session/state-change testing using existing auth architecture.
- Registration duplicate/enumeration/rate-limit testing.
- Claim token/context replay, expiry, revocation, and race testing.
- Account activation/disabled/stale-session testing.
- Stripe webhook replay/idempotency regression only.
- Public/private projection and sensitive logging review.
- File upload/URL/XSS/open-redirect security review for existing systems.
- Browser, HTTP, email, and OAuth test infrastructure where safely provisioned.
- Migration rollback test design for any separately approved migration.
- Cross-phase regression suite and data-integrity validation.

## 4. Out of Scope

- New business features or product flows.
- Authentication redesign or new providers.
- Ownership/claim/subscription/Advertisement redesign.
- New subscription tiers or PREMIUM.
- CRM/advertiser portal.
- Advanced analytics.
- Numeric performance budgets not already documented.
- Monitoring vendor integration without approval.
- Full legacy lint cleanup.

## 5. Frozen Business Rules

- FREE baseline; FEATURED only paid entitlement; PREMIUM unsupported.
- `Broker.userId` is ownership authority.
- Claim completion is ownership transition.
- Subscription does not establish ownership, verification, or publication.
- Direct and claimed Brokers share the dashboard.
- Public eligibility predicate remains authoritative.
- Advertisement CMS remains admin-controlled and separate.

## 6. Security Boundaries

- Server-side authentication and authorization remain authoritative.
- Client IDs/roles/plans are not authority.
- Public projections omit private User/claim/payment data.
- Claim tokens are digest-only, high entropy, expiring, revocable, and single-use.
- Stripe events are signed, durable, idempotent, retryable, and order-safe.
- Admin operations require explicit role and audit behavior where documented.

## 7. API Boundaries

Existing response contracts remain compatible. Phase 11 may add test harnesses and fix verified security defects, but may not create duplicate APIs or redesign route contracts without an approved defect-specific decision.

## 8. Database Boundaries

- No schema change or migration is authorized by default.
- Production data is read-only during audit/testing unless a separately approved migration exists.
- Ownership/subscription/event indexes and uniqueness remain unchanged.
- Any migration work requires dry-run, rollback, preservation, and post-check evidence.

## 9. Testing Requirements

- Unit security/policy tests.
- API authorization/IDOR tests.
- MongoDB transaction/race integration tests.
- Authenticated HTTP tests.
- Browser E2E for direct registration, claim, dashboard, public profile, admin, and critical state transitions when infrastructure exists.
- Email/provider tests using controlled sinks only.
- Stripe test-mode replay/idempotency regression.
- Existing Phase 1–10.1 regression suites.

## 10. Infrastructure Requirements

- isolated MongoDB;
- deterministic fixtures and cleanup;
- reusable authenticated session helper;
- browser runtime/Playwright or approved equivalent;
- controlled email sink;
- controlled OAuth callback environment if OAuth certification is required;
- controlled Stripe test mode;
- optional CI pipeline subject to decision `CI-001`.

## 11. Acceptance Criteria

- No critical IDOR/authentication/authorization defect remains.
- Documented CSRF/session protections are tested.
- Claim/registration/token replay and races are tested.
- Disabled/stale/account-state transitions are tested.
- Stripe idempotency and replay regressions pass.
- Public private-data projections are safe.
- Existing ownership, claims, subscriptions, public profiles, dashboard, and Advertisement behavior remain intact.
- Production data integrity checks pass.
- Browser/email/OAuth results are either executed with controlled fixtures or explicitly marked unavailable.
- No unapproved schema/data/business-rule changes occur.

## 12. Rollback Requirements

Application hardening changes must be small and revertible. Any approved migration requires snapshot, dry-run, explicit rollback, and post-rollback integrity checks. No automatic production mutation is part of this contract.
