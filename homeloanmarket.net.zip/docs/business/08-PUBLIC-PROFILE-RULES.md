# Public Profile Rules

## Current Evidence
Current broker APIs require `isVisible=true`, `verificationStatus=VERIFIED`, and an active related user. A direct registration is initially unverified, so it should not be assumed public before verification under the current policy.

## Target Predicate
Central public discovery requires profile publication `PUBLISHED`, no suspension/disablement, and verification/publication gates defined by product policy. An unowned admin-created profile may be public if admin-approved and otherwise eligible; unowned does not inherently mean hidden. A self-registered profile may be owned before email verification, but public exposure remains subject to current verification/publication rules. Subscription is not a publication prerequisite.

Public responses omit owner account identifiers, private claim data, and leads. Contact submission uses the same publication predicate and must not require a non-null user relation for an approved unowned profile.
