# Phase 12 US SEO Audit

## Audit Matrix

| Area | Current behavior | Expected | Defect | Severity |
|---|---|---|---|---|
| Root metadata | Generic title/description only | US-oriented title/description/template/OG/canonical | Missing | P1 |
| Broker metadata | No route-level `generateMetadata` | Unique eligible public Broker metadata | Missing | P0 |
| Broker canonical | No dynamic canonical | Stable `/brokers/[slug]` canonical | Missing | P0 |
| Broker structured data | No verified JSON-LD | Factually supported public data only | Missing | P1 |
| Listing metadata | No route-specific metadata | Meaningful listing metadata/canonical | Missing | P1 |
| Content metadata | Guides is client page with no metadata | Title/description/canonical | Missing | P1 |
| robots.txt | No `app/robots.ts` found | Block private/admin/API paths | Missing | P0 |
| XML sitemap | No `app/sitemap.ts` found | Include eligible public URLs only | Missing | P0 |
| Private noindex | Auth/dashboard/admin routes have no SEO metadata policy | Private surfaces must not be indexable | Missing | P0 |
| Public eligibility | `isPublicBroker()` used by public paths | Sitemap/metadata must reuse predicate | Required integration | P0 |
| Public projection | Phase 10 safe projection fixes exist | SEO must use safe fields | PASS/reuse | — |
| URLs/slugs | Stable unique `profileSlug` | Preserve canonical URLs | PASS/reuse | — |
| Reviews | Public published-review API/presentation exists | JSON-LD only when factual | Partial | P1 |
| Advertisement SEO | Ads render through public components; no ad URLs | Tracking/event URLs not indexable | PASS/reuse | — |
| Query parameters | Listing uses search/filter query state | Do not create sitemap variants | Requires sitemap discipline | P1 |
| Browser SEO validation | No browser tooling | Code-level validation only | Environment limitation | — |

## Scope

Implement metadata, robots, sitemap, canonical, safe Broker JSON-LD, and private indexability controls. SEO redesign, fake location pages, doorway pages, and search-ranking claims are out of scope.
