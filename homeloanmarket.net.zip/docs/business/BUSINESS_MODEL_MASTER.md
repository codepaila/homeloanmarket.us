# HomeLoanMarket Business Model Master

## Purpose
HomeLoanMarket is a broker/company marketplace. Borrowers discover published profiles and submit leads. Brokers may become owners through two independent onboarding paths: voluntary website registration or claiming an admin-created profile. Both paths converge on the same `User`, `Broker`, dashboard, lead, review, and subscription systems.

Statements marked **Current** are verified from the repository. The remaining statements are the target design and must not be treated as implementation.

## Current Architecture
- **Current:** Next.js App Router, TypeScript, Prisma 6 with MongoDB, NextAuth with JWT sessions, Credentials and Google providers, bcrypt passwords, Resend email, Upstash rate limiting, Stripe subscriptions, and hand-written/Zod-style validation.
- **Current:** `User` roles are `USER`, `BROKER`, and `ADMIN`; `isActive` and `emailVerified` are account flags.
- **Current:** `Broker.userId` is required and unique. The current schema cannot represent an unowned profile.
- **Current:** `Broker` stores profile content, verification, broker status, visibility, counters, reviews, contacts, banks, and one `BrokerSubscription`.
- **Current:** self-registration creates a broker user first; profile creation/setup is a separate authenticated operation. The existing broker registration endpoint validates, hashes, creates a `BROKER` user, and sends verification email.
- **Current:** public broker listing/profile APIs require visible, verified brokers and an active related user.
- **Current:** Stripe subscription feature application also changes broker status, verification, and visibility; target design separates these concerns.

## The Two Onboarding Paths

### Path A: Admin-Created Profile
Admin creates a profile before an account exists. The profile has `creationSource=ADMIN_CREATED`, `ownership=UNOWNED`, and `claim=NOT_REQUIRED` until an invitation is issued. Admin may publish it under publication policy. A secure invitation moves claim state to `INVITED`; opening and email/setup steps move it through progress states. After verified account setup, an atomic transaction attaches the existing profile to the user, changes ownership to `OWNED`, and completes the claim. The original profile ID, slug, data, reviews, leads, counters, subscription, verification, and history remain unchanged. The profile receives or retains FREE access and may later upgrade.

### Path B: Direct Website Broker Registration
A visitor explicitly chooses **Register as Broker**, completes the broker registration form, and submits account/profile information. The system creates the `User` and `Broker` in one logical transaction, associates `Broker.userId` immediately, sets `creationSource=SELF_REGISTERED`, sets `ownership=OWNED`, sets `claim=NOT_REQUIRED`, creates a FREE entitlement, and sends email verification. No admin claim invitation, token, claim URL, or fake claim is created. Until email verification, account/dashboard access is gated. Public visibility remains governed by the existing verification/publication policy; registration and FREE access do not bypass editorial or trust requirements.

## Independent Concepts
1. **Broker Profile:** durable marketplace record.
2. **User Account:** authentication identity and access state.
3. **Ownership:** `UNOWNED` or `OWNED`; how the user/profile relation currently stands.
4. **Creation Source:** `ADMIN_CREATED` or `SELF_REGISTERED`; origin of the profile.
5. **Claim Lifecycle:** invitation process only. Self-registration is `NOT_REQUIRED`, not a completed claim.
6. **Verification Status:** platform/company trust review.
7. **Publication/Visibility:** editorial and safety decision.
8. **Subscription/Commercial Entitlement:** FREE, FEATURED, and billing state. Historical PREMIUM values are migration-only.
9. **Account Status:** pending verification, active, disabled, or other authentication access state.

Ownership is not a role, claim status is not ownership, and subscription is not ownership, verification, or account activation.

## Convergence
`ADMIN_CREATED -> UNOWNED -> CLAIM -> OWNED + FREE -> FEATURED (optional)`

`WEBSITE VISITOR -> REGISTER AS BROKER -> OWNED + FREE -> FEATURED (optional)`

Both owned outcomes use the same authenticated broker dashboard and subscription system. A normal public-user registration, if supported, remains distinct and does not create broker ownership.

## FREE and PREMIUM
FREE is the default commercial entitlement. Registration, verification, activation, ownership, and basic dashboard access require no payment. A successfully claimed admin-created profile receives FREE unless an existing commercial entitlement already applies. A successfully activated direct broker registration receives FREE. Premium/featured access is an independent owner/admin-authorized upgrade reconciled from Stripe. On paid expiry or cancellation, `PREMIUM -> EXPIRED -> FREE`; ownership, profile, URL, reviews, leads, and verification remain unless separately changed by admin policy.

## Public Profile Policy
The current implementation requires visibility, verification, and an active user. The target centralizes this predicate and permits an approved unowned admin-created profile where policy allows; unowned does not inherently mean hidden. A recommended launch policy is `PUBLISHED + VERIFIED`, with admin approval for unowned profiles. Suspended/disabled profiles are hidden regardless of ownership or plan. Email verification controls account access, not necessarily publication, but current verification/publication rules must be preserved until product policy explicitly changes them.

## Invariants
- Direct registration never creates a claim invitation or fake claim.
- Only admin-created profiles require claiming.
- The original admin-created profile entity survives claiming.
- At most one current owner exists at launch; ownership uniqueness is enforced.
- Every valid broker path gets FREE before any premium upgrade.
- Subscription, verification, publication, claim, ownership, creation source, and account states remain independent.
- Claim tokens are random, hashed at rest, expiring, revocable, single-use, and never logged.
- Existing authentication is reused; no second identity system is introduced.

## Source Map
Current behavior is primarily in `prisma/schema.prisma`, `app/api/auth/register/broker/route.ts`, `app/api/brokers/*`, `lib/auth.config.ts`, `lib/currentUser.ts`, `lib/subscription.ts`, `app/api/stripe/webhook/route.ts`, and `actions/email.action.ts`.
