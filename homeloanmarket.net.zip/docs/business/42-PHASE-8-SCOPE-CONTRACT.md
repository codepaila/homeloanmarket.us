# Phase 8 Scope Contract

## Status

**PROPOSED FROM EXISTING ROADMAP; PRODUCT APPROVAL REQUIRED BEFORE IMPLEMENTATION**

The existing documentation has one explicit Phase 8 definition: `IMPLEMENTATION_PLAN.md` Phase 8, “FREE and premium subscription integration.” No later document defines a broader Phase 8 product scope. This contract therefore freezes only the subscription/commercial-lifecycle scope traceable to existing rules and code.

## Objective

Certify and harden the existing FREE/FEATURED commercial entitlement system without rebuilding registration, admin Broker creation, invitation management, claimant claiming, ownership, verification, visibility, authentication, or UI design systems. Historical PREMIUM records must be reconciled before certification; this phase cannot silently reinterpret them.

## In Scope

- Server-authoritative plan/price mapping.
- BrokerSubscription lifecycle consistency.
- FREE fallback resolution.
- Stripe checkout/upgrade/cancel/portal authorization.
- Signed webhook processing.
- Durable webhook idempotency and retry/order handling.
- Paid expiry/cancellation back to effective FREE.
- Commercial placement/rank projections only.
- Usage/limits resolution from one plan configuration source.
- Subscription regression/security/integration tests.

## Out Of Scope

- Broker self-registration.
- Admin Broker creation.
- Invitation generation/resend/revoke/bulk operations.
- Claim preview, claim context, account setup, or ownership completion.
- Changes to `Broker.userId` or `brokers_userId_non_null_unique`.
- Changes to verification or publication business rules.
- New plans, new payment providers, or new authentication systems.
- Team ownership, multiple Broker profiles per User, invoices/accounting, or Phase 9 dashboard redesign.

## Traceability

| Requirement | Existing source |
|---|---|
| FREE is default, payment-free | `07-SUBSCRIPTION-MODEL.md`, BR-012, BR-034 |
| Paid expiry returns to FREE | `07-SUBSCRIPTION-MODEL.md`, BR-015, FR-028 |
| Subscription does not prove ownership/verification | BR-016/017, `27-OWNERSHIP-SUBSCRIPTION-VERIFICATION-AUDIT.md` |
| Paid checkout/webhook/cancel | `17-API-REQUIREMENTS.md`, `IMPLEMENTATION_PLAN.md` Phase 8 |
| Preserve Broker identity on commercial changes | BR-010, BR-015, `33-CLAIM-CONTRACT.md` |

## Functional Contract

- **P8-001:** A missing BrokerSubscription resolves as effective active FREE for compatible reads.
- **P8-002:** A Broker has at most one BrokerSubscription.
- **P8-003:** Client plan and price values are validated against server-owned plan configuration.
- **P8-004:** Paid operations require an authenticated active owner or explicitly authorized admin support operation.
- **P8-005:** Stripe signatures are verified before webhook processing.
- **P8-006:** Each Stripe event is durably processed at most once, with safe retry behavior.
- **P8-007:** Out-of-order events cannot regress newer entitlement state.
- **P8-008:** Payment failure, cancellation, and expiry remove paid entitlement only and restore effective FREE.
- **P8-009:** Commercial transitions never change `Broker.userId`.
- **P8-010:** Commercial transitions never automatically change `Broker.verificationStatus` or `User.emailVerified`.
- **P8-011:** Commercial transitions never publish/unpublish or delete a Broker.
- **P8-012:** Usage/limits/features use one server-owned plan configuration.

## State Contract

Current schema uses `plan`, `isActive`, `startDate`, and `endDate`; no new business enum is authorized by this contract. Effective state is resolved as:

```text
missing subscription -> FREE_ACTIVE
FREE + active         -> FREE_ACTIVE
paid + active         -> PAID_ACTIVE
paid + provider past_due -> PAST_DUE / paid access policy
paid + cancelled/expired -> FREE_ACTIVE
```

The implementation must preserve existing response fields and map provider statuses without making FREE unavailable.

## API Contract

Existing routes are extended, not duplicated:

- `/api/subscription/plans`
- `/api/subscription/checkout`
- `/api/subscription/upgrade`
- `/api/subscription/cancel`
- `/api/subscription/details`
- `/api/subscription/usage`
- `/api/subscription/invoices`
- `/api/subscription/portal`
- `/api/stripe/webhook`

Response shapes remain backward-compatible. Server-owned plan configuration determines accepted plan/price combinations. No request body can set ownership, verification, visibility, role, or subscription state directly.

## Database Contract

Retain `BrokerSubscription.brokerId @unique` and the existing `brokers_userId_non_null_unique` ownership index. A durable processed Stripe event model is required for event-id idempotency and is implemented as `StripeWebhookEvent` in Phase 8.1. It is infrastructure, not a business-rule change.

## Security Contract

- Owner isolation by authenticated User -> Broker relation.
- Admin support actions explicit and audited.
- Stripe signature verification.
- Server-side price/plan mapping.
- Duplicate and replayed event protection.
- No Stripe secrets in responses/logs.
- No subscription-to-ownership or subscription-to-verification coupling.
- Mutation rate limits/CSRF protections consistent with existing architecture.

## Test Contract

- Effective FREE with absent/expired/cancelled subscription.
- Valid/invalid/tampered plan-price requests.
- Owner/admin/ordinary-user/unauthenticated authorization.
- Stripe signature failure.
- Duplicate webhook.
- Out-of-order webhook.
- Failed payment and retry.
- Cancellation/expiry preserving ownership, verification, visibility, profile, reviews, leads, and URL.
- Usage limits from one configuration source.
- Existing registration/admin/claim regression suites.

## Acceptance Criteria

- FREE owned Brokers retain dashboard/basic access.
- Paid transitions are server-authoritative and idempotent.
- Paid expiry/cancellation restores effective FREE.
- Ownership, verification, visibility, and claim state remain unchanged by billing.
- Existing API response contracts remain compatible.
- No duplicate entitlement model is introduced.
- No ownership, claim, verification, visibility, or tier schema change occurs. `StripeWebhookEvent` is the approved minimal infrastructure store for durable Stripe idempotency.
