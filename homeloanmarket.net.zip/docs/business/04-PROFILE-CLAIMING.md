# Profile Claiming

The exact implementation decisions for invitation lifetime, claimant account cases, authentication context, API contracts, races, and email behavior are finalized in `33-CLAIM-CONTRACT.md`.

Claiming applies only to an `ADMIN_CREATED` profile that is currently `UNOWNED`. A self-registered profile is already owned and has claim `NOT_REQUIRED`; it must not be wrapped in a fake claim.

## Canonical Claim Flow
Admin creates profile -> may publish under policy -> admin generates invitation -> company receives secure link -> GET validates without consuming -> company reviews safe profile data -> submits intended email -> system continues an eligible existing account or starts a new one -> email ownership is verified and password is set/reauthenticated -> transaction conditionally consumes invitation and attaches the existing broker record -> ownership becomes `OWNED`, claim becomes `COMPLETED`, FREE is created or retained -> common broker dashboard.

## Rules
- The profile is never recreated or copied.
- Claiming requires a valid invitation, verified submitted email, and eligible account context.
- Email matching alone is not proof of authority.
- Existing users reauthenticate; new users use the existing account setup/verification architecture.
- A profile with an owner, expired/revoked/used invitation, disabled account, or conflicting owned profile pauses or rejects without unauthorized mutation.
- Abandonment leaves the profile unowned and FREE; the invitation expires/revokes normally.
- Claim completion preserves profile ID, slug, content, reviews, leads, counters, subscription, verification, and audit history.
