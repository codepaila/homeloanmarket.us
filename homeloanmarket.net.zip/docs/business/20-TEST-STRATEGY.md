# Test Strategy

## Current Gap
No project-owned test files were found outside dependencies. The design therefore requires a new automated safety net before implementation is considered complete.

## Required Coverage
- Unit: creation-source/ownership/claim guards, token entropy/hash/expiry, FREE default, premium expiry, publication predicate, email normalization.
- Direct-registration integration: validation, rate limiting, password hashing, duplicate handling, transactional user/profile/FREE creation, immediate owner relation, verification resend, activation gating.
- Claim integration: unowned admin profile, invitation lifecycle, new/existing account setup, atomic attachment, unchanged profile identity, no fake claim for self-registration.
- Subscription: FREE creation for both paths, upgrade, Stripe idempotency, cancellation/expiry to FREE, preserved ownership/history.
- API: every permission matrix row, normal user vs broker registration, generic enumeration responses, null-owner reads, contact authorization, admin audit.
- Concurrency: two claim completions, duplicate broker registration submissions, resend/consume races, duplicate/out-of-order webhooks.
- Browser/email: separate registration and claim entry points, verification pending/active states, valid/invalid claim links, abandoned setup, mobile email links.
- Security: IDOR, replay, brute force, token logging/referrer, CSRF, session fixation, role tampering, disabled accounts, admin escalation.
- Regression: existing self-registration, email verification/reset, broker dashboard, public listing/profile, reviews, contacts, free/premium billing.
