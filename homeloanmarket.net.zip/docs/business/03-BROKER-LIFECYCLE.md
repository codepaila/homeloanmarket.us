# Broker and Onboarding Lifecycles

## Profile State
`DRAFT -> PUBLISHED -> HIDDEN`; `PUBLISHED -> SUSPENDED`; `SUSPENDED -> PUBLISHED` only by admin; `PUBLISHED/HIDDEN -> DISABLED` by admin. This is independent of ownership and claim.

## Path A: Admin-Created Profile
Admin create: `creationSource=ADMIN_CREATED`, `ownership=UNOWNED`, `claim=NOT_REQUIRED`, FREE entitlement. Invitation: claim `INVITED`; link open: `IN_PROGRESS`; email/setup: `IN_PROGRESS`; successful verified completion: ownership `OWNED`, claim `COMPLETED`, FREE retained/created. Expired/revoked/failed flows do not alter the profile owner.

## Path B: Direct Registration
Visitor selects broker registration -> form submission -> create user and broker transactionally -> `creationSource=SELF_REGISTERED`, ownership `OWNED`, claim `NOT_REQUIRED`, FREE entitlement -> email verification -> account activation -> broker dashboard. No claim state transition occurs.

## Common Transitions
- Admin publish/hide/suspend/disable: editorial or safety decision.
- Admin verify/unverify: independent trust review.
- Owner edit: authorized content changes only.
- Subscription upgrade/expiry: commercial entitlement only.
- Claim completion: attaches an existing admin-created profile; never creates a second profile.

Invalid transitions include public-user publishing, self-registration creating a claim, subscription changing ownership, claim attaching a self-registered profile, deletion/recreation during claim, or payment bypassing suspension.
