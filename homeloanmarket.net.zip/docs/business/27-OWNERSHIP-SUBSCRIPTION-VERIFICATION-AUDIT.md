# Ownership, Subscription, and Verification Audit

## Scope

Read-only audit of separation between current ownership, commercial entitlement, Broker trust verification, account verification, and public visibility. No implementation changes were made.

## Separation Result

| Concept | Correct representation | Current status |
|---|---|---|
| Ownership | Nullable `Broker.userId` | Schema supports it; application still has null-unsafe consumers. |
| Claim lifecycle | `BrokerClaim`, invitation, and events | Schema exists; no application consumers yet. |
| Creation source | `Broker.creationSource` | Schema field exists but current writes do not populate it. |
| Commercial entitlement | `BrokerSubscription.plan/isActive` | Exists, but projection logic is coupled to Broker status/verification. |
| Broker trust verification | `Broker.verificationStatus/verifiedAt` | Exists, but paid plan writes it incorrectly. |
| Account activation | `User.isActive/emailVerified` | Exists and is used by auth; expiry field is not yet used. |
| Public visibility | `Broker.isVisible` plus query policy | Exists, but queries require User and are inconsistent. |

## Ownership Audit

### Correct Uses
- `app/api/brokers/[id]/route.ts` and `app/api/company/[slug]/route.ts` compare `broker.userId` to the authenticated User for owner authorization.
- `app/api/brokers/me/route.ts` and `app/broker/company/edit/page.tsx` resolve the owner-side Broker by User ID.
- Contact read/respond routes use the authenticated User's broker profile to scope owner actions.

### Required Future Guards
- A null `broker.userId` must never be treated as a match or passed to `User.update`.
- Owner routes should resolve the Broker by current authenticated User and reject unowned profiles naturally.
- Admin routes must use Broker ID and must not require a User relation.
- A claim completion must conditionally set `Broker.userId` only while null.

## Subscription Audit

### FREE
`BrokerSubscription` already represents FREE with `plan=FREE`, `isActive=true`, and no Stripe identifiers. `app/api/brokers/route.ts` creates FREE after profile creation. `app/api/subscription/checkout/route.ts` upserts an inactive FREE placeholder before checkout. However, the current direct registration endpoint creates only User, so it does not yet create Broker or FREE.

### PREMIUM/FEATURED
Stripe checkout/webhook and upgrade routes update `BrokerSubscription.plan`. Plan checks in `lib/stripe.ts`, `lib/subscription.ts`, and subscription UI are commercial feature logic and are not ownership logic.

### Violations
1. `lib/subscription.ts` `applySubscriptionFeatures` sets `BrokerStatus.FEATURED`, `Broker.verificationStatus=VERIFIED`, and visibility based on paid plan.
2. `app/api/subscription/upgrade/route.ts` repeats the same coupling.
3. `app/api/subscription/cancel/route..ts` resets `BrokerStatus` to FREE. Resetting a commercial/ranking projection may be appropriate, but `BrokerStatus.FREE` is not a sufficient subscription state and must not affect ownership.
4. `app/broker/dashboard/page.tsx` gates analytics on `subscription.isActive`; finalized business rules require basic FREE dashboard access, while advanced analytics may be plan-gated.
5. `BrokerStatus` values `FREE` and `FEATURED` overlap conceptually with `SubscriptionPlan`; `SUSPENDED` is operational. This enum should eventually be replaced or narrowed to operational/publication state, with plan kept solely in BrokerSubscription.

### Non-Violations
- No inspected code uses `subscription.plan` to set `Broker.userId`.
- Subscription cancellation does not modify `Broker.userId`.
- Premium expiry/webhook logic does not directly detach ownership.
- User role is not assigned from subscription plan.

## Verification Audit

### Account Verification
`User.emailVerified` is used by broker credential login checks and verification routes. Google provider users are created as active `USER` accounts. The new `emailVerificationTokenExpiresAt` field is currently unused; the next auth/email phase must persist and validate it.

### Broker Verification
`Broker.verificationStatus` is used for public listing/profile gating, badges, and admin/owner presentation. It is incorrectly changed by paid plan upgrade and `applySubscriptionFeatures`. Payment must not establish Broker trust.

### Ownership Confusions
- `isVerifiedBroker` and `isVerified` helpers describe trust, not ownership.
- `BrokerStatus.FEATURED/FREE` helpers describe presentation/commercial projections, not ownership.
- `subscription.isActive` describes entitlement, not dashboard ownership.

## Public Visibility Audit

Current public listing requires `isVisible`, `verificationStatus=VERIFIED`, and an active related User. This makes `userId=null` a hidden/invalid path even when business publication policy permits an approved unowned profile. `app/api/company/[slug]/route.ts` and the public slug page also need centralized predicate adoption because they do not consistently enforce all gates.

## Recommendation

Use `Broker.userId` only for current ownership, `BrokerClaim` only for admin-created claim lifecycle, `BrokerSubscription` only for commercial entitlement, `Broker.verificationStatus` only for platform/company trust, `User.emailVerified/isActive` only for account access, and a centralized publication predicate for public exposure. Treat `BrokerStatus` as technical debt: eventually retain only operational state such as suspension or replace it with explicit ranking/publication projections derived without mutating trust state.
