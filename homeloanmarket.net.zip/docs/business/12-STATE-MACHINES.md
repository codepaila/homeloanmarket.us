# State Machines

These machines are parallel and must not be collapsed into one status field.

## 1. Direct Broker Registration
`VISITOR -> BROKER_FORM -> USER_AND_PROFILE_CREATED -> EMAIL_PENDING -> EMAIL_VERIFIED -> ACTIVE_FREE_BROKER -> PREMIUM_OPTIONAL`.

Creation sets `creationSource=SELF_REGISTERED`, `ownership=OWNED`, and `claim=NOT_REQUIRED`. No claim invitation or claim token exists. User/profile/FREE creation is transactional; dashboard access begins after activation policy.

## 2. Admin-Created Broker Claiming
`ADMIN_CREATE: UNOWNED + NOT_REQUIRED -> INVITED -> IN_PROGRESS -> COMPLETED: OWNED`; failure branches from invitation/progress to `EXPIRED`, `REVOKED`, or `FAILED`. `EXPIRED`, `REVOKED`, and `FAILED` may return to `INVITED` only when an admin issues a fresh invitation; `COMPLETED` cannot reopen. Completion atomically attaches the existing profile. A self-registered profile cannot enter this machine.

## 3. Profile Publication
`DRAFT -> PUBLISHED -> HIDDEN`; `PUBLISHED -> SUSPENDED`; `SUSPENDED -> PUBLISHED` only after admin resolution; either published/hidden state may become `DISABLED` by admin. Publication is independent of ownership, creation source, claim, account, and subscription.

## 4. Account Activation
`PENDING_EMAIL -> ACTIVE -> DISABLED`; password reset is a parallel credential process. Both broker paths use the same User/NextAuth account. Ownership may be present before activation for self-registration, but access is gated.

## 5. FREE Entitlement
`NONE/UNINITIALIZED -> FREE_ACTIVE` on successful direct broker creation/activation policy or successful claim. FREE requires no payment and remains the fallback entitlement after paid expiry.

## 6. Premium Entitlement
`FREE_ACTIVE -> CHECKOUT_PENDING -> PAID_ACTIVE -> PAST_DUE|CANCEL_AT_PERIOD_END -> EXPIRED|CANCELLED -> FREE_ACTIVE`. Suspension overlays commercial display/features. Paid transitions never change ownership, claim, creation source, or verification.

## 7. Verification
`UNVERIFIED -> PENDING_REVIEW -> VERIFIED|REJECTED`; `VERIFIED -> UNVERIFIED` only by admin review. Email verification is an account state; company/profile verification is a separate trust state.
