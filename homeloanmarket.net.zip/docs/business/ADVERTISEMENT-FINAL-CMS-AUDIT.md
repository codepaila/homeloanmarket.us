# Advertisement Final CMS Audit

## Final Decision

**ADVERTISEMENT CMS STATUS: NO-GO**

The internal admin CMS core is substantially implemented, but the current implementation is not production-ready for the full documented 16-placement admin-created-ad -> public-display -> analytics workflow.

The critical gap is public placement integration: only 9 of 16 configured placements are mounted in actual public pages. The remaining placements have API/configuration/component support but are not rendered by any page.

## Authoritative Functional Model

```text
Admin creates ad
  -> CMS validates
  -> Admin selects media/rules
  -> Admin previews
  -> Admin publishes
  -> Public API selects active ad
  -> Correct public placement renders ad
  -> Shared tracker records impression/click
  -> Admin reviews metrics
```

Advertiser accounts, advertiser CRM, payments, inquiry management, external upload portals, and communication integrations are out of scope.

## Area Status Table

| Area | Status | Evidence | Defect | Fixed |
|---|---|---|---|---|
| Admin CMS | PARTIAL | Admin list/new/edit/preview pages and ADMIN APIs exist | No complete end-to-end automated CMS suite | No |
| Advertisement creation | PASS | `POST /api/admin/ads`, Zod validation, server creator ID | Publish readiness required server-side | Yes |
| Editing | PASS | `PUT /api/admin/ads/:id`, admin authorization | No focused API test | No |
| Publishing | PASS | Admin action route and service | Empty/unsafe ads could publish | Yes |
| Unpublishing | PASS | Admin action route | No focused lifecycle test | No |
| Scheduling | PASS | Date filters in public repository | No timezone/browser test | No |
| Placement | PARTIAL | 16 enum values and public map | Only 9 placements are mounted in pages | No |
| Multiple ads per placement | PARTIAL | API limit up to 10 and deterministic ordering | Renderers request/render one; no rotation/slider | No |
| Media Library | PARTIAL | Upload, folders, picker, metadata, soft delete | Documented restore/folder mutation routes incomplete | No |
| Public rendering | PARTIAL | Public API and renderer components exist | 7 configured placements are not page-integrated | No |
| Device targeting | PARTIAL | API detects device and filters fields | Components primarily render desktop media; no responsive E2E | No |
| Impression tracking | PASS after hardening | Shared wrapper now invokes tracker; API requires publishable ad | No focused browser/event integration test | Yes |
| Click tracking | PASS after hardening | Shared tracker and server-stored destination | No focused browser/event integration test | Yes |
| Analytics | PARTIAL | Detail counts and dashboard stats exist | No CTR/date-range analytics contract or tests | No |
| Authorization | PASS | Admin checks server-side in admin routes | No complete HTTP authorization suite | No |
| Security | PARTIAL | URL/media validation and soft delete exist | Public event abuse/rate limits and SVG review remain | Partial |
| Data integrity | PASS | Current data has no missing media/orphan events/reversed dates | 42 reusable media assets are unused, not invalid | No |
| Performance | PARTIAL | Pagination, indexes, SWR, placement ordering | Event dedupe is query-based; no load test | No |
| Testing | FAIL | 2 focused tests plus general regressions | No advertisement API/DB/browser/lifecycle suite | No |
| Documentation | PARTIAL | Extensive CMS docs exist | Placement/UI/API docs contain stale inconsistencies | No |

## Admin CMS Audit

Server-side ADMIN checks exist for:

- create;
- list/search/filter;
- edit;
- preview;
- publish/unpublish;
- archive/restore;
- soft delete/hard delete;
- duplicate;
- bulk actions;
- media upload/list/update/delete;
- folder list/create.

The existing UI includes ad list, create, edit, preview, media, and folder components/pages. There is no project-owned advertisement HTTP/E2E suite proving all mutations and non-admin rejection.

## Creation Validation

Current server-side validation covers enum values, IDs as strings, priority, display order, URL safety, and dates. Hardening added:

- safe relative/HTTP(S) URL validation;
- reversed schedule rejection;
- publish requirement for a creative asset or banner URL;
- publish rejection for unsafe stored URLs;
- deleted/invalid media references remain rejected at create.

## Placement Trace

### Actually Mounted

- `HOMEPAGE_HERO`
- `HOMEPAGE_SEARCH`
- `HOMEPAGE_FEATURED`
- `HOMEPAGE_SERVICES`
- `HOMEPAGE_BANKS`
- `HOMEPAGE_CTA`
- `BROKER_LISTING`
- `BROKER_LISTING_SIDEBAR`
- `LOAN_CALCULATOR`

### Configured but Not Mounted in Public Pages

- `BROKER_PROFILE_HEADER`
- `BLOG_INLINE`
- `FOOTER`
- `ANNOUNCEMENT_TOP`
- `ANNOUNCEMENT_BOTTOM`
- `POPUP_OVERLAY`
- `MOBILE_HEADER_BANNER`

The components and placement map exist, but repository-wide usage tracing found no public page invocation for these seven placements.

## Multiple Ads and Ordering

The public API supports `limit` up to 10 and sorts by:

1. priority ascending;
2. display order ascending;
3. creation time descending.

This is deterministic. The current renderer hooks request one ad, so multiple advertisements can coexist in the database/API but are not rotated or rendered as a slider. No separate slider model is required; rotation is a UI capability gap.

## Scheduling and Device Behavior

Public selection excludes disabled, archived, deleted, future, and expired ads and applies device flags. Boundary comparisons are explicit and use server `Date` values.

The API supports desktop/tablet/mobile filtering. Most concrete renderer components select `desktopMedia` directly rather than using a responsive picture/source strategy, so mobile-specific creative behavior is not fully proven.

## Media Library

The admin-only media system supports upload, Sharp processing, thumbnails, folders, selection, metadata updates, soft deletion, and media references.

Current database audit:

```text
Media assets: 52
Deleted media: 0
Media folders: 10
Unused media assets: 42
Missing media references: 0
```

Unused assets were not deleted. They may be reusable library assets.

## Tracking

The shared `AdvertisementWrapper` now invokes the existing impression and click tracker hooks. Tracking endpoints require a currently publishable advertisement. The click endpoint ignores client-supplied redirect data and uses only stored validated destinations.

Remaining gaps:

- no rate limiting on public event routes;
- no browser/event integration test;
- global five-second impression deduplication is not visitor/session-specific;
- no CTR/date-range analytics contract.

## Data Integrity

Configured database read-only audit:

```text
Advertisements: 32
Published:       32
Archived:         0
Drafts:           0
Deleted:          0
Ad events:      665
Media assets:    52
Media folders:   10
Orphan events:    0
Missing media refs: 0
Reversed schedules: 0
Unsafe stored URL schemes: 0
```

## Authorization and Security

Admin mutations enforce server-side ADMIN role. Public serving and tracking are intentionally unauthenticated. No advertiser self-service or payment path exists.

Hardening addressed:

- client-controlled redirect/open redirect;
- tracking inactive/draft/expired ads;
- unsafe destination schemes;
- incomplete publication;
- soft-delete restore.

Remaining risks:

- public tracking abuse/rate limiting;
- SVG served as-is requires deployment/content-security review;
- no advertisement-specific authenticated HTTP security suite.

## Performance

The public query uses status/date/device/placement filters and indexed ordering fields. Admin lists paginate and public hooks use SWR deduplication. No measured N+1 defect was found.

Event deduplication performs a latest-event query per impression and has no load-test evidence.

## Documentation Findings

- `FRONTEND.md` marks media/folder pages as placeholders while those pages/components exist.
- Several documents list restore/move routes not present in the route inventory.
- Display-rule labels differ from Prisma enum names in places.
- Documentation describes all 16 placements, but public page integration covers only 9.

## Production Readiness Score

**6.5/10**

The score reflects a working admin CRUD/public API core, but incomplete public placement integration, incomplete tests, partial responsive behavior, and analytics/tracking hardening gaps.

## Final Status

**NO-GO**

The current Advertisement CMS is not yet production-ready for the full intended admin-created-ad -> public-display -> analytics workflow because seven configured placements are not connected to public pages and advertisement-specific end-to-end test coverage is absent.

Do not start another advertisement feature phase. Resolve the listed placement integration and test blockers within the existing CMS scope, then recertify.
