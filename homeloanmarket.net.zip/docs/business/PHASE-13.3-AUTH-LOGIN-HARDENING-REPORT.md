# Phase 13.3 Auth Login Hardening Report

## Root Cause Fixed

The credentials login path had three demonstrated defects:

1. Stale demo password hashes were preserved by deterministic seed reconciliation (fixed in Phase 13.3A).
2. The sign-in page called the credentials server action inside a client `try/catch`, masking successful Auth.js redirects as login failures.
3. The CredentialsProvider threw generic errors on rejection, producing a `Configuration` error instead of `CredentialsSignin`.

## Files Changed

- `actions/auth.action.ts`
- `app/(public)/auth/signin/page.tsx`
- `lib/auth.config.ts`
- `prisma/seed/helpers.ts`
- `prisma/seed/seed-demo.ts`
- `tests/phase-13.3a-admin-auth.test.ts`

## Changes

### `app/(public)/auth/signin/page.tsx`

- Converted the credentials form to canonical Server Action submission with `useActionState`.
- Removed the client `try/catch` that masked Auth.js redirects.
- Added the hidden `callbackUrl` form field.
- Successful Auth.js redirects now propagate through Next's server-action redirect handling.
- Failed credentials surface the action's returned error message.
- Google sign-in continues to return through `/auth/signin` for the role-aware proxy decision.

### `actions/auth.action.ts`

- `LoginWithCredential` now uses the canonical `(previousState, formData)` Server Action signature.
- Returns `undefined` on success so the Auth.js redirect controls navigation.
- Returns an error object only for AuthError failures.

### `lib/auth.config.ts`

- CredentialsProvider `authorize()` now returns `null` for missing/unknown users, missing hashes, inactive accounts, unverified Brokers, and failed bcrypt comparisons.
- This produces the correct `CredentialsSignin` rejection instead of `Configuration`.
- Password verification remains bcryptjs through `bcrypt.compare`; no plaintext fallback was added.

### Seed reconciliation

- `ensureAdmin()` and demo-user seeding rehash existing bcrypt hashes only when they are stale or missing (Phase 13.3A).
- No plaintext password is stored or accepted.

### Tests

- `tests/phase-13.3a-admin-auth.test.ts` now asserts the canonical `null` rejection contract and adds an inactive-User rejection case.

## Preserved Behavior

- Existing Auth.js/Credentials provider and session/JWT callbacks.
- Existing bcryptjs algorithm and salt policy.
- Ownership, claims, subscriptions, Advertisement, SEO, public Broker eligibility, and schema unchanged.
