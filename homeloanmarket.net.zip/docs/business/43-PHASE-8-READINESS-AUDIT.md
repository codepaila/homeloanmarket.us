# Phase 8 Readiness Audit

## Executive Summary

**PHASE 8 SCOPE AUDIT STATUS: READY WITH NON-BLOCKING LIMITATIONS**

Phase 8 is not independently defined in the finalized business model. The only explicit roadmap scope is FREE and premium subscription integration. The proposed scope contract narrows work to hardening the existing commercial entitlement and Stripe lifecycle. Registration, admin creation, invitations, claiming, ownership, verification, and visibility are already implemented foundations and must not be rebuilt.

## Current Baseline

### Phase 1

Business model and documentation foundation implemented. Two onboarding paths and independent ownership/claim/subscription/verification concepts are documented.

### Phase 2

Prisma/MongoDB model implemented: nullable Broker ownership, creation source, BrokerClaim, BrokerClaimInvitation, BrokerClaimEvent, and BrokerSubscription.

### Phase 3B

Nullable-owner compatibility, public visibility, FREE dashboard access, ownership checks, and subscription/verification separation were implemented.

### Phase 4

Direct Broker registration creates User + Broker + FREE transactionally, sets `SELF_REGISTERED`, requires email verification, and supports dashboard access.

### Phase 5 / 5B

Claim readiness audit and frozen Claim Contract exist. Claim contract defines exact ownership transition, claimant cases, token/context security, states, and races.

### Phase 6

Admin-created unowned Broker profiles, FREE entitlement, admin management, invitation foundation, resend/revoke, and email transport integration exist.

### Phase 6.5 / 6.6

Pre-claim integration hardening and the operational partial unique ownership index are implemented and verified against isolated/configured MongoDB.

### Phase 6.7 / 6.8

Invitation management contract and recipientEmail persistence/bulk invitation implementation exist.

### Phase 7

Claimant preview/start/context/account classification/reauthentication/completion and atomic ownership race tests exist. Provider/browser tests remain environment-limited.

### Phase 7.5

Build and TypeScript baseline fixes, claim context hardening, rate limits, and transaction rechecks exist. Production build and TypeScript now pass; full lint remains legacy-failing.

## Phase 8 Definition

The explicit source is `IMPLEMENTATION_PLAN.md`:

```text
Phase 8: FREE and premium subscription integration
Guarantee FREE entitlement for successful direct activation and successful claim;
separately support paid checkout, webhook reconciliation, cancellation, and premium expiry to FREE.
```

No authoritative document defines additional Phase 8 features. Billing UI redesign, admin revenue analytics, teams, invoices, or new commercial plans are proposed/out of scope, not final requirements.

## Feature Inventory

| Feature | Status | Phase 8 treatment |
|---|---|---|
| FREE entitlement on registration | IMPLEMENTED | Regression only. |
| FREE entitlement on admin creation | IMPLEMENTED | Regression only. |
| FREE entitlement on claim completion | IMPLEMENTED in transaction contract | Regression only. |
| Public plan catalog | IMPLEMENTED | Validate server/client consistency. |
| Stripe checkout | PARTIALLY IMPLEMENTED | Harden plan-price mapping and failure handling. |
| Stripe upgrade | PARTIALLY IMPLEMENTED | Validate transitions and provider/local consistency. |
| Stripe cancel | IMPLEMENTED/PARTIAL | Test effective FREE and preservation invariants. |
| Stripe webhook | PARTIALLY IMPLEMENTED | Add durable event idempotency/order handling. |
| Stripe portal | IMPLEMENTED | Authorization/regression only. |
| Usage/limits | PARTIALLY IMPLEMENTED | Consolidate effective entitlement resolver. |
| Dashboard FREE access | IMPLEMENTED | Regression only. |
| Paid placement/rank | PARTIALLY IMPLEMENTED | Commercial projection only; no trust/ownership mutation. |
| Admin billing analytics | UNKNOWN | Not an explicit Phase 8 requirement. |
| New Premium features | OUT OF SCOPE | Requires product decision. |

## Business Rule Audit

### Aligned

- `Broker.userId` is ownership only.
- `BrokerSubscription` is commercial entitlement only.
- FREE is baseline access and does not prove ownership, verification, or visibility.
- Paid transitions do not attach/detach Brokers.
- Paid transitions do not automatically verify Brokers.
- Claiming preserves the existing Broker.

### Defects/Risks Found

1. `SubscriptionService.getUsageStats()` reports `isActive=false` when no subscription exists, while effective FREE policy treats missing subscription as active FREE. This is a concrete consistency defect.
2. Checkout accepts body `priceId` and `plan` without proving they are a valid server-side pair.
3. Upgrade accepts arbitrary `plan` and `priceId` values and casts plan to `any`.
4. Stripe webhook processing has no durable processed-event store or event ordering guard.
5. Stripe webhook payment-failed/succeeded handlers only log and do not reconcile local state.
6. `BrokerStatus` still overlaps with commercial concepts in legacy projections/UI, although paid writes were removed in Phase 3B.

These are Phase 8 implementation requirements, not business-model changes.

## Database Readiness

- BrokerSubscription one-to-one relation is usable.
- Ownership partial index is operationally verified.
- Claim models preserve ownership lifecycle.
- No duplicate subscription model is required.
- Durable Stripe event storage was required for idempotency and is now implemented as `StripeWebhookEvent`.
- No ownership, claim, verification, visibility, or subscription-tier schema redesign is required.

## API Readiness

Existing subscription APIs can be hardened in place. No duplicate routes should be created. The main API work is server-authoritative plan/price validation, owner isolation, event idempotency, and stable response behavior.

## Admin Readiness

Admin Broker/profile/invitation management is implemented. Admin subscription navigation exists, but complete admin billing management is not evidenced as implemented and is not automatically Phase 8 scope.

## Broker Dashboard Readiness

FREE owner dashboard access exists. Paid analytics are separately gated. Phase 8 should verify feature-level entitlement checks, not introduce a dashboard redesign.

## Public Website Readiness

Public profile/listing logic is ownership-null-safe and uses visibility/verification/safety policy. Commercial state should affect ranking/features only, never basic existence or ownership. Expiry/cancellation regression is required.

## Authentication Readiness

NextAuth/JWT/Credentials/Google and User/Broker owner resolution are reusable. Subscription endpoints need to continue deriving the owned Broker server-side and must not trust client identity/plan fields.

## Security Readiness

### Ready foundations

- server-side owner authorization;
- claim/ownership transaction and partial owner index;
- Stripe signature construction in webhook;
- FREE/paid separation from ownership and verification;
- build/type safety.

### Phase 8 risks

- arbitrary client plan/price pairs;
- duplicate/out-of-order Stripe events;
- webhook failure with incomplete local reconciliation;
- billing IDOR or stale session ownership;
- legacy BrokerStatus semantic confusion.

## Test Readiness

Existing tests cover policy, admin creation, invitation persistence, ownership indexes, claim completion, and claimant races. Missing Phase 8 coverage includes Stripe event replay/order, plan-price tampering, payment failure, expiry/cancel fallback, billing endpoint authorization, and effective usage limits.

## Build Readiness

- TypeScript: **PASS** after generated dev-type configuration fix.
- Production build: **PASS**.
- Prisma validate: **PASS**.
- Prisma generate: **PASS**.
- Targeted Phase 7 lint: **PASS**.
- Full lint: **FAIL**, 209 pre-existing unrelated errors.

## Dependency Graph

```text
Phase 8 subscription hardening
  -> server plan/price configuration
  -> BrokerSubscription resolver
  -> owned Broker authorization
  -> Stripe checkout/portal
  -> signed webhook
  -> durable event idempotency/order handling
  -> commercial feature projection
  -> dashboard/public regressions
  -> MongoDB/Stripe integration tests
```

## Risk Register

| Risk | Area | Severity | Evidence | Mitigation | Blocks |
|---|---|---:|---|---|---|
| Duplicate webhooks | Stripe | High | No processed-event store | Add durable idempotency and replay tests | Yes for production certification |
| Out-of-order events | Stripe | High | No event ordering guard | Store event timestamps/sequence and reject stale updates | Yes |
| Plan/price tampering | API | High | Client values passed to Stripe | Server map and validate pair | Yes |
| FREE fallback inconsistency | Entitlement | Medium | Usage method differs from resolver | One resolver | No, must fix |
| Payment failure local drift | Stripe | Medium | Handlers only log | Reconcile status and retry | Yes for certification |
| Legacy BrokerStatus overlap | Domain | Medium | Enum/UI still uses plan-like values | Keep operational projection separate | No, cleanup required |
| Full lint debt | Tooling | Low | Existing repository errors | Targeted lint plus scheduled cleanup | No |
| Provider test limits | Operations | Medium | No Stripe live fixture | Mocked Stripe plus staging replay | No for implementation start; yes for release |

## Blockers

- Product approval of the proposed Phase 8 scope contract is still required because no dedicated authoritative Phase 8 specification exists.
- Durable Stripe event idempotency/order strategy must be selected before production certification.
- Server-side plan/price mapping validation must be implemented before accepting paid requests as certified.

## Non-Blocking Limitations

- Full legacy lint errors.
- No live Stripe test mode credentials/fixture documented.
- No browser billing E2E fixture.
- No generic admin audit sink.

## Phase 8 Acceptance Criteria

- One authoritative subscription/entitlement resolver used by APIs and UI projections.
- FREE effective access consistent when missing/expired/cancelled/failed.
- Server rejects unknown plans and mismatched price IDs.
- Webhook signature, duplicate, retry, and out-of-order behavior is durable and tested.
- Payment failure/expiry/cancel preserve Broker ownership, verification, visibility, profile, reviews, leads, and URL.
- Billing endpoints enforce owner/admin authorization and reject IDOR.
- No changes to claim/ownership/verification/publication contracts.
- Existing Phase 3B–7.5 regressions pass.

## Final Readiness Decision

**READY WITH NON-BLOCKING LIMITATIONS** to begin Phase 8 design/implementation after product approval of `42-PHASE-8-SCOPE-CONTRACT.md`. Phase 8 must begin with plan/price validation and webhook idempotency design. No Phase 8 code was implemented in this audit.
