# Advertisement Hardening Report

## Verified Defects Fixed

1. Public click tracking accepted a client-provided redirect URL, creating an open-redirect/tracking-integrity risk.
2. Impression and click endpoints accepted IDs for draft, archived, deleted, expired, or otherwise non-publishable advertisements.
3. Advertisement URL validation did not reject unsafe schemes and did not support the documented safe relative URL contract consistently.
4. Reversed advertisement schedules were accepted by the validation schema.
5. Admin publish could enable an advertisement with no media asset and no fallback banner URL.
6. Soft-deleted advertisements could not be restored through the documented lifecycle.
7. Bulk restore did not clear `isDeleted`.
8. Advertisement validation became import-unsafe when refinement was composed before `.partial()`; schema composition was corrected.

## Fixes

- Added safe relative/HTTP(S) destination validation.
- Removed client redirect authority from click tracking.
- Added publishable-ad checks to impression/click routes.
- Added publish readiness checks for creative and stored URLs.
- Added date-order validation.
- Corrected advertisement restore and bulk restore behavior.
- Added focused URL/schedule regression tests.

## Preserved Behavior

- Internal admin-only CMS model.
- No advertiser accounts.
- No advertiser checkout/payment.
- No new advertisement tiers or business rules.
- Existing API paths and response shapes.
- Existing media, placement, scheduling, and tracking models.
- No Broker, subscription, authentication, ownership, claim, verification, or public Broker behavior changes.

## Remaining Work

- Define and implement the missing Advertisement Inquiry/Contact Request workflow only after a documented business/schema/API decision.
- Add advertisement-specific API/DB/browser/security tests.
- Decide public tracking rate limits and abuse controls.
- Review SVG serving/content-security policy.
- Complete documented media restore/folder mutation APIs if required by the approved contract.

## Validation

- TypeScript: PASS.
- Prisma validation/generation: PASS.
- Production build: PASS.
- Advertisement focused tests: PASS.
- Existing regressions: PASS except one combined-run shared-database race; affected suite passes independently.
- Full lint: pre-existing failures.
