# Phase 13.15 Verification Matrix

| Requirement | Documentation | Schema | Implementation | API | Public UI | Tests |
|---|---|---|---|---|---|---|
| Public broker eligibility | Business model / broker policy | Existing Broker fields | `isPublicBroker` | Broker GET | Route/notFound | Existing broker-policy tests |
| Anonymous review reads | This report | `Review.isPublished` | Safe review projection | `/api/company/:slug/reviews` | Reviews tab | Phase 13.15 tests |
| Authenticated review reads | This report | Existing Review model | Same GET path | Session optional | Same public UI | HTTP verification |
| Review writes | Existing business rules | No schema change | No new write path | Existing writes unchanged | No public write bypass | Authorization preserved |
| Real ratings/counts | SEO/profile docs | `Broker.avgRating`, `totalReviews` | Existing stored values | Broker API | RatingBadge/review summary | DB-backed tests |
| Broker images | Profile/media docs | `logo`, `coverImage` | `BrokerAvatar`, `next/image` | Public broker projection | Controlled hero/logo | Build/route checks |
| Advertisement integration | Advertisement docs | Existing Advertisement/Creative | `AdvertisementRenderer` | Public ad API | Broker profile placement | Public ad tests |
| Responsive profile | Profile requirements | N/A | Responsive grid/buttons/images | N/A | Desktop/mobile layout | Type/build/static checks |
| SEO | SEO audits | N/A | Metadata with real image | N/A | Open Graph | Build/HTTP checks |
| Private-field protection | Security audits | Existing relations | `toPublicBrokerRecord` and review DTO | Safe response | No private data | Public projection tests |
