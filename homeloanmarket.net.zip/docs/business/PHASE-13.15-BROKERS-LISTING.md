# Phase 13.15 Public Brokers Listing

## Implementation Map

| Surface | Existing implementation | Refinement |
|---|---|---|
| Route | `app/(public)/brokers/page.tsx` | Preserved client data flow and real API query |
| Broker query | `useAllBrokers` → `/api/brokers` | Added existing `brokerStatus` query support for Featured filtering |
| Search | `/api/brokers?search=` | Preserved and synchronized to `search` URL parameter; legacy `q` remains readable |
| Filters | City, specialization, minimum rating | Added Featured status; URL state and mobile drawer behavior refined |
| Results | Existing `BrokerGridCard` | Reused without redesign; changed only grid composition |
| Ads | `AdvertisementRenderer` | Kept `BROKER_LISTING` as compact header placement; removed awkward stacked sidebar ad |
| Pagination | Existing page-based pagination | Preserved and synchronized to URL |
| SEO | `app/(public)/brokers/layout.tsx` | Existing canonical metadata preserved |

## Public Data Rules

`/api/brokers` continues to enforce public visibility, verified status, suspended exclusion, and active-owner/null-owner policy. The page does not expose ownership, claims, subscription internals, or private fields.

## UX Changes

- Compact directory introduction with real result count.
- Compact horizontal ad before search controls.
- Three-column desktop, two-column tablet, one-column mobile results.
- URL-synchronized search, filter, featured, and pagination state.
- Featured filter uses the existing public `brokerStatus=FEATURED` query contract.
- Mobile filter drawer locks body scroll and exposes accessible dialog controls.
- Existing BrokerCard visual system remains unchanged.

## Verification

- `/brokers` and valid broker profile routes return `200` anonymously.
- Invalid broker slugs remain `404`.
- Public broker and review API reads remain anonymous-safe.
- Existing advertisement carousel/responsive system is reused.
