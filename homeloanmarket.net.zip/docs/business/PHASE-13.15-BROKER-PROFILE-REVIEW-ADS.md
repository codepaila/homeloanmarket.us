# Phase 13.15 Broker Profile, Reviews, and Advertisements

## Implementation Map

| Surface | Live implementation | Public rule |
|---|---|---|
| Broker route | `app/(public)/brokers/[slug]/page.tsx` | Uses `isPublicBroker`; invalid/ineligible profiles are not found |
| Broker API | `app/api/company/[slug]/route.ts` | Public GET; optional session only enriches owner/admin behavior |
| Reviews API | `app/api/company/[slug]/reviews/route.ts` | Public GET, published reviews only, safe projection |
| Broker UI | `components/sections/broker/BrokerDetailClient.tsx` | Public profile hierarchy, tabs, contact, reviews, similar brokers |
| Broker cards | `components/brokers/*Card.tsx` | Public logo, rating, verification, specialties, location, CTA |
| Media | `Broker.logo`, `Broker.coverImage` | Controlled cover/logo rendering with fallback |
| Advertisement | `AdvertisementRenderer` with `BROKER_PROFILE_HEADER` | Reuses the canonical responsive resolver/carousel |
| SEO | `generateMetadata` in broker route | Canonical title, description, Open Graph image, public eligibility |

## Public Review Visibility

Anonymous and authenticated visitors may read published reviews. The proxy explicitly allows `/api/company/*`. Review responses expose only:

- rating
- comment
- createdAt
- reviewer display name/image

Review IDs, broker IDs, user IDs, ownership data, subscription data, and private fields are not returned by the public review endpoint.

There is no review write endpoint in the current application. No new submission flow was invented; existing review/business rules remain unchanged.

## Profile Hierarchy

The profile now presents:

1. Controlled cover/logo hero.
2. Company/broker identity and verification state.
3. Rating and real review count.
4. Request-information and review actions.
5. Broker-profile advertisement below identity/actions.
6. Contact, specialties, service areas, languages, and bank partnerships.
7. About, reviews, and contact tabs.

All existing broker data and public eligibility rules are reused.

## Advertisement Integration

The profile uses the existing `BROKER_PROFILE_HEADER` placement through `AdvertisementRenderer`. It does not create broker-specific advertisement logic. The canonical advertisement system handles:

- anonymous delivery
- placement targeting
- responsive creative resolution
- multiple-ad carousel behavior
- impression/click tracking
- safe empty/error collapse

## Validation

- Anonymous broker profile route: `200`.
- Anonymous broker API: `200`.
- Anonymous published-review API: `200`.
- Authenticated published-review API: `200`.
- Invalid/ineligible broker remains unavailable.
- Public review response contains no internal identifiers.
- Existing ownership, verification, claim, subscription, and contact rules are unchanged.
