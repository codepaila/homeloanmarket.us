# Broker Claim Implementation Plan

This is a future implementation plan only. No claim API, page, action, email, or ownership attachment was implemented in the compatibility audit.

## Current State

`BrokerClaim`, `BrokerClaimInvitation`, and `BrokerClaimEvent` exist in Prisma but have no application consumers. No admin Broker creation path, claim route, claim landing page, invitation email, or claim tests currently exist.

## Target Eligibility

Claim may start only when:

- `Broker.creationSource=ADMIN_CREATED`;
- `Broker.userId` is null;
- the invitation digest matches and invitation is ACTIVE;
- invitation is not expired/revoked/used;
- claim is not completed/terminal;
- claimant completes verified email/account setup;
- owner uniqueness and account eligibility checks pass.

Self-registered profiles have `userId != null`, no claim row, and derived claim state `NOT_REQUIRED`.

## Recommended Order

1. Add server-side claim repository/service around the three schema models.
2. Generate high-entropy raw tokens, persist only `tokenHash`, and never log raw values.
3. Create BrokerClaim and invitation/event rows in an admin-authorized transaction.
4. Send invitation email after commit with an opaque claim URL and expiry.
5. Add a public claim landing endpoint that validates without consuming and returns safe Broker fields.
6. Record OPENED/STARTED/EMAIL_SUBMITTED events without exposing account existence.
7. Reuse existing User/NextAuth/Credentials/Google/password setup flows; do not create a second auth system.
8. Verify email and reauthenticate existing users before ownership completion.
9. In one transaction, recheck all eligibility, conditionally set Broker.userId, set claim COMPLETED, mark invitation USED, record completion actor/event, and create/retain FREE.
10. Make the transaction race-safe so only one claimant wins.
11. Add seven-day expiry, revoke, resend, and supersede behavior. Invitation rows remain terminal; a fresh invitation may reopen an EXPIRED, REVOKED, or FAILED BrokerClaim, but never a COMPLETED claim.
12. Update public listing/contact/email/admin/dashboard consumers for nullable Broker.user.
13. Add IDOR, replay, enumeration, CSRF, race, expiry, revocation, duplicate-account, and profile-preservation tests.

## Event Requirements

Use the schema enum for `GENERATED`, `SENT`, `OPENED`, `STARTED`, `EMAIL_SUBMITTED`, `VERIFICATION_PENDING`, `COMPLETED`, `EXPIRED`, `REVOKED`, and `FAILED`. Events must be append-only, metadata sanitized, and raw tokens excluded.

## Ownership Invariants

- Claiming updates the existing Broker only; it never creates a replacement profile.
- Subscription creation/retention is separate from ownership attachment.
- Reviews, contacts, counters, slug, verification, and profile identity remain on the same Broker.
- A self-registered Broker cannot be claimed through an invitation.
- An unowned Broker has no dashboard owner and remains admin-managed until completion.
