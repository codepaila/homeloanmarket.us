# Phase 13.3A Admin Authentication Hardening Report

## Root Cause

Existing demo accounts were reconciled without validating their existing password hashes. A stale existing Admin password remained stale after seed execution.

## Fix

### `prisma/seed/helpers.ts`

- `ensureAdmin()` now compares the existing Admin hash with the deterministic seed password using the existing `comparePassword()` bcryptjs implementation.
- The password is rehashed with the existing `hashPassword()` implementation only when absent or incompatible.
- Valid existing hashes are preserved.
- Role, active state, and email verification remain explicitly reconciled.

### `prisma/seed/seed-demo.ts`

- Existing deterministic demo Users, including Brokers, now receive the same hash compatibility check.
- Stale or missing hashes are repaired with bcryptjs.
- No plaintext password is stored or accepted.

### `tests/phase-13.3a-admin-auth.test.ts`

- Added isolated real Credentials-provider authentication coverage for the seeded Admin.
- Added wrong-password rejection.
- Added unknown-email rejection.
- Asserted the returned role is `ADMIN`.

## Redirect Boundary

Redirect code was not redesigned in this phase. After authentication succeeds, the existing server-side role-aware action continues to select `/admin/ads`, while Broker and User destinations remain unchanged.

## Preserved Behavior

- Existing bcryptjs algorithm and salt policy.
- Existing account-state checks.
- Existing Auth.js Credentials provider.
- Existing session/JWT callbacks.
- Existing ownership, claims, subscriptions, Advertisement, SEO, schema, and seed dataset relationships.
