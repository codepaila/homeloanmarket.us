# Edge Cases

For claim-specific decisions and exact outcomes, `33-CLAIM-CONTRACT.md` supersedes the earlier high-level entries in this document.

| Case | Required behavior |
|---|---|
| Direct registration with unknown email | Create only after validation; do not reveal whether a conflicting account exists beyond safe generic response. |
| Direct registration duplicate email/phone | Reject safely or provide existing-account recovery; never create a duplicate user or claim. |
| Direct registration email unverified | Keep broker/profile association and FREE entitlement; block activation/dashboard until verification policy passes. |
| Direct registration abandoned before verification | Retain pending records under retention policy; allow rate-limited verification resend; no claim exists. |
| Normal user vs broker registration | Only explicit broker flow creates broker profile; normal user remains a borrower/account. |
| Admin claim unknown email | Generic continuation response; no account enumeration. |
| Claim existing user | Require sign-in/reauthentication and verified completion; do not duplicate user. |
| Claim user owns another profile | Reject or queue admin review under one-profile policy; never silently detach. |
| Claim existing unverified user | Send verification; no ownership attachment until verified. |
| Self-registered profile presented with claim link | Reject because claim is `NOT_REQUIRED`; support path only. |
| Already claimed profile | Reject invitation; no mutation. |
| Expired/revoked/used token | Reject with appropriate safe state; no reactivation or replay. |
| Simultaneous claims | One atomic winner; loser receives conflict/support response. |
| Multiple invitations | New invitation supersedes/revokes active prior invitations and records history. |
| Claim abandonment | Profile remains unowned and FREE; invitation expires normally. |
| Paid upgrade before/after claim | Permit only authorized owner/admin; never use payment to create ownership. |
| Premium expiry | `PREMIUM -> EXPIRED -> FREE`; preserve ownership, profile, reviews, leads, URL, and verification. |
| Suspension with active plan | Hide/disable paid display; billing/refund policy handled separately. |
| Account disabled | Block login/dashboard; preserve ownership/profile history. |
| Profile disabled mid-flow | Invitation invalidates; no attachment. |
| Slug changed before claim | Invitation resolves through stable profile relation; public link is refreshed safely. |
