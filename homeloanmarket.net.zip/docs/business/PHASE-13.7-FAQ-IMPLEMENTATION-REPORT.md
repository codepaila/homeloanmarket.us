# Phase 13.7 FAQ Implementation Report

## Files Created

- `actions/faqs.ts` — create/update/toggle/delete/move server actions (ADMIN-guarded).
- `app/admin/faqs/page.tsx` — list page with search and status filters.
- `app/admin/faqs/new/page.tsx` — create form.
- `app/admin/faqs/[id]/edit/page.tsx` — edit form.
- `components/admin/faqs/FaqTable.tsx` — table with publish/unpublish, edit, delete, reorder (up/down), and Add button.
- `components/admin/faqs/FaqForm.tsx` — shared create/edit form with server-side validation errors.
- `components/public/faq/FaqAccordion.tsx` — client accordion/search/category UI.
- `tests/phase-13.7-faq.test.ts` — FAQ data-layer tests.

## Files Changed

- `app/(public)/faq/page.tsx` — converted to server component reading published FAQs with canonical/OG/Twitter metadata and FAQPage JSON-LD.
- `lib/admin/navigation.ts` — added `FAQs -> /admin/faqs` under Site Management.
- `lib/admin/dashboard.ts` — overview now includes published/draft FAQ counts.
- `components/admin/dashboard/AdminDashboard.tsx` — Operations KPI grid shows Published FAQs and Draft FAQs.
- `prisma/seed/seed-demo.ts` — deterministic US FAQ seed; corrected legacy FAQ cleanup to exact-prefix filtering.

## CRUD

- Create: validates question (required, ≤300), answer (required, ≤5000), category, displayOrder (integer); rejects duplicate questions; ADMIN-only.
- Read: list with search/status, ordered by displayOrder then createdAt.
- Update: same validation; duplicate-question guard excluding self.
- Publish/unpublish: toggles `isActive`.
- Delete: removes the FAQ.
- Reorder: `moveFaq` swaps `displayOrder` with the adjacent row (up/down).

All mutations run server-side with `getCurrentUser()` ADMIN checks; affected pages are revalidated.

## Public Projection

Published FAQs only (`isActive === true`), deterministic order, FAQPage JSON-LD from published set, safe empty state, drafts never exposed.

## SEO

- `/faq` keeps title/description/canonical (`canonicalUrl('/faq')`), Open Graph, Twitter, robots indexable.
- No individual FAQ URLs; `/faq` remains the canonical FAQ URL. No artificial pages.

## Seed

- 11 deterministic US FAQs: 10 published + 1 draft (`What are jumbo loans and when are they used?`).
- Topics: pre-approval, broker vs lender, down payments, fixed vs adjustable, closing costs, FHA, VA, credit, refinancing, first-time buyers.
- Three consecutive runs identical; duplicate questions 0; draft stays unpublished.

## Dashboard

- Operations KPI grid now shows Published FAQs and Draft FAQs from real database counts.
