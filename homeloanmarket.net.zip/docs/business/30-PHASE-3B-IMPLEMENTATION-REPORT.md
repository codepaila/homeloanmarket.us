# Phase 3B Implementation Report

## Scope

Phase 3B repaired application compatibility with nullable `Broker.userId`, separated ownership from subscription and verification, made public profile reads owner-optional, and restored FREE dashboard access. Broker registration and claiming were not implemented.

## Files Changed

- `lib/broker-policy.ts` (new shared ownership, visibility, entitlement, and contact-email policies)
- `lib/subscription.ts`
- `lib/currentUser.ts`
- `actions/email.action.ts`
- `app/api/brokers/route.ts`
- `app/api/brokers/featured/route.ts`
- `app/api/brokers/[id]/route.ts`
- `app/api/brokers/[id]/contacts/route.ts`
- `app/api/company/[slug]/route.ts`
- `app/(public)/brokers/[slug]/page.tsx`
- `app/api/subscription/upgrade/route.ts`
- `app/api/subscription/cancel/route..ts`
- `app/broker/dashboard/page.tsx`
- `components/brokers/FeaturedBrokerRowCard.tsx`
- `components/sections/broker/BrokerDetailClient.tsx`
- `components/sections/broker/BrokerProfile.tsx`
- `components/layout/admin/sideBarData.ts`
- `prisma/seed.ts`
- `prisma/seed/seed-brokers.ts`
- `tests/phase-3b-broker-policy.test.ts` (new)

No Prisma schema change was made in Phase 3B.

## Null-Safe Changes

- Public broker list no longer requires `where.user.isActive`; it permits `userId=null` and excludes suspended profiles.
- Featured broker query no longer requires a related User.
- Broker detail routes check owner activity only when `userId` is non-null.
- Public company and slug-page queries permit unowned verified/visible Brokers.
- Owner deletion logic conditionally updates User only when `Broker.userId` exists.
- Broker email actions use profile email first for lead delivery and owner email first for account/subscription/review notifications, with safe skip behavior when no recipient exists.
- Verification resend explicitly rejects a broker with no owner account instead of dereferencing null.
- Public detail responses no longer include contact messages/leads.
- Broker contact listing now requires authentication and Broker ownership or ADMIN role.

No non-null assertions were added to hide nullable ownership.

## Ownership Changes

- Ownership checks continue to use `Broker.userId === authenticatedUser.id`.
- `isBrokerOwner` centralizes null-safe owner comparison.
- Null owner IDs are never passed to User updates.
- Unowned profiles can be public but have no owner dashboard.
- Existing self-service Broker creation now writes `creationSource=SELF_REGISTERED`.
- No claim API, claim invitation, or ownership attachment was implemented.

## Subscription Changes

- FREE is treated as an effective active entitlement when a broker has no subscription row, preserving basic access compatibility.
- FREE broker dashboard access is no longer blocked by `subscription.isActive`.
- Paid analytics remain gated separately from dashboard access.
- Subscription upgrade updates BrokerSubscription and commercial placement only.
- Subscription cancellation clears paid `featuredRank` only.
- Subscription service no longer changes `brokerStatus`, `verificationStatus`, `verifiedAt`, or `isVisible`.
- Premium/Featured public presentation uses active `BrokerSubscription.plan` rather than BrokerStatus.
- Ownership is never modified by subscription operations.

## Verification Changes

- Subscription upgrade no longer automatically verifies a Broker.
- Subscription expiration/cancellation no longer resets Broker verification.
- Broker verification remains controlled by `Broker.verificationStatus`.
- User email verification remains controlled by `User.emailVerified`.
- The new persisted email-verification-expiry field remains unused until the later authentication/email phase.

## Visibility Changes

The shared `isPublicBroker` policy requires:

- `isVisible=true`;
- `verificationStatus=VERIFIED`;
- `brokerStatus != SUSPENDED`;
- either no owner or an active owner.

Public visibility no longer requires a User for an otherwise eligible unowned Broker. Subscription is not part of the publication predicate.

## Dashboard Changes

- Owned FREE Brokers can access `/broker/dashboard`.
- Premium/Featured owners receive the paid analytics path.
- Unowned profiles cannot reach the broker dashboard because no User owns them.
- Dashboard authorization remains account/role/profile based; claim-state behavior is deferred to the claim phase.

## Seed Changes

- Existing seeded Brokers are explicitly marked `SELF_REGISTERED`.
- The simple seed now gives the second seeded Broker a FREE subscription.
- Existing seed users remain actual owners; no fake unowned owner was created.
- No admin-created claim example was added because claim behavior is deferred.

## Tests Added

`tests/phase-3b-broker-policy.test.ts` covers:

1. unowned verified Broker public visibility;
2. owned active Broker public visibility;
3. inactive-owner and suspended-profile rejection;
4. ownership derived only from `Broker.userId`;
5. FREE versus paid entitlement behavior;
6. Broker/profile-owner email fallback combinations.

The repository has no existing project test runner configuration. Tests were run directly with `npx tsx --test`.

## Validation

- `npx prisma validate`: **PASS**
- `npx tsx --test tests/phase-3b-broker-policy.test.ts`: **PASS**, 6/6 tests
- `npx tsc --noEmit`: **FAIL due to pre-existing issues only**

Remaining TypeScript errors:

- six missing generated `.next/dev/types/validator.ts` route modules;
- existing `prisma.config.ts` `seed` property type error.

No Phase 3B nullable-owner errors remain in the TypeScript output.

## Remaining Issues

- The direct broker registration endpoint still creates only User; transactional User + Broker + FREE registration belongs to the next registration phase.
- No admin Broker creation path exists yet.
- No claim API, invitation delivery, claim UI, or ownership attachment exists yet.
- `BrokerStatus` remains in the schema for compatibility and still has legacy consumers; paid writes were removed, but a later cleanup should define its operational meaning more narrowly.
- Existing public/listing UI may still display legacy BrokerStatus fields from API payloads.
- FREE entitlement backfill for existing database records requires a data/migration phase.
- The persisted email verification expiry field requires later auth/email implementation.
- `.next` generated route references and `prisma.config.ts` need separate repository cleanup.

## Schema Change Requested

None. Phase 3B required no Prisma schema modification.

## Next Implementation Order

1. Resolve repository TypeScript baseline issues.
2. Implement direct broker registration transaction and FREE entitlement creation.
3. Implement admin Broker creation with `userId=null` and `ADMIN_CREATED`.
4. Implement claim token/invitation service and atomic ownership attachment.
5. Integrate claim/account setup and email verification.
6. Add end-to-end tests for both onboarding paths.
