# Phase 9 Scope Contract

## 1. Authoritative Phase 9 Definition

The only explicit Phase 9 definition found in the authoritative implementation roadmap is:

> **Phase 9: Broker dashboard integration**
>
> Converge both owned paths on the same dashboard and owner APIs. Remove assumptions that every profile has a user and distinguish FREE from paid feature permissions.

**PHASE 9 SCOPE IS ROADMAP-LEVEL, NOT FULLY FINALIZED.**

No authoritative document defines a more detailed Phase 9 feature list, dashboard information architecture, new dashboard workflows, new API response shapes, new database fields, or new UI design requirements. This contract must not invent them.

## 2. Source Documents

- `docs/business/IMPLEMENTATION_PLAN.md`, Phase 9.
- `docs/business/14-FEATURE-REQUIREMENTS.md`, FR-016 through FR-020.
- `docs/business/17-API-REQUIREMENTS.md`, `GET/PATCH /api/brokers/me` and dashboard convergence.
- `docs/business/10-BROKER-WORKFLOW.md`, owner dashboard/profile/contact/subscription behavior.
- `docs/business/15-PERMISSION-MATRIX.md`, dashboard and owner permissions.
- `docs/business/12-STATE-MACHINES.md`, account activation and parallel ownership/claim/subscription states.
- `docs/business/21-CURRENT-VS-PROPOSED.md`, dashboard/authentication reuse and independent ownership model.
- `docs/business/20-TEST-STRATEGY.md`, dashboard/API/security/regression coverage.
- `docs/business/39-PHASE-7-CLAIM-IMPLEMENTATION-REPORT.md`, claim completion redirect and dashboard convergence.
- `docs/business/41-PHASE-7.5-HARDENING-IMPLEMENTATION-REPORT.md`, current claim/auth readiness and limitations.
- `docs/business/50-PHASE-8.5-FINAL-SUBSCRIPTION-PRODUCTION-CERTIFICATION.md`, certified FREE + FEATURED baseline.

## 3. Business Objective

Provide one authenticated Broker dashboard and one owner-API surface for both:

- directly registered, immediately owned Brokers; and
- claimed, previously admin-created Brokers.

The dashboard must preserve the independent concepts already certified:

- ownership is `Broker.userId`;
- claiming is the only admin-profile ownership attachment mechanism;
- verification is independent trust state;
- visibility/publication is independent editorial state;
- subscription is commercial entitlement only;
- active plans are exactly FREE and FEATURED.

## 4. In-Scope Features

The following are the only source-supported Phase 9 capabilities:

- Converge direct-registration and claim-completion users on `/broker/dashboard`.
- Reuse authenticated owner resolution for dashboard and owner APIs.
- Support active FREE owners without requiring payment.
- Distinguish FREE permissions from FEATURED commercial permissions.
- Keep profile editing, contacts, permitted analytics, billing, and account access owner-authorized.
- Preserve null-safe behavior for admin-created/unowned profiles outside the authenticated owner dashboard.
- Reuse the existing authentication, claim, subscription, Broker, review, contact, and dashboard infrastructure.
- Add the minimum tests required to prove the above behavior once the detailed contract is approved.

These are scope capabilities, not authorization to redesign the dashboard or add new product features.

## 5. Out-of-Scope Features

- New subscription tiers, including PREMIUM.
- New payment providers or Stripe business rules.
- Team ownership or multiple Brokers per User.
- Claim state-machine changes.
- Ownership transfer or silent ownership replacement.
- Verification automation or subscription-derived verification.
- Publication/visibility redesign.
- New admin revenue analytics or accounting workflows.
- New lead/CRM product features.
- Dashboard redesign, navigation redesign, or visual-system redesign.
- New authentication providers or a second authentication system.
- Schema migration unless a separately approved dashboard requirement proves it necessary.
- Public profile integration as a new phase objective; it is separately described as Phase 10 in the roadmap.
- Generic SaaS features not present in authoritative documentation.

## 6. Existing Functionality to Reuse

- NextAuth JWT, Credentials, Google provider, bcrypt, email verification, and reset flows.
- `getCurrentUser()` server-side User/Broker resolution.
- `/broker/dashboard` and the existing Broker dashboard components.
- `/api/brokers/me` and `/api/brokers/me/dashboard-stats` owner APIs.
- Existing contact, review, profile, bank, and subscription routes.
- `completeClaimForUser()` atomic claim attachment.
- `SubscriptionService.effectiveSubscription()` and FREE/FEATURED policy.
- `isBrokerOwner()` and current permission helpers.
- Existing `Broker.userId` partial uniqueness index.
- Existing BrokerClaim and BrokerSubscription one-to-one relations.
- Existing Phase 3B, Phase 6, Phase 7, Phase 7.5, and Phase 8.1–8.5 tests.

## 7. New Functionality Required

No new functionality can be finalized from current documentation beyond the roadmap sentence. The likely implementation work, pending product/technical approval, is:

- define the dashboard owner data contract;
- define the exact FREE versus FEATURED dashboard permission matrix;
- identify and remove remaining nullable-owner assumptions in dashboard/owner consumers;
- define which existing owner APIs are authoritative and which response fields are required;
- add tests for both onboarding paths through the same dashboard and owner APIs.

These are unresolved design tasks, not approved implementation work.

## 8. Business Rules

- A direct Broker registration owns its Broker through `Broker.userId` and has FREE entitlement initially.
- A claim completion attaches the existing admin-created Broker atomically and preserves its identity/history.
- A self-registered Broker never enters the claim state machine.
- A Broker cannot own more than one Broker under the existing uniqueness contract.
- FREE remains available without payment.
- FEATURED is the only paid commercial entitlement.
- Subscription/payment never establishes ownership, verification, publication, or claim completion.
- An unowned Broker is not an authenticated owner dashboard target.
- Admin operations remain separate from Broker owner operations.
- Existing API response contracts remain backward-compatible unless a future approved defect fix requires otherwise.

## 9. State Transitions

Phase 9 authorizes no new state machine. It must consume existing parallel states:

```text
Direct path:
VISITOR -> BROKER_FORM -> USER_AND_PROFILE_CREATED -> EMAIL_PENDING
         -> EMAIL_VERIFIED -> ACTIVE_FREE_BROKER -> dashboard

Claim path:
ADMIN_CREATED UNOWNED -> INVITED -> IN_PROGRESS -> COMPLETED OWNED
                                                   -> dashboard

Commercial path, independent:
FREE_ACTIVE <-> FEATURED_ACTIVE -> cancellation/expiry/payment policy -> FREE_ACTIVE
```

Dashboard access is a projection of authenticated account activation, Broker ownership, and effective entitlement. It must not collapse these states into one status.

## 10. API Requirements

Existing APIs to reuse/audit:

- `GET/PATCH /api/brokers/me`.
- `GET /api/brokers/me/dashboard-stats`.
- Existing contact/review/profile/bank APIs used by the dashboard.
- Existing subscription APIs certified in Phase 8.5.

Required future API properties:

- resolve the target Broker from the authenticated User;
- reject unauthenticated and non-owner access;
- validate all mutation input server-side;
- preserve response and error contracts;
- never accept client ownership, User ID, Broker ID, plan, or entitlement as authority;
- use safe errors and existing rate-limit/CSRF architecture where applicable;
- avoid dereferencing a null User for unowned public/admin profiles;
- preserve transaction safety for mutations.

No new route or response shape is authorized by this scope contract.

## 11. UI Requirements

- Reuse the existing Broker dashboard and dashboard layout.
- Show dashboard access only after existing authentication/activation/ownership policy.
- Represent FREE and FEATURED permissions from server-authoritative data.
- Preserve existing loading, empty, and error behavior unless a future contract specifies corrections.
- Do not show paid-only controls to FREE users.
- Do not expose admin-only controls to Broker owners.
- Do not use UI state as entitlement authority.

No visual redesign, navigation redesign, or new page is authorized.

## 12. Database Requirements

No Phase 9 schema change is currently justified by authoritative documentation.

Existing structures to preserve:

- nullable `Broker.userId`;
- unique ownership index `brokers_userId_non_null_unique`;
- `BrokerClaim` and invitation relations;
- one `BrokerSubscription` per Broker;
- User/Broker/Review/Contact/Bank relations;
- certified StripeWebhookEvent infrastructure.

If a future dashboard requirement proves a new field is necessary, it requires a separate schema design, migration, rollback, and data-integrity review. No schema change is authorized by this audit.

## 13. Authentication Requirements

- Reuse NextAuth JWT, Credentials, and Google architecture.
- Preserve active-account and Broker email-verification gates.
- Preserve existing claim reauthentication context.
- Do not create a second session or authentication model.
- Refresh dashboard user/Broker state from the server where required.

## 14. Authorization Requirements

- Owner access is derived from authenticated User -> Broker relation.
- Role checks alone are insufficient.
- A User cannot read or mutate another Broker's dashboard data.
- Admin access is explicit and separate from owner access.
- Unowned admin profiles have no owner dashboard until claim completion.
- Subscription entitlement controls commercial features only.
- Broker owners cannot change verification, claim state, suspension, or other admin fields.

## 15. Security Requirements

- IDOR protection for every owner API.
- Server-side ownership and entitlement resolution.
- Input validation and safe error contracts.
- No sensitive account/private claim data in public responses.
- Preserve claim token/context protections.
- Preserve rate limiting, CSRF strategy, session protections, and disabled-account checks.
- Preserve transaction and uniqueness protections.
- Add audit logging only where an approved mutation requires it.

## 16. Test Requirements

Future Phase 9 implementation must cover:

- direct registration -> authenticated dashboard;
- claim completion -> same authenticated dashboard;
- FREE dashboard access without payment;
- FEATURED paid-only feature access;
- expired/cancelled/failed FEATURED -> FREE dashboard behavior;
- missing subscription -> FREE dashboard behavior;
- owner versus non-owner dashboard API access;
- unauthenticated and stale-session behavior;
- admin versus Broker authorization;
- unowned Broker null-user safety;
- profile, contacts, reviews, leads, and billing response contracts;
- ownership/claim/verification/visibility invariants;
- duplicate/concurrent owner API mutations where applicable;
- browser coverage once an approved browser harness exists.

## 17. Dependencies

```text
Phase 9 dashboard integration
  |
  +-- NextAuth session and activation policy
  +-- User -> Broker ownership resolution
  +-- Direct registration FREE path
  +-- Claim completion atomic attachment
  +-- Broker owner APIs
  +-- FREE + FEATURED entitlement resolver
  +-- Contact/review/profile/bank data relations
  +-- Existing dashboard components/layout
  +-- Existing authorization/rate-limit/CSRF controls
  +-- Unit and MongoDB integration test infrastructure
  +-- Optional authenticated browser/provider fixtures
```

## 18. Acceptance Criteria

Phase 9 may be accepted only after the detailed contract is approved and evidence shows:

- both owned onboarding paths reach the same dashboard;
- FREE owners access permitted dashboard functionality without payment;
- FEATURED-only functionality is server-authoritative and correctly gated;
- missing/expired/cancelled/failed subscriptions retain FREE access;
- owner APIs resolve ownership server-side;
- non-owners, unauthenticated users, and unauthorized roles are rejected;
- unowned profiles do not cause dashboard/API null-user failures;
- existing claim, ownership, verification, visibility, profile, review, lead, and billing behavior remains intact;
- API contracts remain backward-compatible;
- required unit, API, database, security, race, and browser tests pass or are explicitly environment-limited;
- no schema change is made without a separately approved migration design.

## 19. Risks

- The roadmap does not define exact dashboard permissions or response contracts.
- Existing UI hooks and APIs may contain duplicated or stale projections.
- Browser/authenticated HTTP coverage is limited.
- Dashboard analytics and contact data may have paid/free assumptions requiring contract decisions.
- Nullable ownership must not be re-collapsed into a required relation.
- Historical documentation contains obsolete PREMIUM terminology.

## 20. Explicit Non-Goals

- Do not implement Phase 10 public profile integration under Phase 9.
- Do not implement Phase 11 security/testing as a standalone roadmap phase under Phase 9, though Phase 9 must include its own required tests.
- Do not add a dashboard product feature not supported by an authoritative requirement.
- Do not redesign or replace certified Phase 1–8.5 infrastructure.
- Do not begin implementation until the unresolved detailed Phase 9 contract is approved.

## Contract Status

**DRAFT SCOPE ONLY — NOT APPROVED FOR IMPLEMENTATION**

The roadmap definition is authoritative enough to identify the topic, but not enough to authorize detailed implementation decisions.
