# Phase 13.1 Seed Certification

## Status

**PHASE 13.1 STATUS: GO WITH NON-BLOCKING LIMITATIONS**

This certification covers seed-engine safety and repeatability for local development/demo QA. It is not production-data certification and does not authorize production seeding.

## Implementation Summary

- Established one authoritative entrypoint through `prisma/seed/index.ts`.
- Replaced the former random multi-file execution tree with `prisma/seed/seed-demo.ts`.
- Removed inactive duplicate seed modules and random helper code.
- Added deterministic keys, fixed timestamps, local media verification, dependency ordering, and isolated database refusal.
- Added focused seed safety tests in `tests/phase-13.1-seed.test.ts`.

## Seeded Counts

| Area | Result |
|---|---:|
| Users | 17 |
| Brokers | 16 |
| Owned / unowned Brokers | 12 / 4 |
| Public eligible / non-public Brokers | 13 / 3 |
| FREE subscriptions | 9 |
| Active FEATURED subscriptions | 5 |
| Expired/cancelled FEATURED fixtures | 2 |
| PREMIUM subscriptions | 0 |
| Reviews | 26 |
| Contacts | 19 |
| Advertisements | 20 |
| Advertisement placements covered | 16 / 16 |
| Media folders / assets | 7 / 25 |
| Advertisement events | 6 |

## Advertisement Coverage

All 16 certified placement enum values are covered. The seed includes active ads, a deterministic sidebar alternative, a future scheduled fixture, an expired fixture, and a disabled draft fixture. Existing priority/display-order selection, safe relative destinations, media requirements, scheduling, and tracking behavior are unchanged.

## Media Coverage

All 25 seeded assets resolve to existing local WebP files. Sharp metadata is read from the actual file, file sizes are read from disk, folder references are valid, and mobile assets use the existing local mobile paths. No live external image provider is required by the database seed.

## SEO and Public Eligibility

- 13 seeded Brokers pass `isPublicBroker()`.
- Three negative fixtures are hidden, unverified, or suspended.
- Broker slugs are deterministic and unique.
- No seed-generated localhost URL is used.
- No artificial SEO/location page is created.
- Local production HTTP verification against a build generated from the isolated database passed the existing Phase 12.1 SEO test.

## Integrity Results

- Duplicate demo Users: 0.
- Duplicate Broker slugs: 0.
- Duplicate owned Broker Users: 0.
- Duplicate subscriptions: 0.
- Duplicate logical Reviews: 0.
- Duplicate logical Contacts: 0.
- Duplicate Advertisement slugs: 0.
- Duplicate Media fixture paths: 0.
- Orphan Reviews: 0.
- Orphan Contacts: 0.
- Orphan Advertisement events: 0.
- Missing Media references: 0.
- Invalid Media folder references: 0.
- PREMIUM records: 0.

## Validation

- `npx prisma validate`: PASS.
- `npx prisma generate`: PASS.
- `yarn tsc --noEmit`: PASS before the final build regenerated the known incomplete `.next/types/validator.ts` artifact; the post-build rerun reports missing `.next/types/routes.js`.
- Targeted seed lint: PASS.
- Seed safety and regression tests: **33 passed**.
- Production build: PASS.
- Local seeded HTTP SEO test: PASS, 1/1 at `http://127.0.0.1:3102`.
- Full ESLint: FAIL due pre-existing unrelated repository errors, 166 errors and 255 warnings after obsolete seed modules were removed.

## Schema and Migration Status

- Schema changes: none.
- Migrations: none.
- Production database mutation: none.
- Production credentials/payment/OAuth data: none.

## Limitations

- The schema does not distinguish expired from cancelled subscriptions with a dedicated state; both are represented by inactive/expired fields.
- Several child-model logical keys are application-level because the schema has no compound uniqueness constraint.
- Browser visual validation was not executed.
- Standalone post-build TypeScript is blocked by the pre-existing generated `.next/types/validator.ts` import of missing `routes.js`; the Next production build TypeScript phase passes.
- The active seed contains the US demo fixtures already defined by the Phase 13 contract; no additional US conversion was performed as part of this seed-engine hardening pass.
- No production seed or production crawler certification is claimed.

## Production Readiness Score

**8.5/10 for local demo/QA seed readiness**

The deduction reflects application-level rather than database-enforced child uniqueness, unavailable browser validation, full-lint legacy debt, and the explicit prohibition on production execution.

## Final Decision

GO WITH NON-BLOCKING LIMITATIONS. The active seed path is deterministic, dependency-safe, isolated to local/demo databases, repeatable, and free of demonstrated duplicate/orphan/integrity violations in the isolated validation database.
