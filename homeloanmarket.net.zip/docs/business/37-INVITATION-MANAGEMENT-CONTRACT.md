# Invitation Management Contract

## 1. Purpose

This contract finalizes operational invitation management between admin Broker creation and the future claimant-side Phase 7 flow. Creating a Broker does not send or create an invitation. An admin explicitly decides when to invite an eligible unowned Broker.

## 2. Scope

This contract covers:

- single invitation issuance;
- Broker detail invitation management;
- one-time claim-link copying;
- resend/supersede;
- revoke;
- bulk invitation processing;
- recipient history;
- events, security, rate limits, and errors.

It does not implement claimant preview, account setup, claim session, email verification during claim, or ownership completion.

## 3. Creation and Invitation Separation

Admin Broker creation produces only:

```text
ADMIN_CREATED
userId = null
UNVERIFIED
isVisible = false
FREE_ACTIVE
no BrokerClaim row
no invitation
no email
```

The first explicit invitation operation creates/reuses `BrokerClaim`, creates an ACTIVE invitation, and sends the invitation email. Creating or editing a Broker never creates an invitation automatically.

## 4. Eligible Broker

An invitation may be issued only when:

- Broker exists;
- `creationSource=ADMIN_CREATED`;
- `userId=null`;
- Broker is not suspended or disabled;
- BrokerClaim is not COMPLETED;
- the acting user is an active ADMIN.

`isVisible` does not determine claim eligibility. An unowned unpublished Broker may be invited. A claimed Broker cannot receive a new claim invitation.

## 5. Single Invitation Workflow

1. Admin opens `/admin/brokers/:id`.
2. Admin enters a valid recipient email.
3. Server verifies ADMIN authorization and Broker eligibility.
4. Server creates/reopens the existing BrokerClaim according to `33-CLAIM-CONTRACT.md`.
5. Server acquires the per-Broker invitation lock.
6. Server revokes/supersedes any existing ACTIVE invitation.
7. Server generates 32 random bytes and computes SHA-256 lowercase hex digest.
8. Server stores only the digest, recipient metadata, status ACTIVE, and seven-day expiry.
9. Server records GENERATED.
10. Transaction commits.
11. Server constructs the claimant URL and sends the email after commit.
12. Server records SENT on accepted delivery or FAILED on unsuccessful delivery.
13. Admin receives a safe response containing operational status and, only for this explicit request, a one-time claim URL for copying.

No User, ownership, verification, payment, or claimant completion occurs.

## 6. Broker Detail Management

`/admin/brokers/:id` must display for authorized admins:

- recipient email;
- invitation status;
- creation time;
- sent event time when available;
- expiration time;
- revoked/used time when available;
- claim status;
- Send Invitation, Resend, Revoke, and Copy Claim Link controls.

Claimed Brokers show OWNED and do not show an active claim-invitation action. Historical invitations remain visible to admins without token hashes or raw tokens.

## 7. Copy Claim Link

The raw claim URL is a secret credential required by the claimant, so copying is an explicit privileged operation.

- A copyable URL exists only after an invitation is ACTIVE and the Broker remains unowned.
- The explicit send/resend response may include `claimLink` to the authorized admin caller only.
- The admin UI holds the URL in memory and copies it using the browser clipboard API.
- The URL is not persisted, logged, included in events, returned by list/detail APIs, or placed in bulk responses.
- A copy action itself does not send email or create another invitation/event.
- If no ACTIVE invitation exists, the admin must provide recipient email and issue a new invitation first.
- After page reload, the raw URL is unavailable; the admin must issue/resend a fresh invitation to obtain a new copyable link.
- The copyable link is not shown to non-admin users.

The implementation returns the raw claim URL only in the explicit authorized issue/resend response, and the admin UI holds it in memory for copying. It is absent after reload and absent from normal list/detail/bulk responses.

## 8. Resend

Resend requires ADMIN authorization, an invitation reference, and a valid recipient email. The operation resolves the invitation to its Broker server-side and rechecks `creationSource=ADMIN_CREATED` and `userId=null`.

Resend:

- revokes/supersedes the previous ACTIVE invitation;
- records REVOKED with reason `SUPERSEDED`;
- creates a fresh token and digest;
- creates a fresh seven-day expiry;
- creates a new ACTIVE invitation;
- records GENERATED;
- sends the email after commit;
- records SENT or FAILED;
- returns no token hash and returns the raw claim URL only to the explicit authorized admin response for copy.

Resend never creates another Broker, User, subscription, or ownership relationship.

## 9. Revoke

Revoke requires ADMIN authorization and a reason.

- ACTIVE -> REVOKED, with `revokedAt` and one REVOKED event.
- USED, EXPIRED, or already REVOKED invitations remain terminal.
- Revoke of a terminal invitation is idempotent operationally: return its existing terminal state without creating a duplicate transition event.
- Revocation prevents future claimant validation.
- Revocation does not delete the Broker, BrokerClaim, invitation history, subscription, or profile data.
- Revocation never reopens a COMPLETED claim.
- A fresh invitation may later be issued for an unowned Broker according to the claim contract.

## 10. Bulk Invitations

Bulk invitations use an independent per-item operation, not one giant transaction.

### Selection

Only Brokers satisfying `ADMIN_CREATED + userId=null + not suspended/disabled` may be selected. Claimed Brokers are rejected per item and cannot be silently skipped.

### Request

Conceptual endpoint:

`POST /api/admin/brokers/bulk-claim-invitations`

```json
{
  "items": [
    { "brokerId": "...", "recipientEmail": "abc@example.com" },
    { "brokerId": "...", "recipientEmail": "xyz@example.com" }
  ]
}
```

The maximum batch is **50 items**. Every item must contain its own recipient email. No client-supplied role, User ID, source, plan, verification, or token values are accepted.

### Processing

- Authenticate and authorize ADMIN once for the batch.
- Validate all item shapes and reject malformed items individually.
- Process each Broker independently using the single-invitation lock/transaction.
- A failure for one item does not roll back successful items.
- Send each email after that item commits.
- Record per-item GENERATED/SENT/FAILED/REVOKED events.
- Apply per-admin batch and recipient rate limits.
- Do not include raw tokens, claim URLs, token hashes, or internal secrets in the bulk response.

### Response

```json
{
  "results": [
    { "brokerId": "...", "status": "SENT", "invitationId": "...", "expiresAt": "..." },
    { "brokerId": "...", "status": "FAILED", "code": "INVALID_EMAIL" }
  ]
}
```

Bulk operations do not provide Copy Claim Link values. Admin must use the individual detail operation for an explicit copyable link.

## 11. Recipient Email Rules

`Broker.email` is profile contact data and is not ownership proof. Invitation recipient email is operational delivery data.

### Decision

Persist normalized `recipientEmail` on `BrokerClaimInvitation`.

Reason:

- admin detail must show who was invited;
- resend must know the prior target without requiring re-entry;
- invitation history must preserve delivery identity;
- bulk results and support investigations need per-invitation recipient context.

The field is admin/support data, not claimant identity proof. Claimant identity still comes from the verified claim email/User rules in `33-CLAIM-CONTRACT.md`.

Recommended field:

```text
recipientEmail String
```

Normalize to lowercase and trim whitespace. If privacy policy requires minimization, retain the normalized address with the platform’s ordinary administrative data-retention controls. Do not use it to authorize ownership.

This field is now implemented as the required invitation recipient field. Existing invitation records were inspected before the schema change and the configured and isolated databases contained zero records, so no backfill or invented address was required.

## 12. Invitation, Claim, and Ownership Relationship

```text
ADMIN CREATES BROKER
  -> Broker exists, unowned, FREE, unpublished
ADMIN SENDS INVITATION
  -> BrokerClaim + ACTIVE BrokerClaimInvitation
CLAIMANT OPENS LINK
  -> future claimant-side claim process
CLAIM COMPLETES
  -> future atomic Broker.userId attachment
BROKER OWNED
```

Creation does not imply invitation. Invitation does not imply claim started. Claim started does not imply ownership. Ownership exists only when `Broker.userId` is non-null after future completion.

## 13. Invitation Lifecycle

| State | Meaning | Allowed next state |
|---|---|---|
| ACTIVE | Current usable invitation, not expired | USED, EXPIRED, REVOKED |
| USED | Claim completion consumed it | terminal |
| EXPIRED | Seven-day lifetime passed | terminal invitation; fresh invitation may be issued |
| REVOKED | Admin superseded/revoked it | terminal invitation; fresh invitation may be issued |

The BrokerClaim process may be reopened to INVITED for a fresh invitation after EXPIRED, REVOKED, or FAILED. COMPLETED cannot reopen.

## 14. Claim Lifecycle Relationship

BrokerClaim status is independent of invitation status:

- first explicit invitation: claim INVITED;
- claimant-side future start: IN_PROGRESS;
- future successful attachment: COMPLETED;
- expiry/revocation/failure: corresponding terminal/current status;
- fresh admin invitation after EXPIRED/REVOKED/FAILED: claim INVITED again.

No claim completion is part of invitation management.

## 15. Token Security

- 32 cryptographically secure random bytes;
- base64url raw token only in the claimant URL;
- SHA-256 lowercase hex `tokenHash` in the database;
- no raw token in database, Redis, logs, events, list/detail APIs, or bulk responses;
- seven-day `expiresAt`;
- unique token digest;
- one ACTIVE invitation per BrokerClaim;
- Redis/Upstash per-Broker lock plus transaction for issue/resend/revoke;
- create replacement index only after existing ownership validation, as defined in `36-OWNERSHIP-INDEX-REMEDIATION-REPORT.md`.

## 16. Expiration

Expiration is authoritative at request time. Cleanup may materialize EXPIRED, but no endpoint may treat an ACTIVE invitation with `expiresAt <= now` as usable. Expired history is retained. Fresh invitation issuance is allowed only for still-unowned eligible Brokers.

## 17. Concurrency

- Single issue/resend/revoke operations use the same per-Broker distributed lock.
- The transaction revokes existing ACTIVE invitations before creating the replacement.
- A lock failure returns a retryable conflict and creates no new invitation.
- Bulk items acquire independent locks and transactions.
- No bulk transaction spans multiple Brokers.
- Existing non-null owner uniqueness and the remediated partial index remain the ownership backstop.

## 18. Rate Limiting

Current code uses the existing email attempt limiter and distributed claim-issuance lock. The next implementation must add explicit limits for:

- individual issue;
- resend;
- revoke abuse;
- copy-link requests if exposed as a server operation;
- bulk batch count per admin and time window;
- bulk recipient email volume.

No unsafe fallback may issue invitations when the distributed lock is unavailable.

## 19. Authorization

Every invitation-management operation requires an active ADMIN session. The server resolves Broker/Claim/Invitation relations from route IDs and checks ownership/source. A normal USER or BROKER cannot issue, resend, revoke, copy, or bulk-send invitations. Hidden UI is never an authorization control.

## 20. Error Behavior

- 401 unauthenticated;
- 403 authenticated non-admin or unauthorized target;
- 404 inaccessible/nonexistent Broker or invitation with safe wording;
- 409 claimed Broker, completed claim, terminal invitation, lock contention, or state conflict;
- 422 invalid recipient email or malformed request;
- 429 rate limit or lock contention;
- 500 only for unexpected failures, without token/secret details.

Bulk returns per-item safe result codes and does not turn one failure into a batch rollback.

## 21. API Requirements

| Operation | Contract status |
|---|---|
| `POST /api/admin/brokers/:id/claim-invitations` | Existing individual issue endpoint; next implementation must persist recipientEmail and return a one-time admin-only claimLink for explicit copy. |
| `POST /api/admin/claim-invitations/:id/resend` | Existing resend endpoint; next implementation must use persisted recipientEmail when no replacement address is supplied and return one-time claimLink only to admin. |
| `POST /api/admin/claim-invitations/:id/revoke` | Existing revoke endpoint; terminal revoke must be idempotent and lock-compatible. |
| `POST /api/admin/brokers/bulk-claim-invitations` | New required future endpoint; per-item independent processing, max 50, no raw URLs in response. |
| `GET /api/admin/brokers/:id` | Must expose safe recipient/status/timestamps after recipientEmail schema addition; never tokenHash/raw token. |
| Claimant routes | Deferred to Phase 7; this contract does not add or implement them. |

## 22. UI Requirements

Broker detail must provide recipient input, Send Invitation, Resend, Revoke, Copy Claim Link, status, recipient, created time, sent event time, expiry, and history. Copy requires an ACTIVE invitation and displays the one-time response-held URL only. List UI must select only eligible unowned Brokers and provide per-item recipient input for bulk send. Claimed Brokers cannot be selected.

## 23. Event/Audit Requirements

Mandatory claim events:

- GENERATED after invitation persistence;
- SENT after email provider accepts delivery;
- FAILED after provider failure or item-level failure;
- REVOKED for manual revoke or supersede.

Events are append-only, reference BrokerClaim/Invitation, and contain only safe metadata. They contain no raw URL, token hash, password, or unnecessary recipient plaintext. Sent time is represented by the SENT event timestamp; creation time is invitation.createdAt.

Generic admin profile audit remains separate from claim events.

## 24. Data-Model Requirements

Current `BrokerClaimInvitation` has token/status/expiry/used/revoked/created-by fields and event relations. The required operational addition is:

```text
recipientEmail String
```

No ownership boolean, second invitation model, second subscription, or claimant account field is required. The schema change is implemented and synchronized through the project MongoDB/Prisma workflow. No claimant-side behavior is implied by this field.

## 25. Edge Cases

| Case | Contract behavior |
|---|---|
| Claimed Broker | No new invitation, copy, resend, or bulk selection. |
| No active invitation | Send requires recipient; copy is unavailable. |
| Expired/revoked invitation | Fresh invitation may be issued if Broker remains unowned. |
| Used invitation | Cannot be resent as the same invitation; fresh issue is denied if claim completed. |
| Missing Broker email | Admin must provide recipient email. |
| Invalid recipient | 422; no claim state mutation. |
| Email provider failure | Invitation remains committed ACTIVE; FAILED event; resend available. |
| Multiple selected Brokers | Independent result per item; successful items remain committed. |
| One bulk item claimed during processing | That item fails safely; other items continue. |
| Admin edits during invitation | Profile identity/owner remain unchanged; invitation uses current safe profile data. |
| Redis unavailable | No invitation issuance/revocation proceeds through an unsafe fallback; return operational failure. |

## 26. Test Requirements

- Creation does not create invitation/email.
- Individual issue creates one active invitation and FREE/ownership remain unchanged.
- Recipient validation and persistence once schema is added.
- Copy response only available to ADMIN with active invitation and never in list/detail/bulk.
- Resend supersedes old invitation and resets seven-day expiry.
- Revoke active/terminal/idempotent behavior.
- Multiple ACTIVE invitations impossible under concurrent operations.
- Bulk items process independently with per-item result.
- Claimed Brokers rejected by issue/resend/revoke/copy/bulk.
- Raw token absent from storage/events/logs/responses except explicit copy/send response.
- GENERATED/SENT/FAILED/REVOKED event order and safe metadata.
- Email failure preserves committed invitation state.
- Admin/USER/BROKER/unauthenticated authorization and IDOR tests.
- Public visibility remains false and unaffected by invitation operations.
- Existing self-registration remains no-claim and owned.
- Remediated partial owner index permits multiple nulls and rejects duplicate non-null owners.

## 27. Phase 7 Boundary

Phase 7 consumes an ACTIVE invitation through:

```text
claim URL -> preview -> start -> claim context -> email/account/authentication -> verification/reauthentication -> atomic ownership attachment
```

Phase 6.8 does not implement any of those claimant operations. It only implements the operational recipientEmail foundation and invitation-management hardening.

## 28. Final Decision

Creation and invitation are separate. One active invitation is enforced. Copy is explicit-admin-only and memory/response scoped. Resend supersedes and reuses persisted recipientEmail. Revoke is terminal/idempotent. Bulk is independent per Broker. No claimant functionality is part of this phase.
