# Phase 10 Implementation Audit

## Scope

Phase 10 is limited to public Broker profile integration: one public eligibility predicate, approved unowned public profiles, suspended/disabled exclusion, preserved URLs/reviews/contact behavior, and safe public projections.

## Matrix

| Area | Current logic | Required logic | Gap | Action |
|---|---|---|---|---|
| Public predicate | `isPublicBroker()` exists and is used by listing/detail paths | Reuse one predicate across all public surfaces | Review/contact paths do not consistently call it | Fix public review/contact eligibility |
| Unowned public profile | Predicate supports `userId=null` with approved visibility/verification | Do not require User for approved public profile | Contact route rejects `!broker.user` | Fix contact route |
| Suspended/disabled | Predicate rejects suspended and inactive owned account | All public targets must reject | Reviews/contact do not apply predicate | Fix routes |
| Public listing | Filters visibility, verification, suspension, owner active/null | Safe public fields only | User relation selects account identifiers | Remove private User fields |
| Public detail | Applies public predicate | Safe public projection | Includes User id/email/phone and spreads relation | Restrict User projection |
| Public company detail | Applies public predicate | Safe public projection | Includes User id/email/phone and spreads relation | Restrict User projection |
| Public profile page | Applies predicate | Safe public data | Server select includes User id/email/phone | Restrict select |
| Public reviews | Published review query | Target Broker must be public | No Broker publication predicate | Fix review route/projection |
| Public contact | Eligible public Broker contact | Same public predicate; unowned allowed | Requires related User; no predicate | Fix contact route |
| Ownership | `Broker.userId` | Unchanged | None | Preserve |
| Claims | Separate claim services | Unchanged | None | Preserve |
| Subscription | FREE/FEATURED resolver | Unchanged | None | Preserve |
| Advertisement | Separate admin/public CMS | Unchanged | None | Preserve |

## Verified Defects

1. Hidden/suspended/unowned-ineligible Broker reviews could be queried by slug because the review route checked only Broker existence and published review rows.
2. Public contact submission rejected approved unowned Brokers and did not apply the shared public predicate.
3. Public Broker responses selected User account identifiers and spread the User relation into public responses.

## Non-Goals

- No new publication state or schema.
- No ownership/claim/verification/subscription/dashboard change.
- No SEO redesign.
- No Advertisement CMS change.
