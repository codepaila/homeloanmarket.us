# Schema-to-Business Rule Matrix

This matrix maps the finalized rules to database support. It identifies design support only; it does not implement the rules.

| Rule | Database support and enforcement |
|---|---|
| BR-001 | Optional `Broker.userId`; nullable `Broker.user` relation. |
| BR-002 | Unique non-null current owner relation and conditional ownership transaction. |
| BR-003 | Separate ownership relation, creation source, and BrokerClaim lifecycle. |
| BR-004 | `BrokerCreationSource` stored on Broker. |
| BR-005 | Claim eligibility checks `creationSource=ADMIN_CREATED` and `userId=null`; no claim for self-registration. |
| BR-006 | Self-registration creates Broker with non-null userId and no BrokerClaim row. |
| BR-007 | No invitation row/token is created by direct registration; endpoint transaction path is distinct. |
| BR-008 | BrokerClaimInvitation with active status, digest, expiry, and profile eligibility. |
| BR-009 | BrokerClaim terminal completion plus unique owner; transfer is not an implicit update. |
| BR-010 | Existing Broker primary key and all child foreign keys remain unchanged during claim. |
| BR-011 | Both paths reference the same Broker and BrokerSubscription models. |
| BR-012 | One BrokerSubscription per Broker with FREE plan/default entitlement. |
| BR-013 | No claim or registration write may select PREMIUM as its default; schema cannot alone enforce service policy. |
| BR-014 | Subscription fields are separate from User/Broker ownership and claim models. |
| BR-015 | Subscription update transitions paid plan/status to FREE without changing Broker.userId or child IDs. |
| BR-016 | No subscription relation is used as owner foreign key; authorization joins through Broker.userId. |
| BR-017 | Broker verification fields and User email verification fields remain separate. |
| BR-018 | Publication/visibility fields remain on Broker, independent of owner/claim/subscription. |
| BR-019 | Safety/publication state on Broker is checked by public queries; suspension is not encoded by ownership. |
| BR-020 | Nullable owner plus publication/verification fields permits approved unowned public profiles. |
| BR-021 | Invitation token digest, expiry, status, and cryptographic issuance policy. |
| BR-022 | Only tokenHash field exists; no plaintext token column or audit payload. |
| BR-023 | Invitation `usedAt/status` changes only in completion mutation, never preview GET. |
| BR-024 | Conditional update/transaction checks null owner and active invitation before completion. |
| BR-025 | Store no account-disclosure state in public claim lookup; target email hash is optional and non-authoritative. |
| BR-026 | Unique User email/phone, unique owner, and find-or-create transaction. |
| BR-027 | Claim event/invitation status records abandonment/expiry while Broker.userId remains null. |
| BR-028 | One active invitation policy plus unique owner and terminal invitation status. |
| BR-029 | Actor/admin references on ClaimInvitation, ClaimEvent, and optional AuditEvent support audit authorization. |
| BR-030 | Broker profile content remains separate from administrative trust/status fields. |
| BR-031 | Existing User/Broker models plus stored `SELF_REGISTERED` source support voluntary registration. |
| BR-032 | No BrokerClaim relation is required for self-registration; API boundary is separate. |
| BR-033 | BrokerSubscription FREE row created in the direct registration transaction or activation policy boundary. |
| BR-034 | FREE plan has no Stripe identifiers/payment prerequisite; entitlement row can exist with no end date. |
| BR-035 | Paid plan columns are independent of Broker.userId and claim rows. |
| BR-036 | Direct registration transaction writes User, Broker.userId, source, and FREE together. |
| BR-037 | Nullable Broker.userId and source permit an admin-created profile before account creation. |
| BR-038 | Claim updates only ownership/claim/related event data; Broker ID/slug remain stable. |
| BR-039 | User.role and broker creation endpoint are separate; no schema relation forces normal users to own Brokers. |
| BR-040 | Existing User and Account models serve both flows; no duplicate credential model. |
| BR-041 | User email verification fields and explicit future expiry support activation gating. |
| BR-042 | Broker visibility/verification fields are independent of User email verification and FREE. |
| BR-043 | Claim events and optional generic audit events retain immutable business history. |
| BR-044 | User stores only a password hash; no password or setup secret is stored in claim invitation. |
| BR-045 | Public query projections can omit User/private claim relations; schema relations do not require public disclosure. |
| BR-046 | Admin actor, reason, timestamps, and audit/event relations support assisted claiming evidence. |

## Path Verification

### Path A
`Broker(userId=null, creationSource=ADMIN_CREATED)` -> `BrokerClaim + Invitation` -> atomic `Broker.userId=User.id` and claim completion -> existing/new `BrokerSubscription(plan=FREE)` -> optional paid update.

### Path B
`User` -> transactional `Broker(userId=User.id, creationSource=SELF_REGISTERED)` + `BrokerSubscription(plan=FREE)` -> email verification/activation -> optional paid update. No BrokerClaim or invitation is created.
