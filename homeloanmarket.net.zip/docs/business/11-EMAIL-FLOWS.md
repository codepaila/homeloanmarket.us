# Email Flows

Existing flows include broker registration verification, resend verification, password reset, lead notification, review notification, subscription notification, and customer contact confirmation. Current verification expiry is inferred from `User.updatedAt` while registration does not persist a dedicated expiry; target work must correct this without weakening existing reset semantics.

Claim invitation must include company name, public URL, opaque secure link, expiry, why the recipient received it, support, and no password. Verification/setup sends a one-time link or code; password is entered only over HTTPS and stored using the existing password hashing approach. Unknown emails receive generic responses. Existing users receive a sign-in/claim continuation rather than a second account. Delivery retries are idempotent and never reveal token values in logs.
