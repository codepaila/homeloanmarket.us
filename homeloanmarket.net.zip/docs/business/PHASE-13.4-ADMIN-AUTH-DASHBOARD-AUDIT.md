# Phase 13.4 Admin Auth + Dashboard Audit

## Root Cause of Admin Session Failure

Real-path reproduction on the production build (`next start` over `http://127.0.0.1`) showed that the credentials POST returned `302` to `/admin/ads`, but the session was not retained. Two exact causes were demonstrated:

1. **Fragile custom cookie override.** `lib/auth.ts` forced the session token cookie to `__Secure-next-auth.session-token` with `Secure` in production. Over plain HTTP, `Secure` cookies and the `__Secure-` prefix are dropped by browsers, so the authenticated session vanished immediately.
2. **Missing proxy secret resolution.** After removing the override, `getToken({ req })` in `proxy.ts` threw `MissingSecret`, returning 500 for protected routes. `getToken` requires the secret to be explicitly passed or available as a runtime env in the proxy context.

## Cookie/Session Behavior (before)

- Cookie name: `__Secure-next-auth.session-token`
- Attributes: `HttpOnly; Secure; SameSite=Lax`
- Result over local HTTP: browser would not send the Secure cookie back.

## Cookie/Session Behavior (after)

- Canonical Auth.js v5 cookie handling with `trustHost: true`.
- Over local HTTP the non-secure `authjs.session-token` is used; over HTTPS Auth.js applies the secure variant automatically.
- Proxy passes `secret: AUTH_SECRET || NEXTAUTH_SECRET` explicitly to `getToken`.

## Proxy Behavior (before/after)

Before: `app/proxy.ts` named export was inactive; `getToken` lacked explicit secret. After: root `proxy.ts` default export is registered (`ƒ Proxy (Middleware)` in build), consumes the decoded token, and enforces role boundaries. `/admin` is the canonical Admin dashboard and is no longer redirected as a catch-all.

## Redirect Behavior

- ADMIN home: `/admin`.
- BROKER home: `/broker/dashboard`.
- USER home: `/`.
- Callback sanitization unchanged: same-origin authorized destinations only.

## Real-Path Evidence

```text
Admin login  -> session cookie created -> /admin -> 200
Broker login -> /admin -> 307 /broker/dashboard
User login   -> /admin -> 307 /
Unauthenticated /admin -> 307 /auth/signin?callbackUrl=%2Fadmin
Invalid credentials -> /auth/signin?error=CredentialsSignin
```

## Dashboard Data Sources

- Users/Brokers/subscriptions/advertisements: Prisma model counts and bounded `createdAt` buckets.
- Active brokers: the existing eligibility predicate expressed as a query.
- Profile views: existing `Broker.profileViews` counter.
- Advertisement engagement: existing `AdEvent` impressions/clicks (30-day window).
- Revenue: no authoritative payment amount in the local schema — deliberately not fabricated.

## Frozen Contract Verification

No ownership, claim, subscription, Advertisement lifecycle, SEO, public Broker projection, or public eligibility behavior was changed. No production data or schema changes were made.
