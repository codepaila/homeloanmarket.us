# Phase 9 Final Scope Contract

## 1. Objective

Phase 9.1 will integrate the existing Broker dashboard and owner APIs so that directly registered Brokers and successfully claimed Brokers use one authenticated dashboard, one ownership model, one authorization model, and one FREE/FEATURED permission projection.

The implementation must remove unsafe assumptions that every Broker has a User while preserving all certified ownership, claim, verification, visibility, subscription, and advertisement behavior.

## 2. Authoritative Source

The authoritative roadmap definition is `docs/business/IMPLEMENTATION_PLAN.md`, Phase 9:

> Converge both owned paths on the same dashboard and owner APIs. Remove assumptions that every profile has a user and distinguish FREE from paid feature permissions.

Supporting authority:

- `13-BUSINESS-RULES.md`;
- `14-FEATURE-REQUIREMENTS.md`;
- `15-PERMISSION-MATRIX.md`;
- `17-API-REQUIREMENTS.md`;
- `20-TEST-STRATEGY.md`;
- `27-OWNERSHIP-SUBSCRIPTION-VERIFICATION-AUDIT.md`;
- `33-CLAIM-CONTRACT.md`;
- `39-PHASE-7-CLAIM-IMPLEMENTATION-REPORT.md`;
- `41-PHASE-7.5-HARDENING-IMPLEMENTATION-REPORT.md`;
- `50-PHASE-8.5-FINAL-SUBSCRIPTION-PRODUCTION-CERTIFICATION.md`.

## 3. In Scope

- Shared dashboard access for direct-registration and claim-completion paths.
- Server-authoritative owner resolution for dashboard APIs.
- Null-safe behavior for unowned/admin-created Brokers outside owner dashboard paths.
- Explicit FREE and FEATURED dashboard permission projections.
- Existing Broker profile, contacts, reviews, leads, banks, analytics, account, and billing surfaces where already supported.
- Owner/non-owner/admin/unauthenticated authorization behavior.
- Existing dashboard loading, empty, error, desktop, and mobile behavior audit/corrections.
- Phase 9.1 unit, API, integration, race, security, and browser test coverage.

## 4. Out of Scope

- New dashboard product features not present in authoritative requirements.
- Dashboard redesign or navigation redesign.
- New APIs when existing owner APIs can be reused.
- New subscription tiers or PREMIUM.
- Stripe/subscription business-rule changes.
- Ownership transfer or ownership schema redesign.
- Claim state-machine changes.
- Verification or publication redesign.
- Advertisement CMS changes; advertisement remains admin CMS -> public display -> tracking.
- CRM, advertiser workflows, WhatsApp, Gmail, social communication, or advertiser portals.
- Team ownership or multiple Brokers per User.
- Phase 10 public-profile integration.
- Phase 11 as a separate roadmap phase, except Phase 9.1 must include its own required security tests.

## 5. Ownership Paths

### Path A: Direct Registration

```text
Visitor
 -> POST /api/auth/register/broker
 -> transactional User + Broker + FREE
 -> Broker.userId = User.id
 -> SELF_REGISTERED
 -> email activation policy
 -> /broker/dashboard
```

### Path B: Claim Completion

```text
Admin-created Broker with userId = null
 -> invitation
 -> claim start/context/reauthentication
 -> completeClaimForUser()
 -> conditional Broker.userId attachment
 -> claim COMPLETED / invitation USED
 -> /broker/dashboard
```

Both paths must use the same dashboard route, owner API resolution, Broker data model, effective entitlement resolver, and authorization contract.

## 6. Business Rules

- `Broker.userId` is the only current ownership relation.
- A direct registration is owned immediately by its creating User.
- Claim completion is the only ownership attachment mechanism for admin-created profiles.
- A Broker may exist without a User before claim completion.
- A User cannot own multiple Brokers under the existing ownership index.
- FREE is baseline access and requires no payment.
- FEATURED is the only paid commercial entitlement.
- PREMIUM is unsupported in active runtime behavior.
- Subscription does not prove ownership, verification, or publication.
- Claim completion does not create a second Broker or dashboard architecture.
- Verification and `User.emailVerified` remain separate from Broker ownership.
- Public visibility remains governed by existing publication/verification policy.
- Broker owners cannot change administrative verification, claim, suspension, or ownership fields.
- Existing API response contracts remain backward-compatible.

## 7. Dashboard States

| State | Dashboard | Owner APIs | Visible permission baseline |
|---|---|---|---|
| Authenticated User with owned Broker | Allow after activation policy | Owner-scoped allow | Own profile/dashboard permissions |
| Authenticated User without Broker | Redirect/setup or existing account behavior | `/api/brokers/me` returns 404 | No Broker owner features |
| Newly registered Broker, email pending | Existing activation gate | Protected owner APIs reject/gate per current policy | No active dashboard until policy allows |
| Successfully claimed Broker | Allow after completion/activation | Same owner APIs as direct path | Same as equivalent FREE/FEATURED owner |
| Active FREE Broker | Allow | Allow own data | Basic/free permissions only |
| Active FEATURED Broker | Allow | Allow own data | FREE plus explicitly approved paid permissions |
| Expired FEATURED | Allow | Allow own data | Effective FREE permissions |
| Cancelled FEATURED | Allow | Allow own data | Effective FREE permissions |
| Invalid/unsupported subscription | Allow with FREE-safe projection | Allow own data | Effective FREE permissions |
| Unowned Broker | No owner dashboard | No owner API authority | Admin/public behavior only |
| Non-owner | Reject/redirect | 403/404 according to existing contract | No target-owner data |
| ADMIN | Admin UI is authoritative | Admin operations only where explicitly allowed | No automatic Broker-owner impersonation |
| Deleted/inactive User | Reject/gate | Reject protected owner operations | No active owner features |
| Missing/invalid Broker reference | Safe redirect/error | 404/401/403 per route contract | No partial unsafe data |

## 8. Permission Matrix

`UNDEFINED — PRODUCT DECISION REQUIRED` means Phase 9.1 must not infer behavior.

| Capability | FREE owner | FEATURED owner | ADMIN |
|---|---|---|---|
| Dashboard access | Yes after activation | Yes after activation | Separate admin UI; Broker dashboard impersonation undefined |
| Own profile read | Yes | Yes | Yes through admin APIs |
| Own authorized profile editing | Yes | Yes | Yes |
| Change `Broker.userId` | No | No | No through dashboard; separate reviewed ownership workflow only |
| Change claim state | No | No | No through dashboard; claim workflow only |
| Change Broker verification | No | No | Admin-only existing workflow |
| Change `User.emailVerified` | No | No | Existing auth/admin policy only |
| Change publication/visibility | Existing documented policy; exact owner control undefined | Existing documented policy; exact owner control undefined | Admin-controlled |
| View/manage own contacts | Yes, existing limits | Yes, existing limits | Admin where documented |
| View reviews | Yes | Yes | Yes |
| Manage reviews | UNDEFINED — PRODUCT DECISION REQUIRED | UNDEFINED — PRODUCT DECISION REQUIRED | Existing admin policy only |
| View/manage leads | Yes, free limits | Yes, paid limits | Yes where documented |
| Basic analytics | Yes | Yes | Yes |
| Advanced analytics | UNDEFINED — exact boundary required | Intended paid capability; exact fields required | Yes where documented |
| Advertisement information | Not part of Broker dashboard contract | Not part of Broker dashboard contract | Separate Advertisement CMS |
| Featured placement | No paid entitlement | Yes through subscription entitlement | Admin advertisement/placement controls remain separate |
| Paid placement controls | No | UNDEFINED — subscription UI versus dashboard controls must be decided | Separate admin policy |
| Subscription management | Own upgrade/cancel/billing | Own billing | Explicit admin reconciliation only |
| Billing | Own billing | Own billing | Admin reconciliation only |
| Upgrade | Yes to FEATURED | No higher plan | No new tiers |
| Cancellation | Yes | Yes | Explicit admin support only |
| Account settings | Own account | Own account | Own admin account |
| Verification badge entitlement | No | No | Verification is separate admin trust state |

## 9. Owner API Matrix

| API | Current purpose | Auth/owner authority | Phase 9.1 status |
|---|---|---|---|
| `GET /api/brokers/me` | Resolve own Broker/profile/data | Authenticated BROKER; DB lookup by `userId` | Reuse; formalize response/error contract |
| `PATCH /api/brokers/me` | Mutate authorized own profile fields | Authenticated BROKER; DB lookup by `userId` | Reuse; audit field/permission contract |
| `GET /api/brokers/me/dashboard-stats` | Own dashboard statistics | Authenticated User with Broker profile | Reuse; add contract/security tests |
| `GET /api/brokers/[id]/contacts` | Broker contacts | Admin or `broker.userId === currentUser.id` | Reuse; verify all dashboard callers |
| `GET/PATCH /api/user/profile` | Own account profile | Authenticated current User | Reuse; preserve account contract |
| Subscription details/usage/checkout/upgrade/cancel/portal | Own billing | Authenticated current User -> Broker | Reuse Phase 8.5 contract |
| Claim session APIs | Claim context/completion | Existing signed context and auth | Reuse; no dashboard-specific duplicate |

Required properties for every owner API:

- authenticate server-side;
- resolve target Broker from current User where owner scope applies;
- reject client-controlled owner/User/Broker authority;
- preserve existing response/error contracts;
- validate mutations;
- preserve transaction and rate-limit behavior;
- never expose another Broker's private data.

## 10. Authorization Model

```text
NextAuth session
      |
      v
Current User from server database
      |
      v
Broker where Broker.userId = User.id
      |
      v
Owner API / dashboard data
```

`subscription.plan` and `subscription.isActive` are entitlement inputs only. They are never ownership proof.

## 11. Data Model Requirements

**No Phase 9 schema change is currently required.**

Preserve:

- nullable `Broker.userId`;
- `brokers_userId_non_null_unique`;
- `BrokerClaim`, invitation, and event relations;
- one `BrokerSubscription` per Broker;
- User/Broker/Review/ContactMessage/BrokerBank relations;
- existing verification and visibility fields.

If Phase 9.1 requests persisted dashboard metrics or new permission state, stop and produce a separate schema/migration/rollback design.

## 12. UI Requirements

- Reuse `/broker/dashboard`, existing Broker dashboard layout, navigation, and components.
- Reuse existing loading, empty, and error patterns unless a verified defect is approved.
- Render FREE/FEATURED server-authoritative permissions.
- Do not use client subscription state as entitlement authority.
- Ensure both ownership paths reach the same route and data surface.
- Preserve desktop/mobile behavior; browser acceptance is required when infrastructure exists.
- Keep admin UI separate from Broker owner dashboard.

## 13. Testing Requirements

Phase 9.1 must add or execute:

- direct registration -> dashboard integration;
- claim completion -> same dashboard integration;
- owner/non-owner/unauthenticated/admin HTTP authorization;
- valid, invalid, stale, and missing sessions;
- FREE, FEATURED, expired, cancelled, missing, and unsupported subscriptions;
- null-owner public/admin/API safety;
- profile/contact/review/lead/billing contract checks;
- desktop/mobile/loading/empty/error dashboard states;
- IDOR, client-controlled ID, role escalation, and data exposure tests;
- concurrent owner mutations where applicable;
- existing Phase 1–8.6 regression suites.

Browser E2E requires a controlled browser fixture; it must not be claimed without execution.

## 14. Security Requirements

- No authentication bypass.
- No cross-Broker data access.
- No client-controlled ownership or entitlement authority.
- No admin escalation through Broker dashboard APIs.
- No null-owner dereference or accidental owner match.
- No subscription-to-ownership/verification/publication coupling.
- Existing claim token/context, rate-limit, CSRF, session, and transaction controls remain intact.

## 15. Acceptance Criteria

Phase 9.1 is complete only when:

- direct and claimed Brokers reach the same dashboard;
- owner APIs derive ownership from authenticated authority;
- nullable `Broker.userId` is safe throughout dashboard/owner consumers;
- non-owners cannot access another Broker's dashboard/data;
- FREE permissions are approved and enforced;
- FEATURED permissions are approved and enforced;
- expired/cancelled FEATURED uses FREE behavior;
- subscription never proves ownership or verification;
- claim completion remains the ownership transition;
- existing ownership, claim, verification, visibility, profile, review, lead, billing, and advertisement behavior remains intact;
- API response contracts remain compatible;
- required tests pass or have explicit environment limitations;
- no schema change occurs without separate approval.

## 16. Phase 9.1 Implementation Boundaries

Implementation may begin only after the unresolved matrix items marked `UNDEFINED` are decided and the owner API contracts are approved. The first implementation step must be the smallest contract-backed dashboard/owner API test harness, followed by fixes proven by those tests.

## Contract Status

**NOT APPROVED FOR IMPLEMENTATION — PRODUCT DECISIONS REQUIRED**
