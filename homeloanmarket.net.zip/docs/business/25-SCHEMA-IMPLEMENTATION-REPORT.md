# Schema Implementation Report

## Status

This report covers Phase 2 database-schema implementation only. API, server action, authentication, email, UI, component, page, middleware, subscription logic, seed, dependency, environment, and database-data changes were not made.

## 1. Exact Schema Changes Made

`prisma/schema.prisma` was updated to:

- make `Broker.userId` nullable while preserving `@unique` and `@db.ObjectId`;
- make `Broker.user` optional;
- add explicit `onDelete: NoAction` to User -> Broker so deleting a User cannot cascade-delete a Broker profile;
- add nullable `Broker.creationSource` using the approved `BrokerCreationSource` enum;
- add an index on `Broker.creationSource`;
- add `User.emailVerificationTokenExpiresAt`;
- add the approved claim process, invitation, and event models;
- add the approved claim enums and their relations/indexes;
- preserve `BrokerSubscription` as the only commercial entitlement model.

`creationSource` is intentionally nullable in this schema release. Existing Broker records cannot safely default to `ADMIN_CREATED` or `SELF_REGISTERED` without data classification. It must be backfilled and made required in a later controlled data migration after historical provenance is reviewed.

## 2. New Models

### BrokerClaim
Stores the current claim process for an admin-created profile. It has a unique Broker relation, current status, start/completion timestamps, optional completion user, invitations, and events. Self-registered profiles do not need a BrokerClaim row.

### BrokerClaimInvitation
Stores each issued invitation. It contains the BrokerClaim relation, unique `tokenHash`, invitation status, expiration, used/revoked timestamps, and the creating admin User relation. Plaintext tokens are not represented in the schema.

### BrokerClaimEvent
Stores append-only claim lifecycle history with claim/invitation references, optional actor, event type, optional JSON metadata, and occurrence time.

## 3. New Enums

- `BrokerCreationSource`: `ADMIN_CREATED`, `SELF_REGISTERED`
- `BrokerClaimStatus`: `INVITED`, `IN_PROGRESS`, `COMPLETED`, `EXPIRED`, `REVOKED`, `FAILED`
- `BrokerClaimInvitationStatus`: `ACTIVE`, `USED`, `EXPIRED`, `REVOKED`
- `BrokerClaimEventType`: `GENERATED`, `SENT`, `OPENED`, `STARTED`, `EMAIL_SUBMITTED`, `VERIFICATION_PENDING`, `COMPLETED`, `EXPIRED`, `REVOKED`, `FAILED`

The conceptual `NOT_REQUIRED` state remains derived for self-registered profiles; no fake claim row or enum value was added for it.

## 4. Modified Fields

| Model | Field | Before | After |
|---|---|---|---|
| Broker | `userId` | `String @unique` | `String? @unique` |
| Broker | `user` | Required User relation | Optional User relation |
| Broker | `creationSource` | Absent | Nullable `BrokerCreationSource` |
| User | `emailVerificationTokenExpiresAt` | Absent | Nullable `DateTime` |

No ownership boolean, claim boolean, subscription ownership field, plaintext token, duplicate password field, or second Broker profile model was added.

## 5. Modified Relations

- `Broker.user` is optional and explicitly `onDelete: NoAction`.
- `Broker.claim` is an optional one-to-one relation to `BrokerClaim`.
- `BrokerClaim.broker` is required and unique on the claim side.
- `BrokerClaim.completedBy` is an optional User relation named `ClaimCompletedBy`.
- `BrokerClaimInvitation.claim` is required; `createdBy` is a required User relation named `ClaimInvitationsCreated`.
- `BrokerClaimEvent.claim` is required; `invitation` and `actor` are optional, with actor relation `ClaimEventActor`.
- User received `completedClaims`, `createdClaimInvitations`, and `claimEvents` back-relations.
- Existing User, BrokerSubscription, BrokerBank, Review, ContactMessage, Account, and unrelated relations were preserved.

## 6. New Indexes

| Index | Purpose |
|---|---|
| `Broker.creationSource` | Admin/source filtering and migration validation. |
| `BrokerClaim(status, updatedAt)` | Claim queue/status operations. |
| `BrokerClaimInvitation(brokerClaimId, status)` | Find invitations for a claim and active/terminal state. |
| `BrokerClaimInvitation(status, expiresAt)` | Expiration/reconciliation work. |
| `BrokerClaimEvent(brokerClaimId, occurredAt)` | Ordered claim history. |
| `BrokerClaimEvent(invitationId)` | Invitation-specific history lookup. |
| `BrokerClaimEvent(eventType, occurredAt)` | Operational/event reporting. |

Existing indexes were not removed or changed. `tokenHash @unique`, `BrokerClaim.brokerId @unique`, `Broker.userId @unique`, `Broker.profileSlug @unique`, and `BrokerSubscription.brokerId @unique` preserve the approved uniqueness model.

## 7. New Unique Constraints

- `BrokerClaim.brokerId @unique`: one current claim process per Broker.
- `BrokerClaimInvitation.tokenHash @unique`: no duplicate secure token digest.
- Existing `Broker.userId @unique`: no two Brokers can point to one User, and no two Users can own one Broker through this relation.
- Existing `BrokerSubscription.brokerId @unique`: one current entitlement per Broker.
- Existing `Broker.profileSlug @unique`, User email/phone uniqueness, and OAuth provider uniqueness remain.

The behavior of a nullable unique MongoDB index with multiple null `userId` values remains an implementation verification item. Prisma validation does not prove the deployed MongoDB index is suitable for multiple unowned profiles; this must be confirmed before creating more than one unowned Broker.

## 8. Cascade Behavior

User -> Broker is explicitly `NoAction`, not Cascade. A User deletion that still has a Broker relation should be blocked or handled by a future explicit offboarding workflow; the Broker profile will not be accidentally deleted. Existing `Account.user` Cascade remains unchanged and only removes OAuth Account rows with the User. Claim and business records use `NoAction` relations in the new models so historical claim records are not silently deleted through these relations.

Subscription expiration is not a database cascade. It remains a future application/webhook state update to FREE.

## 9. Existing Data Compatibility

- Existing non-null `Broker.userId` values remain valid and are not rewritten.
- Existing Broker IDs, slugs, profile data, reviews, contacts, counters, banks, and subscriptions remain unchanged.
- Existing Broker documents may have no `creationSource`; the field is nullable specifically to avoid false historical classification.
- Existing User documents may have no `emailVerificationTokenExpiresAt`; the field is nullable and requires no destructive backfill.
- No claim rows or token rows were created for existing data.
- Existing seeded records still satisfy required user ownership; seed changes were intentionally not made in this phase.

## 10. Migration Generated

**NOT REQUIRED / NOT GENERATED.** The project uses a MongoDB Prisma datasource and has no `prisma/migrations` directory or migration workflow in `package.json`. No migration command, database push, reset, or data mutation was run. A later controlled data/index migration remains required before production use of multiple unowned profiles and before making `creationSource` required.

## 11. Validation Result

`npx prisma format`: **PASS**

`npx prisma validate`: **PASS**

The validator reported: `The schema at prisma/schema.prisma is valid`.

## 12. Generated Client Result

`npx prisma generate`: **PASS**

Prisma Client `v6.19.3` was generated successfully into `node_modules/@prisma/client`. No application source was changed to accommodate the resulting TypeScript nullability errors.

## 13. Application Files Now Requiring Updates

These files were intentionally not modified. They contain direct or indirect assumptions that every Broker has a User, or that the existing subscription/status model controls behavior:

- `app/api/brokers/route.ts`
- `app/api/brokers/featured/route.ts`
- `app/api/brokers/[id]/route.ts`
- `app/api/company/[slug]/route.ts`
- `app/(public)/brokers/[slug]/page.tsx`
- `app/(public)/brokers/page.tsx`
- `app/api/contacts/send/route.ts`
- `app/api/contacts/[id]/read/route.ts`
- `app/api/contacts/[id]/responded/route.ts`
- `app/api/contacts/my/route.ts`
- `app/api/brokers/[id]/contacts/route.ts`
- `app/api/brokers/me/route.ts`
- `app/api/brokers/me/dashboard-stats/route.ts`
- `app/api/auth/register/broker/route.ts`
- `app/api/auth/verify-email/route.ts`
- `app/api/auth/resend-verification/route.ts`
- `app/api/subscription/checkout/route.ts`
- `app/api/subscription/upgrade/route.ts`
- `app/api/subscription/cancel/route..ts`
- `app/api/subscription/usage/route.ts`
- `lib/auth.config.ts`
- `lib/currentUser.ts`
- `lib/subscription.ts`
- `actions/email.action.ts`
- `app/broker/dashboard/page.tsx`
- `app/broker/company/page.tsx`
- `app/broker/company/edit/page.tsx`
- `prisma/seed.ts`
- `prisma/seed/seed-brokers.ts`

Additional UI/type consumers include `components/brokers/FeaturedBrokerRowCard.tsx`, `components/sections/broker/BrokerDetailClient.tsx`, `hooks/useCurrentUser.ts`, and broker dashboard/profile components. These were not changed.

## 14. Risks and Unresolved Issues

1. The nullable unique `Broker.userId` index must be verified in the actual MongoDB deployment for multiple null owners.
2. `creationSource` is nullable until historical data is classified; admin creation and self-registration application code must explicitly write it later.
3. Prisma Client nullability will cause expected application compile/type failures until Phase 3 query updates are made.
4. Existing public queries dereference `broker.user` and currently exclude/null-fail unowned profiles.
5. Existing email actions cannot notify an unowned profile and need deferred-owner behavior later.
6. Current subscription logic derives verification/visibility from paid plans and must be decoupled later.
7. The schema does not enforce “only ADMIN_CREATED profiles may have BrokerClaim”; service validation and, if needed, data validation must enforce that invariant.
8. The schema does not enforce only one ACTIVE invitation per claim; application transaction policy or a verified MongoDB partial index is required.
9. No generic `AuditEvent` model was added because claim events are required now and generic audit scope was optional in the approved review.
10. No database data was inspected or mutated in this phase; production inventory and index verification remain migration prerequisites.

## 15. Next Implementation Phase

Phase 3 should update broker registration and claim infrastructure against this schema. It must first resolve nullable owner queries, write `creationSource`, create/find FREE entitlements, implement atomic claim completion, and add the publication predicate before enabling admin-created unowned profiles.
