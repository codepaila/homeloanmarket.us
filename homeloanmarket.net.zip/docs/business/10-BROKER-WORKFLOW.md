# Broker Workflow

Self-registered broker verifies email and creates a new profile. An invited company opens a claim, verifies a chosen account email, sets a password or uses an existing authenticated account, and receives ownership of the existing profile. The owner can edit allowed content, manage banks and profile visibility within policy, read/respond to contacts, view permitted analytics, and purchase/cancel subscriptions. Owner cannot alter verification, claim state, suspension, or other administrative fields.
