# Phase 13.1 Seed Engine Audit

## Scope

This phase audited and hardened the seed engine only. The active seed currently contains the deterministic demo fixtures already defined by the Phase 13 contract. No production database, schema, migration, ownership rule, subscription rule, Advertisement behavior, SEO behavior, or application API was changed.

## Authoritative Entry Point

`package.json` runs `npx tsx prisma/seed/index.ts`. The entrypoint now imports exactly one database seed orchestrator: `prisma/seed/seed-demo.ts`.

Active seed files:

- `prisma/seed/index.ts`
- `prisma/seed/seed-demo.ts`
- `prisma/seed/helpers.ts`
- `prisma/seed/config.ts`
- `prisma/seed/download-images.ts` (optional local image preparation; not part of database execution)

The former per-model random modules were removed from the active seed tree because they were no longer imported and contained duplicate-producing logic. No active application behavior depended on them.

## Seed Inventory

| Model | Seed file | Creation method | Logical key | Duplicate risk after hardening | Dependencies |
|---|---|---|---|---|---|
| User | `seed-demo.ts`, `helpers.ts` | `findUnique` by email, update/create | fixed email | None for demo users | none |
| Broker | `seed-demo.ts` | `upsert` | profile slug | None | User for owned profiles |
| BrokerSubscription | `seed-demo.ts` | `upsert` | brokerId | None; one per Broker | Broker |
| BrokerClaim | none | not seeded | N/A | Not applicable | No claim fixture required |
| BrokerClaimInvitation | none | not seeded | N/A | Not applicable; no raw tokens | Claim workflow |
| BrokerClaimEvent | none | not seeded | N/A | Not applicable | Claim workflow |
| BrokerBank | `seed-demo.ts` | scoped delete/recreate for demo Broker | brokerId + fixed bank names | Bounded to demo Brokers | Broker |
| Bank | `seed-demo.ts` | `upsert` by unique name | bank name | None | none |
| LoanProduct | `seed-demo.ts` | `findFirst` by bankId/name, update/create | bankId + product name | None in isolated/demo scope | Bank |
| Property | `seed-demo.ts` | `upsert` | stable slug | None | local image paths |
| BlogPost | `seed-demo.ts` | `upsert` | stable slug | None | local cover paths |
| FAQ | `seed-demo.ts` | `findFirst` by fixed question, update/create | question | None for fixed demo records | none |
| Testimonial | `seed-demo.ts` | `findFirst` by fixed name/comment, update/create | name + comment | None for fixed demo records | local photo paths |
| Review | `seed-demo.ts` | `findFirst` by brokerId/comment, update/create | brokerId + fixed comment | None | Broker, demo User |
| ContactMessage | `seed-demo.ts` | `findFirst` by brokerId/email/subject, update/create | brokerId + email + subject | None | Broker, demo User |
| MediaFolder | `seed-demo.ts` | `upsert` | unique path under `phase13/` | None | none |
| MediaAsset | `seed-demo.ts` | `findFirst` by folderId/fileName, update/create | folderId + fileName | None | MediaFolder, local file |
| Advertisement | `seed-demo.ts` | `upsert` | unique slug | None | admin, MediaAsset |
| AdEvent | `seed-demo.ts` | `findFirst` by ad/type/page/location/time, create if absent | deterministic event fixture tuple | None for seeded events | Advertisement |
| Setting | `seed-demo.ts` | `upsert` | unique key | None | none |
| Notification | none | not seeded | N/A | Not applicable | authenticated User |
| SupportTicket/SupportMessage | none | not seeded | N/A | Not applicable | authenticated User |
| Account | none | not seeded | N/A | OAuth tokens forbidden | User |
| Message | none | not seeded | N/A | Private messaging not required | User |
| StripeWebhookEvent | none | not seeded | N/A | Provider events forbidden | external Stripe |

There is no `Lead` model in the schema. `ContactMessage` is the existing lead/contact record and is seeded through its existing model only.

## Duplicate Risks Found and Fixed

- Removed old random user, Broker, bank, property, blog, FAQ, testimonial, media, Advertisement, contact, review, settings, analytics, and admin modules from the execution tree.
- Removed uncontrolled `Math.random()`, random suffixes, random timestamps, and random helper exports from the active seed helpers.
- Replaced append-only FAQ, testimonial, review, contact, loan product, Advertisement, media, and event creation with deterministic reconciliation.
- Replaced random Advertisement slugs, priorities, dates, and creative selection with fixed fixtures.
- Added database safety refusal for non-local or non-demo MongoDB database names.
- Added local file existence and Sharp metadata checks before MediaAsset creation.

## Validation Defect Corrected

The first isolated execution after implementation failed because the review/contact code looked up `buyer-1` while the deterministic fixture keys were `buyer-one`, `buyer-two`, and so on. The failure was reproducible at review creation, corrected to use the explicit buyer key list, and the seed then completed successfully. Subsequent runs completed with identical results.

## Business Rule Audit

- FREE remains the baseline subscription.
- Active FEATURED is the only paid entitlement created.
- Expired/cancelled FEATURED fixtures contain no provider IDs and resolve through existing entitlement logic; the current schema represents both with inactive/expired fields and has no separate cancellation enum.
- PREMIUM count is zero.
- Owned Brokers use `Broker.userId`; the public and negative admin-created fixtures use `userId=null` and `ADMIN_CREATED` source, avoiding invalid repeated ownership of one User.
- Subscription does not set ownership, verification, or publication.
- `isPublicBroker()` is used for public demo review/contact selection and audit counts.
- Advertisement remains admin-created and uses the existing 16-placement architecture.
- No claim tokens, OAuth records, Stripe credentials, payment methods, or production credentials are seeded.

## Validation Artifact Limitation

The production build completes its TypeScript phase. A standalone post-build `tsc --noEmit` can fail because generated `.next/types/validator.ts` imports missing `.next/types/routes.js`; this is a known generated-artifact issue outside the seed files and was not modified.

## Database Safety

`assertDemoDatabase()` requires a local host and a database name containing `demo` or `phase13`. The certified isolated target was `mongodb://localhost:27017/homeloanmarket-phase13-1`. No reset, migration, drop, or production target was used.
