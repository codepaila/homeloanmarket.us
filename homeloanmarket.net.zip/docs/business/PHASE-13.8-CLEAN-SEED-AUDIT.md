# Phase 13.8 Clean Seed Audit

## Old Dataset Problems

The previous seed (Phase 13.5/13.7) produced a large, demo-looking dataset:

- 82 users, 26 brokers, 68 reviews, 41 contacts, 20+ advertisements, 22,000+ AdEvents.
- Public-facing names prefixed with "Demo", emails at `@example.test`, `[Demo]` review/contact text, 20,500 aggregate profile views.
- Broker images pointed to small local placeholder WebP files with no consistent fallback.

## Cleanup Strategy

`prisma/seed/seed-demo.ts` now begins with `cleanupSeedOwnedData()` which runs only behind the existing `assertDemoDatabase()` local/demo guard. It removes seed-owned records from previous datasets:

- Users with `demo.*` emails or `@example.test` emails.
- Brokers with `demo-` slugs (plus their reviews, contacts, banks, subscriptions, claims, invitations).
- Advertisements with `demo-` slugs or `internalNotes = 'SEED_OWNED'` (plus their AdEvents).
- Media assets/folders tagged `seed-owned` or `phase13`.
- Obsolete blog slugs and `draft-`/`demo-` slugs.
- `[Demo]`/`[Seed]` testimonials and FAQs.

Subscriptions are recreated only for the six intended brokers (delete-then-recreate), so stale subscription rows cannot persist.

## Final Dataset (isolated `homeloanmarket-phase13-5b`)

- Users: 18 (1 Admin + 7 Broker owners + 10 regular users)
- Brokers: 8 (owned 7, unowned 1, public eligible 7)
- Subscriptions: 6 active (3 FREE + 3 FEATURED, PREMIUM 0)
- Reviews: 14
- Contacts: 6
- Claims: 2 (1 INVITED pending, 1 COMPLETED)
- Advertisements: 7 (7 placements, 1 scheduled)
- Media: 3 folders, 9 assets
- Blogs: 4 published, 1 draft
- Ad events: 257 (235 impressions, 22 clicks)
- Profile views: 9,050 (each broker 50–2,500)
- Duplicates: 0, Orphans: 0

## Broker List

1. Sarah Mitchell — Pacific Crest Home Lending — San Diego, CA — FEATURED — owned verified
2. Michael Rodriguez — Lone Star Mortgage Group — Austin, TX — FEATURED — owned verified
3. Emily Carter — Blue Ridge Home Finance — Charlotte, NC — FREE — owned pending verification
4. David Thompson — Evergreen Mortgage Advisors — Seattle, WA — FEATURED — owned verified
5. Jessica Williams — Sunrise Home Lending — Miami, FL — FREE — owned verified
6. Ryan Anderson — Liberty Home Finance — Denver, CO — FREE — owned verified
7. Amanda Brooks — Summit Residential Lending — Dallas, TX — FREE — owned verified (COMPLETED claim)
8. Daniel Martinez — Coastal Mortgage Partners — New York City, NY — FREE — unowned (INVITED claim)

## US Locations

San Diego (CA), Austin (TX), Charlotte (NC), Seattle (WA), Miami (FL), Denver (CO), Dallas (TX), New York City (NY).

## Image / Media Strategy

- Broker logos and cover images use stable `images.unsplash.com` URLs (fixed photo IDs, not `source.unsplash.com`).
- `next.config.ts` already allows `images.unsplash.com` remote patterns.
- `components/brokers/BrokerAvatar.tsx` renders `next/image` with an initials fallback on error; wired into FeaturedBrokerRowCard, BrokerGridCard, BrokerListCard, and BrokerDetailClient.
- Media library assets reference the same stable Unsplash URLs (3 ad creatives, 3 portraits, 3 general/blog).
- Advertisements use `bannerUrl`/desktopMediaId pointing to those creatives.

## Claim Scenarios

- Pending: Coastal Mortgage Partners (unowned, INVITED claim + ACTIVE hashed invitation).
- Completed: Summit Residential Lending (owned via COMPLETED claim, USED invitation).

## Development Login Accounts

- Admin: `admin@homeloanmarket.com` / `Admin@123456`
- Broker: `sarah.mitchell@example.com` / `LocalDev!2026`
- User: `hannah.moore@example.com` / `LocalDev!2026`

All synthetic accounts use bcryptjs hashes (existing mechanism). Public-facing display names are realistic; development emails use the reserved `example.com` domain.
