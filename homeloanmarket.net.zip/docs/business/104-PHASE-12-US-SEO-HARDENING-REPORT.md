# Phase 12 US SEO Hardening Report

## Implemented Changes

- Added root `metadataBase`, US-oriented title/description, canonical, Open Graph, and Twitter metadata.
- Added `app/robots.ts` with public crawl allowance, private/API exclusions, and sitemap reference.
- Added `app/sitemap.ts` containing static public routes and only eligible public Broker profiles.
- Added dynamic Broker profile metadata with canonical, Open Graph, Twitter-compatible route metadata, and noindex handling for ineligible profiles.
- Added safe `LocalBusiness` JSON-LD using public Broker name, description, location, URL, and factual aggregate review values.
- Added listing and guides metadata.
- Added explicit noindex metadata for admin, broker dashboard, auth, claim, and setup route groups.
- Centralized canonical URL normalization and JSON-LD script escaping in `lib/seo.ts`.
- Split admin and broker client layouts from server metadata layouts without changing rendered UI behavior.
- Added focused tests for canonicalization, eligibility, robots, JSON-LD safety, and public profile policy.

## Public Data Safety

SEO queries select only fields needed for public metadata and eligibility. They do not expose user IDs, account credentials, ownership state, subscription data, private contact fields, or authentication fields. Broker phone and email are intentionally not added to JSON-LD.

## Routes

Indexable routes include the public home, listing, broker profiles, informational pages, guides, calculator, and legal pages. Admin, broker dashboard, auth, claim, setup, API, and internal CMS routes are excluded from crawling and/or emit noindex metadata. Sitemap entries never include query variants.

## Validation

- Focused SEO/public profile tests: passed.
- TypeScript: passed.
- Targeted ESLint: passed.
- Production build: passed.

## Limitations

- Browser/Search Console validation is unavailable in this environment.
- Full repository lint contains pre-existing unrelated errors.
- Live database counts and external crawler behavior require the deployment environment.
