# PREMIUM Data Reconciliation Report

## 1. Original Count

Before migration, the configured production database contained:

| Plan | Total | Active |
|---|---:|---:|
| FREE | 14 | 14 |
| FEATURED | 10 | 10 |
| PREMIUM | 13 | 13 |

## 2. Record-by-Record Classification

All 13 active PREMIUM records were individually inspected. Every record had:

- `stripeCustomerId = null`;
- `stripeSubId = null`;
- no provider Product ID or Price ID available;
- local legacy seeded PREMIUM designation;
- existing Broker identity/ownership/profile data independent of the subscription.

Classification for all 13 records: **VERIFIED_FREE**.

No record was classified as VERIFIED_FEATURED because no record had verifiable paid Stripe entitlement. No record was LEGACY_UNRESOLVED because the source data and absence of provider identifiers established the legacy seeded/non-provider-backed origin sufficiently for the approved fallback treatment.

## 3. Evidence

The production seed implementation historically randomized `SubscriptionPlan.PREMIUM` into BrokerSubscription records without creating Stripe customer/subscription IDs. The inspected production records match that structure. BrokerStatus/featuredRank were treated as legacy projections, not as paid entitlement proof.

## 4. Stripe Reconciliation

No affected record had Stripe identifiers, so no Stripe API lookup or Stripe mutation was required. No Stripe data was modified.

## 5. Migration Mapping

```text
PREMIUM -> FREE
```

Applied to all 13 individually classified records.

No Broker fields were changed. In particular, the migration did not modify:

- Broker ID;
- profile slug;
- userId/ownership;
- verificationStatus;
- isVisible;
- brokerStatus;
- featuredRank;
- profile data;
- reviews;
- leads;
- claim records/history;
- Stripe IDs.

## 6. Migration Tool

Added/used:

```bash
npm run db:reconcile-subscription-plans
npm run db:reconcile-subscription-plans -- --apply
```

Default mode is dry-run. Apply mode:

- refuses records with Stripe identifiers;
- updates only `BrokerSubscription.plan`;
- uses one Prisma transaction;
- is safe to rerun;
- reports record-by-record mapping;
- supports `--broker=<id>` targeting.

Post-migration dry-run returned zero PREMIUM records.

## 7. Post-Migration Invariants

Production now contains:

| Plan | Total | Active |
|---|---:|---:|
| FREE | 27 | 27 |
| FEATURED | 10 | 10 |
| PREMIUM | 0 | 0 |

Verified:

- no duplicate BrokerSubscription records;
- BrokerSubscription.brokerId uniqueness intact;
- `brokers_userId_non_null_unique` unchanged;
- existing ownership counts unchanged;
- no claim/verification/visibility/profile fields changed;
- FREE entitlement resolver returns FREE for migrated records;
- no active PREMIUM authoritative runtime plan remains.

## 8. Tests

- Phase 8.1 plan validation/effective entitlement tests: passed.
- Isolated MongoDB subscription integration tests: passed.
- Existing policy/registration/admin/claim regression tests: passed in the available test suites.
- Migration dry-run after apply: zero records.

Post-migration production distribution:

```text
FREE      27 total / 27 active
FEATURED  10 total / 10 active
PREMIUM    0 total / 0 active
```

## 9. Rollback Strategy

The affected subscription IDs and original plan values were captured in the dry-run output before apply. If an approved rollback is required, a controlled operator-only inverse script may restore only those specific subscription IDs after product/data-owner approval. No automatic rollback is run by default and no Stripe data is changed.

## 10. Remaining Technical Debt

- Prisma enum retains PREMIUM for historical compatibility; it is not an authoritative active plan.
- Legacy comments/UI compatibility names remain in some non-authoritative locations and should be cleaned separately.
- Full repository lint has unrelated legacy failures.
- Prisma still retains the historical PREMIUM enum value for compatibility; runtime plan configuration accepts only FREE and FEATURED.
- Some historical comments/marketing labels contain the word premium but are not authoritative plan logic.
- Live Stripe replay and authenticated billing HTTP certification remain environment-dependent.

## 11. Final Decision

**PHASE 8.2 STATUS: PASS**

**PHASE 8.3 READINESS: READY**, subject to the existing Phase 8.1 provider/integration limitations documented in the certification report.
