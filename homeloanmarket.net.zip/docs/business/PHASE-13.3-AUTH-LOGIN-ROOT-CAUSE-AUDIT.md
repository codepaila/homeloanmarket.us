# Phase 13.3 Auth Login Root Cause Audit

## Scope

This audit traced the complete Admin credential login path from the sign-in form through the server action, NextAuth Credentials provider, password verification, JWT/session callbacks, redirect callback, and root proxy. No schema, migration, production data, ownership, claims, subscriptions, Advertisement, SEO, or public Broker behavior was changed.

## Layer Trace

| Layer | Expected | Actual | Failure | Evidence |
|---|---|---|---|---|
| Sign-in page | Submit calls the canonical server action | Called `LoginWithCredential()` imperatively inside try/catch | Successful Auth.js redirect was caught and masked as login failure | Page source |
| Server action | Auth.js `signIn(..., redirectTo)` | Same | Valid credentials redirected but client catch replaced navigation | `actions/auth.action.ts` |
| CredentialsProvider.authorize() | Return user for valid Admin | Returned Admin user after seed repair | Stale existing Admin hash rejected | Direct provider test |
| Prisma User lookup | Admin exists | Exists, active, verified, role ADMIN | None | Isolated DB check |
| Password verification | bcrypt.compare() | bcryptjs compare succeeds after hash repair | Stale hash preserved by seed reconciliation | `lib/aes.ts` + seed test |
| Invalid credentials | CredentialsSignin | Generic `Configuration` error before fix | authorize() threw instead of returning null | HTTP callback evidence |
| JWT/session callbacks | Build minimal token | Minimal projection populated | None | Source |
| Redirect callback | Same-origin only | Sanitized origin enforcement | None | `lib/auth-redirect.ts` |
| Proxy | Consume token, enforce role | Registered at root, role checks active | None after root move | Build `ƒ Proxy` + HTTP |
| Final `/admin/ads` | 200/302 for Admin | 302 for seeded Admin after fix | None | HTTP callback evidence |

## Root Cause (exact)

1. Seed reconciliation preserved stale existing password hashes. A pre-existing Admin/demo account with an incompatible bcrypt hash stayed unauthenticatable. This was fixed in Phase 13.3A by rehashing stale demo hashes with bcryptjs.
2. The sign-in page called the credentials server action inside a client `try/catch`. Successful Auth.js server-action redirects are thrown as control flow, so the catch converted them into "Unable to sign in. Please check your email and password."
3. `authorize()` threw generic `Error` objects for rejected credentials. Auth.js v5 maps those to `Configuration` instead of `CredentialsSignin`, producing a wrong error and an extra error page hop.

## Verified Demo Admin Account

Isolated database only, no secrets exposed:

- Email exists.
- Role `ADMIN`.
- Account active.
- Email verified.
- Password hash present and bcrypt-compatible after seed reconciliation.
- Duplicate Admin count: 0.

## Environment

- Seed target: `homeloanmarket-phase13-1` local MongoDB.
- Application validation target: same database.
- `NEXTAUTH_URL`/`AUTH_URL` set to the running local origin for HTTP validation; no production URL was used.

## Callback and Authorization Boundary

- Same-origin internal paths accepted.
- External/protocol-relative/dangerous/malformed/login-loop values rejected.
- `/admin/*` only for ADMIN, `/broker/*` only for BROKER.
- Public `/brokers` is not treated as protected `/broker`.
- Proxy consumes the authenticated token and does not trust client roles.
