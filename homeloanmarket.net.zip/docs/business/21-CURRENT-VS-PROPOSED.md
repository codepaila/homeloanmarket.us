# Current System vs Proposed Model

| Area | Current verified system | Proposed model |
|---|---|---|
| Broker/user relation | Required unique `Broker.userId` | Optional for unowned admin profiles; unique current owner. |
| Creation source | Not explicit; seeded/self-created records | Explicit `ADMIN_CREATED` or `SELF_REGISTERED`. |
| Direct registration | User creation and verification route exists; profile setup is separate | Dedicated broker flow creates user/profile/FREE transactionally and owns immediately. |
| Admin profiles | No unowned profile support | Admin creates unowned profile and may publish/claim it. |
| Ownership | Implied by required user relation | Explicit independent ownership state. |
| Claiming | No claim model | Only admin-created unowned profiles use invitation claim lifecycle. |
| Self-registration claim | Not defined | Explicitly no claim; `NOT_REQUIRED`. |
| Free access | Free plan exists but feature coupling is inconsistent | FREE automatically follows both valid broker onboarding paths; no payment required. |
| Paid plans | Stripe and plan feature mutation exist | Independent optional upgrade; paid expiry returns to FREE. |
| Visibility | Requires visible, verified, active user | Central policy supports eligible unowned profiles and avoids null-user assumptions. |
| Verification | Sometimes subscription-derived | Independent trust workflow. |
| Auth | NextAuth JWT, Credentials/Google, bcrypt, verification/reset | Reuse for both paths; no second auth system. |
| Admin | Ads/media administration; no broker claim workflow found | Profile, registration oversight, invitation, ownership, status, and audit workflow. |
| Audit | No dedicated claim/audit model found | Immutable business events for registration, ownership, claims, status, billing. |

## Reuse
NextAuth/User, bcrypt, email provider, rate limiting, Stripe webhook foundation, Broker/Profile/Review/Contact entities, slugs, and dashboard patterns.

## Must Change/Add Later
Nullable ownership, creation-source/ownership/claim representation, transactional direct registration, FREE entitlement guarantees, claim models, audit, null-safe queries, independent commercial policy, and tests.

## Do Not Change Without Requirement
MongoDB provider, existing profile IDs/slugs, reviews/leads/history, shared authentication, Stripe provider, public URL conventions, or unrelated advertisement/property systems.
