# Broker Registration Implementation Report

## Status

Phase 4 implements direct website broker self-registration only. Admin-created profile creation and all claim behavior remain unimplemented.

## Endpoint

`POST /api/auth/register/broker`

The existing endpoint was extended rather than creating a second authentication system.

## Request Validation

The endpoint accepts only account/profile registration data:

- name
- optional company name
- email
- phone
- password
- description
- office address
- city
- state
- postal code
- terms/marketing and existing CAPTCHA fields

Email is normalized to lowercase. Phone formatting is normalized for validation. Required Broker fields are validated before persistence. Client-supplied role, user ID, ownership, creation source, broker status, verification status, subscription plan, active flags, Stripe IDs, and claim fields are ignored and never trusted.

The existing broker registration rate limiter and CAPTCHA protection remain active.

## User Creation

The transaction creates a User with:

- `role=BROKER`
- normalized email/phone
- bcrypt password hash through the existing `hashPassword` utility
- `emailVerified=false`
- `isActive=true`

Duplicate email/phone detection occurs inside the transaction and returns a generic 409 response without revealing whether email or phone caused the conflict.

## Broker Creation

The same transaction creates a Broker with:

- `userId=createdUser.id`
- `creationSource=SELF_REGISTERED`
- `verificationStatus=UNVERIFIED`
- `isVisible=true`
- existing compatible `brokerStatus=FREE` default
- submitted required profile fields
- unique deterministic slug derived from company name or display name

No existing Broker is claimed or reused. No BrokerClaim, BrokerClaimInvitation, or claim token is created.

## FREE Subscription Creation

The Broker is created with a nested `BrokerSubscription` in the same transaction:

- `plan=FREE`
- `isActive=true`
- `startDate=now`
- `endDate=null`
- no Stripe customer or subscription

No payment is required.

## Transaction Behavior

User, Broker, and BrokerSubscription are created through one Prisma MongoDB interactive transaction. If duplicate detection, User creation, Broker creation, or nested subscription creation fails, the transaction is rolled back. Email delivery occurs after commit and cannot invalidate committed business state.

If email delivery fails after commit, the account/profile/FREE entitlement remain and the existing resend-verification endpoint provides recovery.

## Email Verification

The existing email action now persists:

- hashed `User.emailVerificationToken`
- `User.emailVerificationTokenExpiresAt`

The verification endpoint validates the persisted expiry, clears both token fields on expiration or successful consumption, and prevents reuse. Email verification changes only `User.emailVerified`; it does not set `Broker.verificationStatus=VERIFIED`.

Credentials login now requires an active account and verified email for BROKER users. Google behavior remains unchanged.

## Dashboard Behavior

The existing broker dashboard remains the destination after verification/login. FREE entitlement is treated as valid access. Paid analytics remain separate from basic dashboard access. No PREMIUM or FEATURED requirement was added.

## Registration UI

The existing `/auth/signup` page was extended with the required Broker profile fields and now communicates:

- FREE broker access is included;
- no payment is required;
- email verification is required before dashboard login.

The success redirect goes to `/auth/verify-email?email=...`, and the existing verification page provides resend and success states.

## Security Controls

- Existing IP rate limiting and CAPTCHA retained.
- Passwords use bcrypt hashing only.
- Server forces BROKER role, SELF_REGISTERED source, UNVERIFIED Broker state, and FREE entitlement.
- User/Broker/subscription ownership values are generated server-side.
- Duplicate account creation is rejected inside the transaction.
- Profile slug collisions are suffixed and checked against the database.
- No claim artifacts or Stripe identifiers are accepted from the client.

## Tests

`tests/phase-3b-broker-policy.test.ts` now also covers registration support utilities:

- server-controlled self-registration defaults;
- required profile input normalization and validation;
- URL-safe deterministic slug generation;
- FREE versus paid entitlement policy;
- ownership derivation;
- public owned/unowned visibility;
- email fallback combinations.

Result: **9 passed, 0 failed** using `npx tsx --test tests/phase-3b-broker-policy.test.ts`.

The repository does not have a configured database integration test runner. Transaction rollback, duplicate database constraints, actual bcrypt persistence, endpoint HTTP execution, and token replay require a later test harness with a MongoDB test replica set.

## Validation

- `npx prisma validate`: **PASS**
- `npx prisma generate`: **PASS**
- focused tests: **PASS**
- `npx tsc --noEmit`: **FAIL due to pre-existing repository issues only**

Remaining TypeScript errors are six missing `.next/dev/types/validator.ts` route modules and the existing `prisma.config.ts` `seed` property type error.

## Remaining Issues

- Registration UI still uses the existing CAPTCHA design, which is not a server-secret challenge.
- Existing verification resend is still an in-memory/email-rate-limit path and should receive broader abuse hardening later.
- Existing email templates and registration notification behavior remain in place.
- Database-backed rollback and endpoint integration tests remain outstanding.
- Profile trust verification remains an admin/future workflow; email verification does not confer Broker verification.
- Claiming and admin-created profile support remain entirely deferred.

## Next Phase Boundary

The next phase may implement admin-created Broker profiles and claim invitations. It must not reinterpret this self-registered Broker as a claim or create a claim row for it.
