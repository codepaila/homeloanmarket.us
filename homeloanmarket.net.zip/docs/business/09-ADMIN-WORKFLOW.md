# Admin Workflow

Admin creates/edits profile -> chooses draft/published visibility -> records verification evidence -> generates invitation -> monitors delivery and claim state -> resends, supersedes, or revokes -> reviews claim history -> assists only with recorded evidence -> manages plan or suspension -> audits every mutation. Admin may view owner and private claim metadata subject to least privilege. Unpublish, suspend, disable, unverify, revoke, and ownership assistance require reason fields. Admin cannot silently replace ownership; transfer requires a separate reviewed workflow.
