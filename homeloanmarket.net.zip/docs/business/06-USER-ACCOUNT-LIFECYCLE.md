# User Account and Activation Lifecycle

## Account States
`PENDING_EMAIL -> ACTIVE -> DISABLED`; credential reset is a parallel `PASSWORD_RESET_PENDING -> ACTIVE` process. Google and Credentials use the existing NextAuth model. No second authentication system is introduced.

## Direct Broker Registration
`FORM_SUBMISSION -> USER_CREATED + EMAIL_PENDING -> BROKER_CREATED/LINKED + FREE_CREATED -> EMAIL_VERIFIED -> ACTIVE -> DASHBOARD_AVAILABLE`. The user and broker association is created immediately as part of the registration transaction. Account login/dashboard access is gated until email verification and activation. The broker does not need admin claim approval for basic account creation. Public publication still follows the existing `isVisible + VERIFIED + active user` policy until the target publication policy is adopted.

## Admin Claim Registration
`VALID_INVITATION -> EMAIL_SUBMITTED -> existing user continuation or new user -> EMAIL_VERIFIED/reauthenticated -> PASSWORD_SETUP -> atomic profile attachment -> ACTIVE owner dashboard`. This process does not create a new broker profile.

## Public User Distinction
A normal public user may browse, submit a lead, and register as a normal user if supported. Only the explicit broker-registration flow creates a broker profile; only a valid admin invitation can start a claim flow.

Dashboard access requires active account, verified email under policy, broker capability, and an owned profile. Account disablement blocks access but does not delete profile history or automatically detach ownership.
