# Frontend Requirements (Phase 4.3)

## Overview

This document specifies the frontend components, API integration, and UI requirements for the **Admin Dashboard** and **Media Library**. It serves as the implementation guide for Phase 4.3 — the UI that consumes the Phase 4.2 backend APIs.

## Components

### Component: Media Library

**Route**: `/app/admin/media/`

**Purpose**: Lists all media assets with search, filter, and management actions.

**Required API Calls**:

| Action | API | Method |
|---|---|---|
| Load assets | `GET /api/admin/media?page=1&limit=50&search=&folderId=` | GET |
| Upload | `POST /api/admin/media` (multipart) | POST |
| Delete | `DELETE /api/admin/media/:id` | DELETE |
| Update metadata | `PUT /api/admin/media/:id` | PUT |
| List folders | `GET /api/admin/media/folders` | GET |
| Create folder | `POST /api/admin/media/folders` | POST |

**Data Structure (from API)**:
```typescript
interface MediaAsset {
  id: string
  fileName: string
  originalName: string
  fileUrl: string                  // e.g. "/uploads/media/abc-123.webp"
  thumbnailUrl: string             // e.g. "/uploads/media/abc-123@200x200.webp"
  mimeType: string
  extension: string
  fileSize: number
  width: number | null
  height: number | null
  altText: string | null
  title: string | null
  tags: string[]
  folderId: string | null
  uploaderId: string
  isDeleted: boolean
  createdAt: string
  updatedAt: string
}

interface MediaFolder {
  id: string
  name: string
  path: string
  parentId: string | null
  children: MediaFolder[]
  assets: MediaAsset[]
  _count: { assets: number }
  isDeleted: boolean
  createdAt: string
  updatedAt: string
}
```

### Component: Media Picker

**Purpose**: Modal/inline component to select an existing media asset (used when creating/editing advertisements).

**Required API Calls**:
- Same as Media Library (for browsing)
- Selection returns `MediaAsset` object

**Props**:
```typescript
interface MediaPickerProps {
  onSelect: (asset: MediaAsset) => void
  value?: string                     // Currently selected asset ID
  allowUpload?: boolean              // Show "Upload" button
}
```

### Component: Image Upload

**Purpose**: Drag-and-drop upload zone with metadata form.

**Required API Calls**:
- `POST /api/admin/media` (multipart form data)

**Form Fields**:
| Field | Type | Required |
|---|---|---|
| file | FileInput | Yes |
| altText | TextInput | Yes |
| title | TextInput | No |
| folderId | FolderSelect | No |
| tags | TagInput | No |

**Loading State**: Progress bar during upload, then preview thumbnail upon success.

**Error State**: Display file size/MIME error messages from backend.

### Component: Advertisement List

**Route**: `/app/admin/ads/`

**Purpose**: Lists all advertisements with filters, bulk actions, and quick enable/disable.

**Required API Calls**:

| Action | API | Method |
|---|---|---|
| Load ads | `GET /api/admin/ads` | GET |
| Publish/Unpublish | `POST /api/admin/ads/:id` with `{action}` | POST |
| Archive/Restore | `POST /api/admin/ads/:id` with `{action}` | POST |
| Delete | `DELETE /api/admin/ads/:id` | DELETE |
| Bulk actions | `POST /api/admin/ads/bulk` | POST |

**Query Parameters**:
- `page`, `limit` — pagination
- `placement` — filter by placement
- `adType` — filter by type
- `isEnabled` — filter by enabled status
- `isArchived` — filter by archived status
- `search` — text search

**Data Structure (from API)**:
```typescript
interface Advertisement {
  id: string
  title: string
  slug: string                  // auto-generated, read-only
  description: string | null
  placement: "HOMEPAGE_HERO" | ... // 16 AdvertisementPlacement values
  type: "HERO_BANNER" | ...    // 8 AdType values
  action: "BANNER_CLICK" | ...  // 4 AdAction values
  buttonVariant: "PRIMARY" | ... // 4 ButtonVariant values
  desktopMediaId: string | null
  mobileMediaId: string | null
  altText: string | null
  bannerUrl: string | null
  buttonLabel: string | null
  buttonUrl: string | null
  openInNewTab: boolean
  displayOrder: number
  priority: number              // 1 = highest, 100 = lowest
  startDate: string | null
  endDate: string | null
  isEnabled: boolean
  isArchived: boolean
  showDesktop: boolean
  showTablet: boolean
  showMobile: boolean
  createdById: string
  updatedById: string | null
  internalNotes: string | null  // admin-only
  isDismissible: boolean
  isDeleted: boolean
  createdAt: string
  updatedAt: string
  desktopMedia: MediaAsset | null
  mobileMedia: MediaAsset | null
}
```

**List Columns**:
| Column | Field | Notes |
|---|---|---|
| Checkbox | — | For bulk selection |
| Preview | `desktopMedia?.thumbnailUrl` | Fallback to icon if null |
| Title | `title` | Click to edit |
| Type | `type` | Badge |
| Placement | `placement` | Badge |
| Status | `isEnabled` | Toggle switch |
| Priority | `priority` | Number |
| Dates | `startDate`–`endDate` | Date range |
| Events | `metrics.impressions` / `metrics.clicks` | Only on detail view |
| Actions | — | Edit, duplicate, archive, delete |

**Filters**:
- Search input (text)
- Placement dropdown (16 options)
- Ad Type dropdown (8 options)
- Status filter (Enabled/Disabled/Archived)

**Bulk Actions**:
- Enable
- Disable
- Archive
- Restore
- Delete (soft)

### Component: Advertisement Form

**Route**: `/app/admin/ads/create/` (create) or `/app/admin/ads/[id]/edit/` (edit)

**Purpose**: Form to create or edit an advertisement.

**Required API Calls**:

| Action | API | Method |
|---|---|---|
| Create | `POST /api/admin/ads` | POST |
| Update | `PUT /api/admin/ads/:id` | PUT |
| Load for edit | `GET /api/admin/ads/:id` | GET |

**Expected API Response (single ad)**:
```typescript
{
  success: true,
  ad: Advertisement,
  metrics: {
    impressions: number,
    clicks: number
  }
}
```

**Form Sections**:

#### Section 1: Basic Info

| Field | Input | Required | Notes |
|---|---|---|---|
| Title | TextInput | Yes | Max 200 chars |
| Description | Textarea | No | Max 1000 chars |
| Internal Notes | Textarea | No | Admin-only, max 500 chars |

#### Section 2: Type, Placement & Action

| Field | Input | Required | Notes |
|---|---|---|---|
| Type | Select | Yes | AdType enum (8 options) |
| Placement | Select | Yes | AdvertisementPlacement enum (16 options) |
| Action | Select | Yes | AdAction enum |
| Button Variant | Select | No | ButtonVariant (4 options, default: PRIMARY) |
| Button Label | TextInput | No | Max 50 chars |
| Button URL | TextInput | No | Relative URL |
| Open in New Tab | Toggle | No | Default: true |

#### Section 3: Media

| Field | Input | Required | Notes |
|---|---|---|---|
| Desktop Media | MediaPicker | No | Must reference uploaded asset |
| Mobile Media | MediaPicker | No | Must reference uploaded asset |
| Alt Text | TextInput | No | Max 200 chars |
| Banner URL | TextInput | No | Alternative to media picker |

#### Section 4: Display Control

| Field | Input | Required | Default |
|---|---|---|---|
| Display Order | NumberInput | No | 0 |
| Priority | NumberInput | No | 10 (1=highest, 100=lowest) |
| Show Desktop | Toggle | No | true |
| Show Tablet | Toggle | No | true |
| Show Mobile | Toggle | No | true |

#### Section 5: Schedule

| Field | Input | Required | Notes |
|---|---|---|---|
| Start Date | DateTimePicker | No | Future date |
| End Date | DateTimePicker | No | After start date |

#### Section 6: Publish

| Field | Input | Default | Notes |
|---|---|---|---|
| Enable | Toggle | OFF | OFF = draft |
| Is Dismissible | Toggle | OFF | Shows close button on public |

#### Validation Rules
- Required fields marked (Title, Type, Placement, Action)
- Start Date ≤ End Date if both provided
- Priority must be between 1–100
- Display Order must be ≥ 0

### Component: Advertisement Preview

**Route**: `/app/admin/ads/[id]/` (detail page) or inline in form

**Purpose**: Shows how the ad will render on desktop, tablet, and mobile.

**Required API Calls**:
- `GET /api/admin/ads/:id` with `action: "preview"`

**Preview API Response**:
```typescript
{
  success: true,
  ad: Advertisement,
  preview: {
    device: "desktop" | "tablet" | "mobile",
    url: "/_preview/ad/{slug}?device=desktop"
  }
}
```

**Preview States**:
- **Desktop (1920×1080)**: Full-size ad render
- **Tablet (768×1024)**: Medium ad render
- **Mobile (375×667)**: Mobile ad render

### Component: Placement Selector

**Purpose**: Dropdown/radio group for selecting where an ad appears.

**Options**: All 16 AdvertisementPlacement enum values.

| Enum Value | Display Name |
|---|---|
| HOMEPAGE_HERO | Homepage Hero |
| HOMEPAGE_SEARCH | Homepage Search |
| HOMEPAGE_FEATURED | Homepage Featured |
| HOMEPAGE_SERVICES | Homepage Services |
| HOMEPAGE_BANKS | Homepage Banks |
| HOMEPAGE_CTA | Homepage CTA |
| BROKER_LISTING | Broker Listing |
| BROKER_PROFILE_HEADER | Broker Profile Header |
| BROKER_LISTING_SIDEBAR | Broker Listing Sidebar |
| LOAN_CALCULATOR | Loan Calculator |
| BLOG_INLINE | Blog Inline |
| FOOTER | Footer |
| ANNOUNCEMENT_TOP | Announcement Top |
| ANNOUNCEMENT_BOTTOM | Announcement Bottom |
| POPUP_OVERLAY | Popup Overlay |
| MOBILE_HEADER_BANNER | Mobile Header Banner |

### Component: Folder Tree

**Purpose**: Sidebar navigation for media folders.

**Required API Calls**:
- `GET /api/admin/media/folders`

## UI States

### Loading States
- Dashboard: Skeleton grid of 8 stat cards, skeleton lists for recent items
- Media Library: Skeleton grid of 12 placeholder cards
- Ad List: Skeleton table of 10 rows
- Ad Form: Skeleton form with loading overlay

### Empty States
- Dashboard (no ads): "No advertisements yet. Create your first advertisement to see it here."
- Media Library: "No media assets found. Upload your first image."
- Ad List: "No advertisements match your filters."
- Ad Form (create): Pre-filled defaults

### Error States
- API failure: "Failed to load data. [Retry]"
- Upload failure: Display specific error message from backend
- Save failure: Display validation errors inline

## Admin Routes (Phase 4.3A)

| Route | Page | Status |
|---|---|---|
| `/admin/ads` | Dashboard Overview | ✅ Built |
| `/admin/ads/list` | Advertisement List | ✅ Built |
| `/admin/media` | Media Library | 🚧 Placeholder |
| `/admin/folders` | Folder Manager | 🚧 Placeholder |

## Create/Edit Routes (Phase 4.3B)

| Route | Page | Status |
|---|---|---|
| `/admin/ads/new` | Create Advertisement | ✅ Built |
| `/admin/ads/[id]/edit` | Edit Advertisement | ✅ Built |
| `/admin/ads/[id]/preview` | Preview Advertisement | ✅ Built |

## Form Architecture (Phase 4.3B)

### Shared Component: AdvertisementForm

**File**: `components/admin/ads/AdvertisementForm.tsx`

**Props**:
```typescript
interface AdvertisementFormProps {
  mode: 'create' | 'edit'
  ad?: Advertisement | null
  onSuccess?: (ad: Advertisement) => void
  onCancel?: () => void
}
```

**Layout**: Premium 2-column layout
- Desktop: Main form (2/3 width) + Sticky preview sidebar (1/3 width)
- Mobile: Single column, preview below form

**Tabs**:
1. Basic Info — Title, Slug, Description, Internal Notes
2. Type & Placement — Placement (grouped dropdown), Type (card selector), Action (card selector)
3. Display — Priority, Display Order, Start/End Date, Enabled/Archived/Dismissible switches, Device visibility toggles
4. Media — Desktop Media picker, Mobile Media picker, Banner URL

**Dynamic Fields**:
- Button section shown only when action is BUTTON_ONLY or BANNER_AND_BUTTON
- Banner Click URL shown only when action is BANNER_CLICK
- Slug auto-generated from title (editable on create, locked on edit)

**Preview Sidebar**:
- Real-time preview as administrator edits
- Desktop/Mobile device toggle
- Shows selected media, title, button preview, placement badge
- Status card showing Enabled/Archived state

**Unsaved Changes Protection**:
- `beforeunload` event listener
- Route change confirmation
- Auto-save draft to localStorage (2s debounce, 24h TTL)
- Draft restore prompt on create page

### Media Picker Dialog

**File**: `components/admin/ads/MediaPickerDialog.tsx`

**Props**:
```typescript
interface MediaPickerDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSelect: (asset: MediaAsset) => void
  selectedAssetId?: string | null
  title?: string
  description?: string
}
```

**Features**:
- Search by filename, title, alt text, tags
- Folder navigation dropdown
- Grid/List view toggle
- Sort by newest, oldest, name
- Preview thumbnails with file type badges
- Shows dimensions and file size
- Motion animations on hover/select
- No upload functionality (handled by Media Library phase)

## Validation (Phase 4.3B)

Uses Zod schemas from `lib/advertisements/validation.ts`:
- `CreateAdSchema` — for new advertisements
- `UpdateAdSchema` — partial schema for edits

Inline validation with error messages, helper text, and character counters.

## Preview Page (Phase 4.3B)

**File**: `app/admin/ads/[id]/preview/page.tsx`

**Features**:
- Read-only preview of advertisement
- Desktop and Mobile preview panels
- Button preview (if applicable)
- Metadata sidebar with placement, type, priority, status, schedule, creator info
- Sticky actions bar: Edit, Publish, Archive, Duplicate, Delete
- All actions call real backend APIs

## Phase 4.3B.1 — Advertisement Management UX & Workflow Polish

### Enhanced Advertisement Form

The `AdvertisementForm` component has been significantly enhanced with premium UX features:

#### Placement-Specific Preview System

Instead of generic card previews, the form now renders advertisement previews specific to the selected placement.

**File**: `components/admin/ads/placementPreviews.ts`

**Features**:
- 16 placement-specific preview configurations
- Each placement has realistic preview container dimensions
- Recommended specs: width, height, aspect ratio, file size, formats, quality
- Background switcher for previewing on different page contexts (Home Light/Dark, Broker Light/Dark, Footer Light/Dark)
- Zoom controls: 50%, 75%, 100%, Fit Width
- Side-by-side desktop/mobile preview on desktop, stacked on mobile

#### Placement Guide Panel

When a placement is selected, an information panel appears explaining:
- Which page it appears on
- Approximate position
- Visibility (Desktop/Mobile/Both)
- Priority level

**File**: `components/admin/ads/PlacementGuide.tsx`

#### Placement Specifications Panel

Displays recommended specifications for the selected placement:
- Recommended Size (e.g., 1920 × 600)
- Aspect Ratio (e.g., 16:5)
- Maximum File Size (e.g., 10 MB)
- Supported Formats (WebP, PNG, JPEG, SVG)
- Quality recommendation (High/Medium)

**File**: `components/admin/ads/PlacementSpecs.tsx`

#### Intelligent Image Validation

When media is selected, automatically validates:
- Width and height against placement recommendations
- Aspect ratio compatibility
- File size limits
- Format support
- Alt text presence

Provides friendly guidance messages:
- ✓ Perfect for Homepage Hero
- ✓ Recommended dimensions
- ⚠ Image is smaller than recommended
- ⚠ Aspect ratio may crop
- ⚠ File size is large

**File**: `components/admin/ads/ImageValidationPanel.tsx`

#### Image Metadata Panel

When media is selected, displays comprehensive metadata:
- Filename
- Folder
- Dimensions
- Aspect Ratio
- File Size
- Format
- Alt Text
- Tags
- Uploaded By
- Upload Date

**File**: `components/admin/ads/ImageMetadataPanel.tsx`

#### Publish Readiness Checklist

Before publishing, displays a validation checklist:
- ✓ Title
- ✓ Placement
- ✓ Desktop Image
- ✓ Action Type
- ✓ Schedule
- ✓ Priority
- ✓ URLs
- ✓ Button Configuration

Shows "Ready to Publish" or "Action Required" status. Disables Publish until requirements are satisfied.

**File**: `components/admin/ads/PublishReadinessChecklist.tsx`

#### Activity Timeline Sidebar

Right sidebar includes:
- Created timestamp
- Updated timestamp
- Published/Archived/Restored/Deleted events
- Latest Impression Count
- Latest Click Count
- Created By
- Updated By
- Current Status

**File**: `components/admin/ads/ActivityTimeline.tsx`

#### Improved Duplicate Workflow

Replaced instant duplication with a dialog that allows administrators to choose:
- New Title
- Copy Images
- Copy Schedule
- Copy Priority
- Copy Status
- Copy Button Settings
- Generate New Slug

**File**: `components/admin/ads/DuplicateDialog.tsx`

#### Improved Archive Dialog

Enhanced confirmation dialog explaining:
- Advertisement will be removed from public pages
- All data preserved
- Statistics preserved
- Can be restored later

**File**: `components/admin/ads/ArchiveDialog.tsx`

#### Sticky Preview Header

Preview page now has a sticky top toolbar with:
- Save
- Publish
- Disable
- Archive
- Duplicate
- Preview Public
- Delete
- Back

Always visible while scrolling.

#### Unsaved Changes UX

- Highlighted changed sections in sticky indicator
- Shows exactly which fields are modified
- Prompts only when required
- Avoids unnecessary warnings

#### Better Empty States

Premium empty states using Lucide icons, professional copy, and clear call-to-action. No emojis.

#### Motion & Animation

Subtle motion using motion/react:
- Fade transitions
- Slide animations
- Scale effects
- Layout transitions
- Dialog animations
- Hover effects

Never overanimated. No flashy effects.

## Sidebar Integration

The Advertisements section was added to the Platform Admin sidebar under a new "Advertisements" expandable item:
- **Overview** → `/admin/ads`
- **Advertisements** → `/admin/ads/list`
- **Media Library** → `/admin/media` (disabled, coming soon)
- **Folders** → `/admin/folders` (disabled, coming soon)

Active route highlighting and mobile responsive sidebar are supported via existing admin layout components.

## Reusable Components Created

| Component | Location | Purpose |
|---|---|---|
| `AdvertisementCard` | `components/admin/ads/AdvertisementCard.tsx` | Card preview for ads |
| `AdvertisementStatusBadge` | `components/admin/ads/AdvertisementStatusBadge.tsx` | Published/Draft/Archived/Scheduled/Expired badge |
| `PlacementBadge` | `components/admin/ads/PlacementBadge.tsx` | Human-readable placement badge |
| `PriorityBadge` | `components/admin/ads/PriorityBadge.tsx` | Priority level badge |
| `AdvertisementTable` | `components/admin/ads/AdvertisementTable.tsx` | Full data table with selection, pagination, responsive columns |
| `AdvertisementToolbar` | `components/admin/ads/AdvertisementToolbar.tsx` | Search, filters, sort, refresh, bulk actions |
| `AdvertisementActionsDropdown` | `components/admin/ads/AdvertisementActionsDropdown.tsx` | Row actions menu |
| `DeleteDialog` | `components/admin/ads/DeleteDialog.tsx` | Confirmation dialog for delete |
| `StatsCard` | `components/admin/ads/StatsCard.tsx` | Dashboard stat card |
| `SectionHeader` | `components/admin/ads/SectionHeader.tsx` | Page title + action button |
| `LoadingSkeleton` | `components/admin/ads/LoadingSkeleton.tsx` | Skeleton loaders for stats, table rows, cards |

## Hooks Created

| Hook | Location | Purpose |
|---|---|---|
| `useAdminAdStats` | `hooks/useAdminAds.ts` | Fetch dashboard stats from `/api/admin/ads/stats` |
| `useAdminAds` | `hooks/useAdminAds.ts` | Fetch paginated ad list with filters |
| `useAdminAd` | `hooks/useAdminAds.ts` | Fetch single ad detail (for future detail page) |
| `useMediaAssets` | `hooks/useAdminAds.ts` | Fetch media assets (for future media library) |
| `useMediaFolders` | `hooks/useAdminAds.ts` | Fetch folder tree (for future folder manager) |

## Phase 4.3C — Premium Media Library & Asset Management

### Media Library Page

**Route**: `/admin/media`

**Features**:
- Grid view, List view, Gallery view with instant switching
- View mode persisted in localStorage
- Upload dialog with drag & drop, browse, paste support
- Multiple file upload with progress bars
- Search by filename, title, alt text, tags
- Filter by format (PNG, JPEG, WebP, GIF, SVG)
- Sort by newest, oldest, name, size, dimensions
- Folder filter dropdown
- Show deleted assets toggle
- Storage dashboard with stats
- Bulk actions (move, delete, restore)
- Image details drawer
- Image metadata editing
- Copy URL functionality

### Folder Manager Page

**Route**: `/admin/folders`

**Features**:
- Tree view of all folders
- Breadcrumb navigation
- Create folder
- Rename folder (inline editing)
- Delete folder with confirmation
- Folder statistics (asset count)
- Expand/collapse folders
- Nested folder support

### Upload Dialog

**File**: `components/admin/media/UploadDialog.tsx`

**Features**:
- Drag & drop support
- Browse files
- Paste from clipboard
- Multiple file upload
- Progress bars per file
- Cancel/remove files
- Retry failed uploads
- Alt text input
- Folder selection
- New folder creation
- File validation (size, format)
- Preview before upload

### Image Details Drawer

**File**: `components/admin/media/ImageDetailsDrawer.tsx`

**Features**:
- Large preview
- Metadata display (filename, dimensions, format, size)
- Tags display
- Usage detection (advertisements using this image)
- Copy URL
- Delete/Restore actions

### Image Edit Dialog

**File**: `components/admin/media/ImageEditDialog.tsx`

**Features**:
- Edit title
- Edit alt text
- Preview image
- Metadata display

### Components Created

| Component | Location | Purpose |
|---|---|---|
| `MediaToolbar` | `components/admin/media/MediaToolbar.tsx` | Top toolbar with search, filters, sort, view toggle, upload, refresh |
| `MediaGrid` | `components/admin/media/MediaGrid.tsx` | Premium grid view with hover actions |
| `MediaList` | `components/admin/media/MediaList.tsx` | Compact table view with sticky header |
| `MediaGallery` | `components/admin/media/MediaGallery.tsx` | Pinterest-like masonry layout |
| `UploadDialog` | `components/admin/media/UploadDialog.tsx` | Professional upload dialog with drag & drop |
| `ImageDetailsDrawer` | `components/admin/media/ImageDetailsDrawer.tsx` | Side drawer for asset details |
| `ImageEditDialog` | `components/admin/media/ImageEditDialog.tsx` | Edit asset metadata |
| `FolderManager` | `components/admin/media/FolderManager.tsx` | Folder tree with create/rename/delete |
| `StorageDashboard` | `components/admin/media/StorageDashboard.tsx` | Storage usage statistics |
| `EmptyStates` | `components/admin/media/EmptyStates.tsx` | Premium empty state illustrations |

### Hooks Added

| Hook | Location | Purpose |
|---|---|---|
| `useCreateFolder` | `hooks/useAdminAds.ts` | Create new folder |
| `useUpdateFolder` | `hooks/useAdminAds.ts` | Rename folder |
| `useDeleteFolder` | `hooks/useAdminAds.ts` | Delete folder |
| `useUpdateAsset` | `hooks/useAdminAds.ts` | Update asset metadata |
| `useDeleteAsset` | `hooks/useAdminAds.ts` | Soft delete asset |
| `useRestoreAsset` | `hooks/useAdminAds.ts` | Restore deleted asset |
| `useMoveAsset` | `hooks/useAdminAds.ts` | Move asset to folder |
| `useUploadAsset` | `hooks/useAdminAds.ts` | Upload new asset |

### API Routes Added

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/admin/media/folders/[id]` | PUT | Rename folder |
| `/api/admin/media/folders/[id]` | DELETE | Delete folder |
| `/api/admin/media/[id]/restore` | POST | Restore deleted asset |
| `/api/admin/media/[id]/move` | POST | Move asset to folder |

## Phase 4.3D — Public Advertisement Rendering System

### Components Created

| Component | Location | Purpose |
|---|---|---|
| `AdvertisementRenderer` | `components/advertisements/AdvertisementRenderer.tsx` | Universal renderer mapping placements to specialized components |
| `AdvertisementSlot` | `components/advertisements/AdvertisementSlot.tsx` | Simple slot renderer |
| `AdvertisementBanner` | `components/advertisements/AdvertisementBanner.tsx` | Standard banner renderer |
| `AdvertisementHero` | `components/advertisements/AdvertisementHero.tsx` | Hero banner with eager loading and preload |
| `AdvertisementSidebar` | `components/advertisements/AdvertisementSidebar.tsx` | Sidebar banner renderer |
| `AdvertisementPopup` | `components/advertisements/AdvertisementPopup.tsx` | Center popup with delay, ESC, overlay click, session tracking |
| `AdvertisementSticky` | `components/advertisements/AdvertisementSticky.tsx` | Bottom sticky banner with dismiss and safe area |
| `AdvertisementFooter` | `components/advertisements/AdvertisementFooter.tsx` | Footer banner renderer |
| `AdvertisementInline` | `components/advertisements/AdvertisementInline.tsx` | Inline content ad renderer |
| `AdvertisementButton` | `components/advertisements/AdvertisementButton.tsx` | CTA button only renderer |
| `AdvertisementWrapper` | `components/advertisements/AdvertisementWrapper.tsx` | Reusable wrapper with click handling and ARIA |
| `AdvertisementLoading` | `components/advertisements/AdvertisementLoading.tsx` | Loading skeleton |
| `AdvertisementFallback` | `components/advertisements/AdvertisementFallback.tsx` | Empty fallback |
| `AdvertisementError` | `components/advertisements/AdvertisementError.tsx` | Error fallback |

### Hooks Created

| Hook | Location | Purpose |
|---|---|---|
| `usePublicAd` | `hooks/useAdvertisements.ts` | Fetch public ads by placement with SWR caching |
| `useDeviceType` | `hooks/useAdvertisements.ts` | Detect current device type (desktop/tablet/mobile) |
| `useImpressionTracker` | `lib/advertisements/tracker.ts` | IntersectionObserver-based impression tracking |
| `useClickTracker` | `lib/advertisements/tracker.ts` | Click tracking with localStorage deduplication |
| `useDismissibleAd` | `lib/advertisements/tracker.ts` | Dismissible ad state with localStorage persistence |
| `usePopupSession` | `lib/advertisements/tracker.ts` | Session-based popup show tracking |

### Public Routes Integrated

| Route | Placement | Component |
|---|---|---|
| `/` (Homepage) | HOMEPAGE_HERO | AdvertisementHero |
| `/` (Homepage) | HOMEPAGE_SEARCH | AdvertisementBanner |
| `/` (Homepage) | HOMEPAGE_FEATURED | AdvertisementBanner |
| `/` (Homepage) | HOMEPAGE_SERVICES | AdvertisementBanner |
| `/` (Homepage) | HOMEPAGE_BANKS | AdvertisementBanner |
| `/` (Homepage) | HOMEPAGE_CTA | AdvertisementBanner |
| `/brokers` | BROKER_LISTING | AdvertisementBanner |
| `/brokers` | BROKER_LISTING_SIDEBAR | AdvertisementBanner |
| `/brokers/[slug]` | BROKER_PROFILE_HEADER | AdvertisementHero |
| `/calculator` | LOAN_CALCULATOR | AdvertisementBanner |
| Global Footer | FOOTER | AdvertisementFooter |
| Global Header | MOBILE_HEADER_BANNER | AdvertisementSticky |
| Global Layout | ANNOUNCEMENT_TOP | AdvertisementBanner |
| Global Layout | POPUP_OVERLAY | AdvertisementPopup |
| Global Layout | MOBILE_BOTTOM_STICKY | AdvertisementSticky |

### Tracking Implementation

- **Impression Tracking**: IntersectionObserver with 50% visibility threshold and 500ms delay
- **Click Tracking**: POST to `/api/ads/click` before navigation, non-blocking via `keepalive: true`
- **Dismissible Ads**: localStorage persistence for dismissed ad IDs
- **Popup Session**: sessionStorage to show popup only once per session
- **Duplicate Prevention**: Tracked impression/click IDs stored in localStorage

### Responsive Behavior

- Desktop image → Mobile image → Desktop fallback (automatic via `getAdImage`)
- Hero ads use `loading="eager"` and `fetchPriority="high"`
- All other placements use `loading="lazy"`
- Sticky mobile banner uses `env(safe-area-inset-bottom)` for iPhone notch

### Accessibility

- Semantic HTML and ARIA labels on all ad containers
- Keyboard navigation support (Enter/Space to click)
- Escape key closes popup and sticky ads
- Visible focus rings via native browser styles
- Screen reader support via native elements

### Performance

- SWR caching for all API calls (60s deduping interval)
- `useMemo` for sorted/filtered assets (in admin components)
- `memo()` on all advertisement components
- Lazy image loading everywhere except hero placements
- No layout shift (images have natural dimensions)
- Preload only HOMEPAGE_HERO and HOMEPAGE_SEARCH

## Related Documents
- [API.md](./API.md) — API endpoint specifications
- [ADMIN.md](./ADMIN.md) — Admin capabilities
- [DATABASE.md](./DATABASE.md) — Data models