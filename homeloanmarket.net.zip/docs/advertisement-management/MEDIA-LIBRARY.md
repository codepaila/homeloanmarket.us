# Media Library

## Overview

The Media Library handles all image uploads, storage, and organization for the Advertisement Management System. Platform Admins upload images here before assigning them to advertisements.

## Architecture

```
Upload → Validation → Processing → Storage → Database Record
```

The backend implementation lives in:
- `lib/advertisements/imageProcessor.ts` — Sharp-based processing
- `app/api/admin/media/route.ts` — Upload/list endpoints
- `lib/advertisements/mediaRepository.ts` — Data access
- `lib/advertisements/services.ts` — MediaService business logic

## Upload Flow

### Step 1: Access Upload

- Navigate to **Admin → Media Library**
- Click "Upload Media"
- Drag & drop or click to select files

### Step 2: File Processing

```
Client Upload → Validation → Optimization → Storage → Database Record
```

1. **Validation** (`validateUpload()` in `imageProcessor.ts`):
   - File type: JPEG, PNG, WebP, GIF, SVG only
   - File size: max 10MB (2MB for SVG)
   - MIME type validation (not just extension)

2. **Processing** (`processImage()` using Sharp):
   - Converted to WebP at quality 85 (SVG preserved as-is)
   - Thumbnail generated: 200×200 WebP, quality 80
   - Responsive variants generated but not stored as separate URLs:
     - 400px variant
     - 800px variant
     - 1200px variant
   - EXIF/GPS metadata stripped
   - Width/height extracted from image metadata

3. **Storage**: Saved to `public/uploads/media/{objectId}.webp`
   - Relative path stored in DB: `/uploads/media/{objectId}.webp`
   - Thumbnail stored: `/uploads/media/{objectId}@200x200.webp`

4. **Database**: `MediaAsset` record created via `createMediaAsset()`

### Step 3: Metadata Entry

Required and optional fields on upload (via multipart form):

| Field | Required | Description |
|---|---|---|
| file | Yes | Image file (JPEG, PNG, WebP, GIF, SVG) |
| altText | Yes | Accessibility description |
| title | No | Short title for display |
| folderId | No | Organize into folders |
| tags | No | Searchable tags (JSON string array) |

Slug (on Advertisement) is auto-generated from title — admin does not set it manually.

## Folder System

### Folder Hierarchy

Folders use a self-referencing parent/children relationship:

```prisma
model MediaFolder {
  id        String  @id @default(auto()) @map("_id") @db.ObjectId
  name      String
  path      String  @unique
  parentId  String? @db.ObjectId
  parent    MediaFolder?   @relation("FolderHierarchy", ...)
  children  MediaFolder[]  @relation("FolderHierarchy")
  assets    MediaAsset[]
  ...
}
```

### Default Folder Structure

```
/uploads/media/
├── advertisements/     # Ad-specific assets
├── shared/             # Reusable assets
└── (user-created)      # Admin-created folders
```

File storage path: `public/uploads/media/{objectId}.webp`

### Folder Operations

| Operation | Endpoint | Method |
|---|---|---|
| List folder tree | `/api/admin/media/folders` | GET |
| Create folder | `/api/admin/media/folders` | POST |

## File Operations

### Upload

**Endpoint**: `POST /api/admin/media` (multipart form data)

Supported formats and limits:

| Format | Extension | Max Size | Processing |
|---|---|---|---|
| JPEG | .jpg, .jpeg | 10MB | → WebP |
| PNG | .png | 10MB | → WebP (preserves transparency) |
| WebP | .webp | 10MB | Stored as-is |
| GIF | .gif | 5MB | First frame → WebP |
| SVG | .svg | 2MB | Stored as-is |

### List Assets

**Endpoint**: `GET /api/admin/media`

Query parameters:
- `page` (default: 1)
- `limit` (default: 50, max: 100)
- `search` — search by filename, title, altText, tags
- `folderId` — filter by folder

### Get Single Asset

**Endpoint**: `GET /api/admin/media/:id`

Returns full asset with folder and uploader details.

### Update Asset

**Endpoint**: `PUT /api/admin/media/:id`

Editable fields: `title`, `altText`

Moving assets between folders is handled via the move operation (update `folderId`).

### Rename Asset

Update via `PUT /api/admin/media/:id` with `title` field.

### Move Asset

Update via `PUT /api/admin/media/:id` with `folderId` field.

### Soft Delete

**Endpoint**: `DELETE /api/admin/media/:id`

- Sets `isDeleted = true`
- File remains on disk
- Asset hidden from list queries (filtered by `isDeleted = false`)
- Cannot link a deleted asset to new advertisements

### Restore

- Filter media library by "Deleted"
- Set `isDeleted = false` via repository method
- Asset reappears in normal listings

### Hard Delete (Compliance)

- Requires explicit admin action (via `hard_delete` on advertisement, or similar)
- Removes file from filesystem
- Removes database record

### Search

Search by:
- Filename (`fileName`, `originalName`)
- Title
- Alt text
- Tags

Uses MongoDB text search with `mode: "insensitive"` regex matching.

## Image Processing

### Processing Pipeline

1. **Format Conversion**: All raster images converted to WebP at quality 85
2. **SVG Handling**: Stored as-is (no conversion)
3. **Thumbnail**: 200×200 cropped square for admin grid
4. **Responsive Variants**: Generated at 400px, 800px, 1200px widths
5. **Metadata Stripping**: All EXIF data removed
6. **Dimension Detection**: Width/height extracted via Sharp metadata

### Storage Layout

```
public/uploads/media/
├── {objectId}.webp            # Main image (WebP)
├── {objectId}@200x200.webp    # Thumbnail (200×200)
├── {objectId}@400x400.webp    # Small variant
├── {objectId}@800x800.webp    # Medium variant
└── {objectId}@1200x1200.webp  # Large variant
```

### Database Fields

| Field | Type | Description |
|---|---|---|
| `fileUrl` | String | Relative URL (e.g., `/uploads/media/{id}.webp`) |
| `thumbnailUrl` | String? | Relative URL to thumbnail |
| `mimeType` | String | e.g., `image/webp` |
| `extension` | String | e.g., `webp`, `svg` |
| `fileSize` | Int | File size in bytes |
| `width` | Int? | Image width in pixels |
| `height` | Int? | Image height in pixels |
| `altText` | String? | Accessibility description |
| `tags` | String[] | Searchable tags |
| `fileName` | String | Actual filename on disk |
| `originalName` | String | Original uploaded filename |
| `title` | String? | Admin-set display title |

## Media Asset Model

```prisma
model MediaAsset {
  id            String   @id @default(auto()) @map("_id") @db.ObjectId
  fileName      String
  originalName  String
  fileUrl       String
  thumbnailUrl  String?
  mimeType      String
  extension     String
  fileSize      Int
  width         Int?
  height        Int?
  altText       String?
  title         String?
  tags          String[] @default([])
  folderId      String?  @db.ObjectId
  uploaderId    String   @db.ObjectId

  folder        MediaFolder? @relation(...)
  uploader      User         @relation("UploadedMedia", ...)

  desktopAdvertisements Advertisement[] @relation("DesktopMedia")
  mobileAdvertisements  Advertisement[] @relation("MobileMedia")

  isDeleted     Boolean  @default(false)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @default(now()) @updatedAt

  @@map("media_assets")
}
```

## Soft Delete Strategy

- `isDeleted` boolean field on `MediaAsset` and `MediaFolder`
- No `deletedAt` or `deletedBy` fields (simpler, matches Phase 4.0 design)
- DELETE sets `isDeleted = true`
- All read queries filter `WHERE isDeleted = false`
- Restore sets `isDeleted = false`

## CDN Compatibility

When migrating to S3 + CloudFront:
1. Set `fileUrl` to CDN URL after upload
2. Set `thumbnailUrl` to CDN thumbnail
3. Update nginx/static serving to redirect old paths to CDN
4. No frontend changes required (URLs are relative, served from app root)

## Related Documents

- [DATABASE.md](./DATABASE.md) — Schema definitions
- [ADMIN.md](./ADMIN.md) — Media library admin interface
- [API.md](./API.md) — Media API endpoints
- [FRONTEND.md](./FRONTEND.md) — Image rendering

## Phase 4.3C — Premium Media Library UI

### Media Library Page (`/admin/media`)

Complete media asset management interface with grid/list/gallery views.

#### Views
- **Grid View**: Premium cards with preview, metadata, hover actions
- **List View**: Compact table with sticky header, all columns
- **Gallery View**: Pinterest-like masonry layout
- View mode persisted in localStorage

#### Toolbar
- Upload button
- New Folder button
- Search (filename, title, alt text, tags)
- Format filter (PNG, JPEG, WebP, GIF, SVG)
- Folder filter
- Sort (newest, oldest, name, size, dimensions)
- View toggle (grid/list/gallery)
- Refresh button
- Storage usage display
- Selection counter with bulk actions

#### Image Details Drawer
- Large preview
- Complete metadata (filename, dimensions, format, size, tags, dates)
- Usage detection (advertisements using this image)
- Copy URL (relative and full)
- Delete/Restore actions

#### Image Edit Dialog
- Edit title
- Edit alt text
- Preview image

#### Bulk Actions
- Move to folder
- Delete (soft)
- Restore
- Clear selection

### Folder Manager Page (`/admin/folders`)

Complete folder management interface with tree view, create/rename/delete, statistics.

### Components

| Component | Location | Purpose |
|---|---|---|
| `MediaToolbar` | `components/admin/media/MediaToolbar.tsx` | Top toolbar |
| `MediaGrid` | `components/admin/media/MediaGrid.tsx` | Grid view |
| `MediaList` | `components/admin/media/MediaList.tsx` | Table view |
| `MediaGallery` | `components/admin/media/MediaGallery.tsx` | Gallery view |
| `UploadDialog` | `components/admin/media/UploadDialog.tsx` | Upload with drag & drop |
| `ImageDetailsDrawer` | `components/admin/media/ImageDetailsDrawer.tsx` | Asset details |
| `ImageEditDialog` | `components/admin/media/ImageEditDialog.tsx` | Edit metadata |
| `FolderManager` | `components/admin/media/FolderManager.tsx` | Folder tree |
| `StorageDashboard` | `components/admin/media/StorageDashboard.tsx` | Storage stats |
| `EmptyStates` | `components/admin/media/EmptyStates.tsx` | Empty state illustrations |

### New API Routes

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/admin/media/folders/[id]` | PUT | Rename folder |
| `/api/admin/media/folders/[id]` | DELETE | Delete folder |
| `/api/admin/media/[id]/restore` | POST | Restore deleted asset |
| `/api/admin/media/[id]/move` | POST | Move asset to folder |
