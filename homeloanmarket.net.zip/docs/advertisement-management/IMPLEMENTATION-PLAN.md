# Implementation Plan

## Overview

The Advertisement Management System is implemented in 7 phases. Each phase delivers a focused, deployable increment. Phase 1 creates the database schema; subsequent phases build on top.

## Phase 1: Prisma Models (Weeks 1-2)

### Deliverables

- Prisma schema with `MediaAsset`, `MediaFolder`, `Advertisement`, `AdEvent` models
- Enums: `AdType`, `ButtonVariant`, `EventType`
- All indexes and relations
- Seed data: none required (positions are string keys)

### Scope

**New Tables**:
1. `MediaFolder` — Folder hierarchy for media organization
2. `MediaAsset` — Image asset storage with metadata
3. `Advertisement` — Banner ad configuration with placement and scheduling
4. `AdEvent` — Impression/click event logging

**Enums**:
- `AdType`: HERO_BANNER, SECTION_BANNER, INLINE_BANNER, SIDEBAR_BANNER, FOOTER_BANNER, SPONSORED_BANNER, POPUP_CAMPAIGN, ANNOUNCEMENT_BAR
- `ButtonVariant`: PRIMARY, SECONDARY, OUTLINE, GHOST
- `EventType`: IMPRESSION, CLICK

**Indexes**:
- Advertisement: positionKey, adType, isEnabled/isArchived, startDate/endDate, priority
- MediaAsset: url, mimeType, isDeleted
- AdEvent: advertisementId/eventType, timestamp, positionKey

### Success Criteria
- Migration runs successfully
- All collections created with correct indexes
- Enums validated

### Dependencies
- None (baseline phase)

---

## Phase 2: Media Library (Weeks 3-4)

### Deliverables

- Media upload API endpoint (`POST /api/admin/media/upload`)
- Media asset CRUD API (`GET/PUT/DELETE /api/admin/media/:id`)
- Media folder management API (`GET/POST /api/admin/media/folders`)
- Admin media library UI component
- Image optimization service (Sharp integration)
- Soft delete and restore functionality

### Scope

**Backend**:
1. Upload endpoint with file validation (JPEG, PNG, WebP, GIF, SVG)
2. Image optimization pipeline (WebP conversion, thumbnail generation)
3. Media asset list/update/delete APIs with soft delete
4. Folder CRUD APIs
5. Search and filter capabilities

**Frontend (Admin)**:
1. Media library browser (grid/list view, search, filters)
2. Upload interface (drag & drop, file picker, metadata entry)
3. Media picker (used in ad creation form)

### Success Criteria
- Upload accepts all supported formats
- Images optimized to WebP + thumbnails
- Media library UI displays assets correctly
- Folder navigation works
- Search returns correct results
- Soft delete and restore work

### Dependencies
- Phase 1 (MediaAsset, MediaFolder models)

---

## Phase 3: Advertisement CRUD (Weeks 5-6)

### Deliverables

- Advertisement CRUD API (`GET/POST/PUT/DELETE /api/admin/ads`)
- Publish/Archive/Restore endpoints
- Bulk operations endpoint
- Admin ad listing, creation, and editing UI
- Preview functionality (desktop, tablet, mobile)
- Scheduling and priority configuration

### Scope

**Backend**:
1. Full CRUD for advertisements
2. Publish endpoint (`POST /api/admin/ads/:id/publish`)
3. Archive endpoint (`POST /api/admin/ads/:id/archive`)
4. Restore endpoint (`POST /api/admin/ads/:id/restore`)
5. Duplicate endpoint (`POST /api/admin/ads/:id/duplicate`)
6. Bulk operations (`POST /api/admin/ads/bulk`)
7. Preview endpoint (`POST /api/admin/ads/:id/preview`)

**Frontend (Admin)**:
1. Ad listing dashboard with filters and search
2. Ad creation form (all 8 ad types, all interaction modes)
3. Ad edit form with all configuration options
4. Preview modal (desktop/tablet/mobile)
5. Draft/publish workflow

### Success Criteria
- Admin can create all 8 ad types
- All 4 interaction modes work
- All 16 position keys available for assignment
- Scheduling activates/deactivates ads
- Preview renders correctly for all device types
- Bulk operations work

### Dependencies
- Phase 1 (Advertisement model)
- Phase 2 (Media library for asset selection)

---

## Phase 4: Public Renderer (Weeks 7-8)

### Deliverables

- `AdvertisementRenderer` React component
- All 8 ad type rendering components
- Public ad serving API (`GET /api/ads/public`)
- Impression tracking API (`POST /api/ads/impression`)
- Click tracking API (`POST /api/ads/click`)

### Scope

**Backend**:
1. Public ad serving endpoint with position/device filters
2. Impression logging with deduplication
3. Click logging with redirect
4. Server-side ad selection with priority sorting

**Frontend Components**:
1. `AdvertisementRenderer` — main container component
2. `HeroBanner`, `SectionBanner`, `InlineBanner`, `SidebarBanner`
3. `FooterBanner`, `SponsoredBanner`, `PopupCampaign`, `AnnouncementBar`
4. `AdImage` — responsive image with lazy loading and WebP fallback

### Success Criteria
- Ads render correctly for all 8 types
- Priority-based selection works
- Impression tracking fires at 50% viewport for 1 second
- Click tracking works with non-blocking Beacon API
- No performance impact on page load
- Graceful degradation when no ads available

### Dependencies
- Phase 1 (Advertisement, AdEvent models)
- Phase 3 (Published ads must exist)

---

## Phase 5: Homepage Integration (Weeks 9-10)

### Deliverables

- AdRenderer integrated into homepage
- All homepage placements configured
- SSR for above-fold ads
- Client-side SWR caching
- Lazy loading for below-fold ads

### Scope

**Homepage Integrations**:
1. `homepage-hero` — Above-the-fold hero banner (SSR + priority loading)
2. `homepage-search` — Below search bar
3. `homepage-featured` — Before featured brokers section
4. `homepage-services` — Within services section
5. `homepage-banks` — Between bank partners
6. `homepage-cta` — Before main CTA section

### Success Criteria
- Ads render on all homepage positions
- No layout shift during ad loading
- Above-fold ads load with SSR
- Below-fold ads lazy load
- 5-minute cache for ad data

### Dependencies
- Phase 4 (AdRenderer component and public API)

---

## Phase 6: Broker Pages (Weeks 11-12)

### Deliverables

- AdRenderer integrated into broker listing page
- AdRenderer integrated into broker profile page
- Loan calculator page integration
- Blog page integration
- Footer and announcement bar integration

### Scope

**Page Integrations**:
1. `broker-listing-sidebar` — Broker search results sidebar
2. `broker-profile-header` — Broker profile header (sponsored banner)
3. `loan-calculator` — Calculator page sidebar
4. `blog-inline` — Between blog article content
5. `footer` — Above footer
6. `announcement-top` / `announcement-bottom` — Sticky announcement bars
7. `mobile-header-banner` — Mobile-only header banner

### Success Criteria
- Ads render on all integrated pages
- Mobile-specific ads show only on mobile
- Announcement bars are sticky

### Dependencies
- Phase 4 (AdRenderer component)
- Phase 5 (Homepage integration as reference)

---

## Phase 7: Testing (Weeks 13-14)

### Deliverables

- Unit tests for all components
- Integration tests for API endpoints
- E2E tests for admin workflows
- Accessibility tests (WCAG 2.1 AA)
- Performance tests
- Security tests

### Scope

**Test Coverage**:
1. Database tests (schema validation, queries)
2. Upload tests (file validation, optimization)
3. Media tests (CRUD, folder management, search)
4. Advertisement tests (CRUD, scheduling, priority)
5. Responsive tests (all 3 breakpoints)
6. Dark mode tests
7. Accessibility tests (axe-core)
8. Performance tests (Ad load time < 100ms)
9. Analytics tests (impression/click tracking)
10. Security tests (access control, injection)

### Success Criteria
- 90%+ code coverage
- All critical tests pass
- No accessibility violations
- Ad load time < 100ms
- Page load impact < 50ms

### Dependencies
- All previous phases complete

---

## Release Schedule

| Phase | Duration | Key Milestone |
|---|---|---|
| 1: Prisma Models | 2 weeks | Database schema ready |
| 2: Media Library | 2 weeks | Upload + optimization working |
| 3: Ad CRUD | 2 weeks | Admin panel can create ads |
| 4: Public Renderer | 2 weeks | Ads render on pages |
| 5: Homepage | 2 weeks | Ads on homepage |
| 6: Broker Pages | 2 weeks | Ads across all pages |
| 7: Testing | 2 weeks | Full test coverage |

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Migration conflicts | Low | High | New collections only; no existing collection changes |
| Image optimization failure | Low | Medium | Fallback to original image |
| Ad load performance | Medium | High | SWR caching + SSR + lazy loading |
| Priority algorithm bugs | Medium | Medium | Unit tests for sorting logic |
| XSS in ad content | Low | High | Input sanitization + CSP headers |

## Rollback Plan

If any phase causes issues:
1. **Phase 2**: Roll back Prisma migration; disable media upload route
2. **Phase 3**: Remove ad CRUD routes; hide admin panel
3. **Phase 4**: Remove AdRenderer components; revert to no-ads layout
4. **Phase 5-6**: Remove AdRenderer placements from pages

## Related Documents

- [DATABASE.md](./DATABASE.md) — Schema for Phase 1
- [MEDIA-LIBRARY.md](./MEDIA-LIBRARY.md) — Media details for Phase 2
- [ADMIN.md](./ADMIN.md) — Admin functionality for Phases 2-3
- [FRONTEND.md](./FRONTEND.md) — Rendering for Phase 4
- [API.md](./API.md) — All endpoint specifications
- [CHANGELOG.md](./CHANGELOG.md) — Change history
