# API Specification

## Overview

All admin endpoints require authentication with `ADMIN` role. Public endpoints are accessible without authentication.

## Authentication

| Endpoint | Auth Required | Role |
|---|---|---|
| `/api/admin/media` | Yes | Admin |
| `/api/admin/media/:id` | Yes | Admin |
| `/api/admin/media/folders` | Yes | Admin |
| `/api/admin/ads` | Yes | Admin |
| `/api/admin/ads/:id` | Yes | Admin |
| `/api/admin/ads/bulk` | Yes | Admin |
| `/api/ads/public` | No | Public |
| `/api/ads/impression` | No | Public |
| `/api/ads/click` | No | Public |

## Errors

```json
{
  "success": false,
  "error": "Error message"
}
```

| Code | Meaning |
|---|---|
| 200 | OK |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 409 | Conflict |
| 422 | Validation Error |
| 500 | Internal Server Error |

---

## Media API

### List Media Assets

```
GET /api/admin/media

Query Parameters:
  page (number, default: 1)
  limit (number, default: 50, max: 100)
  search (string, optional) — search by filename, title, altText, tags
  folderId (string, optional) — filter by folder

Response (200):
{
  "success": true,
  "assets": [
    {
      "id": "507f1f77bcf86cd799439011",
      "fileName": "abc-123.webp",
      "originalName": "hero-banner.png",
      "fileUrl": "/uploads/media/abc-123.webp",
      "thumbnailUrl": "/uploads/media/abc-123@200x200.webp",
      "title": "Spring Sale Hero",
      "altText": "Spring sale banner",
      "mimeType": "image/webp",
      "extension": "webp",
      "fileSize": 45678,
      "width": 1200,
      "height": 400,
      "tags": ["hero", "spring"],
      "folderId": null,
      "isDeleted": false,
      "createdAt": "2025-01-01T12:00:00Z",
      "updatedAt": "2025-01-01T12:00:00Z"
    }
  ],
  "total": 156,
  "page": 1,
  "limit": 50,
  "totalPages": 4
}
```

### Upload Media Asset

```
POST /api/admin/media
Content-Type: multipart/form-data

Form Fields:
  file: <image file> (required, max 10MB)
  altText: <string> (required)
  title: <string> (optional, max 200 chars)
  folderId: <string> (optional)
  tags: <json string array> (optional, e.g., '["hero","spring"]')

Supported formats: JPEG, PNG, WebP, GIF, SVG
Maximum size: 10MB (2MB for SVG)

Image Processing (automatic):
  - Converted to WebP at quality 85 (except SVG)
  - Thumbnail generated: 200×200 WebP
  - Responsive variants: 400px, 800px, 1200px
  - EXIF/GPS metadata stripped

Response (201):
{
  "success": true,
  "asset": {
    "id": "64f2a3c9e4b0a1d2f3e4a5b6",
    "fileName": "64f2a3c9-1234-5678-abcd-ef1234567890.webp",
    "originalName": "hero-banner.png",
    "fileUrl": "/uploads/media/64f2a3c9-1234-5678-abcd-ef1234567890.webp",
    "thumbnailUrl": "/uploads/media/64f2a3c9-1234-5678-abcd-ef1234567890@200x200.webp",
    "title": "Spring Sale Hero",
    "altText": "Spring sale banner",
    "mimeType": "image/webp",
    "extension": "webp",
    "fileSize": 45678,
    "width": 1200,
    "height": 400,
    "tags": [],
    "folderId": null,
    "uploaderId": "507f1f77bcf86cd799439011",
    "isDeleted": false,
    "createdAt": "2025-01-01T12:00:00Z",
    "updatedAt": "2025-01-01T12:00:00Z"
  }
}

Error (400):
{
  "success": false,
  "error": "File size exceeds 10MB limit"
}

Error (400):
{
  "success": false,
  "error": "Unsupported file type: image/tiff. Use JPEG, PNG, WebP, or GIF"
}

Error (400):
{
  "success": false,
  "error": "Alt text is required"
}
```

### Get Media Asset

```
GET /api/admin/media/:id

Response (200):
{
  "success": true,
  "asset": {
    "id": "507f1f77bcf86cd799439011",
    "fileName": "abc-123.webp",
    "originalName": "hero-banner.png",
    "fileUrl": "/uploads/media/abc-123.webp",
    "thumbnailUrl": "/uploads/media/abc-123@200x200.webp",
    "title": "Spring Sale Hero",
    "altText": "Spring sale banner",
    "mimeType": "image/webp",
    "extension": "webp",
    "fileSize": 45678,
    "width": 1200,
    "height": 400,
    "tags": ["hero", "spring"],
    "folder": null,
    "uploader": {
      "id": "507f1f77bcf86cd799439011",
      "name": "Admin User",
      "email": "admin@homeloanmarket.com"
    },
    "isDeleted": false,
    "createdAt": "2025-01-01T12:00:00Z",
    "updatedAt": "2025-01-01T12:00:00Z"
  }
}

Error (404):
{
  "success": false,
  "error": "Asset not found"
}
```

### Update Media Asset

```
PUT /api/admin/media/:id

Body:
{
  "title": "Updated Title",
  "altText": "Updated alt text"
}

Response (200):
{
  "success": true,
  "asset": { ...updated media asset... }
}

Error (404):
{
  "success": false,
  "error": "Asset not found"
}
```

### Delete Media Asset (Soft Delete)

```
DELETE /api/admin/media/:id

Response (200):
{
  "success": true,
  "message": "Asset soft deleted successfully"
}

Error (404):
{
  "success": false,
  "error": "Asset not found"
}

Note: Performs soft delete (isDeleted = true). File is not removed from disk.
```

### List Folders

```
GET /api/admin/media/folders

Response (200):
{
  "success": true,
  "folders": [
    {
      "id": "507f1f77bcf86cd799439011",
      "name": "Hero Banners",
      "path": "/advertisements/heros/",
      "parentId": null,
      "isDeleted": false,
      "createdAt": "2025-01-01T12:00:00Z",
      "updatedAt": "2025-01-01T12:00:00Z",
      "children": [...],
      "_count": { "assets": 23 }
    }
  ]
}
```

### Create Folder

```
POST /api/admin/media/folders

Body:
{
  "name": "Hero Banners",
  "parentId": "507f1f77bcf86cd799439011" (optional)
}

Response (201):
{
  "success": true,
  "folder": {
    "id": "64f2a3c9e4b0a1d2f3e4a5b6",
    "name": "Hero Banners",
    "path": "/advertisements/hero-banners/",
    "parentId": null,
    "isDeleted": false,
    "createdAt": "2025-01-01T12:00:00Z",
    "updatedAt": "2025-01-01T12:00:00Z"
  }
}

Error (404):
{
  "success": false,
  "error": "Parent folder not found"
}
```

---

## Advertisement API

### List Advertisements

```
GET /api/admin/ads

Query Parameters:
  page (number, default: 1)
  limit (number, default: 25, max: 100)
  placement (string, optional) — AdvertisementPlacement enum value
  adType (string, optional) — AdType enum value
  isEnabled (boolean, optional) — "true" or "false"
  isArchived (boolean, optional) — "true" or "false"
  search (string, optional) — search by title, slug, description

Response (200):
{
  "success": true,
  "ads": [
    {
      "id": "507f1f77bcf86cd799439011",
      "title": "Spring Hero Banner",
      "slug": "spring-hero-banner",
      "description": "Promo for spring",
      "placement": "HOMEPAGE_HERO",
      "type": "HERO_BANNER",
      "action": "BANNER_AND_BUTTON",
      "buttonVariant": "PRIMARY",
      "desktopMediaId": "507f1f77bcf86cd799439011",
      "mobileMediaId": null,
      "altText": "Spring sale banner",
      "bannerUrl": null,
      "buttonLabel": "Find Brokers",
      "buttonUrl": "/brokers",
      "openInNewTab": true,
      "displayOrder": 0,
      "priority": 5,
      "startDate": "2025-01-10T00:00:00Z",
      "endDate": "2025-02-10T23:59:59Z",
      "isEnabled": true,
      "isArchived": false,
      "showDesktop": true,
      "showTablet": true,
      "showMobile": true,
      "createdById": "507f1f77bcf86cd799439011",
      "updatedById": null,
      "internalNotes": "Homepage Spring Campaign",
      "isDismissible": false,
      "isDeleted": false,
      "createdAt": "2025-01-01T12:00:00Z",
      "updatedAt": "2025-01-05T08:30:00Z",
      "desktopMedia": { ...media asset... },
      "mobileMedia": null
    }
  ],
  "total": 12,
  "page": 1,
  "limit": 25,
  "totalPages": 1
}
```

### Create Advertisement

```
POST /api/admin/ads

Body:
{
  "title": "Spring Hero Banner",
  "description": "Full description text",
  "placement": "HOMEPAGE_HERO",
  "type": "HERO_BANNER",
  "action": "BANNER_AND_BUTTON",
  "buttonVariant": "PRIMARY",
  "desktopMediaId": "507f1f77bcf86cd799439011",
  "mobileMediaId": "507f1f77bcf86cd799439011",
  "altText": "Spring sale hero banner",
  "buttonLabel": "Find Brokers",
  "buttonUrl": "/brokers",
  "openInNewTab": true,
  "displayOrder": 0,
  "priority": 5,
  "startDate": "2025-01-10T00:00:00Z",
  "endDate": "2025-02-10T23:59:59Z",
  "isEnabled": true,
  "showDesktop": true,
  "showTablet": true,
  "showMobile": true,
  "internalNotes": "Homepage Spring Campaign"
}

Notes:
- Slug is auto-generated from title (read-only, admin cannot set)
- createdById and updatedById are set from authenticated user

Response (201):
{
  "success": true,
  "ad": { ...full ad object... }
}

Error (422):
{
  "success": false,
  "error": "Validation failed",
  "issues": [...]
}

Error (404):
{
  "success": false,
  "error": "Desktop media asset not found"
}
```

### Get Single Advertisement

```
GET /api/admin/ads/:id

Response (200):
{
  "success": true,
  "ad": { ...full ad object... },
  "metrics": {
    "impressions": 12500,
    "clicks": 320
  }
}

Error (404):
{
  "success": false,
  "error": "Advertisement not found"
}
```

### Update Advertisement

```
PUT /api/admin/ads/:id

Body (partial update — any subset of fields):
{
  "priority": 5,
  "isEnabled": true,
  "startDate": "2025-01-15T00:00:00Z",
  "title": "Updated Title"
}

Response (200):
{
  "success": true,
  "ad": { ...updated ad object... }
}
```

### Delete Advertisement (Archive)

```
DELETE /api/admin/ads/:id

Note: This archives the ad (isArchived=true, isEnabled=false).
The ad is NOT hard deleted.

Response (200):
{
  "success": true,
  "message": "Advertisement archived successfully"
}
```

### Advertisement Actions

Actions are performed via POST to `/api/admin/ads/:id` with an `action` field:

#### Publish

```
POST /api/admin/ads/:id
Body: { "action": "publish" }

Sets: isEnabled=true, isArchived=false
Response (200): { "success": true, "ad": {...} }
```

#### Unpublish

```
POST /api/admin/ads/:id
Body: { "action": "unpublish" }

Sets: isEnabled=false
Response (200): { "success": true, "ad": {...} }
```

#### Archive

```
POST /api/admin/ads/:id
Body: { "action": "archive" }

Sets: isArchived=true, isEnabled=false
Response (200): { "success": true, "ad": {...} }
```

#### Restore

```
POST /api/admin/ads/:id
Body: { "action": "restore" }

Sets: isArchived=false, isEnabled=false
Response (200): { "success": true, "ad": {...} }
```

#### Duplicate

```
POST /api/admin/ads/:id
Body: {
  "action": "duplicate",
  "title": "Copy Name" (optional, defaults to "{original} (Copy)"),
  "placement": "HOMEPAGE_SEARCH" (optional, defaults to original)
}

Creates new ad with new slug, desktopMediaId/mobileMediaId copied.
New ad has isEnabled=false.

Response (201): { "success": true, "ad": {...} }
```

#### Hard Delete

```
POST /api/admin/ads/:id
Body: { "action": "hard_delete" }

Permanently removes the ad document. Use with caution.

Response (200): { "success": true, "message": "Advertisement permanently deleted" }
```

#### Preview

```
POST /api/admin/ads/:id
Body: { "action": "preview", "device": "desktop" | "tablet" | "mobile" }

Response (200): { "success": true, "ad": {...}, "preview": { "device": "desktop", "url": "/preview/ad/{slug}?device=desktop" } }
```

### Bulk Operations

```
POST /api/admin/ads/bulk

Body:
{
  "action": "enable",
  "ids": ["507f1f77bcf86cd799439011", "61e2a1b3c4d5e6f78901234"]
}

Valid actions: enable, disable, archive, restore, delete

Response (200):
{
  "success": true,
  "processed": 5,
  "message": "5 advertisements enabled successfully"
}

Validation Error (422):
{
  "success": false,
  "error": "Validation failed",
  "issues": [...]
}
```

---

## Public Advertisement API

### Get Active Ads for Position

```
GET /api/ads/public?position=homepage-hero&limit=1

Query Parameters:
  position (string, required) — kebab-case placement key (e.g., "homepage-hero") or enum value (e.g., "HOMEPAGE_HERO")
  limit (number, optional, default: 1, max: 10)

No authentication required.

Selection Rules — only returns ads where:
- isEnabled == true
- isArchived == false
- isDeleted == false
- startDate <= NOW() (or startDate is null)
- endDate >= NOW() (or endDate is null)
- showDesktop/showTablet/showMobile matches detected device

Sorted by:
- priority ASC (1 = highest)
- displayOrder ASC (0 = first)
- createdAt DESC (fallback tiebreaker)

Response (200):
{
  "success": true,
  "ads": [
    {
      "id": "64f2a3c9e4b0a1d2f3e4a5b6",
      "title": "Find Your Dream Home",
      "type": "HERO_BANNER",
      "action": "BANNER_AND_BUTTON",
      "buttonVariant": "PRIMARY",
      "altText": "Spring sale banner",
      "bannerUrl": null,
      "buttonLabel": "Find Brokers",
      "buttonUrl": "/brokers",
      "openInNewTab": true,
      "isDismissible": false,
      "desktopMedia": {
        "fileUrl": "/uploads/media/abc-123.webp",
        "thumbnailUrl": "/uploads/media/abc-123@200x200.webp",
        "altText": "Spring sale banner",
        "width": 1200,
        "height": 400
      },
      "mobileMedia": null
    }
  ]
}

No ads available:
{
  "success": true,
  "ads": [],
  "message": "No active advertisements for this position"
}

Invalid placement:
{
  "success": false,
  "error": "Invalid placement: unknown-position"
}
```

### Log Impression

```
POST /api/ads/impression
Content-Type: application/json

{
  "advertisementId": "64f2a3c9e4b0a1d2f3e4a5b6",
  "positionKey": "homepage-hero",
  "userId": "user-xyz" (optional)
}

Server automatically captures:
- IP address (SHA-256 hashed)
- User agent
- Referrer
- Page URL
- Country/City (from CDN headers if available)

Deduplication: If same advertisementId receives an impression within 5 seconds, response includes "deduplicated": true.

Response (200):
{
  "success": true
}

Deduplicated response:
{
  "success": true,
  "deduplicated": true
}
```

### Log Click

```
POST /api/ads/click
Content-Type: application/json

{
  "advertisementId": "64f2a3c9e4b0a1d2f3e4a5b6",
  "positionKey": "homepage-hero",
  "userId": "user-xyz" (optional)
}

Server automatically captures:
- IP address (SHA-256 hashed)
- User agent
- Referrer
- Page URL

Response (200):
{
  "success": true,
  "redirectUrl": "/brokers"
}

If no redirect URL is configured:
{
  "success": true,
  "redirectUrl": "/"
}

Event not found (404):
{
  "success": false,
  "error": "Advertisement not found"
}
```

---

## Placement Keys

All 16 supported placement values (accepted as enum or kebab-case):

| Enum Value | Kebab-case Key | Location |
|---|---|---|
| HOMEPAGE_HERO | homepage-hero | Homepage top banner |
| HOMEPAGE_SEARCH | homepage-search | Below search bar |
| HOMEPAGE_FEATURED | homepage-featured | Featured brokers section |
| HOMEPAGE_SERVICES | homepage-services | Services section |
| HOMEPAGE_BANKS | homepage-banks | Bank partners section |
| HOMEPAGE_CTA | homepage-cta | Before main CTA |
| BROKER_LISTING | broker-listing | Broker search results |
| BROKER_PROFILE_HEADER | broker-profile-header | Broker profile header |
| BROKER_LISTING_SIDEBAR | broker-listing-sidebar | Broker listing sidebar |
| LOAN_CALCULATOR | loan-calculator | Calculator page sidebar |
| BLOG_INLINE | blog-inline | Between blog content |
| FOOTER | footer | Above footer |
| ANNOUNCEMENT_TOP | announcement-top | Top sticky bar |
| ANNOUNCEMENT_BOTTOM | announcement-bottom | Bottom sticky bar |
| POPUP_OVERLAY | popup-overlay | Center screen modal |
| MOBILE_HEADER_BANNER | mobile-header-banner | Mobile-only header |

---

## Related Documents

- [DATABASE.md](./DATABASE.md) — Model definitions
- [BACKEND.md](./BACKEND.md) — Architecture and layer descriptions
- [ADMIN.md](./ADMIN.md) — Admin panel capabilities
- [FRONTEND.md](./FRONTEND.md) — Frontend API usage
- [SECURITY.md](./SECURITY.md) — Security measures
- [DISPLAY-RULES.md](./DISPLAY-RULES.md) — Public display logic
- [MEDIA-LIBRARY.md](./MEDIA-LIBRARY.md) — Upload details
- [IMPLEMENTATION-PLAN.md](./IMPLEMENTATION-PLAN.md) — Phased implementation
