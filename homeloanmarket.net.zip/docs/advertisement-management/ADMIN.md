# Admin Panel

## Overview

The admin panel provides a web interface for Platform Admins to manage advertisements and media assets. All admin routes require authentication with admin role.

This document describes the backend capabilities required by the Admin UI. The UI itself (Phase 4.3) will be built using these backend APIs.

## Access Control

Uses existing `UserRole` enum from project schema. Only `ADMIN` role can access the Advertisement Management system.

Authentication is handled via existing `getCurrentUser()` which uses NextAuth sessions.

| UserRole | Can Access Admin | Can Manage Ads | Can Manage Media |
|---|---|---|---|
| USER | No | No | No |
| BROKER | No | No | No |
| ADMIN | Yes | Yes | Yes |

## Navigation

```
Admin Menu
├── Advertisements
│   ├── Overview
│   ├── Advertisements
│   ├── New Advertisement
│   ├── Media Library
│   └── Folders
```

Route structure: `/app/admin/ads/`, `/app/admin/media/`, `/app/admin/ads/new`, `/app/admin/ads/[id]/edit`, `/app/admin/ads/[id]/preview`

## Advertisement Management

### List Advertisements

**API**: `GET /api/admin/ads`

| Query Parameter | Type | Default | Description |
|---|---|---|---|
| page | number | 1 | Page number |
| limit | number | 25 | Items per page (max 100) |
| placement | string | — | Filter by AdvertisementPlacement enum |
| adType | string | — | Filter by AdType enum |
| isEnabled | boolean | — | Filter by enabled status |
| isArchived | boolean | — | Filter by archived status |
| search | string | — | Search by title, slug, description |

#### List Columns

| Column | Source Field | Description |
|---|---|---|
| Checkbox | — | Select for bulk actions |
| Preview | desktopMedia.thumbnailUrl | Thumbnail of ad media |
| Title | `title` | Ad title |
| Type | `type` | Ad type badge |
| Placement | `placement` | AdvertisenumPlacement enum value |
| Enabled | `isEnabled` | Enabled/Disabled toggle |
| Priority | `priority` | Numeric priority (1=highest) |
| Schedule | startDate, endDate | Date range |
| Events | metrics | Impression/click counts |
| Actions | — | Edit, archive, delete |

#### Bulk Actions

**API**: `POST /api/admin/ads/bulk`

| Action | Sets |
|---|---|
| enable | `isEnabled = true` |
| disable | `isEnabled = false` |
| archive | `isArchived = true, isEnabled = false` |
| restore | `isArchived = false` |
| delete | `isDeleted = true, isEnabled = false, isArchived = true` |

#### Quick Stats

- Total Ads
- Published (isEnabled=true, isArchived=false)
- Draft (isEnabled=false, isArchived=false)
- Archived (isArchived=true)

### Create Advertisement

**API**: `POST /api/admin/ads`

### Form Fields

| Field | Frontend Input | Backend Field | Required | Validation |
|---|---|---|---|---|
| Title | TextInput | `title` | Yes | Max 200 chars |
| Description | Textarea | `description` | No | Max 1000 chars |
| Type | Select | `type` | Yes | AdType enum |
| Placement | Select | `placement` | Yes | AdvertisementPlacement enum |
| Action | Select | `action` | Yes | AdvertisementAction enum |
| Button Variant | Select | `buttonVariant` | No | ButtonVariant (default: PRIMARY) |
| Desktop Media | MediaPicker | `desktopMediaId` | No | Must reference existing asset |
| Mobile Media | MediaPicker | `mobileMediaId` | No | Must reference existing asset |
| Alt Text | TextInput | `altText` | No | Max 200 chars |
| Banner URL | TextInput | `bannerUrl` | No | Relative URL |
| Button Label | TextInput | `buttonLabel` | No | Max 50 chars |
| Button URL | TextInput | `buttonUrl` | No | Valid URL |
| Open in New Tab | Toggle | `openInNewTab` | No | Default: true |
| Display Order | NumberInput | `displayOrder` | No | Default: 0 |
| Priority | NumberInput | `priority` | No | 1-100, default: 10 |
| Start Date | DateTimePicker | `startDate` | No | Future date |
| End Date | DateTimePicker | `endDate` | No | After start date |
| Show Desktop | Toggle | `showDesktop` | No | Default: true |
| Show Tablet | Toggle | `showTablet` | No | Default: true |
| Show Mobile | Toggle | `showMobile` | No | Default: true |
| Internal Notes | Textarea | `internalNotes` | No | Admin-only, max 500 chars |
| Is Dismissible | Toggle | `isDismissible` | No | Default: false |
| Enable | Toggle | `isEnabled` | No | Default: false (draft) |

**Slug auto-generation**: The `slug` field is automatically generated from the `title` field during creation. Admin should not set this manually.

### Edit Advertisement

**API**: `PUT /api/admin/ads/:id`

All fields are editable except `slug` (auto-generated, immutable).

### Advertisement Actions

All actions are performed via `POST /api/admin/ads/:id` with an `action` body field:

| Action | API Request | Effect |
|---|---|---|
| Publish | `{ "action": "publish" }` | `isEnabled=true, isArchived=false` |
| Unpublish | `{ "action": "unpublish" }` | `isEnabled=false` |
| Archive | `{ "action": "archive" }` | `isArchived=true, isEnabled=false` |
| Restore | `{ "action": "restore" }` | `isArchived=false, isEnabled=false` |
| Duplicate | `{ "action": "duplicate" }` | Creates copy with new slug, isEnabled=false |
| Delete | `{ "action": "hard_delete" }` | Permanently removes from DB |

### Delete vs Archive

- **Archive** — Ad hidden from pages, preserved in admin with "Archived" filter. Can be restored.
- **Delete (DELETE /:id)** — Sets `isDeleted=true` (soft delete). Cannot be linked to new ads.
- **Hard Delete** — Removes document permanently. Requires explicit confirmation.

## Media Management

### Media Actions

**API endpoints:**

| Action | Endpoint | Method |
|---|---|---|
| List assets | `/api/admin/media` | GET |
| Upload | `/api/admin/media` | POST |
| Get asset | `/api/admin/media/:id` | GET |
| Update metadata | `/api/admin/media/:id` | PUT |
| Soft delete | `/api/admin/media/:id` | DELETE |
| List folders | `/api/admin/media/folders` | GET |
| Create folder | `/api/admin/media/folders` | POST |

### Upload

**API**: `POST /api/admin/media` (multipart form)

Form fields:
- `file` — image file (required, max 10MB, JPEG/PNG/WebP/GIF/SVG)
- `altText` — accessibility description (required)
- `title` — display title (optional)
- `folderId` — folder to place asset (optional)
- `tags` — JSON string array (optional)

The backend handles:
- File validation (MIME type, size)
- Image processing (WebP conversion, thumbnails)
- Database record creation

### Move Asset

**API**: `PUT /api/admin/media/:id` with `{ "folderId": "..." }`

### Update Metadata

**API**: `PUT /api/admin/media/:id` with `{ "title": "...", "altText": "..." }`

### Delete (Soft)

**API**: `DELETE /api/admin/media/:id`

Sets `isDeleted=true`. File remains on disk.

### Restore

Filter by deleted assets, then restore via repository method (`isDeleted=false`).

## Filters

Filterable fields on advertisement list:

| Filter | API Parameter | Options |
|---|---|---|
| Search | `search` | Text search |
| Placement | `placement` | 16 placement keys |
| Ad Type | `adType` | 8 AdType values |
| Enabled | `isEnabled` | true/false |
| Archived | `isArchived` | true/false |

## Search

Search across:
- Advertisement title (`title`)
- Slug (`slug`)
- Description (`description`)
- Internal notes (`internalNotes`)
- Media filename (`fileName`, `originalName`)
- Media alt text (`altText`)

## Phase 4.3B.1 — Advertisement Management UX & Workflow Polish

### Enhanced Create/Edit Form

The create/edit form (`AdvertisementForm`) now includes:

#### Placement Guide
When a placement is selected, shows:
- Page location
- Approximate position
- Visibility (Desktop/Mobile/Both)
- Priority level

#### Placement Specifications
Displays recommended specs for selected placement:
- Recommended Size
- Aspect Ratio
- Maximum File Size
- Supported Formats
- Quality recommendation

#### Image Validation Panel
Automatically validates selected media:
- ✓/⚠/✗ icons for passed/warning/failed
- Width/height check
- Aspect ratio check
- File size check
- Format check
- Alt text check
- Friendly guidance messages

#### Image Metadata Panel
Shows complete media details:
- Filename, folder, dimensions
- Aspect ratio, file size, format
- Alt text, tags
- Uploaded by, upload date

#### Publish Readiness Checklist
Before publish, validates:
- Title present
- Placement selected
- Desktop image selected
- Action type configured
- Schedule set
- Priority set
- URLs configured
- Button configured
- Shows "Ready to Publish" or "Action Required"
- Disables Publish until requirements met

#### Activity Timeline Sidebar
Right sidebar shows:
- Created/Updated timestamps
- Published/Archived/Restored events
- Latest impression/click counts
- Created by / Updated by
- Current status

#### Improved Duplicate Dialog
Administrator can choose:
- New Title
- Copy Images
- Copy Schedule
- Copy Priority
- Copy Status
- Copy Button Settings
- Generate New Slug

#### Improved Archive Dialog
Explains clearly:
- Removes from public pages
- Preserves all data
- Preserves statistics
- Allows future restoration

#### Unsaved Changes UX
- Sticky indicator showing changed fields
- Highlights modified sections
- Prompts only when required

#### Sticky Preview Header
Preview page toolbar with:
- Edit, Publish, Archive, Duplicate, Delete, Back
- Always visible while scrolling

#### Preview Improvements
- Background switcher (Home Light/Dark, Broker Light/Dark, Footer Light/Dark)
- Zoom controls (50%, 75%, 100%, Fit Width)
- Side-by-side desktop/mobile preview on desktop
- Stacked on mobile

### New Components

| Component | Purpose |
|---|---|
| `PlacementGuide` | Placement location information panel |
| `PlacementSpecs` | Recommended specifications panel |
| `ImageValidationPanel` | Intelligent image validation |
| `ImageMetadataPanel` | Complete media metadata display |
| `PublishReadinessChecklist` | Pre-publish validation checklist |
| `ActivityTimeline` | Activity history in sidebar |
| `DuplicateDialog` | Improved duplicate workflow |
| `ArchiveDialog` | Enhanced archive confirmation |
| `placementPreviews.ts` | 16 placement preview configurations |

## Phase 4.3C — Premium Media Library & Asset Management

### Media Library (`/admin/media`)

Complete media asset management interface with:

#### Views
- **Grid View**: Premium cards with preview, metadata, hover actions
- **List View**: Compact table with sticky header, all columns
- **Gallery View**: Pinterest-like masonry layout
- View mode persisted in localStorage

#### Toolbar
- Upload button
- New Folder button
- Search (filename, title, alt text, tags)
- Format filter (PNG, JPEG, WebP, GIF, SVG)
- Folder filter
- Sort (newest, oldest, name, size, dimensions)
- View toggle (grid/list/gallery)
- Refresh button
- Storage usage display
- Selection counter with bulk actions

#### Image Details Drawer
- Large preview
- Complete metadata (filename, dimensions, format, size, tags, dates)
- Usage detection (advertisements using this image)
- Copy URL (relative and full)
- Delete/Restore actions

#### Image Edit Dialog
- Edit title
- Edit alt text
- Preview image

#### Bulk Actions
- Move to folder
- Delete (soft)
- Restore
- Clear selection

### Folder Manager (`/admin/folders`)

Complete folder management interface with:

#### Tree View
- Hierarchical folder tree
- Expand/collapse folders
- Asset count per folder
- Selected folder highlighting

#### Actions
- Create folder (root or nested)
- Rename folder (inline editing)
- Delete folder with confirmation
- Folder statistics

### Upload Dialog

Professional upload experience with:
- Drag & drop
- Browse files
- Paste from clipboard
- Multiple file upload
- Progress bars
- Cancel/remove files
- Alt text input
- Folder selection
- New folder creation
- File validation
- Duplicate detection

### Storage Dashboard

Displays:
- Total images
- Total storage
- Unused images
- Deleted images

### New API Routes

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/admin/media/folders/[id]` | PUT | Rename folder |
| `/api/admin/media/folders/[id]` | DELETE | Delete folder |
| `/api/admin/media/[id]/restore` | POST | Restore deleted asset |
| `/api/admin/media/[id]/move` | POST | Move asset to folder |

## Related Documents

- [DATABASE.md](./DATABASE.md) — Model definitions
- [API.md](./API.md) — API endpoint specifications
- [BACKEND.md](./BACKEND.md) — Architecture overview
- [MEDIA-LIBRARY.md](./MEDIA-LIBRARY.md) — Media management details
- [FRONTEND.md](./FRONTEND.md) — Frontend requirements
- [SECURITY.md](./SECURITY.md) — Security measures
