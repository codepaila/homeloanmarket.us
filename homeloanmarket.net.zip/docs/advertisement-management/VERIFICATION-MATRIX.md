# Advertisement Format Verification Matrix

| Requirement | Documentation | Schema | Implementation | API | Admin UI | Public UI | Tests |
|---|---|---|---|---|---|---|---|
| Format validation | `FORMAT-RESPONSIVE-EXTENSION.md` | `AdvertisementFormat` | `formats.ts` | Create/update validation | Compatible format slots | Resolver fallback | Format unit tests |
| Placement compatibility | Format extension | Placement enum | `PLACEMENT_FORMATS` | Server rejects incompatible assignments | Slots filtered by placement | Compatible resolver | Compatibility tests |
| Existing media selection | Media Library docs | `MediaAsset` | `MediaSelector` | `/api/admin/media` | Responsive creative slots | Media URL DTO | Form-context regression |
| Uploaded media assignment | Media/API docs | Creative relation | Service sync | Admin ad POST/PUT | Upload/select flow | Public resolver | API round-trip |
| Multiple ads | Display rules | Multiple Advertisement rows | Shared carousel | `limit=10` | Existing CRUD | Carousel | UI carousel tests |
| Single ad | Display rules | One row | Direct card | Public API | Existing CRUD | Static card | UI tests |
| Responsive fallback | Format extension | Legacy fields retained | `creativeResolver.ts` | Device-aware response | Mobile/desktop fields | Exact/fallback output | Resolver tests |
| Schedule/status | Display rules | Existing status/date fields | Existing repository predicate | Public endpoint | Existing controls | Public filtering | Lifecycle tests |
| Tracking | API/security docs | `AdEvent` | Existing tracker | Impression/click routes | Existing metrics | Visible creative tracking | Public tracking tests |
| Preview | Admin docs | Existing ad/media relations | Controlled placement preview | Existing preview action | Format selector | Responsive container | Preview/type/build validation |
| Seed integrity | Seed contract | Creative relation | Deterministic upserts | Public response | Media picker data | Multiple formats | Two clean seed runs |

| Top-banner height cap | DISPLAY-RULES sizing contract | No schema field | `FULL_WIDTH_BANNER_DISPLAY` in `placementSpecs.ts` | Reads canonical heights | `Max 150px on desktop` spec panel | Bounded slot (`h-[90px] sm:h-[120px] lg:h-[150px]`) | `phase-15.6-top-banner-height`, placement-size-contract |

Top / full-width banner contract: **desktop maximum 150px, tablet approximately 120px, mobile approximately 90px** (mobile < tablet < desktop). The slot height is owned by exactly one component (`ad-layout.ts`) using complete literal Tailwind classes so the desktop 150px cap is authoritative and no stale 200px desktop rule survives.

## Known Limitations

- Page targeting remains placement-based; no arbitrary URL targeting field was added.
- Media upload processing still follows the existing storage pipeline; this extension does not add a new CDN or variant service.
- Automated browser pixel testing is not configured in the repository; HTTP, render, type, build, and focused unit checks are used instead.
