# Backend Architecture

## Overview

The Advertisement Management backend is a lightweight internal CMS built on the existing HomeLoanMarket Next.js + Prisma MongoDB stack. Platform Admins upload promotional banners and create advertisements that are displayed on public pages.

```
┌─────────────┐     ┌──────────────────┐     ┌──────────────┐
│  Admin UI   │────→│  API Routes      │────→│  MongoDB     │
│  (Next.js)  │     │  (Next.js)       │     │  (Prisma)    │
└─────────────┘     └──────────────────┘     └──────────────┘
                           │  Public API
                           ▼
                    ┌──────────────┐     ┌──────────────┐
                    │  Public      │     │  AdRenderer  │
                    │  Endpoints   │     │  (Frontend)  │
                    └──────────────┘     └──────────────┘
```

## Folder Structure

```
lib/advertisements/
├── types.ts                 # TypeScript types matching Prisma models
├── dto.ts                   # DTO interfaces for requests/responses
├── validation.ts            # Zod validation schemas
├── utils.ts                 # Utility functions (slug, filename, dates, IP, device)
├── imageProcessor.ts        # Sharp-based image processing
├── mediaRepository.ts       # Data access: MediaFolder, MediaAsset
├── advertisementRepository.ts # Data access: Advertisement, AdEvent
└── services.ts              # Business logic: MediaService, AdvertisementService

app/api/
├── admin/
│   ├── media/
│   │   ├── route.ts          # GET (list), POST (upload)
│   │   └── [id]/route.ts     # GET, PUT, DELETE
│   ├── media/folders/
│   │   └── route.ts          # GET (tree), POST (create)
│   ├── ads/
│   │   ├── route.ts          # GET (list), POST (create)
│   │   └── [id]/route.ts     # GET, PUT, DELETE, POST (actions)
│   └── ads/bulk/
│       └── route.ts          # POST (bulk actions)
└── ads/
    ├── public/route.ts       # GET (serve active ads)
    ├── impression/route.ts   # POST (track impressions)
    └── click/route.ts        # POST (track clicks)
```

## Architecture Layers

### Repository Layer

Data access layer that abstracts Prisma queries. No business logic.

**MediaRepository** (13 methods):
- `findFolders`, `findFolderTree` — reads with `_count` aggregation
- `findAssets`, `findAsset`, `findAssetByUrl` — with search and filtering
- `findDeletedAssets` — for restore UI
- `createFolder`, `updateFolder`, `deleteFolder` — folder CRUD
- `renameAsset`, `moveAsset` — asset metadata operations
- `softDeleteAsset`, `restoreAsset`, `hardDeleteAsset` — delete lifecycle

**AdvertisementRepository** (16 methods):
- `findMany`, `findById`, `findBySlug` — reads with includes and pagination
- `create`, `update` — mutations
- `publish`, `unpublish`, `archive`, `restore` — status transitions
- `softDelete`, `hardDelete` — delete lifecycle
- `duplicate` — copies ad with new slug
- `findActiveByPlacement` — public display query with filters and sort
- `bulkUpdate` — bulk actions
- `findDeleted` — for restore UI

**AdEventRepository** (3 methods):
- `create` — logs impression/click events
- `countByAdvertisement` — returns impression + click counts
- `getStats` — aggregated stats with optional filters

### Service Layer

Business logic layer that validates inputs, enforces rules, and calls repositories.

**MediaService**:
- Validates folder existence before operations
- Wraps `createMediaAsset()` from imageProcessor
- Checks asset existence before update/delete/restore
- Delegates to MediaRepository for all DB operations

**AdvertisementService**:
- `create()` — auto-generates unique slug, validates media references exist
- `update()` — validates ad exists before update
- `publish()` — sets `isEnabled=true, isArchived=false`
- `archive()` — sets `isArchived=true, isEnabled=false`
- `restore()` — sets `isArchived=false, isEnabled=false`
- `duplicate()` — copies ad, new slug, `isEnabled=false`
- `bulkAction()` — dispatches enable/disable/archive/restore/delete
- `findActiveAds()` — calls repository with device-aware filtering
- `recordImpression()`, `recordClick()` — logs tracking events
- `getStats()` — retrieves ad metrics

### Validation Layer

Uses Zod schemas (already available in project). All input is validated before processing.

| Schema | Validates |
|---|---|
| `CreateMediaFolderSchema` | Folder name (1-100 chars), optional parentId |
| `UploadMediaSchema` | Alt text (required), optional title/description/folderId |
| `CreateAdSchema` | Title (required), placement (enum), type (enum), action (enum), priority (1-100), dates, URLs |
| `UpdateAdSchema` | Partial version of CreateAdSchema |
| `AdQuerySchema` | Page, limit, placement, adType, isEnabled, search |
| `BulkAdActionSchema` | Action enum, non-empty IDs array |
| `ImpressionSchema` | Required advertisementId, optional metadata |
| `ClickSchema` | Required advertisementId, optional metadata |

### Utility Layer

**utils.ts** exports:
- `slug(text)` — converts text to URL-safe slug (kebab-case)
- `generateUniqueSlug(title)` — ensures slug uniqueness in DB
- `sanitizeFileName(name)` — sanitizes filenames
- `isImageMime(mimeType)` — validates image MIME types
- `getImageExtension(mimeType)` — maps MIME to extension
- `getDeviceType(headers)` — detects desktop/tablet/mobile from User-Agent
- `getClientIP(headers)` — extracts IP from request headers
- `hashIP(ip)` — SHA-256 hashes IP for privacy
- `isDateWithinRange(start, end, now)` — checks if date falls within range
- `getPublicUrl(fileUrl)` — converts relative URL to absolute

### Image Processing Layer

**imageProcessor.ts** handles the complete upload pipeline:

1. **`validateUpload(file)`** — checks file exists, size (max 10MB), MIME type
2. **`processImage(file)`** — uses Sharp to:
   - Convert to WebP at quality 85 (preserves SVG as-is)
   - Generate 200×200 thumbnail
   - Generate 400px, 800px, 1200px responsive variants (stored in filename)
   - Extract width/height from metadata
   - Return relative URLs (`/uploads/media/{id}.webp`)
3. **`createMediaAsset(data)`** — full pipeline: validate → process → save file → create DB record

Storage: All images saved to `public/uploads/media/` with relative URLs stored in DB.

## Media Flow

```
Admin uploads image → POST /api/admin/media (multipart)
  → MediaService.upload()
    → imageProcessor.createMediaAsset()
      → validateUpload()     [size, MIME check]
      → processImage()       [Sharp: WebP, thumbnails, dimensions]
      → prisma.mediaAsset.create()  [store relative URLs in MongoDB]
  → Returns { success: true, asset: {...} }
```

## Advertisement Flow

```
Admin creates ad → POST /api/admin/ads
  → AdvertisementService.create()
    → generateUniqueSlug(title)    [check uniqueness]
    → MediaRepository.findAsset()   [validate mediaId references]
    → AdvertisementRepository.create()  [insert document]
  → Returns { success: true, ad: {...} }

Admin publishes → POST /api/admin/ads/:id with { action: "publish" }
  → AdvertisementService.publish()
    → AdvertisementRepository.publish()  [isEnabled=true, isArchived=false]

Public page loads → GET /api/ads/public?position=homepage-hero
  → AdvertisementService.findActiveAds()
    → AdvertisementRepository.findActiveByPlacement()
      → Filters: isEnabled=true, isArchived=false, isDeleted=false, date range
      → Sort: priority ASC, displayOrder ASC, createdAt DESC
      → Returns PublicAdResponse array
```

## Event Tracking Flow

```
Frontend renders ad → fires POST /api/ads/impression
  → Deduplicates: same adId within 5 seconds → deduplicated response
  → AdvertisementService.recordImpression()
    → AdEventRepository.create() → INSERT ad_event document

Frontend detects click → fires POST /api/ads/click
  → AdvertisementService.recordClick()
    → AdEventRepository.create() → INSERT ad_event document
    → Returns redirectUrl from buttonUrl or bannerUrl

Admin views ad detail → GET /api/admin/ads/:id
  → AdvertisementService.getById()
    → AdvertisementRepository.findById()
    → AdvertisementService.getStats() → AdEventRepository.countByAdvertisement()
  → Returns ad + metrics { impressions, clicks }
```

## Authentication & Authorization

All admin routes reuse the existing HomeLoanMarket authentication:

```typescript
import { getCurrentUser } from "@/lib/currentUser"
import prisma from "@/lib/prisma"

const user = await getCurrentUser()
if (!user || user.role !== "ADMIN") {
  return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
}
```

- Uses existing NextAuth session via `getCurrentUser()`
- Reuses existing `UserRole.ADMIN` enum value
- No new auth models or tables created
- Public routes have no auth check

## Error Handling

Consistent response format:
```json
// Success: { success: true, ...data }
// Error:   { success: false, error: "message" }
```

| Status | Meaning | Trigger |
|---|---|---|
| 400 | Bad Request | Missing required field, invalid input |
| 401 | Unauthorized | Not authenticated or not ADMIN |
| 404 | Not Found | Asset/ad/folder not found |
| 409 | Conflict | Duplicate slug |
| 422 | Validation Error | Zod schema validation failure |
| 500 | Internal Error | Unexpected server error |

## Related Documents

- [DATABASE.md](./DATABASE.md) — Prisma schema
- [API.md](./API.md) — Endpoint specifications
- [MEDIA-LIBRARY.md](./MEDIA-LIBRARY.md) — Media management
- [ADMIN.md](./ADMIN.md) — Admin capabilities
- [SECURITY.md](./SECURITY.md) — Security measures
- [DISPLAY-RULES.md](./DISPLAY-RULES.md) — Public display logic
