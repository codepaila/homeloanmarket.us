# Display Rules

## Overview

Public advertisement display rules determine which ads are served at each placement position. These rules are enforced by the backend — the frontend simply requests ads for a position and renders what is returned.

## Selection Criteria

The `GET /api/ads/public?position=<key>` endpoint returns ads that satisfy ALL of the following conditions:

| Rule | Operator | Description |
|---|---|---|
| `isEnabled` | Equals | `true` — only enabled ads are served |
| `isArchived` | Equals | `false` — archived ads are hidden |
| `isDeleted` | Equals | `false` — deleted ads are hidden |
| `startDate` | `<= NOW()` | Null = immediately available |
| `endDate` | `>= NOW()` | Null = no expiration |
| `showDesktop` / `showTablet` / `showMobile` | Device match | Only return ad if current device is enabled |

## Sorting Order

Returned ads are sorted by:

1. **`priority` ASC** — Priority 1 (highest) appears before Priority 100 (lowest)
2. **`displayOrder` ASC** — Lower numbers appear first (0 = first)
3. **`createdAt DESC`** — Newer ads win ties on priority and display order

## Placement Selection

Clients pass a placement key as the `position` query parameter. The backend accepts both enum values and kebab-case keys, mapped via the `DEVICE_KEY_MAP`:

```typescript
const DEVICE_KEY_MAP = {
  "homepage-hero": AdvertisementPlacement.HOMEPAGE_HERO,
  "homepage-search": AdvertisementPlacement.HOMEPAGE_SEARCH,
  // ... all 16 placements
}
```

When multiple ads exist for the same placement, the sorting rules above determine which are returned first. The `limit` parameter (default 1, max 10) controls how many are returned.

## Fallback Behavior

- If no ads match the criteria → empty `ads: []` array returned
- Frontend components render nothing (collapse gracefully) or show fallback content
- No "ad block" placeholder or error message

## Device Targeting

Based on `User-Agent` header, the backend detects device type and filters ads by the corresponding `show{Device}` boolean:

| Device Type | Detected From | Filter Field |
|---|---|---|
| desktop | User-Agent | `showDesktop` |
| tablet | User-Agent | `showTablet` |
| mobile | User-Agent | `showMobile` |

Only ads where the matching boolean is `true` will be returned.

## All Placement Keys

### Homepage Placements

| Key (kebab-case) | Enum Value | Description |
|---|---|---|
| `homepage-hero` | `HOMEPAGE_HERO` | Full-width hero banner at top of homepage |
| `homepage-search` | `HOMEPAGE_SEARCH` | Below search bar on homepage |
| `homepage-featured` | `HOMEPAGE_FEATURED` | Featured brokers section |
| `homepage-services` | `HOMEPAGE_SERVICES` | Services section |
| `homepage-banks` | `HOMEPAGE_BANKS` | Bank partner logos section |
| `homepage-cta` | `HOMEPAGE_CTA` | Call-to-action before main content |

### Broker Pages

| Key (kebab-case) | Enum Value | Description |
|---|---|---|
| `broker-listing` | `BROKER_LISTING` | Broker search results page |
| `broker-profile-header` | `BROKER_PROFILE_HEADER` | Top of broker profile page |
| `broker-listing-sidebar` | `BROKER_LISTING_SIDEBAR` | Sidebar on broker listing page |

### Other Pages

| Key (kebab-case) | Enum Value | Description |
|---|---|---|
| `loan-calculator` | `LOAN_CALCULATOR` | Calculator page sidebar |
| `blog-inline` | `BLOG_INLINE` | Between blog content |
| `footer` | `FOOTER` | Above footer content |
| `announcement-top` | `ANNOUNCEMENT_TOP` | Sticky bar at top of viewport |
| `announcement-bottom` | `ANNOUNCEMENT_BOTTOM` | Sticky bar at bottom of viewport |

### Modal & Mobile

| Key (kebab-case) | Enum Value | Description |
|---|---|---|
| `popup-overlay` | `POPUP_OVERLAY` | Center-screen modal (shows once per session via cookie) |
| `mobile-header-banner` | `MOBILE_HEADER_BANNER` | Mobile-only header banner |

## Ad Types

Each ad has a `type` field that determines its rendering behavior:

| AdType | Description |
|---|---|
| `HERO_BANNER` | Full-width hero image |
| `SECTION_BANNER` | Mid-content section banner |
| `INLINE` | In-content inline placement |
| `SIDEBAR` | Fixed-width sidebar box |
| `FOOTER` | Low-height footer banner |
| `SPONSORED` | Sponsored badge overlay |
| `POPUP` | Modal dialog with close button |
| `ANNOUNCEMENT` | Thin sticky announcement bar |

## Click & Banner Actions

The `action` field determines interactivity:

| Action | bannerUrl clickable | buttonUrl clickable |
|---|---|---|
| `BANNER_CLICK` | Yes | No |
| `BUTTON_ONLY` | No | Yes |
| `BANNER_AND_BUTTON` | Yes | Yes |
| `DISPLAY_ONLY` | No | No |

## Impression & Click Tracking

- Impressions are deduplicated: same `advertisementId` within 5 seconds is not double-counted
- Clicks are logged on every valid click
- Both send `navigator.sendBeacon()` (non-blocking, fire-and-forget)
- Redirect happens immediately after click event is queued

## Slot Sizing Contract

Slot dimensions are canonical in `lib/advertisements/placementSpecs.ts` and applied by a single component (`components/advertisements/ad-layout.ts`). No public advertisement sizes itself from its natural image dimensions; every creative is contained (`object-contain`) inside its bounded slot.

### Top / full-width banner (homepage-hero, homepage-search, homepage-featured, homepage-services, homepage-banks, homepage-cta, broker-listing, broker-profile-header, loan-calculator, blog-inline)

The top full-width banner is a compact premium announcement strip, not a tall hero:

| Device | Maximum displayed height |
|---|---|
| Desktop | 150px |
| Tablet | approximately 120px |
| Mobile | approximately 90px |

- Heights always descend `mobile < tablet < desktop`.
- Full width is preserved (`mx-auto w-full max-w-[1280px]`) with `overflow-hidden`.
- Creatives use `object-contain` so they are never cropped or distorted.
- The slot classes must exist as complete literal strings (`h-[90px] sm:h-[120px] lg:h-[150px]`) in `ad-layout.ts`; classes built from template interpolation are not compiled by Tailwind v4 and silently remove the height cap.

### Other placements

Sidebar, footer, announcement, popup, and mobile-header placements keep their own canonical display heights defined per placement in `PLACEMENT_SIZE_SPECS` (e.g. announcement bars are ultra-short at 50/60/70, footer at 60/70/80). Changing the top-banner contract must not alter these.

## Related Documents

- [API.md](./API.md) — Public API specification
- [BACKEND.md](./BACKEND.md) — Backend architecture
