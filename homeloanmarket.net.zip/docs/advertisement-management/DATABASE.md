# Database Architecture

## Overview

This document defines the Prisma MongoDB schema for the Advertisement Management System. All models follow existing HomeLoanMarket conventions (ObjectId Primary Keys, `@@map`, timestamp patterns). New collections are added alongside existing ones — the existing `User` collection is not modified structurally.

## Conventions (Matches Existing Project)

```prisma
id  String  @id @default(auto()) @map("_id") @db.ObjectId
@@map("collection_name")
createdAt DateTime @default(now())
updatedAt DateTime @updatedAt
foreignKey String @db.ObjectId
```

## Enums

### AdvertisementPlacement

16 placement enum values matching the README's supported placements:

```prisma
enum AdvertisementPlacement {
  HOMEPAGE_HERO
  HOMEPAGE_SEARCH
  HOMEPAGE_FEATURED
  HOMEPAGE_SERVICES
  HOMEPAGE_BANKS
  HOMEPAGE_CTA
  BROKER_LISTING
  BROKER_PROFILE_HEADER
  BROKER_LISTING_SIDEBAR
  LOAN_CALCULATOR
  BLOG_INLINE
  FOOTER
  ANNOUNCEMENT_TOP
  ANNOUNCEMENT_BOTTOM
  POPUP_OVERLAY
  MOBILE_HEADER_BANNER
}
```

### AdvertisementAction

Defines how an ad interacts with the user:

```prisma
enum AdvertisementAction {
  DISPLAY_ONLY      // Static display, no click actions
  BANNER_CLICK      // Entire banner is clickable
  BUTTON_ONLY       // Only CTA button is clickable
  BANNER_AND_BUTTON // Both banner and CTA button are clickable
}
```

### AdType

```prisma
enum AdType {
  HERO_BANNER
  SECTION_BANNER
  INLINE_BANNER
  SIDEBAR_BANNER
  FOOTER_BANNER
  SPONSORED_BANNER
  POPUP_CAMPAIGN
  ANNOUNCEMENT_BAR
}
```

### ButtonVariant

```prisma
enum ButtonVariant {
  PRIMARY
  SECONDARY
  OUTLINE
  GHOST
}
```

### EventType

```prisma
enum EventType {
  IMPRESSION
  CLICK
}
```

## Models

### MediaFolder

Organizes media assets in a simple folder hierarchy.

```prisma
model MediaFolder {
  id        String  @id @default(auto()) @map("_id") @db.ObjectId
  name      String
  path      String  @unique
  parentId  String? @db.ObjectId

  parent    MediaFolder?   @relation("FolderHierarchy", fields: [parentId], references: [id], onDelete: NoAction, onUpdate: NoAction)
  children  MediaFolder[]  @relation("FolderHierarchy")
  assets    MediaAsset[]

  isDeleted Boolean @default(false)

  createdAt DateTime @default(now())
  updatedAt DateTime @default(now()) @updatedAt

  @@index([parentId])
  @@index([isDeleted])
  @@map("media_folders")
}
```

### MediaAsset

Stores uploaded image files with metadata and optimized variants.

```prisma
model MediaAsset {
  id            String   @id @default(auto()) @map("_id") @db.ObjectId
  title         String?
  fileName      String    // Filename on disk (e.g., "hero-banner.webp")
  originalName  String    // Original uploaded filename
  fileUrl       String    // Relative URL path (e.g., "/uploads/media/banner.webp")
  thumbnailUrl  String?   // Relative URL to thumbnail variant
  mimeType      String    // e.g., "image/webp", "image/jpeg"
  extension     String    // File extension without dot (e.g., "webp")
  fileSize      Int       // File size in bytes
  width         Int?      // Image width in pixels
  height        Int?      // Image height in pixels
  altText       String?   // Accessibility description
  tags          String[]  @default([]) // Searchable tags

  // Relations
  folderId      String?   @db.ObjectId
  uploaderId    String    @db.ObjectId

  folder        MediaFolder?  @relation(fields: [folderId], references: [id], onDelete: NoAction, onUpdate: NoAction)
  uploader      User          @relation("UploadedMedia", fields: [uploaderId], references: [id], onDelete: NoAction, onUpdate: NoAction)

  desktopAdvertisements Advertisement[] @relation("DesktopMedia")
  mobileAdvertisements  Advertisement[] @relation("MobileMedia")

  // Soft delete
  isDeleted     Boolean  @default(false)

  // Timestamps
  createdAt     DateTime @default(now())
  updatedAt     DateTime @default(now()) @updatedAt

  // Indexes
  @@index([fileUrl])
  @@index([uploaderId])
  @@index([folderId])
  @@index([isDeleted])
  @@map("media_assets")
}
```

### Advertisement

Defines a banner ad with content, placement, and scheduling.

```prisma
model Advertisement {
  id              String                 @id @default(auto()) @map("_id") @db.ObjectId
  title           String
  slug            String                 @unique // Auto-generated from title; admin should not set manually
  description     String?
  placement       AdvertisementPlacement
  type            AdType
  action          AdvertisementAction
  buttonVariant   ButtonVariant          @default(PRIMARY)

  // Media
  desktopMediaId  String?                @db.ObjectId
  mobileMediaId   String?                @db.ObjectId

  // Content
  altText         String?
  bannerUrl       String?                // Relative URL as fallback if no media asset
  buttonLabel     String?
  buttonUrl       String?
  openInNewTab    Boolean                @default(true)
  internalNotes   String?                // Admin-only notes (never shown publicly)
  isDismissible   Boolean                @default(false) // Show dismiss button (Announcement Bar, Popup)

  // Display control
  displayOrder    Int                    @default(0)  // Order within same placement (0 = first)
  priority        Int                    @default(10) // 1 = highest, 100 = lowest

  // Scheduling
  startDate       DateTime?              // When ad becomes active (null = immediately)
  endDate         DateTime?              // When ad stops (null = no end)

  // Status
  isEnabled       Boolean                @default(false)
  isArchived      Boolean                @default(false)
  showDesktop     Boolean                @default(true)
  showTablet      Boolean                @default(true)
  showMobile      Boolean                @default(true)

  // Audit
  createdById     String                 @db.ObjectId
  updatedById     String?                @db.ObjectId

  // Relations
  desktopMedia    MediaAsset?            @relation("DesktopMedia", fields: [desktopMediaId], references: [id], onDelete: NoAction, onUpdate: NoAction)
  mobileMedia     MediaAsset?            @relation("MobileMedia", fields: [mobileMediaId], references: [id], onDelete: NoAction, onUpdate: NoAction)
  createdBy       User                   @relation("CreatedBy", fields: [createdById], references: [id], onDelete: NoAction, onUpdate: NoAction)
  updatedBy       User?                  @relation("UpdatedBy", fields: [updatedById], references: [id], onDelete: NoAction, onUpdate: NoAction)

  events          AdEvent[]

  // Soft delete
  isDeleted       Boolean                @default(false)

  // Timestamps
  createdAt       DateTime               @default(now())
  updatedAt       DateTime               @default(now()) @updatedAt

  // Indexes
  @@index([placement, displayOrder])
  @@index([priority])
  @@index([startDate, endDate])
  @@index([createdById])
  @@index([isDeleted])
  @@map("advertisements")
  @@map("advertisements")
}
```

### AdEvent

Records individual ad impressions and clicks.

```prisma
model AdEvent {
  id              String     @id @default(auto()) @map("_id") @db.ObjectId
  advertisementId String     @db.ObjectId
  eventType       EventType

  // Context
  ipAddress       String?
  userAgent       String?
  referrer        String?
  page            String?
  country         String?
  city            String?

  // Relations
  advertisement   Advertisement @relation(fields: [advertisementId], references: [id], onDelete: Cascade)

  // Timestamp
  createdAt       DateTime   @default(now())

  // Indexes
  @@index([advertisementId, eventType])
  @@index([createdAt])
  @@index([country])
  @@map("ad_events")
}
```

## Soft Delete Strategy

All CMS models use a simple `isDeleted` boolean field for soft delete:

```
DELETE operation → Sets isDeleted = true
Read operations → Filters WITH deleted: false (query-level filtering)
Restore operation → Sets isDeleted = false
```

**Fields on every CMS collection:**
- `isDeleted` — Boolean, default false

**Hard delete** is available as a separate admin action for compliance cleanup.

## Relations Summary

```
User → MediaAsset (uploader) — has many
User → Advertisement (createdBy) — has many
User → Advertisement (updatedBy) — has many (optional)
MediaFolder → MediaAsset (folder) — has many
MediaAsset → Advertisement (desktopMedia) — has many
MediaAsset → Advertisement (mobileMedia) — has many
Advertisement → AdEvent (events) — has many
```

## Indexes

| Collection | Fields | Purpose |
|---|---|---|
| media_folders | `parentId` | Folder hierarchy tree |
| media_folders | `isDeleted` | Filtering deleted folders |
| media_assets | `fileUrl` | Asset retrieval by URL |
| media_assets | `uploaderId` | User-scoped queries |
| media_assets | `folderId` | Folder-scoped queries |
| media_assets | `isDeleted` | Media library filtering |
| advertisements | `placement, displayOrder` | Position-based ad selection and ordering |
| advertisements | `priority` | Priority-based ad selection |
| advertisements | `startDate, endDate` | Schedule filtering |
| advertisements | `createdById` | Admin-scoped queries |
| advertisements | `isDeleted` | Filtered queries for active ads |
| ad_events | `advertisementId, eventType` | Event queries |
| ad_events | `createdAt` | Time-based queries |

## Collection Names

| Model | Collection |
|---|---|
| MediaFolder | `media_folders` |
| MediaAsset | `media_assets` |
| Advertisement | `advertisements` |
| AdEvent | `ad_events` |

## Reusable Existing Models

The following existing models/enums are reused unchanged:

| Existing Entity | Usage |
|---|---|
| `User` | `MediaAsset.uploader` and `Advertisement.createdBy`/`updatedBy` relations |
| `UserRole` | Access control (only `ADMIN` role can access the system) |
| `Account` | OAuth authentication for admin sessions |

**User model additions (minor, additive only):**
- `uploadedMedia MediaAsset[]` — back-reference for uploaded assets
- `createdAds Advertisement[]` — back-reference for created ads
- `updatedAds Advertisement[]` — back-reference for updated ads

No existing fields are modified, removed, or renamed on the User model.

## Validation & Generation

```bash
# Schema validation
npx prisma validate
# Result: ✅ Schema is valid

# Client generation
npx prisma generate
# Result: ✅ Client generated successfully
```

## Related Documents

- [README.md](./README.md) — System overview
- [MEDIA-LIBRARY.md](./MEDIA-LIBRARY.md) — Upload workflow
- [ADMIN.md](./ADMIN.md) — Admin panel
- [API.md](./API.md) — API endpoints
- [FRONTEND.md](./FRONTEND.md) — Rendering
- [IMPLEMENTATION-PLAN.md](./IMPLEMENTATION-PLAN.md) — Phased implementation
- [CHANGELOG.md](./CHANGELOG.md) — Documentation history
