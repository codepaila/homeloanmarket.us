# Advertisement Management System

## Purpose

The Advertisement Management System is a simple internal CMS that lets Platform Admins upload promotional banners and display them on HomeLoanMarket's public pages. This is an internal tool only — no external advertisers, no payments, no bidding.

## Features

- **Ad Creation**: Upload images and configure banner ads
- **Media Library**: Centralized asset management with folder organization
- **Multi-Position**: 16 supported display positions across the site
- **Archiving**: Hide ads without deleting (soft delete)
- **Admin Panel**: Web interface for managing ads and media
- **Frontend Renderer**: React component for displaying ads on pages
- **Responsive**: Desktop and mobile rendering
- **Dark Mode**: Automatic dark mode support
- **Lazy Loading**: Non-blocking ad rendering

## Architecture Overview

```
┌─────────────┐     ┌──────────────┐     ┌──────────────┐
│  Admin UI   │────→│  API Routes  │────→│   MongoDB    │
│  (Next.js)  │     │  (Next.js)   │     │  (Prisma)    │
└─────────────┘     └──────────────┘     └──────────────┘
                           │
                           ▼
                    ┌──────────────┐     ┌──────────────┐
                    │  Media Store │     │  AdRenderer  │
                    │  (Local/S3)  │     │  (Frontend)  │
                    └──────────────┘     └──────────────┘
```

**Components:**
- **MediaAsset**: Image files stored in local filesystem (future: S3)
- **Advertisement**: Banner configuration linked to a MediaAsset
- **Admin Panel**: Full CRUD for ads and media
- **AdRenderer**: Frontend component placed on public pages
- **Public API**: Serves active ads to the frontend

## Folder Structure

```
docs/advertisement-management/
├── README.md                 # This file
├── DATABASE.md               # Prisma schema definitions
├── MEDIA-LIBRARY.md          # Upload/organize/manage assets
├── ADMIN.md                  # Admin panel functionality
├── FRONTEND.md               # AdRenderer component and rendering
├── API.md                    # REST API endpoint specifications
├── IMPLEMENTATION-PLAN.md    # Phased rollout
└── CHANGELOG.md              # Documentation history
```

## Advertisement Lifecycle

```
Draft → Published → Archived → Deleted
   ↘       ↗         ↘          ↗
  (edit)        (restore)   (soft delete)
```

| State | Description |
|---|---|
| Draft | Created but not yet published. Not visible on public pages. |
| Published | Visible on public pages. Can be archived or edited. |
| Archived | Hidden from pages. Can be restored or deleted. |
| Deleted | Soft-deleted (isDeleted=true). Removed from all views. |

## Supported Placements

Ads are assigned to one or more placement keys representing positions on the site:

| # | Placement Key | Location | Ad Type |
|---|---|---|---|
| 1 | `homepage-hero` | Homepage top banner | HERO_BANNER |
| 2 | `homepage-search` | Below search bar | INLINE_BANNER |
| 3 | `homepage-featured` | Featured brokers section | SECTION_BANNER |
| 4 | `homepage-services` | Services section | SECTION_BANNER |
| 5 | `homepage-banks` | Bank partners section | INLINE_BANNER |
| 6 | `homepage-cta` | Before main CTA | HERO_BANNER |
| 7 | `broker-listing` | Broker search results sidebar | SIDEBAR_BANNER |
| 8 | `broker-profile-header` | Broker profile header | SPONSORED_BANNER |
| 9 | `broker-listing-sidebar` | Broker listing sidebar | SIDEBAR_BANNER |
| 10 | `loan-calculator` | Calculator page sidebar | SIDEBAR_BANNER |
| 11 | `blog-inline` | Between blog content | INLINE_BANNER |
| 12 | `footer` | Above footer | FOOTER_BANNER |
| 13 | `announcement-top` | Top of viewport (sticky) | ANNOUNCEMENT_BAR |
| 14 | `announcement-bottom` | Bottom of viewport (sticky) | ANNOUNCEMENT_BAR |
| 15 | `popup-overlay` | Center screen modal | POPUP_CAMPAIGN |
| 16 | `mobile-header-banner` | Mobile-only header | HERO_BANNER |

## Simple Workflow

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  Upload  │ →  │  Create  │ →  │  Preview │ →  │ Publish  │
│  Media   │    │  Ad      │    │  Ad      │    │  Ad      │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
                                              ↓
                                       ┌──────────┐
                                       │  Serve   │
                                       │  on Site │
                                       └──────────┘
                                              ↓
                                       ┌──────────┐
                                       │ Archive  │
                                       │ Restore  │
                                       └──────────┘
```

## Related Documents

- [DATABASE.md](./DATABASE.md) — Prisma schema definitions
- [MEDIA-LIBRARY.md](./MEDIA-LIBRARY.md) — Media upload and management
- [ADMIN.md](./ADMIN.md) — Admin panel features
- [FRONTEND.md](./FRONTEND.md) — Ad rendering on public pages
- [API.md](./API.md) — REST API endpoints
- [IMPLEMENTATION-PLAN.md](./IMPLEMENTATION-PLAN.md) — Phased rollout
- [CHANGELOG.md](./CHANGELOG.md) — Documentation history
