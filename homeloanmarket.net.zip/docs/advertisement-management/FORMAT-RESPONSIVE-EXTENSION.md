# Responsive Advertisement Format Extension

## Audit Summary

The original advertisement documentation is archived in `docs/advertisement-management.zip`. It describes the original 16-placement CMS, eight semantic `AdType` values, two legacy media slots, scheduling, device flags, and placement-as-page-targeting.

The live implementation was compared against every archived advertisement document before this extension. The important gaps were:

- `Advertisement` had only `desktopMediaId` and `mobileMediaId`; it could not store format-specific creatives.
- Placement specifications were advisory only and were not persisted or enforced by the API.
- `AdType` described behavior/location, not creative geometry.
- Multiple advertisements per placement were supported by the API, but the admin form had no format assignment and public selection had no format resolver.
- There is no separate page-target model. The existing placement enum is the page/position target.
- The archived frontend documentation listed specialized renderers that are no longer the live public architecture.
- Archived media documentation claims 400/800/1200 variants and IP hashing, but the live implementation currently stores the processed asset/thumbnail and captures the value returned by `getClientIP`.

## Audit Matrix

| Requirement | Documentation | Schema | API | Admin Form | Public Renderer | Status |
|---|---|---|---|---|---|---|
| Semantic ad types | 8 `AdType` values | `AdType` enum | Validated by Zod | Type selector | Resolver accepts all | Supported |
| Placement targeting | 16 placement values | `placement` enum | Public/admin filters | Placement selector | Placement resolver | Supported |
| Page targeting | Placement implied page | No separate field | No separate field | No separate field | Placement is page target | Explicit limitation |
| Multiple ads per placement | Documented as ordered list | Multiple rows allowed | `limit` up to 10 | One ad per form | Carousel | Supported |
| Desktop/mobile creatives | Two legacy fields | `desktopMediaId`, `mobileMediaId` | Existing fields preserved | Existing selectors preserved | Legacy fallback | Supported |
| Format-specific creatives | Not represented | `AdvertisementCreative` relation | `creativeAssignments` | Format-aware slots | Exact/fallback resolver | Added |
| HORIZONTAL / VERTICAL / SQUARE / RECTANGLE / MOBILE | Not represented | `AdvertisementFormat` enum | Validated assignments | Placement-compatible slots | Format-aware resolution | Added |
| Scheduling | `startDate`/`endDate` | Existing fields | Active query | Date inputs | Active query | Supported |
| Responsive visibility | Device booleans | `showDesktop`, `showTablet`, `showMobile` | User-agent filtering | Visibility toggles | Device resolver | Supported |
| Media upload/selection | Media Library | `MediaAsset` | Admin media APIs | Shared `MediaSelector` | Media URL output | Supported |
| Carousel | Prior gap | No schema needed | Returns multiple ads | No admin change required | Shared carousel | Added |
| Impression/click analytics | `AdEvent` | Existing model | Public endpoints | Admin metrics | Visible-ad tracking | Supported |
| Admin authorization | ADMIN-only | Existing `UserRole` | Admin routes guarded | Existing routes | Public routes unauthenticated | Supported |
| Responsive preview | Documented but natural-height in places | N/A | Existing preview action | Existing preview upgraded | Controlled placement container | Added |

## Format Architecture

`AdvertisementFormat` is a creative geometry, not a replacement for `AdType`:

- `HORIZONTAL`: wide banners, normally 2:1 through 4:1.
- `VERTICAL`: sidebar/rail portraits, normally 2:3 through 1:2.
- `SQUARE`: 1:1 card/grid creative.
- `RECTANGLE`: standard 4:3 through 3:2 promotional creative.
- `MOBILE`: mobile-specific banner or portrait creative.

`AdvertisementCreative` links one advertisement to one non-deleted `MediaAsset` and one format. A format may be assigned once per advertisement. Existing desktop/mobile fields remain for backward compatibility.

## Resolution Strategy

1. Select the exact compatible format for the requested placement/device.
2. Select the next compatible format configured for that placement.
3. Fall back to legacy mobile media on mobile.
4. Fall back to legacy desktop media.
5. Fall back to the legacy banner URL.
6. Render nothing when no creative exists.

## Responsive Slot Heights

Every horizontal placement renders inside a bounded slot whose height is controlled by one component (`components/advertisements/ad-layout.ts`), driven by the canonical `display` triple in `lib/advertisements/placementSpecs.ts`. The full-width top banner strip is capped at:

| Device | Maximum displayed height |
|---|---|
| Desktop | 150px |
| Tablet | approximately 120px |
| Mobile | approximately 90px |

The slot classes are emitted as complete literal strings (`h-[90px] sm:h-[120px] lg:h-[150px]`) so Tailwind v4 compiles them; interpolated class names are not scanned and would silently drop the cap. Creatives are contained with `object-contain` inside the bounded slot and are never cropped or distorted.

## Seed Strategy

The clean seed creates deterministic US mortgage examples with:

- 18 advertisements.
- 13 populated placements.
- 3 homepage hero ads for carousel testing.
- 2 broker sidebar ads.
- 2 blog inline ads.
- 2 square homepage featured ads.
- Horizontal, vertical, rectangle, square, and mobile creative assignments.
- 31 unique media assets.
- 35 advertisement creative assignments.

Seed cleanup remains scoped to the isolated demo database and is idempotent.
