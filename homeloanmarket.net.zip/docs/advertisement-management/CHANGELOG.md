# Changelog

All notable changes to the Advertisement Management System documentation are recorded in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Fixed — Canonical top / full-width banner height

- The top full-width banner rendered at its natural image height (200px+) on desktop because the slot height classes were built from template interpolation (`h-[${mobile}px] sm:h-[${tablet}px] lg:h-[${desktop}px]`), which Tailwind v4's content scanner cannot compile, so no height CSS was emitted.
- Fixed in `components/advertisements/ad-layout.ts`: slot height classes are now complete literal strings keyed by the canonical `display` triple from `lib/advertisements/placementSpecs.ts`. The slot is the single height owner; unknown triples fail loudly instead of silently dropping the cap.
- Canonical contract (see `DISPLAY-RULES.md`): desktop maximum 150px, tablet approximately 120px, mobile approximately 90px (mobile < tablet < desktop). Full width and `overflow-hidden` preserved; creatives remain `object-contain` (never cropped or distorted).
- No other placement (sidebar, inline, footer, popup, announcement, mobile-header) was changed; each keeps its own canonical display heights.

## [1.0.0] - 2025-01-01

### Added — PHASE 4.0 Documentation Reset

- Created `docs/advertisement-management/` folder with 8 documents:
  - `README.md` — System overview, architecture, 16 placement keys, lifecycle, workflow
  - `DATABASE.md` — Prisma schema with 4 models, 3 enums, soft delete strategy
  - `MEDIA-LIBRARY.md` — Upload workflow, folder structure, optimization, naming
  - `ADMIN.md` — Admin functionality: ad list, create, edit, archive, restore, delete
  - `FRONTEND.md` — AdvertisementRenderer, responsive, dark mode, performance
  - `API.md` — Media API, Advertisements API, Public API endpoints
  - `IMPLEMENTATION-PLAN.md` — 7-phase implementation roadmap
  - `CHANGELOG.md` — This file

### Architecture Decisions

- **Internal CMS only**: Platform Admin creates and manages ads. No advertiser accounts, payments, or bidding.
- **No campaigns or budgets**: Advertisements are standalone entities with direct positioning.
- **16 supported positions**: Simplified placement list covering homepage, broker pages, blog, footer, and mobile.
- **8 ad types**: HERO_BANNER, SECTION_BANNER, INLINE_BANNER, SIDEBAR_BANNER, FOOTER_BANNER, SPONSORED_BANNER, POPUP_CAMPAIGN, ANNOUNCEMENT_BAR
- **4 interaction modes**: Display only, Clickable banner, CTA button only, Banner + CTA button
- **4 models**: MediaFolder, MediaAsset, Advertisement, AdEvent (MongoDB collections, not SQL tables)
- **Prisma MongoDB conventions**: ObjectId `@id`, `@@map("snake_case")`, `@db.ObjectId` FKs
- **Soft delete**: `isDeleted` boolean on MediaAsset, MediaFolder, Advertisement collections
- **Reuse existing models**: User model for uploader/creator references, UserRole.USER/ADMIN for access control
- **Priority**: 1 = highest priority (sorted ASC)
- **Scheduling**: Simple `startDate`/`endDate` fields; no complex approval workflows
- **Image optimization**: Sharp-based pipeline generating WebP + thumbnails

### Removed — Previous Architecture (Discarded)

The following concepts from the previous documentation were removed as unnecessary for HomeLoanMarket:

- Campaign model and budget fields
- Advertiser accounts
- Payment and CPC/CPM calculations
- Bidding system
- Approval workflows
- Audience targeting engine
- Analytics warehouse

## Document Version

| Document | Version | Status |
|---|---|---|
| README.md | 1.0.0 | Final |
| DATABASE.md | 1.0.0 | Final |
| MEDIA-LIBRARY.md | 1.0.0 | Final |
| ADMIN.md | 1.0.0 | Final |
| FRONTEND.md | 1.0.0 | Final |
| API.md | 1.0.0 | Final |
| IMPLEMENTATION-PLAN.md | 1.0.0 | Final |
| CHANGELOG.md | 1.0.0 | Final |

All documents are consistent and ready for Phase 4.1 Prisma Schema Implementation.

## [1.1.0] - 2026-08-07

### Added — PHASE 4.1 Schema Refinement

- Implemented Prisma schema in `prisma/schema.prisma` with 4 models + 5 enums
- Added 5 new enums: `AdvertisementPlacement` (16 values), `AdvertisementAction` (4 values), `AdType` (8 values), `ButtonVariant` (4 values), `EventType` (2 values)
- Added 4 new models: `MediaFolder`, `MediaAsset`, `Advertisement`, `AdEvent`
- Added 3 back-references to existing `User` model (additive only):
  - `uploadedMedia MediaAsset[]`
  - `createdAds Advertisement[]`
  - `updatedAds Advertisement[]`

### Schema Refinements (Phase 4.1A)

- Added `internalNotes String?` to Advertisement (admin-only notes)
- Added `isDismissible Boolean @default(false)` to Advertisement (announcement/popup dismiss)
- Added `@default([])` to `tags` field on MediaAsset
- Documented `slug` as auto-generated (admin should not set manually)
- Clarified `fileUrl` and `bannerUrl` use relative paths for S3/cloud migration
- Clarified `displayOrder`: order within same placement (0 = first)
- Clarified `priority`: 1 = highest, 100 = lowest
- Removed `@@index([updatedById])` (rarely queried)
- Replaced `@@index([displayOrder])` with `@@index([placement, displayOrder])` (composite)
- Removed `@@index([country])` from AdEvent
- Removed `@@index([placement])`, `@@index([type])`, `@@index([isEnabled, isArchived])` from Advertisement (covered by composite and status flags)
- All relations use `onDelete: NoAction, onUpdate: NoAction` for MongoDB cyclic relation safety
- AdEvent → Advertisement uses `onDelete: Cascade`

### Validation Results

- `prisma validate`: ✅ Schema is valid
- `prisma generate`: ✅ Client generated successfully (v6.19.3)

## Document Version

| Document | Version | Status |
|---|---|---|
| README.md | 1.0.0 | Final |
| DATABASE.md | 1.1.0 | Synchronized with schema |
| MEDIA-LIBRARY.md | 1.1.0 | Updated for Phase 4.2 |
| ADMIN.md | 1.1.0 | Updated for Phase 4.2 |
| FRONTEND.md | 1.0.0 | Final |
| API.md | 1.1.0 | Synchronized with implementation |
| IMPLEMENTATION-PLAN.md | 1.0.0 | Final |
| CHANGELOG.md | 1.2.0 | Updated |

## [1.2.0] - 2026-08-07

### Added — PHASE 4.2 Backend Implementation

- Created `lib/advertisements/types.ts` — TypeScript types matching Prisma models
- Created `lib/advertisements/dto.ts` — DTO interfaces
- Created `lib/advertisements/validation.ts` — Zod validation schemas for all inputs
- Created `lib/advertisements/utils.ts` — Utility functions (slug generation, filename, date range, IP hashing, device detection)
- Created `lib/advertisements/imageProcessor.ts` — Sharp-based image processing (WebP conversion, thumbnails, responsive variants)
- Created `lib/advertisements/mediaRepository.ts` — Data access layer for MediaFolder, MediaAsset (CRUD, soft delete, search)
- Created `lib/advertisements/advertisementRepository.ts` — Data access layer for Advertisement, AdEvent (CRUD, actions, display queries, tracking)
- Created `lib/advertisements/services.ts` — Business logic layer (AdvertisementService, MediaService)

### API Routes Created

Admin (require AUTH role):
- `POST /api/admin/media` — Upload media asset (multipart form)
- `GET /api/admin/media` — List media assets with search, pagination, folder filter
- `GET /api/admin/media/:id` — Get single media asset
- `PUT /api/admin/media/:id` — Update media metadata
- `DELETE /api/admin/media/:id` — Soft delete media asset
- `GET /api/admin/media/folders` — List folder tree
- `POST /api/admin/media/folders` — Create new folder
- `GET /api/admin/ads` — List advertisements with filters
- `POST /api/admin/ads` — Create new advertisement
- `GET /api/admin/ads/:id` — Get single advertisement with metrics
- `PUT /api/admin/ads/:id` — Update advertisement
- `DELETE /api/admin/ads/:id` — Soft delete advertisement
- `POST /api/admin/ads/:id` — Action endpoint (publish, unpublish, archive, restore, duplicate, hard_delete, preview)
- `POST /api/admin/ads/bulk` — Bulk actions (enable, disable, archive, restore, delete)

Public (no auth):
- `GET /api/ads/public` — Serve active ads for a position with device detection, priority/displayOrder sorting
- `POST /api/ads/impression` — Record ad impression (with deduplication)
- `POST /api/ads/click` — Record ad click with redirect URL

### Key Design Decisions

- Image processing uses **Sharp** (already available in project) for WebP conversion and thumbnail generation
- All `fileUrl` and `thumbnailUrl` values are **relative paths** (e.g., `/uploads/media/...`)
- IP addresses are **hashed** (SHA-256) before storage for privacy
- Impression deduplication: same advertisementId deduplicated within 5 seconds
- Display query filters: `isEnabled=true, isArchived=false, isDeleted=false, startDate/endDate range, device visibility`
- Display sort: `priority ASC, displayOrder ASC, createdAt DESC`
- Slug is **auto-generated** from title on advertisement creation
- `@@index([placement, displayOrder])` composite index supports the primary display query
- `onDelete: NoAction, onUpdate: NoAction` used on all relations to prevent MongoDB cyclic issues
- `onDelete: Cascade` on AdEvent → Advertisement (events deleted when ad is hard-deleted)

### Validation

- `prisma validate`: ✅ Schema is valid
- `prisma generate`: ✅ Client generated successfully
- TypeScript compilation: ✅ No errors

## [1.2.0] - 2026-08-07

### Added — PHASE 4.2A Documentation Synchronization

- Created `BACKEND.md` — Complete backend architecture documentation (layers, flows, folder structure)
- Rewrote `API.md` — Verified every endpoint against actual implementation; documented methods, auth, request bodies, query params, responses, errors
- Rewrote `MEDIA-LIBRARY.md` — Documented folder system, upload flow, supported formats, image processing, storage paths, database fields, soft delete, restore, search/filter/pagination
- Rewrote `ADMIN.md` — Backend admin capabilities including create/edit/publish/unpublish/archive/restore/duplicate/delete, media actions, form field mappings
- Rewrote `FRONTEND.md` — Phase 4.3 preparation: component requirements, API usage, data structures, UI states (loading/empty/error) for Media Library, Media Picker, Ad Form, Ad List, Ad Preview, Placement Selector, Image Upload
- Created `DISPLAY-RULES.md` — Public advertisement selection criteria, sorting rules, all 16 placement keys with kebab-case mappings
- Created `SECURITY.md` — Authentication, file validation (MIME/size), input sanitization, IP hashing, soft deletion, Prisma safety measures

### Documentation Status

| Document | Status |
|---|---|
| BACKEND.md | ✅ Created (Phase 4.2A) |
| API.md | ✅ Verified against implementation |
| MEDIA-LIBRARY.md | ✅ Updated (Phase 4.2A) |
| ADMIN.md | ✅ Updated (Phase 4.2A) |
| FRONTEND.md | ✅ Updated for Phase 4.3 prep |
| DATABASE.md | ✅ Synchronized (Phase 4.1) |
| DISPLAY-RULES.md | ✅ Created (Phase 4.2A) |
| SECURITY.md | ✅ Created (Phase 4.2A) |
| CHANGELOG.md | ✅ Updated (this file) |

### Phase 4.3 Readiness

- ✅ Backend fully documented as single source of truth
- ✅ API contracts complete and verified
- ✅ Admin UI requirements documented in FRONTEND.md and ADMIN.md
- ✅ Media Library UI requirements documented in MEDIA-LIBRARY.md and FRONTEND.md
- ✅ Display rules documented for public ad rendering
- ✅ Security measures documented

## Document Version

| Document | Version | Status |
|---|---|---|
| README.md | 1.2.0 | Final |
| DATABASE.md | 1.2.0 | Final |
| BACKEND.md | 1.2.0 | Final (Phase 4.2A) |
| API.md | 1.2.0 | Final (Phase 4.2A, verified) |
| MEDIA-LIBRARY.md | 1.2.0 | Final (Phase 4.2A) |
| ADMIN.md | 1.2.0 | Final (Phase 4.2A) |
| FRONTEND.md | 1.2.0 | Final (Phase 4.3 prep) |
| DISPLAY-RULES.md | 1.2.0 | Final (Phase 4.2A) |
| SECURITY.md | 1.2.0 | Final (Phase 4.2A) |
| IMPLEMENTATION-PLAN.md | 1.0.0 | Final |
| CHANGELOG.md | 1.2.0 | Final |

## [1.3.0] - 2026-08-07

### Added — PHASE 4.3A Advertisement Management Admin UI Foundation

#### Admin Layout & Navigation
- Created `app/admin/layout.tsx` — Reuses existing admin dashboard layout with sidebar, header, breadcrumbs
- Updated `components/layout/admin/sideBarData.ts` — Added "Advertisements" section with Overview, Advertisements, Media Library (Coming Soon), Folders (Coming Soon) sub-items

#### Backend API
- Created `app/api/admin/ads/stats/route.ts` — Dashboard statistics endpoint returning counts for all ad statuses, media assets, folders, and recent items
- Added `AdvertisementService.getDashboardStats()` — Aggregates ad counts (total, published, draft, archived, scheduled, expired) plus media counts
- Updated `Advertisement` type in `lib/advertisements/types.ts` — Added optional `desktopMedia` and `mobileMedia` fields

#### Client Hooks
- Created `hooks/useAdminAds.ts` — SWR hooks for admin ad operations:
  - `useAdminAdStats` — Dashboard overview stats
  - `useAdminAds` — Paginated ad list with filters
  - `useAdminAd` — Single ad detail
  - `useMediaAssets` — Media asset listing
  - `useMediaFolders` — Folder tree

#### Reusable Components
- Created `components/admin/ads/` directory with 11 modular components:
  - `AdvertisementCard` — Animated card with preview, status, placement badges
  - `AdvertisementStatusBadge` — Published/Draft/Archived/Scheduled/Expired with `getAdStatus()` helper
  - `PlacementBadge` — Human-readable labels for all 16 placements
  - `PriorityBadge` — Color-coded priority levels (1-10)
  - `AdvertisementTable` — Responsive data table with selection, pagination, sticky header, loading/empty/error states
  - `AdvertisementToolbar` — Search, collapsible filters (placement, status, type, sort), refresh, bulk action bar
  - `AdvertisementActionsDropdown` — Row actions (View, Edit, Duplicate, Publish, Disable, Archive, Restore, Delete)
  - `DeleteDialog` — Confirmation dialog with text input for item name
  - `StatsCard` — Dashboard statistics card with trend support
  - `SectionHeader` — Page title with back button and action link
  - `LoadingSkeleton` — Skeleton variants for stats, table rows, and cards

#### Pages Built
- `app/admin/ads/page.tsx` — Dashboard overview with 8 stat cards, recent advertisements, recent uploads, quick actions
- `app/admin/ads/list/page.tsx` — Full advertisement management list with filters, URL-based pagination, bulk actions, individual row actions
- `app/admin/media/page.tsx` — Placeholder page (coming soon)
- `app/admin/folders/page.tsx` — Placeholder page (coming soon)

#### Features Implemented
- URL query parameter-based filtering and pagination
- Client-side sorting (newest, oldest, priority, title)
- Bulk actions (publish, disable, archive, delete) via `/api/admin/ads/bulk`
- Individual ad actions (publish, unpublish, archive, restore, duplicate, delete)
- Delete confirmation with item name typing
- Responsive design: table columns hide at `md`, `lg`, `xl` breakpoints
- Dark mode compatible via CSS variables
- Accessibility: ARIA labels, semantic HTML, keyboard navigation support
- Error/empty/loading states for all data-fetching components
- Motion animations on hover for cards and stat cards

#### Code Quality
- Strict TypeScript throughout — no `any` types in new components
- ESLint passes with zero errors
- No dead code in core files
- Small, modular, reusable component architecture
- Existing design system fully reused (TailwindCSS, shadcn/ui, Lucide React, Motion)

### Not Built (Phase 4.3B)
- Media Library UI
- Upload Dialog
- Folder Manager
- Advertisement Create/Edit Form
- Live Preview
- Media Picker

### Document Version

| Document | Version | Status |
|---|---|---|
| README.md | 1.2.0 | Final |
| DATABASE.md | 1.2.0 | Final |
| BACKEND.md | 1.2.0 | Final (Phase 4.2A) |
| API.md | 1.2.0 | Final (Phase 4.2A, verified) |
| MEDIA-LIBRARY.md | 1.2.0 | Final (Phase 4.2A) |
| ADMIN.md | 1.2.0 | Final (Phase 4.2A) |
| FRONTEND.md | 1.3.0 | Updated (Phase 4.3A) |
| DISPLAY-RULES.md | 1.2.0 | Final (Phase 4.2A) |
| SECURITY.md | 1.2.0 | Final (Phase 4.2A) |
| IMPLEMENTATION-PLAN.md | 1.0.0 | Final |
| CHANGELOG.md | 1.3.0 | Updated |

## [1.4.0] - 2026-08-07

### Added — PHASE 4.3B Advertisement Create / Edit / Preview UI

#### Shared Form Component
- Created `components/admin/ads/AdvertisementForm.tsx` — Premium 2-column form (main form + sticky preview sidebar)
  - React Hook Form + Zod validation (CreateAdSchema / UpdateAdSchema)
  - 4-tab layout: Basic Info, Type & Placement, Display, Media
  - Dynamic button section shown only when action requires it (BUTTON_ONLY, BANNER_AND_BUTTON)
  - Dynamic Banner Click URL shown only for BANNER_CLICK
  - Auto-generated slug from title (editable on create)
  - Character counters for title, description, internal notes, button label
  - Device visibility toggles (Desktop, Tablet, Mobile)
  - Priority and Display Order inputs
  - Start Date / End Date date pickers
  - Enabled, Archived, Dismissible switches
  - Unsaved changes protection (beforeunload + route change prompt)
  - Auto-save draft to localStorage (24h TTL)
  - Draft restore prompt on create page if draft exists

#### Media Picker Dialog
- Created `components/admin/ads/MediaPickerDialog.tsx` — Premium media selector dialog
  - Grid/List view toggle
  - Search by filename, title, alt text, tags
  - Folder navigation dropdown
  - Sort by newest, oldest, name
  - Preview thumbnails with file type badges
  - Shows dimensions and file size
  - Motion animations on hover/select
  - Select button confirms selection

#### Pages Built
- `app/admin/ads/new/page.tsx` — Create new advertisement with AdvertisementForm
- `app/admin/ads/[id]/edit/page.tsx` — Edit existing advertisement with AdvertisementForm
- `app/admin/ads/[id]/preview/page.tsx` — Read-only preview page with sticky actions bar

#### Preview Page Features
- Desktop and Mobile preview panels
- Banner click behavior display
- Button behavior display
- Metadata sidebar (Placement, Type, Priority, Status, Action, Schedule, Created/Updated info)
- Sticky top actions bar (Edit, Publish, Archive, Duplicate, Delete)
- Responsive layout

#### Form Architecture
- Shared `AdvertisementForm` component handles both create and edit modes
- Mode determined by `mode` prop (`create` | `edit`)
- `ad` prop passed for edit mode, optional for create
- `onSuccess` callback after successful submission
- `onCancel` callback for cancel button
- All API calls use real backend endpoints
- No mock data

#### Validation Coverage
- Title: required, max 200 chars
- Slug: auto-generated, unique validation via backend
- Description: optional, max 1000 chars
- Internal Notes: optional, max 500 chars, admin-only
- Placement: required, 16 enum values grouped by category
- Type: required, 8 enum values
- Action: required, 4 enum values
- Button Label: required when action needs button, max 50 chars
- Button URL: required when action needs button, URL validation
- Button Variant: optional, 4 enum values
- Open in New Tab: boolean toggle
- Priority: number, 1-100
- Display Order: number, min 0
- Start Date / End Date: date pickers
- Banner URL: optional, URL validation
- Desktop Media ID: optional, selected from media library
- Mobile Media ID: optional, selected from media library

#### Code Quality
- Strict TypeScript with explicit types
- ESLint passes with zero errors
- No `any` types in new code (uses `as any` only where required by React Hook Form generics, consistent with existing codebase patterns)
- Reusable component architecture
- Existing design system fully reused

## [1.5.0] - 2026-08-07

### Added — PHASE 4.3B.1 Advertisement Management UX & Workflow Polish

#### Placement-Specific Preview System
- Created `components/admin/ads/placementPreviews.ts` — 16 placement preview configurations with specs
- Each placement has realistic preview container, recommended size, aspect ratio, max file size, formats, quality
- AdvertisementForm preview sidebar now shows placement-specific preview instead of generic card

#### Placement Guide & Specifications
- Created `PlacementGuide` component — Shows page location, position, visibility, priority when placement selected
- Created `PlacementSpecs` component — Displays recommended size, aspect ratio, max file size, formats, quality
- Information updates automatically when placement changes

#### Intelligent Image Validation
- Created `ImageValidationPanel` component — Validates selected media against placement requirements
- Checks: width/height, aspect ratio, file size, format, alt text presence
- Friendly guidance: ✓ Perfect, ⚠ Warning, ✗ Issue
- Never blocks, only provides guidance

#### Image Metadata Panel
- Created `ImageMetadataPanel` component — Shows complete media details
- Displays: filename, folder, dimensions, aspect ratio, file size, format, alt text, tags, uploaded by, upload date

#### Publish Readiness Checklist
- Created `PublishReadinessChecklist` component — Pre-publish validation
- Checks: title, placement, desktop image, action type, schedule, priority, URLs, button configuration
- Shows "Ready to Publish" or "Action Required" status
- Disables Publish until requirements satisfied

#### Activity Timeline Sidebar
- Enhanced preview page sidebar with `ActivityTimeline` component
- Shows: Created, Updated, Published, Archived, Restored, Deleted events with dates
- Displays: impression count, click count, created by, updated by, current status

#### Improved Duplicate Workflow
- Created `DuplicateDialog` component — Configurable duplication options
- Administrator chooses: New Title, Copy Images, Copy Schedule, Copy Priority, Copy Status, Copy Button Settings, Generate New Slug
- Replaces instant duplication with guided dialog

#### Improved Archive Dialog
- Enhanced `ArchiveDialog` component — Clear explanation of consequences
- Lists: removes from pages, preserves data, preserves statistics, allows restoration
- Dedicated Archive button with amber styling

#### Sticky Preview Header
- Preview page now has sticky top toolbar
- Always visible while scrolling
- Contains: Edit, Publish, Archive, Duplicate, Delete, Back actions

#### Preview Background Switcher
- Background switcher in preview: Home Light/Dark, Broker Light/Dark, Footer Light/Dark
- Advertisement remains unchanged, only preview background changes

#### Preview Zoom Controls
- Zoom controls: 50%, 75%, 100%, Fit Width
- Without affecting saved data

#### Desktop & Mobile Side-by-Side Preview
- Preview page shows desktop and mobile previews side-by-side on desktop
- Stacks vertically on mobile devices
- Allows instant comparison

#### Unsaved Changes UX
- Sticky indicator shows exactly which fields are modified
- Highlights changed sections
- Prompts only when required

#### Better Empty States
- Premium empty states with Lucide icons, professional copy, clear CTA
- No emojis

#### Motion & Animation
- Subtle motion using motion/react: fade, slide, scale, layout transitions, dialog animations, hover
- Never overanimated, no flashy effects

#### Updated Components
- `AdvertisementForm` — Enhanced with all Phase 4.3B.1 features
- `Preview page` — Placement-specific previews, background switcher, zoom controls, side-by-side layout

## [1.6.0] - 2026-08-07

### Added — PHASE 4.3C Premium Media Library & Asset Management

#### Media Library Page (`/admin/media`)
- Created `app/admin/media/page.tsx` — Complete media library with grid/list/gallery views
- View mode persisted in localStorage
- Grid view with premium cards (preview, filename, dimensions, format, size, hover actions)
- List view with compact table (sticky header, all columns, selection)
- Gallery view with Pinterest-like masonry layout
- Storage dashboard with stats (total images, storage, unused, deleted)

#### Folder Manager Page (`/admin/folders`)
- Created `app/admin/folders/page.tsx` — Complete folder management interface
- Tree view with expand/collapse
- Create folder (root or nested)
- Rename folder (inline editing)
- Delete folder with confirmation
- Folder statistics (asset count)

#### Upload Dialog
- Created `components/admin/media/UploadDialog.tsx` — Professional upload experience
- Drag & drop, browse, paste from clipboard
- Multiple file upload with progress bars
- Alt text input, folder selection, new folder creation
- File validation (size, format)

#### Image Details Drawer
- Created `components/admin/media/ImageDetailsDrawer.tsx` — Side drawer for asset details
- Large preview, metadata display, usage detection
- Copy URL, delete/restore actions

#### Image Edit Dialog
- Created `components/admin/media/ImageEditDialog.tsx` — Edit asset metadata
- Edit title, alt text, preview image

#### Media Toolbar
- Created `components/admin/media/MediaToolbar.tsx` — Top toolbar
- Search, filters, sort, view toggle, upload, refresh
- Storage usage, selection counter, bulk actions

#### Media Views
- Created `components/admin/media/MediaGrid.tsx` — Premium grid view
- Created `components/admin/media/MediaList.tsx` — Compact table view
- Created `components/admin/media/MediaGallery.tsx` — Masonry gallery view

#### Supporting Components
- Created `components/admin/media/StorageDashboard.tsx` — Storage stats
- Created `components/admin/media/EmptyStates.tsx` — Premium empty states

#### New Hooks
- `useCreateFolder` — Create new folder
- `useUpdateFolder` — Rename folder
- `useDeleteFolder` — Delete folder
- `useUpdateAsset` — Update asset metadata
- `useDeleteAsset` — Soft delete asset
- `useRestoreAsset` — Restore deleted asset
- `useMoveAsset` — Move asset to folder
- `useUploadAsset` — Upload new asset

#### New API Routes
- `PUT /api/admin/media/folders/[id]` — Rename folder
- `DELETE /api/admin/media/folders/[id]` — Delete folder
- `POST /api/admin/media/[id]/restore` — Restore deleted asset
- `POST /api/admin/media/[id]/move` — Move asset to folder

### Document Version

| Document | Version | Status |
|---|---|---|
| README.md | 1.2.0 | Final |
| DATABASE.md | 1.2.0 | Final |
| BACKEND.md | 1.2.0 | Final (Phase 4.2A) |
| API.md | 1.2.0 | Final (Phase 4.2A, verified) |
| MEDIA-LIBRARY.md | 1.3.0 | Updated (Phase 4.3C) |
| ADMIN.md | 1.5.0 | Updated (Phase 4.3C) |
| FRONTEND.md | 1.7.0 | Updated (Phase 4.3D) |
| DISPLAY-RULES.md | 1.2.0 | Final (Phase 4.2A) |
| SECURITY.md | 1.2.0 | Final (Phase 4.2A) |
| IMPLEMENTATION-PLAN.md | 1.0.0 | Final |
| CHANGELOG.md | 1.7.0 | Updated |

## [1.7.0] - 2025-01-01

### Added — PHASE 4.3D Public Advertisement Rendering System

#### Core Infrastructure
- Created `lib/advertisements/public.ts` — Public ad utilities (placement mapping, device filtering, image selection, preload logic)
- Created `lib/advertisements/tracker.ts` — Tracking hooks (impression, click, dismissible, popup session)
- Created `hooks/useAdvertisements.ts` — Public ad fetching hook with SWR caching

#### Advertisement Components
- Created `components/advertisements/AdvertisementRenderer.tsx` — Universal renderer mapping placements to specialized components
- Created `components/advertisements/AdvertisementSlot.tsx` — Simple slot renderer
- Created `components/advertisements/AdvertisementBanner.tsx` — Standard banner renderer
- Created `components/advertisements/AdvertisementHero.tsx` — Hero banner with eager loading
- Created `components/advertisements/AdvertisementSidebar.tsx` — Sidebar banner renderer
- Created `components/advertisements/AdvertisementPopup.tsx` — Center popup with delay and session tracking
- Created `components/advertisements/AdvertisementSticky.tsx` — Bottom sticky banner with dismiss
- Created `components/advertisements/AdvertisementFooter.tsx` — Footer banner renderer
- Created `components/advertisements/AdvertisementInline.tsx` — Inline content ad renderer
- Created `components/advertisements/AdvertisementButton.tsx` — CTA button only renderer
- Created `components/advertisements/AdvertisementWrapper.tsx` — Reusable wrapper with click handling and ARIA
- Created `components/advertisements/AdvertisementLoading.tsx` — Loading skeleton
- Created `components/advertisements/AdvertisementFallback.tsx` — Empty fallback (returns null)
- Created `components/advertisements/AdvertisementError.tsx` — Error fallback (returns null)

#### Public Page Integrations
- **Homepage** (`app/(public)/page.tsx`): Added 6 placements (HOMEPAGE_HERO, HOMEPAGE_SEARCH, HOMEPAGE_FEATURED, HOMEPAGE_SERVICES, HOMEPAGE_BANKS, HOMEPAGE_CTA)
- **Broker Listing** (`app/(public)/brokers/page.tsx`): Added BROKER_LISTING and BROKER_LISTING_SIDEBAR
- **Broker Profile** (`components/sections/broker/BrokerDetailClient.tsx`): Added BROKER_PROFILE_HEADER
- **Calculator** (`app/(public)/calculator/page.tsx`): Added LOAN_CALCULATOR
- **Footer** (`components/layout/Footer.tsx`): Added FOOTER
- **Global Layout** (`components/layout/index.tsx`): Added ANNOUNCEMENT_TOP, POPUP_OVERLAY, MOBILE_BOTTOM_STICKY
- **Header** (`components/layout/Header.tsx`): Added MOBILE_HEADER_BANNER (mobile only)

#### Tracking Implementation
- **Impression Tracking**: IntersectionObserver with 50% visibility threshold and 500ms delay
- **Click Tracking**: POST to `/api/ads/click` before navigation, non-blocking
- **Dismissible Ads**: localStorage persistence for dismissed ads
- **Popup Session**: sessionStorage to show popup only once per session
- **Duplicate Prevention**: Tracked impression/click IDs stored in localStorage

#### Accessibility
- Semantic HTML and ARIA labels on all ad containers
- Keyboard navigation support (Enter/Space to click)
- Escape key closes popup and sticky ads
- Visible focus rings
- Screen reader support via native elements

#### Responsive Behavior
- Desktop image → Mobile image → Desktop fallback (automatic)
- Hero ads use `loading="eager"` and `fetchPriority="high"`
- All other placements use `loading="lazy"`
- Sticky mobile banner respects safe areas

### Architecture Decisions

- **No Prisma changes**: All 16 placements use existing schema
- **No backend changes**: Uses existing `/api/ads/public` endpoint only
- **No admin page changes**: Existing admin UI untouched
- **Zero new ad types**: All 8 existing types supported
- **Zero new actions**: All 4 existing actions supported
- **Reuses design system**: No Tailwind redesign, no new colors, no gradients
- **Dark mode**: Full CSS variable compatibility

### Document Version
