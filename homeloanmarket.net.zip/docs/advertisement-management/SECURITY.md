# Security

## Overview

This document describes the security measures implemented in the Advertisement Management backend (Phase 4.2). All measures follow existing HomeLoanMarket project conventions.

## Authentication & Authorization

### ADMIN Role Requirement

All admin routes reuse the existing authentication system:

```typescript
import { getCurrentUser } from "@/lib/currentUser"
import { UserRole } from "@prisma/client"

const user = await getCurrentUser()
if (!user || user.role !== UserRole.ADMIN) {
  return NextResponse.json(
    { success: false, error: "Unauthorized" },
    { status: 401 }
  )
}
```

- Uses existing NextAuth sessions
- Reuses `UserRole` enum from Prisma (`ADMIN`, `BROKER`, `USER`)
- No new auth models or tables created
- All admin routes in `/app/api/admin/` check role

### Public Routes

Public endpoints (`/api/ads/public`, `/api/ads/impression`, `/api/ads/click`) do not require authentication. Access control is enforced via server-side filtering (only enabled, non-archived, non-deleted ads are returned).

## File Upload Security

### File Validation

**Location**: `lib/advertisements/imageProcessor.ts` (`validateUpload()`)

1. **File existence**: Rejects if file is null/undefined
2. **MIME type validation**: Only allows:
   - `image/jpeg`
   - `image/png`
   - `image/webp`
   - `image/gif`
   - `image/svg+xml`

   Implementation:
   ```typescript
   const ALLOWED_MIME_TYPES = [
     "image/jpeg", "image/png", "image/webp",
     "image/gif", "image/svg+xml"
   ]
   ```

3. **Size validation**: Maximum 10MB for images, 2MB for SVG:
   ```typescript
   const MAX_FILE_SIZE = 10 * 1024 * 1024  // 10MB
   const MAX_SVG_SIZE = 2 * 1024 * 1024    // 2MB
   ```

### MIME Validation (Not Just Extension)

File MIME type is read from the file's `type` property (set by browser upload dialog), not from the file extension. This prevents simple extension spoofing attacks.

### Path Traversal Prevention

- Filenames are sanitized using `sanitizeFileName()`:
  ```typescript
  function sanitizeFileName(name: string): string {
    return name.replace(/[^a-zA-Z0-9._-]/g, "_").replace(/\.\.+/g, ".")
  }
  ```
- Output filenames use UUID-based naming (`{objectId}.webp`), not user-supplied names
- All files stored in a single directory (`public/uploads/media/`)
- No user-supplied path components used in file system paths

### Image Processing Safety

All image processing through Sharp:
- Strips EXIF data (including GPS location) automatically during WebP conversion
- SVG files are stored as-is (not processed through Sharp)
- GIFs: only first frame converted to WebP (no animation support)
- Maximum image dimensions are checked before processing

## Input Sanitization

### Backend Validation (Zod)

All API inputs are validated via Zod schemas in `lib/advertisements/validation.ts`:

| Schema | Validates Against |
|---|---|
| `CreateMediaFolderSchema` | Folder names (1-100 chars) |
| `UploadMediaSchema` | Alt text length, tags array |
| `CreateAdSchema` | Priority range (1-100), date ranges, enum values |
| `UpdateAdSchema` | Same as Create (partial) |
| `AdQuerySchema` | Pagination bounds (page≥1, limit≤100) |
| `BulkAdActionSchema` | Non-empty IDs array, valid action enum |
| `ImpressionSchema` | Required advertisementId |
| `ClickSchema` | Required advertisementId |

### XSS Protection

- All string inputs are stored as-is (no HTML processing)
- Frontend must escape content when rendering (React's default behavior)
- `altText`, `title`, `buttonLabel` fields are plain text — no markdown/HTML
- Internal notes are not displayed publicly

### Injection Prevention

- All database queries use Prisma ORM (parameterized queries, no SQL injection)
- No raw SQL or string interpolation in queries
- MongoDB ObjectId conversion done safely via `new ObjectId()` with try/catch
- String-to-enum conversion happens via explicit mapping (throws on unknown values)

## IP Hashing & Privacy

### IP Address Handling

For event tracking (impressions, clicks):

```typescript
function hashIP(ip: string): string {
  return crypto
    .createHash("sha256")
    .update(ip)
    .digest("hex")
}
```

- Client IP is SHA-256 hashed before storage
- Hashed IP stored in `AdEvent.ipAddress` field
- Original IP is never stored in database
- Hash cannot be reversed to obtain original IP

### User Agent

- Full user agent string stored for analytics/debugging
- Not linked to personally identifiable information

## Soft Deletion

### Advertisement Soft Delete

```typescript
model Advertisement {
  // ...
  isDeleted Boolean @default(false)
  // ...
}
```

- DELETE operations set `isDeleted = true` (no physical deletion)
- All active ad queries filter `isDeleted = false`
- Hard delete requires explicit action via `POST /api/admin/ads/:id` with `{ action: "hard_delete" }`

### Media Asset Soft Delete

```typescript
model MediaAsset {
  // ...
  isDeleted Boolean @default(false)
  // ...
}
```

- Files remain on disk after soft delete
- Soft-deleted assets cannot be linked to new advertisements
- All media listing queries filter `isDeleted = false`

### Prisma Safety

- Prisma's built-in query builder prevents SQL/NoSQL injection
- All queries go through generated Prisma Client (type-safe)
- Model relations use `@relation` with explicit field mapping
- No `prisma.$queryRaw()` or `prisma.$executeRaw()` used anywhere
- ObjectId references validated before database operations
- All mutations wrapped in try/catch with proper error handling

## Rate Limiting Considerations

Public endpoints do not currently implement rate limiting. This should be considered for Phase 4.4 or when traffic increases. Existing Next.js middleware or a reverse proxy (nginx) can be used to add rate limiting without backend changes.

## Security Headers

The Next.js application (existing project) sets standard security headers:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `Content-Security-Policy` (existing project policy)
- `Referrer-Policy: strict-origin-when-cross-origin`

## What's NOT Implemented (Future)

| Feature | Rationale |
|---|---|
| Billing/Ad platform concepts | Simple internal CMS, no monetization |
| Advertiser accounts | Only internal admin use |
| Auction/bidding | Priority-based selection only |
| Real-time bidding | Out of scope |

## Related Documents

- [BACKEND.md](./BACKEND.md) — Architecture overview
- [API.md](./API.md) — API endpoint security notes
- [DISPLAY-RULES.md](./DISPLAY-RULES.md) — Public ad filtering
