# FINAL PRODUCTION READINESS AUDIT

Audit date: 2026-08-10  
Repository: HomeLoanMarket US  
Mode: **READ-ONLY / AUDIT-ONLY**

## 1. Executive Verdict

# NO-GO

The repository is **not yet production-ready** based on the uploaded source tree.

The decisive blocker is a **C3-equivalent sensitive-data leak** that remains in an alternate broker profile edit route. `lib/currentUser.ts` returns the complete Prisma `User` record, including credential/reset/verification fields, and `app/broker/profile/edit/page.tsx` passes that complete object directly into a Client Component. The existing C3 remediation correctly fixed `/broker/profile/personal`, but the alternate `/broker/profile/edit` boundary reintroduces the same class of leak.

A second production-blocking business defect was also independently identified: the public subscription page posts only `priceId`, while the checkout API requires both `priceId` and `plan`, so that public revenue entry point cannot create checkout sessions.

No production source code was changed during this audit. Findings are documented only.

## 2. Validation Summary

| Check | Result | Evidence |
| ----- | ------ | -------- |
| Documentation inventory | PASS | `docs/verification/**`, `docs/business/**`, advertisement-management documentation, claim contract, security/subscription reports inspected |
| C1 JWT identity protection | VERIFIED | `lib/auth.config.ts` no longer merges client `session.user` into JWT; identity is refreshed from DB |
| C2 public contact flow | VERIFIED | `app/api/contacts/send/route.ts` resolves by `profileSlug`, validates identifier presence, checks public eligibility, and writes against resolved Broker |
| C3 original remediation | VERIFIED | `lib/currentUser.ts` excludes `accounts`/`contactMessages`; explicit safe DTOs exist in `/broker/profile/personal` and other audited boundaries |
| C3 equivalent variant | **FAIL / BLOCKER** | `/broker/profile/edit` passes full `getCurrentUser()` result to Client Component; full User contains password/reset/verification fields |
| H1 contact paywall | VERIFIED | `toPublicBrokerRecord()` strips protected contact fields unless explicitly entitled |
| H2 mass assignment | VERIFIED with documented visibility exception | canonical broker allowlist blocks ownership/status/metrics/verification fields; visibility editing is explicitly preserved legacy behavior by Phase 9 product decisions |
| H3 password recovery | VERIFIED | hashed token persistence, expiry, single-use clearing, correct reset route, no raw token logging |
| H4 verification schema writes | VERIFIED | no production `PENDING`/`verificationDocuments` writes found; schema is `UNVERIFIED | VERIFIED` |
| H5 service-city entitlement | VERIFIED server-side | `/api/brokers/me` and `/api/company/[slug]` use `maxServiceCitiesForEntitlement()` |
| H6 Stripe ordering | VERIFIED with residual limitation | PROCESSING registration precedes stale check; PROCESSING + PROCESSED events considered; Redis lock has fallback |
| H7 claim recipient binding | VERIFIED | recipient match enforced during email step and completion transaction |
| Public subscription checkout | **FAIL / BLOCKER** | `app/(public)/subscription/page.tsx` sends only `priceId`; `/api/subscription/checkout` requires `priceId` + `plan` |
| Advertisement public delivery | VERIFIED by source/tests evidence; live execution unavailable | canonical renderer, bounded slots, lifecycle filters, public API, tracking routes |
| Advertisement admin authorization | VERIFIED by source/tests evidence | admin routes call `getCurrentUser()` and require `ADMIN` |
| Media upload security | VERIFIED by source | admin-only upload, 10 MB limit, SVG/AVIF rejection, Sharp processing, generated filenames, MIME/content validation tests present |
| TypeScript | NOT EXECUTED in this audit | uploaded archive has no `node_modules`; prior report claims PASS |
| Prisma validate/generate | NOT EXECUTED in this audit | uploaded archive has no installed dependencies; prior reports claim PASS |
| Full lint | NOT EXECUTED in this audit | no installed dependency tree; prior reports document legacy lint debt |
| Production build | NOT EXECUTED in this audit | no installed dependency tree; prior reports claim PASS |
| Live HTTP | NOT EXECUTED | no running application/DB/Stripe environment supplied with archive |
| Browser/viewport | NOT EXECUTED | browser automation/runtime not supplied |
| Stripe E2E | NOT EXECUTED | no live/test Stripe fixture supplied |

## 3. C1–C3 Status

### C1 — JWT `session.update()` client-controlled identity merge

**Status: VERIFIED/FIXED.**

**Evidence:** `lib/auth.config.ts` explicitly documents and implements the removal of client `session.user` merging. The JWT callback derives identity from the server-issued `user` at sign-in and refreshes identity from Prisma using the existing trusted `token.email`. Repository search found no equivalent `token = { ...token, ...session.user }` pattern.

**Affected workflow:** authentication/session refresh, claim completion, broker setup.

**Regression test:** `tests/phase-16-critical-security-fixes.test.tsx`; prior remediation report records 10/10 passing. This audit could not rerun it because dependencies are absent.

### C2 — Public broker contact submission

**Status: VERIFIED/FIXED.**

**Evidence:** `app/api/contacts/send/route.ts` requires a broker identifier, prefers canonical `brokerSlug`, resolves the Broker server-side, checks `isPublicBroker()`, then writes `brokerId: broker.id`. `proxy.ts` intentionally permits anonymous `/api/contacts/send`. Rate limiting is present through `contactBrokerRateLimit`.

The retained `brokerId` fallback is not an authorization bypass: the server still resolves and validates the actual Broker and only accepts public-eligible profiles.

**Affected workflow:** anonymous public broker contact/lead generation.

**Regression test:** `tests/phase-16-critical-security-fixes.test.tsx`; prior report records C2 coverage as passing. Live HTTP was not rerun in this audit.

### C3 — OAuth credentials / private User data reaching browser boundaries

**Status: **REGRESSION / NEW VARIANT — BLOCKER**.

**Evidence:** The original remediation is correct in `lib/currentUser.ts` with respect to `accounts` and `contactMessages`, and `/broker/profile/personal/page.tsx` now constructs an explicit safe DTO.

However, `lib/currentUser.ts` still returns `{ ...user, ... }`, where the Prisma `User` record contains:

- `password`
- `emailVerificationToken`
- `emailVerificationTokenExpiresAt`
- `resetPasswordToken`
- `resetPasswordTokenExpiry`
- plus other server-only relations/fields depending on the selected object

`app/broker/profile/edit/page.tsx` does:

```text
const user = await getCurrentUser()
...
<EditPersonalProfile user={user} />
```

`EditPersonalProfile` is a Client Component. Its TypeScript prop type is narrowed, but TypeScript does **not** remove runtime object properties during RSC serialization. Therefore the full returned object remains a client-bound payload.

This is the same security class as C3 and is independently reachable at `/broker/profile/edit` even though `/broker/profile/personal` was hardened.

**Affected workflow:** broker personal-profile editing and any authenticated browser session reaching the alternate route.

**Regression test:** existing C3 tests cover the hardened `/broker/profile/personal` boundary but do not prove the alternate `/broker/profile/edit` boundary is safe. A new regression test is required before production.

**Production impact:** sensitive credential/reset/verification material can be serialized into the browser/RSC payload. This is an unacceptable credential/secret exposure.

**Smallest safe fix:** change only the affected server-to-client boundary to construct the same explicit safe User DTO already used by `/broker/profile/personal`; alternatively make `getCurrentUser()` itself return a server-safe projection and use a separate server-only loader where full User data is genuinely required. The minimal remediation should preserve the existing Client Component contract.

## 4. H1–H7 Status

### H1 — Contact-detail entitlement bypass

**Status: VERIFIED/FIXED.**

**Evidence:** `lib/public-broker.ts` strips `phone`, `whatsapp`, `email`, `website`, `officeAddress`, and `pinCode` unless `includeContact === true`. Public listing/detail/featured paths calculate entitlement server-side using `hasPaidEntitlement()` and owner/admin exceptions where appropriate.

**Affected workflow:** public broker listing/detail.

**Regression test:** `tests/phase-17-high-fixes.test.tsx`; prior report records H1 coverage passing.

### H2 — Broker mass assignment / ownership transfer

**Status: VERIFIED/FIXED, with documented legacy visibility behavior.**

**Evidence:** `BROKER_EDITABLE_FIELDS` and `BROKER_ADMIN_FIELDS` in `lib/broker-policy.ts` provide a canonical allowlist. `userId`, ownership, metrics, verification state, subscription, claims, and other system fields are excluded from broker input. Historical routes now use `pickBrokerEditableFields()`.

`isVisible` remains editable by the broker in `/api/brokers/me`, `/api/brokers/[id]`, and `/api/company/[slug]`. This is not classified as a new security bypass because Phase 9 product decisions explicitly preserved legacy owner visibility behavior and marked visibility redesign out of scope. The same contract says admin publication remains authoritative for the broader publication model.

**Affected workflow:** broker profile editing.

**Regression test:** `tests/phase-17-high-fixes.test.tsx` and `tests/phase-18-high-medium-fixes.test.ts` cover allowlists and route wiring.

### H3 — Password recovery

**Status: VERIFIED/FIXED.**

**Evidence:** reset tokens are generated with `crypto.randomBytes(32)`, SHA-256 hashed before persistence, expire after one hour, and are cleared after successful or expired use. The email uses `/auth/reset-password`. Repository search found no logging of the raw reset token or reset URL.

A separate rate-limit gap remains; see Medium Findings.

**Affected workflow:** password recovery.

**Regression test:** `tests/phase-17-high-fixes.test.tsx`; prior report records H3 coverage passing.

### H4 — Invalid verification enum/field writes

**Status: VERIFIED/FIXED.**

**Evidence:** repository source search found no production write of `verificationStatus: 'PENDING'` and no production `verificationDocuments` reference outside tests/documentation discussing the historical defect. Prisma schema defines `VerificationStatus` as `UNVERIFIED | VERIFIED`.

**Affected workflow:** admin broker verification.

**Regression test:** `tests/phase-18-high-medium-fixes.test.ts`; prior report records H4 coverage passing.

### H5 — FREE service-city limit

**Status: VERIFIED/FIXED.**

**Evidence:** `maxServiceCitiesForEntitlement()` is based on `hasPaidEntitlement()`, not raw `isActive`. Both `/api/brokers/me` and `/api/company/[slug]` enforce the server-side limit. FREE resolves to one city; active paid FEATURED resolves to unlimited.

The Client `CompanyProfile` still contains a legacy `hasActiveSubscription` check, but the authoritative mutation boundary is server-side and uses the canonical entitlement helper, so the client condition is not an entitlement bypass.

**Affected workflow:** broker profile service-area editing.

**Regression test:** `tests/phase-18-high-medium-fixes.test.ts`; prior report records H5 coverage passing.

### H6 — Stripe webhook out-of-order race

**Status: VERIFIED/FIXED with residual same-timestamp limitation.**

**Evidence:** `app/api/stripe/webhook/route.ts` verifies signatures, records events as `PROCESSING` before the stale check, considers both `PROCESSING` and `PROCESSED` newer events, uses unique `eventId`, and provides a best-effort Redis subscription lock. Redis failure falls back to the database ordering guard.

Residual limitation: `event.created` has second-level granularity. Two distinct Stripe events for the same subscription with exactly equal `event.created` timestamps are not ordered by the current predicate. No evidence in this source audit demonstrates that this can corrupt a real Stripe lifecycle in the current event set, so this is documented as a residual robustness risk rather than a new HIGH finding.

**Affected workflow:** Stripe subscription lifecycle.

**Regression test:** `tests/phase-18-high-medium-fixes.test.ts`; prior report records H6 coverage passing.

### H7 — Claim invitation recipient binding

**Status: VERIFIED/FIXED.**

**Evidence:** `isClaimRecipientMatch()` is enforced in `app/api/claims/session/email/route.ts` and again inside the authoritative `completeClaimForUser()` transaction. Expiry, used/revoked state, reauthentication freshness, conditional `userId: null` ownership attachment, and generic errors are preserved.

**Affected workflow:** Broker claim invitation and ownership transfer.

**Regression test:** `tests/phase-18-high-medium-fixes.test.ts`; prior report records H7 coverage passing.

## 5. Equivalent / Variant Findings

| Finding | File/Path | Severity | Impact | Classification |
| ------- | --------- | -------- | ------ | -------------- |
| Full Prisma User object passed to Client Component | `lib/currentUser.ts` → `app/broker/profile/edit/page.tsx` | **CRITICAL** | Credential/reset/verification secrets can enter RSC/browser payload | **A. MUST FIX BEFORE PRODUCTION** |
| Public subscription checkout omits required `plan` | `app/(public)/subscription/page.tsx` → `app/api/subscription/checkout/route.ts` | **HIGH / business blocker** | Public paid checkout returns 400 and cannot start purchase | **A. MUST FIX BEFORE PRODUCTION** |
| Credential login limiter exists but is not wired into the actual `LoginWithCredential`/Auth.js authorize path | `lib/rateLimit.ts`, `actions/auth.action.ts`, `lib/auth.config.ts` | MEDIUM | Online password guessing is less constrained than intended | **B. SHOULD FIX BEFORE PRODUCTION** |
| Forgot-password endpoint has no distributed rate limiter | `app/api/auth/forgot-password/route.ts` | MEDIUM | Email/DB abuse and reset-email flooding | **B. SHOULD FIX BEFORE PRODUCTION** |
| Resend-verification endpoint has no distributed rate limiter | `app/api/auth/resend-verification/route.ts` | MEDIUM | Verification-email flooding and operational abuse | **B. SHOULD FIX BEFORE PRODUCTION** |
| Public ad impression/click endpoints have no rate limiter | `app/api/ads/impression/route.ts`, `app/api/ads/click/route.ts` | MEDIUM | Database/event-volume abuse and analytics pollution | **B. SHOULD FIX BEFORE PRODUCTION** |
| Account email can be changed without resetting `emailVerified` / re-verifying new address | `app/api/user/profile/route.ts` | MEDIUM | Recovery/contact identity can move to an unverified address | **B. SHOULD FIX BEFORE PRODUCTION** |
| Hard-coded Stripe price fallback exists | `lib/stripe.ts` | MEDIUM | Missing production env can silently select an unintended/stale price | **B. SHOULD FIX BEFORE PRODUCTION** |
| Public review write endpoint is absent while product FAQ promises customer reviews | `components/sections/landing/FAQ.tsx`, `app/api/company/[slug]/reviews/route.ts` | MEDIUM / product integrity | Public review creation workflow is not implemented; only read path exists | **B. SHOULD FIX BEFORE PRODUCTION** |
| Generic client/server fetch helpers reference non-existent legacy API routes | `lib/fetchServer.ts`, `lib/fetchClient.ts` | LOW/MEDIUM | Dead integration paths can fail if invoked | **C/D depending usage; currently non-blocking** |
| Media hard-delete helper deletes DB record but does not remove stored file | `lib/advertisements/mediaRepository.ts` | LOW | Long-term disk/storage orphan accumulation | **B. SHOULD FIX BEFORE PRODUCTION** |

## 6. Medium Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Credential login rate limiting | Limiter exists but actual credential sign-in action does not call it | MEDIUM | Brute-force attempts can reach Auth.js credentials flow without the intended 5/10m control | **B** | Apply the distributed limiter at the actual credential authentication boundary and test repeated failures |
| Forgot-password rate limiting | Missing | MEDIUM | Repeated reset-email requests can create email/provider/DB load | **B** | Add IP-based distributed limit while preserving generic account-existence response |
| Resend-verification rate limiting | Missing | MEDIUM | Verification email abuse | **B** | Add distributed IP/email limits and preserve non-enumerating responses |
| Advertisement tracking rate limiting | Missing | MEDIUM | Impression/click event spam can inflate DB volume and analytics | **B** | Add distributed per-IP/ad/window controls; retain legitimate anonymous tracking |
| Email-change re-verification | Missing | MEDIUM | New account email is not re-verified after authenticated email change | **B** | Reset `emailVerified` and use the existing verification lifecycle for a changed address |
| Stripe price fallback | Present | MEDIUM | Misconfiguration can charge/display an unintended price | **B** | Require a production-configured Stripe price ID; remove production fallback or fail closed |
| Review write path | Missing | MEDIUM | Customer review feature promised by FAQ has no current mutation API | **B** | Implement only after review-authenticity/permission contract is finalized |
| Media hard-delete cleanup | DB hard delete without filesystem deletion | LOW/MEDIUM | Orphaned files consume storage over time | **B** | Couple hard deletion to safe file removal and add orphan reconciliation |

## 7. Low / Informational Findings

| Finding | Current Status | Severity | Production Impact | Classification | Recommendation |
| ------- | -------------- | -------- | ----------------- | -------------- | -------------- |
| Full repository lint debt | Previously documented legacy failures | LOW | Does not directly demonstrate a runtime security defect | **F. INFRASTRUCTURE / TESTING GAP** | Reduce incrementally after blockers |
| Browser/viewport certification unavailable | Not executable from archive | INFO | Responsive behavior not independently pixel-certified | **F** | Add browser CI before release certification |
| Live HTTP/Stripe provider fixtures unavailable | Not executable from archive | INFO | End-to-end provider behavior remains externally unverified | **F** | Run staging HTTP + Stripe test-mode certification |
| Profile-view counter is a simple increment | Current design | LOW | Automated/bot traffic can inflate analytics | **C. ACCEPTABLE DOCUMENTED RISK** | Consider event-based analytics/rate controls later |
| Owner visibility editing remains legacy behavior | Explicitly preserved by Phase 9 decisions | LOW | Owner can hide own profile; not an ownership/admin bypass | **C. ACCEPTABLE DOCUMENTED RISK** | Keep until product explicitly changes publication contract |
| Equal-second Stripe event ordering | Current H6 implementation uses `event.created` | LOW | Rare ordering ambiguity for events sharing identical timestamp | **C. ACCEPTABLE DOCUMENTED RISK** | Consider stronger deterministic ordering if Stripe lifecycle requirements demand it |

## 8. Regression Findings

### C3 regression / variant — confirmed

The prior C3 remediation hardened `/broker/profile/personal`, but the alternate `/broker/profile/edit` route still passes the full `getCurrentUser()` result to a Client Component. This is a genuine regression/variant in the same sensitive-data boundary.

### H2 visibility behavior — not classified as a regression

The canonical broker allowlist still permits `isVisible`. This was compared against the Phase 9 product-decision documentation and is intentionally preserved legacy behavior rather than a new mass-assignment vulnerability.

### H5 client entitlement check — not a bypass

`components/sections/broker/CompanyProfile.tsx` retains a client-side `hasActiveSubscription` condition, but server mutation routes enforce the paid entitlement. The client condition does not establish authorization.

### Advertisement subsystem

The recent advertisement work has a coherent canonical renderer, bounded slot heights, format validation, media picker/upload path, lifecycle controls, anonymous public delivery, and public tracking. No new CRITICAL/HIGH advertisement vulnerability was identified in this source audit.

## 9. Security Boundary Verification

### Authentication

Credentials authentication is server-side and broker login requires `emailVerified`. Google users are created as USER by default. A rate-limit implementation exists but is not wired to the actual `LoginWithCredential`/Auth.js credentials path, leaving a medium abuse-control gap.

### Authorization

Admin APIs consistently resolve `getCurrentUser()` and require `role === ADMIN`. Broker APIs generally resolve ownership from the authenticated user rather than request-controlled ownership identifiers. `proxy.ts` provides route-level protection, but API handlers remain the authoritative boundary.

### Ownership

Broker ownership mutations use server-derived authenticated identity and conditional `userId: null` attachment during claims. The ownership partial-index operational requirement remains deployment-sensitive and must be reconciled after Prisma index synchronization.

### Sessions

C1 is fixed: no client identity merge. JWT refresh derives identity from the database. However, the `getCurrentUser()` return object is too broad for client boundaries and caused the C3 variant described above.

### PII

Public broker DTOs intentionally strip private contact data unless entitled. Lead `contactMessages` are excluded from the canonical current-user loader, but the broker profile edit C3 variant exposes User credential/reset/verification fields.

### Tokens

Claim tokens are hashed/digest-based and reset tokens are hashed before persistence. No raw reset-token logging was found. Claim recipient binding is enforced at both session email and completion.

### Claims

Recipient binding, expiry, revocation, used-state, reauthentication, conditional ownership attachment, generic errors, and rate limits are implemented. The latest claim audit documents the ownership-index operational requirement.

### Payments

Stripe signature verification, plan/price validation, event idempotency, and lifecycle mutation are implemented. Public subscription checkout is currently broken because its client request omits the required `plan` parameter.

### Subscriptions

FREE/FEATURED effective entitlement is centralized. H5 is enforced server-side. Stripe webhook ordering is guarded. The public pricing page/checkout contract is inconsistent and the Stripe price fallback is risky if production environment configuration is absent.

### Admin

Admin advertisement/media/broker/claim/subscription routes use server-side role checks. Some admin routes return 401 while others return 403 for unauthenticated/non-admin requests; this is a consistency issue rather than an authorization bypass.

## 10. Business Workflow Verification

### Broker signup

**Status: Source-verified with external execution unavailable.**

Email broker registration uses `createBrokerAccount()` inside a Prisma transaction, creates FREE entitlement, stores bcrypt password, and sends verification email after commit. Existing USER → Broker onboarding uses `createBrokerForExistingUser()` transactionally and preserves the existing account. Google onboarding wiring is documented as repaired in the latest claim/registration audit.

### Broker profile

**Status: Functional with one security-boundary defect.**

Profile mutation uses broker ownership and allowlists, but `/broker/profile/edit` passes an unsafe full User object to a Client Component.

### Public broker visibility

**Status: Source-verified.**

Public listing/detail/review reads require `isPublicBroker()` for non-admin users. Protected contact fields are entitlement-gated.

### Contact / lead generation

**Status: Source-verified.**

Anonymous public contact is allowed, broker is resolved server-side, public eligibility is enforced, lead is attached to resolved broker, and contact abuse has a distributed limiter. Email notification failures do not block lead persistence.

### Subscription

**Status: PARTIAL / BLOCKED by public checkout contract.**

Authenticated broker checkout/upgrade/cancel/portal paths are wired, but the public subscription page posts an incomplete payload. This blocks that revenue entry point.

### Stripe webhook

**Status: Source-verified; provider E2E unavailable.**

Signature verification, event ledger, ordering guard, idempotency, Redis lock, and fallback are present.

### Claim

**Status: Source-verified.**

Invitation recipient binding and completion transaction are correct in the audited paths.

### Advertisement

**Status: Source-verified; live execution unavailable.**

Admin authorization, lifecycle, public targeting, format validation, responsive bounded slots, carousel, tracking, and anonymous delivery are implemented.

### Admin management

**Status: Source-verified.**

Advertisement and media mutations are admin-gated. Broker admin mutation uses explicit field allowlists.

### Media

**Status: Source-verified.**

Upload is admin-only, limited to 10 MB, rejects SVG and AVIF, validates MIME/content through the image-processing path, rasterizes with Sharp, uses generated UUID filenames, and prevents path traversal through basename-based serving/storage. Hard-delete file cleanup remains incomplete.

### Reviews

**Status: READ path verified; WRITE path incomplete.**

Public published-review retrieval is implemented and anonymous. No review creation mutation route was found, while the public FAQ advertises customer review submission. This is a product completeness risk rather than a demonstrated security bypass.

### Password recovery

**Status: Source-verified with rate-limit gap.**

Reset token lifecycle is correct, but the public reset-request endpoint lacks the distributed limiter documented elsewhere in the security backlog.

## 11. Advertisement Verification

- **Admin CRUD:** implemented behind ADMIN checks; update input is schema-validated; publish/archive/restore/duplicate/bulk actions are server-side.
- **Media picker:** existing MediaSelector infrastructure resolves reusable MediaAsset records; admin upload is separately protected.
- **Upload:** 10 MB limit, image MIME validation, SVG/AVIF rejection, Sharp processing, UUID filenames, cleanup on DB-create failure.
- **Placement:** canonical placement enum/specification mapping in `placementSpecs.ts` and `ad-layout.ts`.
- **Format:** HORIZONTAL, RECTANGLE, SQUARE, VERTICAL, MOBILE contracts with aspect-ratio validation and placement compatibility checks.
- **Carousel:** multiple eligible ads use the shared carousel; single ads render without carousel controls.
- **Responsive layout:** explicit literal Tailwind height classes prevent dynamic-class omission; natural image size cannot control public slot height.
- **Tracking:** impression deduplication exists for a five-second IP/ad window; click/impression endpoints remain publicly reachable without rate limiting.
- **Anonymous delivery:** `/api/ads/public` is intentionally public and uses active/archive/schedule/device rules.
- **Lifecycle:** enable/disable, archive/restore, schedule, device targeting, and publishability checks exist.
- **Duplicate mounts:** recent advertisement verification documents a single canonical public renderer and placement mount strategy.
- **Remaining risk:** tracking abuse controls are not rate-limited; media hard deletion does not remove physical files.

## 12. Test Evidence

### This audit execution

- **Passed:** 0 runtime test cases executed from the uploaded archive.
- **Failed:** 0 runtime test cases executed.
- **Skipped:** 0 runtime test cases executed.
- **Unavailable:** repository test execution, because the archive contains no `node_modules` and no lockfile was included; there is also no configured `test` script in `package.json`.

### Source/test inventory

- 49 test files are present.
- 268 `test()`/`it()` declarations were counted statically.
- Numerous tests are intentionally gated with `{ skip: !database }`, `{ skip: !base }`, `{ skip: !adsBase }`, or similar runtime prerequisites.
- Prior remediation reports claim **117 passed / 0 failed / 0 skipped** for the C1–H7 remediation set. Those results are historical evidence only and were **not independently rerun from this archive**.

## 13. Build / Type / Lint

| Validation | Current audit result | Historical evidence |
| ---------- | -------------------- | ------------------- |
| Prisma validate | NOT EXECUTED | Prior reports: PASS |
| Prisma generate | NOT EXECUTED | Prior reports: PASS |
| TypeScript `npx tsc --noEmit` | NOT EXECUTED | Prior reports: PASS |
| `yarn lint` | NOT EXECUTED | Prior reports document legacy repository lint debt |
| Production build | NOT EXECUTED | Prior reports: PASS |
| Targeted C1–H7 tests | NOT EXECUTED | Prior reports: 117 pass / 0 fail / 0 skip |
| Browser automation | UNAVAILABLE | No browser runtime/fixture in archive |
| Live HTTP | UNAVAILABLE | No running server/database supplied |
| Stripe E2E | UNAVAILABLE | No provider fixture/credentials supplied |

## 14. Infrastructure Limitations

### Application defects

1. C3-equivalent sensitive User-object leak at `/broker/profile/edit`.
2. Public subscription checkout payload mismatch.

### Test infrastructure

The uploaded repository does not contain `node_modules` or a lockfile and has no `test` script. Runtime validation therefore cannot be independently executed from the supplied archive.

### Browser automation

Not available in the supplied project environment. Responsive/public UI claims remain source/test-evidence based rather than browser-certified.

### Live HTTP

Not available. No running server/DB was supplied for this audit.

### Stripe E2E

Not available. Signature/event ordering can be source-reviewed, but real Stripe provider delivery was not exercised.

### Staging/production availability

Not supplied. No deployment environment, production database, Redis instance, or Stripe test account was available to this audit.

## 15. Remaining Production Risks

1. **C3-equivalent secret serialization** — production blocker.
2. **Public subscription checkout failure** — production/revenue blocker.
3. Credential login rate limiting is not enforced at the actual credentials boundary.
4. Forgot-password and resend-verification endpoints lack distributed abuse controls.
5. Public ad tracking lacks distributed rate limiting.
6. Account email changes do not trigger re-verification.
7. Stripe price configuration has a hard-coded fallback if the expected environment variable is absent.
8. Customer review creation is not implemented despite product-facing review language.
9. Media hard-delete leaves physical files behind.
10. Full browser/live HTTP/Stripe certification remains unavailable.

## 16. Required Before Production

1. **Fix the C3-equivalent `/broker/profile/edit` client-boundary leak.** The server must pass only an explicit safe User DTO containing fields required by `EditPersonalProfile`.
2. **Fix the public subscription checkout contract.** The public subscription page must send the required plan identifier, or the server must derive the authoritative plan from the validated price ID. The server must remain authoritative for price/plan selection.
3. Add regression coverage proving the alternate profile-edit route cannot serialize password/reset/verification fields.
4. Add a regression test proving the public subscription page creates a valid checkout request.

## 17. Recommended After Production

1. Enforce credential-login rate limiting at the real Auth.js credential boundary.
2. Add distributed limits to forgot-password and resend-verification.
3. Add abuse controls to public advertisement impression/click endpoints.
4. Require email re-verification after authenticated account email changes.
5. Remove or fail-closed the hard-coded Stripe price fallback for production.
6. Finalize and implement the review write contract if customer reviews are a required product feature.
7. Add media-file cleanup/orphan reconciliation.
8. Add browser/viewport certification and live HTTP/Stripe staging suites.
9. Normalize admin 401/403 response semantics.
10. Remove or formally deprecate dead client/server API helpers.
11. Add/verify database indexes based on actual production query profiles.
12. Reduce repository lint debt.

## 18. Final GO/NO-GO Reasoning

**FINAL VERDICT: NO-GO.**

The C1–C2 and H1–H7 remediation work is largely verified from the actual implementation, and the advertisement subsystem is substantially hardened. However, the audit found a real C3-equivalent regression/variant that the previous remediation did not cover:

`getCurrentUser()` → full Prisma User object → `/broker/profile/edit` → Client Component.

Because the User model contains password/reset/verification secret fields, a TypeScript-only prop narrowing does not make this boundary safe. This is an unacceptable sensitive-data exposure and independently defeats the intent of the C3 remediation.

The public subscription page also fails to provide the `plan` parameter required by its checkout API, leaving a public revenue entry point non-functional. That is a business-critical production defect.

Therefore the application cannot receive a GO recommendation until those two blockers are remediated and regression-tested.

The remaining rate-limit, email re-verification, tracking, review, media-cleanup, configuration, lint, and browser/E2E items are not all production blockers individually. They should be addressed according to the classifications above rather than being inflated into additional CRITICAL/HIGH findings.

### Required blocker records

#### Blocker 1 — C3 equivalent

1. **Finding:** sensitive User fields reach a Client Component.
2. **Severity:** CRITICAL.
3. **Exact root cause:** `getCurrentUser()` spreads the full Prisma User record; `/broker/profile/edit/page.tsx` passes that object directly to `EditPersonalProfile`.
4. **Exact file/path:** `lib/currentUser.ts`; `app/broker/profile/edit/page.tsx`; `components/sections/broker/EditPersonalProfile.tsx`.
5. **Exact code path:** authenticated broker → `/broker/profile/edit` → `getCurrentUser()` → full User object → RSC serialization → Client Component.
6. **Affected workflow:** broker personal profile editing.
7. **Security/business impact:** credential/reset/verification secret exposure in browser payload.
8. **Canonical source of truth:** C3 security contract plus existing safe DTO pattern in `app/broker/profile/personal/page.tsx`.
9. **Smallest safe fix:** pass the explicit safe DTO already used by the hardened personal-profile route.
10. **Required regression test:** assert `/broker/profile/edit` does not pass/serialize password, reset tokens, or verification tokens.
11. **Blocks production:** **YES**.

#### Blocker 2 — Public subscription checkout contract

1. **Finding:** public subscription CTA sends incomplete checkout payload.
2. **Severity:** HIGH / revenue blocker.
3. **Exact root cause:** `app/(public)/subscription/page.tsx` sends `{ priceId }`; `app/api/subscription/checkout/route.ts` requires `{ priceId, plan }` and returns 400 when plan is absent.
4. **Exact file/path:** `app/(public)/subscription/page.tsx`; `app/api/subscription/checkout/route.ts`.
5. **Exact code path:** public subscription page → `handleSelect()` → POST `/api/subscription/checkout` → missing `plan` → HTTP 400.
6. **Affected workflow:** public paid subscription checkout.
7. **Security/business impact:** users cannot enter the paid purchase flow through this public pricing surface.
8. **Canonical source of truth:** server `validatePlanPrice()` / `subscriptionPlans` in `lib/stripe.ts`.
9. **Smallest safe fix:** include the selected plan in the request, or preferably derive/validate the plan server-side from the authoritative price configuration while retaining server-side price validation.
10. **Required regression test:** public pricing CTA → checkout API receives a valid plan/price pair and produces a checkout session for an authenticated broker.
11. **Blocks production:** **YES** for the current intended public revenue flow.

## Final Audit Change Declaration

- **production files changed:** NO
- **Prisma/schema changed:** NO
- **tests added/changed:** NO
- **documentation changed:** YES — this audit report only
- **final verdict:** **NO-GO**
