# Admin Brokers — Bulk Import, Multi-Invite & Operation Status Audit

## What was audited

Reviewed `app/admin/brokers/page.tsx`, `AdminBulkInvitations.tsx`, `import/page.tsx`,
`app/api/admin/brokers/{route,import,bulk-claim-invitations}`, `[id]/claim-invitations`,
`claim-invitations/[id]/{resend,revoke}`, `lib/claim-invitation.ts`, `lib/claim-flow.ts`,
`lib/claim-completion.ts`, `lib/rateLimit.ts`, and the Prisma `BrokerClaim` /
`BrokerClaimInvitation` / `BrokerClaimEvent` models.

## Findings

- The broker page had **no summary metrics, no selection column, no invitation status badges,
  no server-side pagination**, and passed the **entire** broker list to the client.
- `AdminBulkInvitations` was a large inline checkbox list with raw per-row results and no
  review/confirm/retry flow.
- The bulk API returned only `{ results: [{ brokerId, status, code }] }` with internal codes and
  **no idempotency** (a double-click re-issued a new invitation, superseding the previous one).

## Changes

### Server API — `app/api/admin/brokers/bulk-claim-invitations/route.ts`
- **Idempotency**: an active invitation to the same recipient returns `SKIPPED`/`ALREADY_INVITED`
  instead of issuing a duplicate.
- Returns a `summary` (`total/sent/failed/skipped`) and per-row `results` with `brokerName`,
  `recipientEmail`, `status`, `invitationId`, `errorCode`, `errorMessage` (human-readable).
- Keeps the 1–50 item limit, same-origin + admin authorization, and per-recipient rate limits.
- Batch-loads brokers + active invitations once (no N+1).

### `lib/claim-errors.ts` (new)
- Maps internal codes (`INVALID_EMAIL`, `RATE_LIMITED`, `ALREADY_INVITED`, `EMAIL_DELIVERY_FAILED`,
  etc.) to admin-friendly messages. Raw codes/stack traces are never surfaced.

### `app/admin/brokers/page.tsx`
- Header: "Broker Management" + Create/Import/Export actions.
- Six summary metric cards (Total/Owned/Unowned/Invitations Pending/Accepted/Failures) via
  server-side `count` queries.
- Filters: search, ownership, invitation status, verification, broker status, creation source,
  state, city (URL `GET` params → shareable/bookmarkable).
- **Server-side pagination** (`page`/`pageSize`, filter-preserving prev/next).

### `app/admin/brokers/AdminBulkInvitations.tsx` (rewritten)
- Full operational table (Select, Broker, Ownership, Verification, Subscription, Visibility,
  Invitation, Created, Actions) with compact status badges.
- Checkbox selection limited to eligible brokers (unowned, `ADMIN_CREATED`, not suspended, not
  claimed) with select-all-visible.
- Sticky action bar ("N brokers selected · Send Invitations · Clear").
- Bulk dialog: review (per-row recipient email with inline validation) → confirm ("Send N
  invitations") → results (sent/skipped/failed summary + row table) → retry-failed (resubmits
  only `FAILED` items).

### `app/admin/brokers/[id]/page.tsx`
- Added a Claim Timeline section driven by `BrokerClaimEvent` (event type, time, actor).

## Deliberately NOT changed

- No new `BrokerInvitationBatch` model — the synchronous endpoint already returns full per-item
  results and a summary; a persistent batch/job model was judged not "genuinely needed".
- No Prisma schema changes; `Broker.userId` uniqueness, location, and claim security are intact.
- No duplicate claim/invitation architecture; `issueBrokerClaimInvitation()` remains the single
  issuance path.
- Import page left largely as-is (already has upload → preview → validate → confirm).

## Tests

`tests/admin-bulk-invitations.test.ts` (new) — error-code mapping, API auth/limit, idempotency,
summary shape, no-raw-token, page metrics/filters/pagination, UI selection/review/confirm/retry.
Focused run: **37 tests, 35 pass, 0 fail, 2 skipped** (DB-only).

## Validation

- `npx tsc --noEmit` — exit 0
- `npx next build` — success
- `npx eslint` (changed files) — clean
- `git diff --check` (changed files) — clean

## Remaining Issues

1. Import result UI still renders a summary string + row error list rather than a dedicated
   "Import Complete" panel with a downloadable error report.
2. Invitation "FAILED" (email delivery) is surfaced only in the transient bulk result panel;
   persisting email-send state on the invitation would require a schema change.
3. No persistent batch model / navigable batch ID (bulk send is synchronous).
